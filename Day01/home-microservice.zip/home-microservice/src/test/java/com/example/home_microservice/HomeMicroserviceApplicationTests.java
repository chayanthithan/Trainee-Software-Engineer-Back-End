package com.example.home_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
