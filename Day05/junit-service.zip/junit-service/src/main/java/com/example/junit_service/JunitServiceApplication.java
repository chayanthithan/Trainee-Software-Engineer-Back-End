package com.example.junit_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunitServiceApplication.class, args);
	}

}
