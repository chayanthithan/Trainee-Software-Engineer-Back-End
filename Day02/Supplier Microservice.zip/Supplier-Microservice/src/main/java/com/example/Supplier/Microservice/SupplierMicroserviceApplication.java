package com.example.Supplier.Microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplierMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplierMicroserviceApplication.class, args);
	}

}
