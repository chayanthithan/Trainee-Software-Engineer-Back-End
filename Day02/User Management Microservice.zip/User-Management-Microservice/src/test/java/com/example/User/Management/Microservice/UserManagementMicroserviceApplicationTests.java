package com.example.User.Management.Microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
