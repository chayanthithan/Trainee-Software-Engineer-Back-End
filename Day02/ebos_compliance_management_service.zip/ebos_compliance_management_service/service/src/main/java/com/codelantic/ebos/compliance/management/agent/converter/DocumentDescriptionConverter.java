package com.codelantic.ebos.compliance.management.agent.converter;


import com.codelantic.ebos.compliance.management.api.dto.ImageResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DocumentDescriptionConverter {
    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;
    @Value("${sftp.base.url}")
    private String imagePath;

    public ImageResponseDto convertToDto(String message, String imageName, int i) {
        ImageResponseDto imageResponseDto = new ImageResponseDto();
        imageResponseDto.setFilePath(message);
        imageResponseDto.setDownloadPath(sftpUploadPath + message);
        imageResponseDto.setFileName(imageName);
        imageResponseDto.setImageViewPath(imagePath + message);
        log.info("viewwww...{}", imagePath + message);
        imageResponseDto.setImageNumber(i);
        return imageResponseDto;
    }
}
