package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.FileUploadAgent;
import com.codelantic.ebos.compliance.management.api.dto.DeleteImageDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDetailDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.UploadDocumentsDto;
import com.jcraft.jsch.JSchException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RequestMapping("api/v1/file-upload-controller")
@RestController
@RequiredArgsConstructor
@Validated
public class FileUploadController {
    private final FileUploadAgent fileUploadAgent;

    @PostMapping("/upload-documents")
    public ImageDetailDto uploadDocuments(@RequestPart @NotEmpty(message = "You should add at least one file") List<MultipartFile> files,
                                          @RequestParam(required = false) @NotBlank(message = "Sub category is required") String subCategoryId,
                                          @RequestParam(required = false) String readingId,
                                          @RequestParam(required = false) Integer imageNumber,
                                          @RequestParam(value = "audioOrImage") @NotNull(message = "Audio Or Image Required")
                                          @Pattern(regexp = "AUDIO|IMAGE", message = "Value must be either 'AUDIO' or 'IMAGE'")
                                          String audioOrImage) throws JSchException {

        UploadDocumentsDto uploadDocumentsDto = UploadDocumentsDto.builder()
                .subCategoryId(subCategoryId)
                .imageNumber(imageNumber)
                .readingId(readingId)
                .build();

        return fileUploadAgent.uploadDocuments(uploadDocumentsDto, files,audioOrImage);
    }

    @DeleteMapping("/delete-image")
    public ResponseDto deleteImage(@RequestPart @Valid List<DeleteImageDto> deleteImageDtos,
                                   @RequestParam(value = "saveOrUpdate") @NotNull(message = "Save Or Update Required")
                                   @Pattern(regexp = "SAVE|UPDATE", message = "Value must be either 'SAVE' or 'UPDATE'")
                                   String saveOrUpdate) {
        return fileUploadAgent.deleteImage(deleteImageDtos, saveOrUpdate);
    }
    @PostMapping("/download-document")
    public ResponseEntity<byte[]> downloadDocument(@RequestParam(required = false ,value = "documentUrl" ) List<String> documentUrl) throws IOException {
        return fileUploadAgent.downloadDocument(documentUrl);
    }
    @PostMapping("/download-single-document")
    public ResponseEntity<byte[]> downloadSingleDocument(@RequestParam(required = false ,value = "documentUrl" ) String documentUrl) throws IOException, JSchException {
        return fileUploadAgent.downloadSingleDocument(documentUrl);
    }

}
