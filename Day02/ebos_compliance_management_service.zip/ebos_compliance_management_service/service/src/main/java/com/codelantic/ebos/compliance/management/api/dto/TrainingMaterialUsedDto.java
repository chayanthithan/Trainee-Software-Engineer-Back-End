package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TrainingMaterialUsedDto {

    private String id;
    @NotBlank(message = "Training Material Used Name is required")
    private String trainingMaterialUsedName;
    @NotBlank(message = "Business Id is required")
    private String businessId;
}
