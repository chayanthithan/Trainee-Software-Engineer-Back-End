package com.codelantic.ebos.compliance.management.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.codelantic.file.utilities.service.FileUploadService;
import com.codelantic.file.utilities.service.FileUploadServiceFactory;
import com.codelantic.file.utilities.service.FileUploadServiceInterface;
import com.codelantic.file.utilities.service.MainFileUploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;


@Configuration
@PropertySource("classpath:application.properties")
@RequiredArgsConstructor
public class CodelanticFileUtilityModuleConfig {

    private final Environment env;

    @Bean
    public MainFileUploadService s3FileUploadService(AmazonS3 amazonS3) {
        return new MainFileUploadService(amazonS3);
    }

    @Bean
    public FileUploadServiceInterface fileUploadServiceInterface(MainFileUploadService s3FileUploadService) {
        return s3FileUploadService;
    }

    @Bean
    public FileUploadServiceFactory fileUploadServiceFactory(FileUploadServiceInterface fileUploadServiceInterface) {
        return new FileUploadServiceFactory(fileUploadServiceInterface);
    }

    @Bean
    public FileUploadService fileUploadService(FileUploadServiceFactory fileUploadServiceFactory) {
        return new FileUploadService();
    }

    @Bean
    public AmazonS3 amazonS3ClientOne() {
        String accessKeyOne = env.getProperty("cloud.aws.credentials.access.key.upload");
        String secretKeyOne = env.getProperty("cloud.aws.credentials.secret.key.upload");
        String regionOne = env.getProperty("cloud.aws.region.upload");

        return AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKeyOne, secretKeyOne)))
                .withRegion(regionOne)
                .build();
    }
}
