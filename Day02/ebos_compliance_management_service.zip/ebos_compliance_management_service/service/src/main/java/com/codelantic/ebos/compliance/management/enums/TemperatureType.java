package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

public enum TemperatureType {
    COOL("Cool"),
    FROZEN("Frozen"),
    AMBIENT("Ambient"),
    WARM("Warm"),
    HOT("Hot");

    private final String mappedValue;

    TemperatureType(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static TemperatureType fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        return Arrays.stream(TemperatureType.values())
                .filter(type -> type.mappedValue.equalsIgnoreCase(mappedValue))
                .findFirst()
                .orElseThrow(() -> new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST));
    }

    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        return Arrays.stream(TemperatureType.values())
                .map(TemperatureType::getMappedValue)
                .toList();
    }


}
