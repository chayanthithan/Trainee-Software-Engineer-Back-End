package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReadingImagesDto {
    private String id;
    private String imageName;
    private String imagePath;
    private String viewImagePath;
    private String downloadImagePath;
    private String questionsReadingId;
    private String checklistReadingId;
    private String temperatureReadingId;
}
