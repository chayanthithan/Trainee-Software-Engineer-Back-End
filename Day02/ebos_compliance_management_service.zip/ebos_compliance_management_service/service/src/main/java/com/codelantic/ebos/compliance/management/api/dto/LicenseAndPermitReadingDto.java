package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class LicenseAndPermitReadingDto {
    private String id;
    private String licenseOrPermitName;
    private String licenseOrPermitNumber;
    private String typeOfLicenseOrPermit;
    private String issuingAuthority;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private LocalDate renewalDate;
    private String businessName;
    private String businessAddress;
    private String holdersName;
    private String contactPhoneNumber;
    private String contactEmail;
    private String conditionsOrRestrictions;
    private LocalDate renewalApplicationDedLine;
    private LocalDate reminderDate;
    private LocalTime reminderTime;
    private String comments;
    private String subCategoryFormConfigurationsId;
    private Set<ReminderToDto> reminderTos;
    private Set<DocumentsDto> documents;
    private String complianceSubCategoryId;
    private String createdBy;
}
