package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class  TemperatureOverviewDto {
    private int rowNo;
    private String id;
    private String subCategoryName;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String complianceStatus;
    private List<TemperatureTypeOverviewDto> temperatureTypeOverviewDtos;
    private String comments;
    private List<String> notify;
    private String temperatureTypeRangeConfigurationsId;

    public TemperatureOverviewDto(String id, LocalDate date, LocalTime time, String employeeName, ComplianceStatus complianceStatus, String comments, String temperatureTypeRangeConfigurationsId) {
        this.id=id;
        this.date = date;
        this.time = time;
        this.employeeName = employeeName;
        this.complianceStatus=complianceStatus!=null?complianceStatus.getMappedValue():null;
        this.comments = comments;
        this.temperatureTypeRangeConfigurationsId = temperatureTypeRangeConfigurationsId;
    }
    public TemperatureOverviewDto(){

    }

}
