package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TemperatureReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.TempreatureReadingGetDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.TemperatureReading;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRangeConfigurations;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeConfigurationsRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TemperatureReadingConverter {

    private final ReadingImagesConverter readingImagesConverter;
    private final NotifyToConverter notifyToConverter;
    private final TemperatureTypeRangeConfigurationsRepository temperatureTypeRangeConfigurationsRepository;
    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;

    public TemperatureReading convert(TemperatureReadingDto temperatureReadingDto) {
        return TemperatureReading.builder()
                .id(temperatureReadingDto.getId())
                .complianceSubCategoryId(temperatureReadingDto.getComplianceSubCategoryId())
                .temperatureTypeRangeConfigurationsId(temperatureReadingDto.getTemperatureTypeRangeConfigurationsId())
                .quantity(temperatureReadingDto.getQuantity())
                .actualReading(temperatureReadingDto.getActualReading())
                .comments(temperatureReadingDto.getComments())
                .complianceReadingId(temperatureReadingDto.getComplianceReadingId())
                .readingImages(temperatureReadingDto.getReadingImages()!=null? temperatureReadingDto.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(temperatureReadingDto.getNotifyTo()!=null? temperatureReadingDto.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .build();

    }

    public TemperatureReadingDto convert(TemperatureReading temperatureReading) {
        return TemperatureReadingDto.builder()
                .id(temperatureReading.getId())
                .complianceSubCategoryId(temperatureReading.getComplianceSubCategoryId())
                .temperatureTypeRangeConfigurationsId(temperatureReading.getTemperatureTypeRangeConfigurationsId())
                .quantity(temperatureReading.getQuantity())
                .actualReading(temperatureReading.getActualReading())
                .comments(temperatureReading.getComments())
                .complianceReadingId(temperatureReading.getComplianceReadingId())
                .readingImages(temperatureReading.getReadingImages()!=null? temperatureReading.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(temperatureReading.getNotifyTo()!=null? temperatureReading.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .build();

    }
    public TempreatureReadingGetDto convertTempreature(TemperatureReading temperatureReading) {
        TemperatureTypeRangeConfigurations temperatureTypeRangeConfigurations =
                temperatureTypeRangeConfigurationsRepository
                        .findById(temperatureReading.getTemperatureTypeRangeConfigurationsId())
                        .orElseThrow(() ->
                                new ServiceException(
                                        "TemperatureTypeRangeConfigurations Not Found",
                                        ApplicationConstants.BAD_REQUEST,
                                        HttpStatus.BAD_REQUEST
                                )
                        );
        TemperatureTypeRange temperatureTypeRange =  temperatureTypeRangeRepository.findById(temperatureTypeRangeConfigurations.getTemperatureTypeRangeId()).orElseThrow(() ->
                new ServiceException(
                        "temperatureTypeRange Not Found",
                        ApplicationConstants.BAD_REQUEST,
                        HttpStatus.BAD_REQUEST
                ));



        return TempreatureReadingGetDto.builder()
                .id(temperatureReading.getId())
                .complianceSubCategoryId(temperatureReading.getComplianceSubCategoryId())
                .temperatureTypeRangeConfigurationsId(temperatureReading.getTemperatureTypeRangeConfigurationsId())
                .item(temperatureTypeRangeConfigurations.getItems())
                .tempreatureType(temperatureTypeRange.getTemperatureType().getMappedValue())
                .startTempreature(temperatureTypeRange.getStartTemperature())
                .endTempreature(temperatureTypeRange.getEndTemperature())
                .quantity(temperatureReading.getQuantity())
                .actualReading(temperatureReading.getActualReading())
                .complianceReadingId(temperatureReading.getComplianceReadingId())
                .readingImages(temperatureReading.getReadingImages()!=null? temperatureReading.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(temperatureReading.getNotifyTo()!=null? temperatureReading.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .sequence(temperatureTypeRangeConfigurations.getSequence())
                .build();

    }

}
