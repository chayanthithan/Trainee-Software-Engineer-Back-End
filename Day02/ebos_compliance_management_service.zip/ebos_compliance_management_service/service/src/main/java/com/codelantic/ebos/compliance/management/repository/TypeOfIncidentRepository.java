package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TypeOfIncidentDto;
import com.codelantic.ebos.compliance.management.entity.TypeOfIncident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TypeOfIncidentRepository extends JpaRepository<TypeOfIncident,String> {

    Boolean existsByIncidentTypeAndBusinessId(String incidentType,String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TypeOfIncidentDto(t.id,t.incidentType) " +
            "FROM TypeOfIncident t " +
            "WHERE t.businessId IS NULL OR t.businessId = :businessId")
    List<TypeOfIncidentDto> getAllTypeOfIncidents(String businessId);
}
