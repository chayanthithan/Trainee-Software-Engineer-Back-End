package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.DeliveryOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureOverviewSearchDto;
import com.codelantic.ebos.compliance.management.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DeliveryAgent {
    private final DeliveryService deliveryService;

    public PaginatedResponseDto<DeliveryOverviewDto> getAllDeliveryOverview(TemperatureOverviewSearchDto deliverySearchDto) {
        Page<DeliveryOverviewDto> deliveryOverviewDtos = deliveryService.getAllDeliveryOverview(deliverySearchDto);
        PaginatedResponseDto<DeliveryOverviewDto> deliveryOverviewDtoPaginated = new PaginatedResponseDto<>();
        deliveryOverviewDtoPaginated.setData(deliveryOverviewDtos.getContent());
        deliveryOverviewDtoPaginated.setCurrentPage(deliverySearchDto.getPage());
        deliveryOverviewDtoPaginated.setTotalPages(deliveryOverviewDtos.getTotalPages());
        deliveryOverviewDtoPaginated.setTotalItems(deliveryOverviewDtos.getTotalElements());
        return deliveryOverviewDtoPaginated;
    }
}
