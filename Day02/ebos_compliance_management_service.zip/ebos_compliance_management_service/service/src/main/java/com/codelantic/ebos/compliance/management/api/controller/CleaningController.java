package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.CleaningAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDate;



@RestController
@RequestMapping("api/v1/cleaning")
@RequiredArgsConstructor
@Validated
public class CleaningController {
private final CleaningAgent cleaningAgent;

    @GetMapping("/get-all-cleaning")
    public PaginatedResponseDto<CleaningOverViewDisplayDto> overViewForCleaning(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                @RequestParam(value = "subCategoryId") String subCategoryId){
        CleaningOverviewSearchDto cleaningOverviewSearchDto = CleaningOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .businessId(businessId)
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName)
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus) : null)
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .build();

        return cleaningAgent.getAllOverViewForCleaning(cleaningOverviewSearchDto);

    }

    @GetMapping("/get-overview-cleaning-by-id")
    public CleaningOverViewDisplayDto getOverviewCleaningById(@RequestParam(value = "id") String complianceReadingId){
              return cleaningAgent.getOverviewCleaningById(complianceReadingId);

    }
}
