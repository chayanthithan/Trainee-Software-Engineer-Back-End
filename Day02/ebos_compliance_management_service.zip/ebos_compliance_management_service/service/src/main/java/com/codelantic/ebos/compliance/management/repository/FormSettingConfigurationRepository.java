package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.FormSettingConfigurationDto;
import com.codelantic.ebos.compliance.management.entity.FormSettingConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface FormSettingConfigurationRepository extends JpaRepository<FormSettingConfiguration, String> {
    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.FormSettingConfigurationDto(fs.fieldCategory,fs.id, fs.fieldName, fs.fieldType) " +
            "FROM FormSettingConfiguration fs JOIN SubCategoryFormConfigurations scf ON fs.id = scf.formSettingsConfigurationId " +
            "WHERE scf.complianceSubCategoryId = :complianceSubCategoryId")
    List<FormSettingConfigurationDto> getAllConfiguredField(String complianceSubCategoryId);

    @Query("SELECT new com.codelantic.ebos.compliance.management.api.dto.FormSetting" +
            "ConfigurationDto(fsc.fieldCategory," +
            "fsc.id,fsc.fieldName,fsc.fieldType ) " +
            "FROM FormSettingConfiguration fsc " +
            "WHERE fsc.complianceId = :complianceId ")
    List<FormSettingConfigurationDto> findFields(Integer complianceId);

    @Query("SELECT f.id FROM FormSettingConfiguration f WHERE f.id IN :ids")
    Set<String> findExistingIds(@Param("ids") Set<String> ids);


    @Query("SELECT DISTINCT NEW com.codelantic.ebos.compliance.management.api.dto.FormSettingConfigurationDto(fs.fieldCategory, fs.id, fs.fieldName, fs.fieldType, FALSE) " +
            "FROM FormSettingConfiguration fs " +
            "LEFT JOIN SubCategoryFormConfigurations scf ON fs.id = scf.formSettingsConfigurationId " +
            "WHERE scf.complianceSubCategoryId = :complianceSubCategoryId OR fs.complianceId = :id")
    List<FormSettingConfigurationDto> findAllByCompliance(@Param("complianceSubCategoryId") String complianceSubCategoryId, @Param("id") String id);





}
