package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ComplaintTypeSaveDto;
import com.codelantic.ebos.compliance.management.entity.CompliantType;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ComplaintConverter {
    private final UserManagementClient userManagementClient;
    private final Validations validations;

    public CompliantType convertToEntity(ComplaintTypeSaveDto complaintTypeSaveDto) {
        userManagementClient.checkBusinessId(complaintTypeSaveDto.getBusinessId());
        validations.checkComplaintType(complaintTypeSaveDto.getTypeOfCompliant(), complaintTypeSaveDto.getBusinessId());
        CompliantType compliantType = new CompliantType();
        compliantType.setBusinessId(complaintTypeSaveDto.getBusinessId());
        compliantType.setTypeOfCompliant(complaintTypeSaveDto.getTypeOfCompliant());
        return compliantType;
    }
}
