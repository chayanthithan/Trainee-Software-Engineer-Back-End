package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder

public class UploadDocumentsDto {
    private String subCategoryId;
    private String readingId;
    private Integer imageNumber;


}
