package com.codelantic.ebos.compliance.management.api.dto;

public class TotalCheckedCountDto {
    private Long totalCount;
    private Long checkedCount;

    public TotalCheckedCountDto(Long totalCount, Long checkedCount) {
        this.totalCount = totalCount;
        this.checkedCount = checkedCount;
    }

    public Long getTotalCount() {
        return totalCount;
    }

    public Long getCheckedCount() {
        return checkedCount;
    }
}
