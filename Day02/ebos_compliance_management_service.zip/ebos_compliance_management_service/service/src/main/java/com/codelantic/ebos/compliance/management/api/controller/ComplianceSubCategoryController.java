package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceSubCategoryAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/compliance-sub-category")
@RequiredArgsConstructor
@Validated
public class ComplianceSubCategoryController {
    private final ComplianceSubCategoryAgent complianceSubCategoryAgent;

    @PostMapping
    public ResponseDto saveComplianceSubCategory(@RequestBody @Valid ComplianceSubCategorySaveDto complianceSubCategorySaveDto) {
        return complianceSubCategoryAgent.saveComplianceSubCategory(complianceSubCategorySaveDto);
    }

    @GetMapping("/get-sub-categories")
    public List<SubCategoryDto> getSubCategories(@RequestParam(value = "complianceId", required = false) @NotNull(message = "complianceId is required") Integer complianceId,
                                                 @RequestParam(value = "businessId", required = false) @NotEmpty(message = "businessId is required") String businessId
    ) {
        return complianceSubCategoryAgent.getSubCategories(complianceId, businessId);
    }

    @GetMapping("/get-by-id/{subCategoryId}")
    public ComplianceSubCategoryResponseDto getById(@PathVariable("subCategoryId") String subCategoryId) {
        return complianceSubCategoryAgent.getById(subCategoryId);
    }

    @PutMapping
    public ResponseDto updateComplianceSubCategory(@RequestBody @Valid ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto) {
        return complianceSubCategoryAgent.updateComplianceSubCategory(complianceSubCategoryUpdateDto);
    }

    @GetMapping("/get-all-by-compliance-type-id")
    public List<FormSettingConfigurationDto> getAllByComplianceTypeId(@RequestParam("complianceId") Integer complianceId){
        return complianceSubCategoryAgent.getAllByComplianceTypeId(complianceId);
    }

    @PutMapping("/update-status")
    public ResponseDto updateSubCategoryStatus(@RequestParam(value = "subCategoryId", required = false) @NotEmpty(message = "subCategoryId is required") String subCategoryId, @RequestParam(value = "status", required = false) @NotNull(message = "status is required") Boolean status) {
        return complianceSubCategoryAgent.updateSubCategoryStatus(subCategoryId, status);
    }

    @GetMapping("/get-check-list-and-question")
    public GetCheckListQuestionDto getCheckListAndQuestion(@RequestParam(value = "complianceSubCategoryId",required = false) @NotBlank(message = "Compliance sub category id is required") String complianceSubCategoryId ){
        return complianceSubCategoryAgent.getCheckListAndQuestion(complianceSubCategoryId);
    }


}
