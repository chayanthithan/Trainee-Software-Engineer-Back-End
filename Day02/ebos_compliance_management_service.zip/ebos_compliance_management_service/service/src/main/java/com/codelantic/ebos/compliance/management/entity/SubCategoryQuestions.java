package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.util.Set;


@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubCategoryQuestions {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String complianceSubCategoryId;
    private String heading;
    private String question;
    private Boolean isCommentAvailable;
    private Boolean isDocumentAvailable;
    private Boolean status;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "subCategoryQuestionsId")
    private Set<SubCategoryQuestionsReadings> subCategoryQuestionsReadings;


}
