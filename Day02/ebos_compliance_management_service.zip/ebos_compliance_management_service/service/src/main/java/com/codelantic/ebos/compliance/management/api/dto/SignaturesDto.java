package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SignaturesDto {
    private String id;
    private String imageName;
    private String imagePath;
    private String viewImagePath;
    private String downloadImagePath;
    private String signatureOf;
    private String trainingReadingId;
}
