package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.LicenseAndPermitReadingAgent;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.LicensePermitOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;


@RestController
@RequestMapping("api/v1/license-and-permit")
@RequiredArgsConstructor
@Validated
public class LicenseAndPermitsController {
    private final LicenseAndPermitReadingAgent licenseAndPermitReadingAgent;

    @GetMapping("/get-all-license-and-permit-reading")
    public PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> overViewForLicenseAndPermitReading(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                                       @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                                       @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                                       @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                                       @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                                       @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                                       @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                                       @RequestParam(value = "subCategoryId",required = true) String subCategoryId){
        LicensePermitOverviewSearchDto licensePermitOverviewSearchDto = LicensePermitOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .businessId(businessId)
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName)
                .subCategoryId(subCategoryId)
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus) : null)
                .businessId(businessId)
                .build();

        return licenseAndPermitReadingAgent.getAllLicensePermits(licensePermitOverviewSearchDto);

    }
    @GetMapping("/get-overview-by-id")
    public LicenseAndPermitReadingOverViewDto getLicenseOverviewById(@RequestParam(value = "id")String id,@RequestParam(value = "rowNo") String rowNo)
    {
        return licenseAndPermitReadingAgent.getLicenseOverviewById(id,rowNo);
    }
}
