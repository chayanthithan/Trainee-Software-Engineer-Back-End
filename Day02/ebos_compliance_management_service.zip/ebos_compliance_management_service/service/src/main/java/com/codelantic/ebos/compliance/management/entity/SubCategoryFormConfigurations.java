package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubCategoryFormConfigurations {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String formSettingsConfigurationId;
    private String complianceSubCategoryId;

    public SubCategoryFormConfigurations(String formSettingsConfigurationId) {
        this.formSettingsConfigurationId = formSettingsConfigurationId;
    }
}
