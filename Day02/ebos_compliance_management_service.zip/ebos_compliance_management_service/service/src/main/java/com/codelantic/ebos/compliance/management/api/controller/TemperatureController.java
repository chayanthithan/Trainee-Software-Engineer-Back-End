package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.TemperatureAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/temperature")
@RequiredArgsConstructor
@Validated
public class TemperatureController {

    private final TemperatureAgent temperatureAgent;

    @PostMapping("/temperature-type-range")
    public TemperatureTypeRangeResponseDto saveTemperatureTypeRange(@RequestBody @Valid List<TemperatureTypeRangeDto> temperatureTypeRangeDto){
        return temperatureAgent.saveTemperatureTypeRange(temperatureTypeRangeDto);
    }

    @PutMapping("/temperature-type-range")
    public TemperatureTypeRangeResponseDto updateTemperatureTypeRange(@RequestBody @Valid TemperatureTypeRangeUpdateDto temperatureTypeRangeUpdateDto){
        return temperatureAgent.updateTemperatureTypeRange(temperatureTypeRangeUpdateDto);
    }

    @GetMapping("/temperature-type-range")
    public List<TemperatureTypeRangeDto> getAllTemperatureRangeDto(@RequestParam(value = "complianceSubCategoryId",required = false) @NotBlank(message = "Compliance Sub Category Id is required") String complianceSubCategoryId){
        return temperatureAgent.getAllTemperatureRangeDto(complianceSubCategoryId);
    }

    @GetMapping("/temperature-reading-configurations")
    public TemperatureReadingConfigurationsDto getAllTemperatureReadingConfigurations(@RequestParam(value = "subCategoryId",required = false) @NotBlank(message = "subCategoryId is required") String subCategoryId){
        return temperatureAgent.getAllTemperatureReadingConfigurations(subCategoryId);
    }

    @GetMapping("/temperature-overview")
    public PaginatedResponseDto<TemperatureOverviewDto> getAllTemperatureOverview(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business Id is required") String businessId, @RequestParam(value = "subCategoryId",required = false) @NotBlank(message = "Sub Category Id is required") String subCategoryId,
                                                                                  @RequestParam(value = "fromDate",required = false) @NotNull(message = "From date is required") LocalDate fromDate,
                                                                                  @RequestParam(value = "toDate",required = false) @NotNull(message = "To date is required") LocalDate toDate,
                                                                                  @RequestParam(value = "page") @Positive(message = "Page should be positive") int page, @RequestParam(value = "size") @Positive(message = "Size should be positive")int size,
                                                                                  @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                  @RequestParam(value = "employeeIds",required = false) List<String> employeeIds, @RequestParam(value = "notifyTos",required = false) List<String> notifyTos){

        TemperatureOverviewSearchDto temperatureOverviewSearchDto = TemperatureOverviewSearchDto.builder()
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .fromDate(fromDate)
                .toDate(toDate)
                .page(page)
                .size(size)
                .complianceStatus(complianceStatus)
                .employeeIds(employeeIds)
                .notifyTos(notifyTos)
                .build();
        return temperatureAgent.getAllTemperatureOverview(temperatureOverviewSearchDto);
    }


    @GetMapping("/temperature-overview-row-download")
    public TemperatureOverviewDto getAllTemperatureOverviewRow(@RequestParam(value = "id") String id){
        return temperatureAgent.getAllTemperatureOverviewRow(id);
    }

    @GetMapping("temperature-overview-row-download-by-id")
    public TemperatureOverviewDto getAllTemperatureOverviewRowById(@RequestParam(value = "id") String id) {
        return temperatureAgent.getAllTemperatureOverviewRowById(id);
    }



}
