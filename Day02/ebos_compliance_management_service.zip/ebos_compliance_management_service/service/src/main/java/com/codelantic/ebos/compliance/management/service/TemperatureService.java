package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.TemperatureConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.*;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserFisrtNameLastNameDto;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
@Slf4j
public class TemperatureService {

    private final UserManagementClient userManagementClient;

    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;

    private final TemperatureConfigurationsRepository temperatureConfigurationsRepository;

    private final Validations validations;

    private final TemperatureReadingRepository temperatureReadingRepository;

    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final ComplianceReadingRepository complianceReadingRepository;
    private final TemperatureConverter temperatureConverter;

    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;

    public List<TemperatureTypeRange> saveTemperatureTypeRange(List<TemperatureTypeRange> temperatureTypeRanges) {

        return temperatureTypeRangeRepository.saveAll(temperatureTypeRanges);
    }

    public TemperatureTypeRangeResponseDto updateTemperatureTypeRange(TemperatureTypeRangeUpdateDto temperatureTypeRangeUpdateDto) {
        List<TemperatureTypeRangeDto> saved = temperatureTypeRangeRepository.getAllTemperatureRangeDto(temperatureTypeRangeUpdateDto.getComplianceSubcategoryId());

        if (saved.isEmpty()) {
            ComplianceSubCategory complianceSubCategory = complianceSubCategoryRepository.findById(temperatureTypeRangeUpdateDto.getComplianceSubcategoryId()).orElseThrow(
                    () -> new ServiceException("Sub category not found", "Bad request", HttpStatus.BAD_REQUEST));
            log.info("complianceSubCategory {}", complianceSubCategory);
        }

        if(!temperatureTypeRangeUpdateDto.getTemperatureTypeRangeDtoList().isEmpty()) {
            List<TemperatureTypeRangeDto> temperatureTypeRangeDtoList = temperatureTypeRangeUpdateDto.getTemperatureTypeRangeDtoList();

            for(TemperatureTypeRangeDto temperatureTypeRangeDto : temperatureTypeRangeDtoList) {
                TemperatureTypeRange temperatureTypeRange = temperatureTypeRangeRepository.findById(temperatureTypeRangeDto.getId()).orElse(null);
                if(temperatureTypeRange!=null) {
                    temperatureTypeRange.setStartTemperature(temperatureTypeRangeDto.getStartTemperature());
                    temperatureTypeRange.setEndTemperature(temperatureTypeRangeDto.getEndTemperature());
                    temperatureTypeRangeRepository.save(temperatureTypeRange);
                }
            }
        }
        TemperatureTypeRangeResponseDto temperatureTypeRangeResponseDto = new TemperatureTypeRangeResponseDto();
        temperatureTypeRangeResponseDto.setComplianceSubCategoryId(temperatureTypeRangeUpdateDto.getComplianceSubcategoryId());
        return temperatureTypeRangeResponseDto;
    }


    public List<TemperatureTypeRangeDto> getAllTemperatureRangeDto(String complianceSubCategoryId) {

        return temperatureTypeRangeRepository.getAllTemperatureRangeDto(complianceSubCategoryId);
    }

    public TemperatureReadingConfigurationsDto getAllTemperatureReadingConfigurations(String subCategoryId) {
        if (!complianceSubCategoryRepository.existsById(subCategoryId)) {
            throw new ServiceException("Subcategory Not Found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        TemperatureReadingConfigurationsDto temperatureReadingConfigurationsDto = temperatureConfigurationsRepository.geTemperatureConfigurationBySubCategoryId(subCategoryId);
        if (temperatureReadingConfigurationsDto != null) {
            List<TemperatureItemDto> items = temperatureConfigurationsRepository.findAllTemperatureReadingConfigurations(temperatureReadingConfigurationsDto.getTemperatureConfigurationId());
            temperatureReadingConfigurationsDto.setItems(items);
        }
        return temperatureReadingConfigurationsDto;
    }

    public Page<TemperatureOverviewDto> getAllTemperatureOverview(TemperatureOverviewSearchDto temperatureOverviewSearchDto) {
        Pageable pageable = PageRequest.of(temperatureOverviewSearchDto.getPage() - 1, temperatureOverviewSearchDto.getSize());

        userManagementClient.checkBusinessId(temperatureOverviewSearchDto.getBusinessId());

        validations.dateValidation(temperatureOverviewSearchDto.getFromDate(), temperatureOverviewSearchDto.getToDate());

        ComplianceSubCategory complianceSubCategory = complianceSubCategoryRepository
                .findById(temperatureOverviewSearchDto.getSubCategoryId())
                .orElseThrow(() -> new ServiceException(ApplicationConstants.SUB_CATEGORY_NOT_FOUND, ApplicationConstants.BAD_REQUEST, HttpStatus.NOT_FOUND));


        Page<TemperatureOverviewDto> temperatureOverviewDtos = temperatureReadingRepository.getAllTemperatureOverview(
                temperatureOverviewSearchDto.getBusinessId(),
                temperatureOverviewSearchDto.getSubCategoryId(),
                temperatureOverviewSearchDto.getFromDate(),
                temperatureOverviewSearchDto.getToDate(),
                pageable,
                ComplianceStatus.fromMappedValue(temperatureOverviewSearchDto.getComplianceStatus()),
                temperatureOverviewSearchDto.getEmployeeIds() != null ? temperatureOverviewSearchDto.getEmployeeIds() : List.of("ALL"),
                temperatureOverviewSearchDto.getNotifyTos() != null ? temperatureOverviewSearchDto.getNotifyTos() : List.of("ALL")
        );

        Page<TemperatureOverviewDto> updatedTemperatureOverviewDtos = temperatureOverviewDtos.map(dto -> {
            String createdBy = dto.getEmployeeName();
            UserName userName = userManagementClient.getUserNameById(createdBy);
            dto.setEmployeeName(userName.getName());
            dto.setSubCategoryName(complianceSubCategory.getSubCategoryName());
            return dto;
        });
        List<TemperatureTypeOverviewAllDto> allTemperatureTypeOverviewDtos1 = temperatureTypeRangeRepository.getAllTemperatureTypeOverView(temperatureOverviewSearchDto.getSubCategoryId());
        List<TemperatureTypeOverviewDto> allTemperatureTypeOverviewDtos = allTemperatureTypeOverviewDtos1.stream().map(dto -> {
            TemperatureTypeOverviewDto dtoTemperature = new TemperatureTypeOverviewDto();
            BeanUtils.copyProperties(dto, dtoTemperature);
            return dtoTemperature;
        }).toList();

        AtomicInteger rowNo = new AtomicInteger(1);
        updatedTemperatureOverviewDtos.getContent().forEach(temperatureDto -> {
            List<TemperatureTypeOverviewDto> temperatureTypeOverviewDtos = temperatureTypeRangeRepository.getTemperatureTypeOverView(
                    temperatureDto.getId());
            List<String> ids = temperatureTypeOverviewDtos.stream().map(dto -> dto.getId()).toList();
            List<TemperatureTypeOverviewDto> updatedTemperatureTypeOverviewDtoList = new ArrayList<>(temperatureTypeOverviewDtos.stream()
                    .map(dto -> {
                        String temperatureReadingId = dto.getTemperatureReadingId();
                        List<ImageOrAudioNameWithLink> imageOrAudioLinks = temperatureTypeRangeRepository.findReadingImagesByTemperatureReadingId(temperatureReadingId);
                        List<ImageOrAudioNameWithLink> imageOrAudioLinkss = new ArrayList<>();
                        for (ImageOrAudioNameWithLink imageOrAudioNameWithLink : imageOrAudioLinks) {
                            imageOrAudioNameWithLink.setDownloadLink(downloadBaseUrl + imageOrAudioNameWithLink.getDownloadLink());
                            imageOrAudioNameWithLink.setLink(baseUrl + imageOrAudioNameWithLink.getLink());
                            imageOrAudioLinkss.add(imageOrAudioNameWithLink);
                        }

                        dto.setTemperatureOverviewDownloadDto(imageOrAudioLinkss);
                        List<String> notifyToList = temperatureReadingRepository.getTemperatureNotifyTo(temperatureReadingId);
                        if (notifyToList != null && !notifyToList.isEmpty()) {
                            List<String> notifyResponse = notifyToList.stream()
                                    .map(notify -> {
                                        UserFisrtNameLastNameDto userFisrtNameLastNameDto = userManagementClient.getUserFisrtNameLastNameById(notify);
                                        return userFisrtNameLastNameDto.getName() + " " + userFisrtNameLastNameDto.getLastName();
                                    })
                                    .toList();
                            dto.setNotifyTo(notifyResponse);
                        }
                        return dto;
                    })
                    .toList());

            List<TemperatureTypeOverviewDto> missed = allTemperatureTypeOverviewDtos.stream().filter(dto -> !ids.contains(dto.getId())).toList();
            List<TemperatureTypeOverviewDto> finalList = Stream.concat(missed.stream(), updatedTemperatureTypeOverviewDtoList.stream()).sorted(Comparator.comparingInt(dto -> dto.getSequence())).toList();
            temperatureDto.setTemperatureTypeOverviewDtos(finalList);

            int currentRowNo = rowNo.getAndIncrement();

            temperatureDto.setRowNo(currentRowNo);

        });

        return updatedTemperatureOverviewDtos;
    }


    public ComplianceReading getAllTemperatureOverviewRow(String id) {
        return complianceReadingRepository
                .findById(id)
                .orElseThrow(() -> new ServiceException("Sub category not found", ApplicationConstants.BAD_REQUEST, HttpStatus.NOT_FOUND));

    }

    public TemperatureOverviewDto getAllTemperatureOverviewRowById(String id) {
        ComplianceCategory complianceCategory = ComplianceCategory.TEMPERATURE;
        ComplianceReading complianceReading = complianceReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return temperatureConverter.convertToTemperatureOverviewDto(complianceReading);
    }


}
