package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.IncidentReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface IncidentReadingRepository extends JpaRepository<IncidentReading, String> {
    @Query("select i from IncidentReading i " +
            "WHERE i.complianceSubCategoryId = :subCategoryId " +
            "AND i.date BETWEEN :fromDate AND :toDate " +
            "AND (:employeeName IS NULL OR i.createdBy = :employeeName) " +
            "AND (:complianceStatus IS NULL OR i.complianceStatus = :complianceStatus)")
    Page<IncidentReading> getAllIncidentOverview(String subCategoryId, LocalDate fromDate, LocalDate toDate, String employeeName, ComplianceStatus complianceStatus, Pageable pageable);

    @Query("select i from IncidentReading i " +
            "WHERE i.id = :id ")
    IncidentReading getOverViewById(String id);
}
