package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VisitTypeDto {
    private String id;
    @NotBlank(message = "Type of visit is required")
    private String typeOfVisit;
    @NotBlank(message = "BusinessId is required")
    private String businessId;

    public VisitTypeDto(String id, String typeOfVisit) {
        this.id = id;
        this.typeOfVisit = typeOfVisit;
    }
}
