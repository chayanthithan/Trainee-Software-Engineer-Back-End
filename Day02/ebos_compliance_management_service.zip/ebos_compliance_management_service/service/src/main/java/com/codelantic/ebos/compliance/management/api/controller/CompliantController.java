package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.CompliantAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/complaint")
@RequiredArgsConstructor
@Validated
public class CompliantController {

    private final CompliantAgent compliantAgent;

    @PostMapping("/compliant-type")
    public ResponseDto saveComplaintType(@Valid @RequestBody ComplaintTypeSaveDto complaintTypeSaveDto) {
        return compliantAgent.saveComplaintType(complaintTypeSaveDto);
    }

    @GetMapping("/compliant-type")
    public List<ComplaintTypeSaveDto> getComplainType(@RequestParam(value = "businessId", required = false) @NotBlank(message = "Business Id is required") String businessId) {
        return compliantAgent.getComplainType(businessId);
    }

    @GetMapping("/get-all-compliant-overview")
    public PaginatedResponseDto<CompliantOverViewDto> getAllComplaints(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business id is required") String businessId,
                                                                       @RequestParam(value = "complianceSubCategoryId", required = false) @NotBlank(message = "Compliance Sub Category Id is required") String complianceSubCategoryId,
                                                                       @RequestParam(value = "fromDate", required = false) @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                       @RequestParam(value = "toDate", required = false) @NotNull(message = "To Date is required") LocalDate toDate,
                                                                       @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                       @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                       @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                       @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size){
        CompliantOverviewSearchDto compliantOverviewSearchDto = CompliantOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .businessId(businessId)
                .complianceSubCategoryId(complianceSubCategoryId)
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName)
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus) : null)
                .build();

        return compliantAgent.getAllComplaints(compliantOverviewSearchDto);

    }

    @GetMapping("/get-overview-compliant-by-id")
    public CompliantOverViewDto getOverviewCompliantById( @RequestParam(value = "id") String id) {
        return compliantAgent.getOverviewCompliantById(id);
    }

}
