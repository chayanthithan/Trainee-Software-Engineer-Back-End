package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DocumentsLicenseDto;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingOverViewDto;
import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class LicenseAndPermitReadingConverter {

    private final ReminderToConverter reminderToConverter;
    private final DocumentsConverter documentsConverter;
    private final UserManagementClient userManagementClient;

    public LicenseAndPermitReading convert(LicenseAndPermitReadingDto licenseAndPermitReadingDto) {
        String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return LicenseAndPermitReading.builder()
                .id(licenseAndPermitReadingDto.getId())
                .licenseOrPermitName(licenseAndPermitReadingDto.getLicenseOrPermitName())
                .licenseOrPermitNumber(licenseAndPermitReadingDto.getLicenseOrPermitNumber())
                .typeOfLicenseOrPermit(licenseAndPermitReadingDto.getTypeOfLicenseOrPermit())
                .issuingAuthority(licenseAndPermitReadingDto.getIssuingAuthority())
                .issueDate(licenseAndPermitReadingDto.getIssueDate())
                .expiryDate(licenseAndPermitReadingDto.getExpiryDate())
                .renewalDate(licenseAndPermitReadingDto.getRenewalDate())
                .businessName(licenseAndPermitReadingDto.getBusinessName())
                .businessAddress(licenseAndPermitReadingDto.getBusinessAddress())
                .holdersName(licenseAndPermitReadingDto.getHoldersName())
                .contactPhoneNumber(licenseAndPermitReadingDto.getContactPhoneNumber())
                .contactEmail(licenseAndPermitReadingDto.getContactEmail())
                .conditionsOrRestrictions(licenseAndPermitReadingDto.getConditionsOrRestrictions())
                .renewalApplicationDedLine(licenseAndPermitReadingDto.getRenewalApplicationDedLine())
                .reminderDate(licenseAndPermitReadingDto.getReminderDate())
                .reminderTime(licenseAndPermitReadingDto.getReminderTime())
                .comments(licenseAndPermitReadingDto.getComments())
                .complianceSubCategoryId(licenseAndPermitReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .reminderTos(licenseAndPermitReadingDto.getReminderTos() != null ? licenseAndPermitReadingDto.getReminderTos().stream().map
                        (reminderToConverter::convert).collect(Collectors.toSet()) : null)
                .documents(licenseAndPermitReadingDto.getDocuments() != null ? licenseAndPermitReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public LicenseAndPermitReadingOverViewDto convertToDto(LicenseAndPermitReading licenseAndPermitReading) {
        LicenseAndPermitReadingOverViewDto licenseAndPermitReadingOverViewDto = LicenseAndPermitReadingOverViewDto.builder()
                .id(licenseAndPermitReading.getId())
                .date(licenseAndPermitReading.getIssueDate())
                .time(licenseAndPermitReading.getReminderTime())
                .licensePermitName(licenseAndPermitReading.getLicenseOrPermitName())
                .licensePermitNumber(licenseAndPermitReading.getLicenseOrPermitNumber())
                .typeOfLicensePermit(licenseAndPermitReading.getTypeOfLicenseOrPermit())
                .issueDate(licenseAndPermitReading.getIssueDate())
                .expiryDate(licenseAndPermitReading.getExpiryDate())
                .renewalDate(licenseAndPermitReading.getRenewalDate())
                .comments(licenseAndPermitReading.getComments())
                .complianceStatus(licenseAndPermitReading.getComplianceStatus() != null ? licenseAndPermitReading.getComplianceStatus().getMappedValue() : null)
                .build();

        if (licenseAndPermitReading.getCreatedBy() != null) {
            UserName userName = userManagementClient.getUserNameById(licenseAndPermitReading.getCreatedBy());
            licenseAndPermitReadingOverViewDto.setEmployeeName(userName.getName());
        }
        if (licenseAndPermitReading.getDocuments() != null) {
            Set<DocumentsLicenseDto> documentsDtoAfterConversion = licenseAndPermitReading.getDocuments().stream()
                    .map(documentsConverter::convertForLicense)
                    .collect(Collectors.toSet());
            licenseAndPermitReadingOverViewDto.setDocuments(documentsDtoAfterConversion);
        }
        return licenseAndPermitReadingOverViewDto;
    }
    public LicenseAndPermitReadingOverViewDto convertToDtos(LicenseAndPermitReading licenseAndPermitReading,String rawNo) {
        LicenseAndPermitReadingOverViewDto licenseAndPermitReadingOverViewDto = LicenseAndPermitReadingOverViewDto.builder()
                .rowNo(rawNo)
                .id(licenseAndPermitReading.getId())
                .date(licenseAndPermitReading.getIssueDate())
                .time(licenseAndPermitReading.getReminderTime())
                .licensePermitName(licenseAndPermitReading.getLicenseOrPermitName())
                .licensePermitNumber(licenseAndPermitReading.getLicenseOrPermitNumber())
                .typeOfLicensePermit(licenseAndPermitReading.getTypeOfLicenseOrPermit())
                .issueDate(licenseAndPermitReading.getIssueDate())
                .expiryDate(licenseAndPermitReading.getExpiryDate())
                .renewalDate(licenseAndPermitReading.getRenewalDate())
                .comments(licenseAndPermitReading.getComments())
                .complianceStatus(licenseAndPermitReading.getComplianceStatus() != null ? licenseAndPermitReading.getComplianceStatus().getMappedValue() : null)
                .build();

        if (licenseAndPermitReading.getCreatedBy() != null) {
            UserName userName = userManagementClient.getUserNameById(licenseAndPermitReading.getCreatedBy());
            licenseAndPermitReadingOverViewDto.setEmployeeName(userName.getName());
        }
        if (licenseAndPermitReading.getDocuments() != null) {
            Set<DocumentsLicenseDto> documentsDtoAfterConversion = licenseAndPermitReading.getDocuments().stream()
                    .map(documentsConverter::convertForLicense)
                    .collect(Collectors.toSet());
            licenseAndPermitReadingOverViewDto.setDocuments(documentsDtoAfterConversion);
        }
        return licenseAndPermitReadingOverViewDto;
    }
    public LicenseAndPermitReadingDto convert(LicenseAndPermitReading licenseAndPermitReading) {
        return LicenseAndPermitReadingDto.builder()
                .id(licenseAndPermitReading.getId())
                .licenseOrPermitName(licenseAndPermitReading.getLicenseOrPermitName())
                .licenseOrPermitNumber(licenseAndPermitReading.getLicenseOrPermitNumber())
                .typeOfLicenseOrPermit(licenseAndPermitReading.getTypeOfLicenseOrPermit())
                .issuingAuthority(licenseAndPermitReading.getIssuingAuthority())
                .issueDate(licenseAndPermitReading.getIssueDate())
                .expiryDate(licenseAndPermitReading.getExpiryDate())
                .renewalDate(licenseAndPermitReading.getRenewalDate())
                .businessName(licenseAndPermitReading.getBusinessName())
                .businessAddress(licenseAndPermitReading.getBusinessAddress())
                .holdersName(licenseAndPermitReading.getHoldersName())
                .contactPhoneNumber(licenseAndPermitReading.getContactPhoneNumber())
                .contactEmail(licenseAndPermitReading.getContactEmail())
                .conditionsOrRestrictions(licenseAndPermitReading.getConditionsOrRestrictions())
                .renewalApplicationDedLine(licenseAndPermitReading.getRenewalApplicationDedLine())
                .reminderDate(licenseAndPermitReading.getReminderDate())
                .reminderTime(licenseAndPermitReading.getReminderTime())
                .comments(licenseAndPermitReading.getComments())
                .reminderTos(licenseAndPermitReading.getReminderTos() != null ? licenseAndPermitReading.getReminderTos().stream().map
                        (reminderToConverter::convert).collect(Collectors.toSet()) : null)
                .documents(licenseAndPermitReading.getDocuments() != null ? licenseAndPermitReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public void updateConvert(LicenseAndPermitReading existingReading, LicenseAndPermitReadingDto licenseAndPermitReadingDto) {

        existingReading.setId(licenseAndPermitReadingDto.getId());
        existingReading.setLicenseOrPermitName(licenseAndPermitReadingDto.getLicenseOrPermitName());
        existingReading.setLicenseOrPermitNumber(licenseAndPermitReadingDto.getLicenseOrPermitNumber());
        existingReading.setTypeOfLicenseOrPermit(licenseAndPermitReadingDto.getTypeOfLicenseOrPermit());
        existingReading.setIssuingAuthority(licenseAndPermitReadingDto.getIssuingAuthority());
        existingReading.setIssueDate(licenseAndPermitReadingDto.getIssueDate());
        existingReading.setExpiryDate(licenseAndPermitReadingDto.getExpiryDate());
        existingReading.setRenewalDate(licenseAndPermitReadingDto.getRenewalDate());
        existingReading.setBusinessName(licenseAndPermitReadingDto.getBusinessName());
        existingReading.setBusinessAddress(licenseAndPermitReadingDto.getBusinessAddress());
        existingReading.setHoldersName(licenseAndPermitReadingDto.getHoldersName());
        existingReading.setContactPhoneNumber(licenseAndPermitReadingDto.getContactPhoneNumber());
        existingReading.setContactEmail(licenseAndPermitReadingDto.getContactEmail());
        existingReading.setConditionsOrRestrictions(licenseAndPermitReadingDto.getConditionsOrRestrictions());
        existingReading.setRenewalApplicationDedLine(licenseAndPermitReadingDto.getRenewalApplicationDedLine());
        existingReading.setReminderDate(licenseAndPermitReadingDto.getReminderDate());
        existingReading.setReminderTime(licenseAndPermitReadingDto.getReminderTime());
        existingReading.setComments(licenseAndPermitReadingDto.getComments());

        if (licenseAndPermitReadingDto.getReminderTos() != null) {
            existingReading.setReminderTos(licenseAndPermitReadingDto.getReminderTos().stream()
                    .map(reminderToConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (licenseAndPermitReadingDto.getDocuments() != null) {
            existingReading.setDocuments(licenseAndPermitReadingDto.getDocuments().stream()
                    .map(documentsConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
