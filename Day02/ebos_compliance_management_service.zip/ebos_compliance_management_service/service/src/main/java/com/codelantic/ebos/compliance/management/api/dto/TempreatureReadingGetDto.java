package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Set;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class TempreatureReadingGetDto {
    private String id;
    private String complianceSubCategoryId;
    private String temperatureTypeRangeConfigurationsId;
    private String startTempreature;
    private String endTempreature;
    private String tempreatureType;
    private String item;
    private Integer quantity;
    private String actualReading;
    private String complianceReadingId;
    private Set<ReadingImagesDto> readingImages;
    private Set<NotifyToDto> notifyTo;
    private String recommendedStartTemperature;
    private String recommendedEndTemperature;
    private String temperatureType;
    private  int sequence;

}
