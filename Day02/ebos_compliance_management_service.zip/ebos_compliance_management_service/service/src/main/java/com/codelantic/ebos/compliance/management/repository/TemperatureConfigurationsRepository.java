package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TemperatureItemDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureReadingConfigurationsDto;
import com.codelantic.ebos.compliance.management.entity.TemperatureConfigurations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TemperatureConfigurationsRepository extends JpaRepository<TemperatureConfigurations,String> {

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureReadingConfigurationsDto(s.temperatureConfigurations.id, " +
            "t.isRequiredQuantityBasedTempReading)" +
            "FROM TemperatureConfigurations t JOIN ComplianceSubCategory s ON t.id=s.temperatureConfigurations.id " +
            "WHERE s.id=:subCategoryId")
    TemperatureReadingConfigurationsDto geTemperatureConfigurationBySubCategoryId(@Param("subCategoryId") String subCategoryId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureItemDto(tc.id,tc.items,tr.startTemperature,tr.endTemperature,tr.temperatureType,tc.sequence) " +
            "FROM TemperatureTypeRangeConfigurations tc " +
            "LEFT JOIN TemperatureTypeRange tr ON tc.temperatureTypeRangeId = tr.id " +
            "WHERE tc.temperatureConfigurationsId = :temperatureConfigurationsId")
    List<TemperatureItemDto> findAllTemperatureReadingConfigurations(@Param("temperatureConfigurationsId") String temperatureConfigurationsId);




}
