package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class TemperatureTypeRangeDto {
    private String id;
    @NotBlank(message = "Temperature type is required")
    private String temperatureType;
    private String startTemperature;
    private String endTemperature;
    private Boolean status;
    private String complianceSubCategoryId;


    public TemperatureTypeRangeDto(String id, TemperatureType temperatureType, String startTemperature, String endTemperature,Boolean status,String complianceSubCategoryId) {
        this.id = id;
        this.temperatureType = temperatureType != null ? temperatureType.getMappedValue() : null;
        this.startTemperature = startTemperature;
        this.endTemperature = endTemperature;
        this.status = status;
        this.complianceSubCategoryId = complianceSubCategoryId;
    }

    public TemperatureTypeRangeDto(){

    }

}
