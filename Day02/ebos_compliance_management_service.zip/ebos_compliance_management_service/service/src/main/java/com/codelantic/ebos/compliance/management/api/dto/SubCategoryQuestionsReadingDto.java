package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

@Data
public class SubCategoryQuestionsReadingDto {
    private String subCategoryQuestionsId;
    private String yesOrNo;
    private String comments;
}
