package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.PotentialImpactDto;
import com.codelantic.ebos.compliance.management.entity.PotentialImpact;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PotentialImpactConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;
    public PotentialImpact convert(PotentialImpactDto potentialImpactDto) {
        return PotentialImpact.builder()
                .id(potentialImpactDto.getId())
                .audio(potentialImpactDto.getAudio())
                .audioPath(potentialImpactDto.getAudioPath())
                .incidentReadingId(potentialImpactDto.getIncidentReadingId())
                .build();
    }

    public PotentialImpactDto convert(PotentialImpact potentialImpact) {
        return PotentialImpactDto.builder()
                .id(potentialImpact.getId())
                .audio(potentialImpact.getAudio())
                .viewAudioPath(baseUrl+potentialImpact.getAudioPath())
                .downloadAudioPath(downloadBaseUrl+potentialImpact.getAudioPath())
                .incidentReadingId(potentialImpact.getIncidentReadingId())
                .build();
    }
}
