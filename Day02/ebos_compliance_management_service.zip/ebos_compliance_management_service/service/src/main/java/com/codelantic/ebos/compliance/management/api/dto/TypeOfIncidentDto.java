package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TypeOfIncidentDto {
    private String id;
    @NotBlank(message = "Incident type is required")
    private String incidentType;
    @NotBlank(message = "Business Id is required")
    private String businessId;

    public TypeOfIncidentDto(String id, String incidentType) {
        this.id = id;
        this.incidentType = incidentType;
    }
    public TypeOfIncidentDto(){

    }
}
