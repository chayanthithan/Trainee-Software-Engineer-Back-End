package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.entity.BusinessComplianceConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ComplianceConverter {


    public BusinessComplianceConfiguration convertToBusinessComplianceEntity(ComplianceConfigurationsDto complianceConfigurationsDto){
         BusinessComplianceConfiguration businessComplianceConfiguration=new BusinessComplianceConfiguration();
         businessComplianceConfiguration.setComplianceId(complianceConfigurationsDto.getComplianceId());
         businessComplianceConfiguration.setBusinessId(complianceConfigurationsDto.getBusinessId());
         return businessComplianceConfiguration;
    }


}
