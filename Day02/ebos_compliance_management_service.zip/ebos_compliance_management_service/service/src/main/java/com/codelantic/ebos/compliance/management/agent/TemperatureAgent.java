package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.TemperatureConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.compliance.management.service.TemperatureService;
import com.codelantic.ebos.compliance.management.validations.Validations;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class TemperatureAgent {

    private final TemperatureService temperatureService;
    private final TemperatureConverter temperatureConverter;
    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;
    private final Validations validations;

    public TemperatureTypeRangeResponseDto saveTemperatureTypeRange(List<TemperatureTypeRangeDto> temperatureTypeRangeDtos) {
        Set<String> uniqueTemperatureTypes = new HashSet<>();

        String complianceSubCategoryId = UUID.randomUUID().toString();

        List<TemperatureTypeRange> temperatureTypeRanges = temperatureTypeRangeDtos.stream()
                .map(dto -> {
                    if (dto.getId() == null) {
                        if (!uniqueTemperatureTypes.add(dto.getTemperatureType())) {
                            throw new ServiceException("Duplicate temperature type '" + dto.getTemperatureType() + "' found in the request", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
                        }
                        dto.setComplianceSubCategoryId(complianceSubCategoryId);
                        return temperatureConverter.convert(dto);
                    } else {
                        TemperatureTypeRange existingRange = temperatureTypeRangeRepository.findById(dto.getId())
                                .orElseThrow(() -> new ServiceException("Temperature Type Range not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
                        validations.checkTemperatureTypeAndComplianceSubCategoryId(dto.getTemperatureType(), dto.getComplianceSubCategoryId());

                        dto.setComplianceSubCategoryId(complianceSubCategoryId);
                        temperatureConverter.convert(existingRange, dto);
                        return existingRange;
                    }
                })
                .toList();

        temperatureService.saveTemperatureTypeRange(temperatureTypeRanges);

        TemperatureTypeRangeResponseDto temperatureTypeRangeResponseDto = new TemperatureTypeRangeResponseDto();
        temperatureTypeRangeResponseDto.setComplianceSubCategoryId(complianceSubCategoryId); // Return the common complianceSubCategoryId
        return temperatureTypeRangeResponseDto;
    }

    public TemperatureTypeRangeResponseDto updateTemperatureTypeRange(TemperatureTypeRangeUpdateDto temperatureTypeRangeDto) {
        return temperatureService.updateTemperatureTypeRange(temperatureTypeRangeDto);
    }


    public List<TemperatureTypeRangeDto> getAllTemperatureRangeDto(String complianceSubCategoryId) {
        return temperatureService.getAllTemperatureRangeDto(complianceSubCategoryId);
    }

    public TemperatureReadingConfigurationsDto getAllTemperatureReadingConfigurations(String subCategoryId) {
        return temperatureService.getAllTemperatureReadingConfigurations(subCategoryId);
    }

    public PaginatedResponseDto<TemperatureOverviewDto> getAllTemperatureOverview(TemperatureOverviewSearchDto temperatureOverviewSearchDto) {
        Page<TemperatureOverviewDto> temperatureOverviewDtos = temperatureService.getAllTemperatureOverview(temperatureOverviewSearchDto);

        List<TemperatureOverviewDto> temperatureOverviewDtoList = temperatureOverviewDtos.getContent();

        PaginatedResponseDto<TemperatureOverviewDto> temperatureOverviewDtoPaginatedResponseDto = new PaginatedResponseDto<>();

        temperatureOverviewDtoPaginatedResponseDto.setData(temperatureOverviewDtoList);
        temperatureOverviewDtoPaginatedResponseDto.setCurrentPage(temperatureOverviewSearchDto.getPage());
        temperatureOverviewDtoPaginatedResponseDto.setTotalPages(temperatureOverviewDtos.getTotalPages());
        temperatureOverviewDtoPaginatedResponseDto.setTotalItems(temperatureOverviewDtos.getTotalElements());

        return temperatureOverviewDtoPaginatedResponseDto;
    }


    public TemperatureOverviewDto getAllTemperatureOverviewRow(String id) {
        ComplianceReading complianceReadingList=temperatureService.getAllTemperatureOverviewRow(id);

        return temperatureConverter.getAllTemperatureOverviewRow(complianceReadingList);
    }

    public TemperatureOverviewDto getAllTemperatureOverviewRowById(String id) {
        return temperatureService.getAllTemperatureOverviewRowById(id);
    }


}
