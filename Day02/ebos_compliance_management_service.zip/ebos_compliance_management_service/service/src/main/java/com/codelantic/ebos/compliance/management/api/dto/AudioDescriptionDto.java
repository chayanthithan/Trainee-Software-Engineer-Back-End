package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AudioDescriptionDto {
    private String id;
    private String fileName;
    private String fullViewPath;
    private String downloadPath;
}
