package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class QuestionsDto {
    private String heading;
    private List<QuestionHeadingDto> headingLists;

}
