package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.TrainingReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingOverViewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingReadingDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.TrainingReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.TrainingReadingRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TrainingReadingService {

    private final TrainingReadingConverter trainingReadingConverter;
    private final TrainingReadingRepository trainingReadingRepository;
    private final UserManagementClient userManagementClient;

    private final Validations validations;

    public ResponseDto save(TrainingReadingDto trainingReadingDto) {
        trainingReadingRepository.save(trainingReadingConverter.convert(trainingReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(TrainingReadingDto trainingReadingDto) {

        if (trainingReadingDto.getId() == null) {
            throw new ServiceException("training reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        TrainingReading existingReading = trainingReadingRepository.findById(trainingReadingDto.getId()).
                orElseThrow(() -> new ServiceException("training reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        trainingReadingConverter.updateConvert(existingReading, trainingReadingDto);
        trainingReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public TrainingReadingDto getById(String id, ComplianceCategory complianceCategory) {
        TrainingReading trainingReading = trainingReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return trainingReadingConverter.convertToDto(trainingReading);
    }

    public Page<TrainingReading> getAllTrainingReading(TrainingOverViewSearchDto trainingOverViewSearchDto) {
        userManagementClient.checkBusinessId(trainingOverViewSearchDto.getBusinessId());
        validations.dateValidation(trainingOverViewSearchDto.getFromDate(),trainingOverViewSearchDto.getToDate());
        Pageable pageable= PageRequest.of(Math.max(trainingOverViewSearchDto.getPage()-1,0), trainingOverViewSearchDto.getSize());
        return trainingReadingRepository.findAllTrainingReadings(trainingOverViewSearchDto.getBusinessId(),
                trainingOverViewSearchDto.getSubCategoryId(),
                Date.valueOf(trainingOverViewSearchDto.getFromDate()),
                Date.valueOf(trainingOverViewSearchDto.getToDate()),
                trainingOverViewSearchDto.getOrganizedBy(),
                trainingOverViewSearchDto.getTrainerId()!=null?trainingOverViewSearchDto.getTrainerId(): List.of("All"),
                trainingOverViewSearchDto.getParticipantId()!=null?trainingOverViewSearchDto.getParticipantId():List.of("All"),
                trainingOverViewSearchDto.getComplianceStatus(),
                pageable);
    }

    public TrainingReading getOverviewTrainingById(String id) {
        return trainingReadingRepository.findById(id)
                .orElseThrow(() -> new ServiceException("Training reading not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
    }
}
