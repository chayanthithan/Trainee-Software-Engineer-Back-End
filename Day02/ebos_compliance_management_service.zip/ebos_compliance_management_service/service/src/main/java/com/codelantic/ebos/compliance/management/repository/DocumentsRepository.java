package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.Documents;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DocumentsRepository extends JpaRepository<Documents, String> {

    boolean existsByImagePathAndId(String imagePath, String documentId);

    @Modifying
    @Transactional
    @Query("DELETE FROM Documents d WHERE d.imagePath = :imagePath AND d.id = :documentId")
    int deleteImage(String imagePath, String documentId);

    @Query("SELECT COALESCE(MAX(d.imageNumber), 0) FROM Documents d " +
            "WHERE d.trainingReadingId = :readingId " +
            "OR d.licenseAndPermitReadingId = :readingId " +
            "OR d.wasteManagementReadingId = :readingId " +
            "OR d.incidentReadingId = :readingId " +
            "OR d.visitorReadingId = :readingId " +
            "OR d.complaintReadingId = :readingId")
    Integer getLastImageNumber(@Param("readingId") String readingId);
}
