package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.IncidentConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.service.IncidentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@RequiredArgsConstructor
public class IncidentAgent {

    private final IncidentService incidentService;
    private final IncidentConverter incidentConverter;

    public ResponseDto saveTypeOfIncident(TypeOfIncidentDto typeOfIncidentDto) {
        TypeOfIncident typeOfIncident = incidentConverter.convert(typeOfIncidentDto);
        return incidentService.saveTypeOfIncident(typeOfIncident);
    }

    public ResponseDto saveDepartment(DepartmentDto departmentDto) {
        Department department = incidentConverter.convertToEntity(departmentDto);
        return incidentService.saveDepartment(department);
    }

    public List<ViewDepartmentDto> getAllDepartment(String businessId) {
        return incidentService.getAllDepartment(businessId);
    }

    public List<TypeOfIncidentDto> getAllTypeOfIncidents(String businessId) {
        return incidentService.getAllTypeOfIncidents(businessId);
    }

    public ResponseDto saveLocation(LocationDto locationDto) {
        Location location= incidentConverter.convertToEntity(locationDto);
        return incidentService.saveLocation(location);
    }

    public List<LocationDto> getAllLocation(String businessId) {
        return incidentService.getAllLocation(businessId);
    }

    public ResponseDto saveSeverity(@Valid SeverityDto severityDto) {
        Severity severity = incidentConverter.convertToEntity(severityDto);
        return incidentService.saveSeverity(severity);
    }

    public List<SeverityDto> getAllSeverities( String businessId) {
        return incidentService.getAllSeverities(businessId);
    }

    public  List<FormSettingConfigurationDto> getAllConfiguredField(String complianceSubCategoryId) {
        return incidentService.getAllConfiguredField(complianceSubCategoryId);
    }

    public PaginatedResponseDto<IncidentOverviewDto> getAllIncidentOverview(IncidentOverviewSearchDto incidentOverviewSearchDto) {
        Page<IncidentReading> incidentOverviewDtos = incidentService.getAllIncidentOverview(incidentOverviewSearchDto);

        List<IncidentReading> incidentReadings = incidentOverviewDtos.getContent();
        Integer rowStartNum=1;
        AtomicInteger rowCounter = new AtomicInteger(rowStartNum);
        List<IncidentOverviewDto> overviewDtos = incidentReadings.stream().map(dto -> incidentConverter.convertToOverview(dto,rowCounter.getAndIncrement())).toList();
        PaginatedResponseDto<IncidentOverviewDto> incidentOverviewDtoPaginatedResponseDto = new PaginatedResponseDto<>();

        incidentOverviewDtoPaginatedResponseDto.setData(overviewDtos);
        incidentOverviewDtoPaginatedResponseDto.setCurrentPage(incidentOverviewSearchDto.getPage());
        incidentOverviewDtoPaginatedResponseDto.setTotalPages(incidentOverviewDtos.getTotalPages());
        incidentOverviewDtoPaginatedResponseDto.setTotalItems(incidentOverviewDtos.getTotalElements());

        return incidentOverviewDtoPaginatedResponseDto;
    }

    public IncidentOverviewDto getOverViewById(String id) {
       return incidentConverter.convertToOverview(incidentService.getOverViewById(id),1);

    }
}
