package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface PestControlRepository extends JpaRepository<ComplianceReading, String> {


    @Query(value = """
            SELECT new com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto(
            ROW_NUMBER() OVER () ,
            c.id,
            c.date,
            c.time,
            c.createdBy,
            COUNT(CASE WHEN cr.isChecked = 'TRUE' THEN cr.id END),
            COUNT(distinct cr.id),
            COUNT(CASE WHEN sqr.yesOrNo like 'yes' or sqr.yesOrNo like 'no' THEN sqr.id END),
            COUNT(distinct sqr.id),
            c.complianceStatus )
            FROM ComplianceReading c
            LEFT JOIN CheckListReading cr ON cr.complianceReadingId = c.id
            LEFT JOIN SubCategoryQuestionsReadings sqr ON sqr.complianceReadingId = c.id
            WHERE (:complianceSubCategoryId IS NULL OR c.complianceSubCategoryId = :complianceSubCategoryId)
            AND (:employeeName IS NULL OR c.createdBy = :employeeName)
            AND (c.date BETWEEN :fromDate AND :toDate)
            AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus)
            GROUP BY c.id ORDER BY c.date desc""")
    Page<PestControlOverviewDto> getAlll(String complianceSubCategoryId, String employeeName, LocalDate fromDate,
                                        LocalDate toDate, ComplianceStatus complianceStatus, Pageable paging);

    @Query(value = """
            SELECT c
            FROM ComplianceReading c
            WHERE (:complianceSubCategoryId IS NULL OR c.complianceSubCategoryId = :complianceSubCategoryId)
            AND (:employeeName IS NULL OR c.createdBy = :employeeName)
            AND (c.date BETWEEN :fromDate AND :toDate)
            AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus)
            GROUP BY c.id ORDER BY c.date desc""")
    Page<ComplianceReading> getAll(String complianceSubCategoryId, String employeeName, LocalDate fromDate,
                                        LocalDate toDate, ComplianceStatus complianceStatus, Pageable paging);

    @Query("SELECT c FROM ComplianceReading c WHERE c.id=:id ")
    ComplianceReading getOverViewById(String id);
}
