package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UploadDocumentDto {
    private String businessId;
    private String subCategoryName;
    private String complianceName;

}
