package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ComplianceSubCategoryResponseDto {
    private String id;
    private String subCategoryName;
    private Integer complianceId;
    private Boolean isTemperature;
    private Boolean isCheckList;
    private Boolean isForm;
    private Boolean isYesOrNo;
    private String businessId;
    private Boolean isCheckThisBoxToAddCommentsToTheForm;
    private Boolean isDeclarationStatement;
    private Boolean status;
    private TemperatureConfigurationsDto temperatureConfigurationsDto;
    private Set<SubCategoryCheckListSaveDto> subCategoryCheckListSaveDto;
    private Set<SubCategoryQuestionsSaveDto> subCategoryQuestionsSaveDto;
    private List<FormSettingConfigurationDto> formConfigurationSaveDto;
}
