package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.*;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class IncidentService {

    private final TypeOfIncidentRepository typeOfIncidentRepository;
    private final Validations validations;
    private final UserManagementClient userManagementClient;
    private final DepartmentRepository departmentRepository;
    private final SeverityRepository severityRepository;
    private final LocationRepositoty locationRepositoty;
    private final FormSettingConfigurationRepository formSettingConfigurationRepository;
    private final SubCategoryFormConfigurationsRepository subCategoryFormConfigurationsRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final IncidentReadingRepository incidentReadingRepository;

    public ResponseDto saveTypeOfIncident(TypeOfIncident typeOfIncident) {

        validations.checkIncidentType(typeOfIncident.getIncidentType(),typeOfIncident.getBusinessId());
        userManagementClient.checkBusinessId(typeOfIncident.getBusinessId());
        typeOfIncidentRepository.save(typeOfIncident);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Type Of Incident Saved Successfully");
        return responseDto;
    }

    public List<TypeOfIncidentDto> getAllTypeOfIncidents(String businessId) {
        return typeOfIncidentRepository.getAllTypeOfIncidents(businessId);
    }

    public ResponseDto saveDepartment(Department department) {
        userManagementClient.checkBusinessId(department.getBusinessId());
        validations.checkDeparment(department.getDepartmentName(),department.getBusinessId());
        departmentRepository.save(department);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Department Saved Successfully!");
        return responseDto;
    }

    public List<ViewDepartmentDto> getAllDepartment(String businessId) {
        log.info("department--------{}",businessId);
        userManagementClient.checkBusinessId(businessId);
        return departmentRepository.getAllDepartment(businessId);
    }

    public ResponseDto saveLocation(Location location) {
        userManagementClient.checkBusinessId(location.getBusinessId());
        validations.checkLocation(location.getLocationName(), location.getBusinessId());
        locationRepositoty.save(location);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Location Saved Successfully!");
        return responseDto;
    }

    public List<LocationDto> getAllLocation(String businessId) {
        userManagementClient.checkBusinessId(businessId);
        return locationRepositoty.getAllLocation(businessId);

    }

    public ResponseDto saveSeverity(Severity severity) {
        ResponseDto responseDto = new ResponseDto();

        userManagementClient.checkBusinessId(severity.getBusinessId());
        validations.checkSeverityName(severity.getSeverityName(),severity.getBusinessId());
        severityRepository.save(severity);

        responseDto.setMessage("Severity name saved successfully");
        return responseDto;
    }

    public List<SeverityDto> getAllSeverities(String businessId) {
        userManagementClient.checkBusinessId(businessId);
        return severityRepository.getAllSeverities(businessId);
    }

    public List<FormSettingConfigurationDto> getAllConfiguredField(String complianceSubCategoryId) {
       Boolean isAvalible= subCategoryFormConfigurationsRepository.existsByComplianceSubCategoryId(complianceSubCategoryId);
       if(Boolean.FALSE.equals(isAvalible))
       {
           throw new ServiceException("Compliance SubCategory Id: "+complianceSubCategoryId+"  Not Found","Not Found",HttpStatus.BAD_REQUEST);
       }
        List<FormSettingConfigurationDto> formSettingConfigurationDtoList = formSettingConfigurationRepository.getAllConfiguredField(complianceSubCategoryId);


        // Use Stream API to group fieldDetails by fieldCategory
        Map<String, List<FieldConfigurationDto>> groupedMap = formSettingConfigurationDtoList.stream()
                .flatMap(dto -> dto.getFieldDetails().stream()
                        .map(detail -> new AbstractMap.SimpleEntry<>(dto.getFieldCategory(), detail)))
                .collect(Collectors.groupingBy(
                        Map.Entry::getKey,
                        Collectors.mapping(Map.Entry::getValue, Collectors.toList())
                ));

        // Create the final consolidated list
        return groupedMap.entrySet().stream()
                .map(entry -> {
                    FormSettingConfigurationDto consolidatedDto = new FormSettingConfigurationDto();
                    consolidatedDto.setFieldCategory(entry.getKey());
                    consolidatedDto.setFieldDetails(entry.getValue());
                    return consolidatedDto;
                })
                .toList();

    }


    public Page<IncidentReading> getAllIncidentOverview(IncidentOverviewSearchDto incidentOverviewSearchDto) {
        Pageable pageable = PageRequest.of(incidentOverviewSearchDto.getPage() - 1, incidentOverviewSearchDto.getSize());

        // Validate date range
        validations.dateValidation(incidentOverviewSearchDto.getFromDate(), incidentOverviewSearchDto.getToDate());

        // Store the result of findByIdForValidation for further use if needed
        String complianceSubCategory = complianceSubCategoryRepository.findByIdForValidation(incidentOverviewSearchDto.getSubCategoryId())
                .orElseThrow(() -> new ServiceException("Sub category not found", ApplicationConstants.BAD_REQUEST, HttpStatus.NOT_FOUND));

        log.info("id------{}",complianceSubCategory);
        return incidentReadingRepository.getAllIncidentOverview(
                incidentOverviewSearchDto.getSubCategoryId(),
                incidentOverviewSearchDto.getFromDate(),
                incidentOverviewSearchDto.getToDate(),
                incidentOverviewSearchDto.getEmployeeName(),
                incidentOverviewSearchDto.getComplianceStatus(),
                pageable
        );
    }

    public IncidentReading getOverViewById(String id) {
        return incidentReadingRepository.getOverViewById(id);
    }
}
