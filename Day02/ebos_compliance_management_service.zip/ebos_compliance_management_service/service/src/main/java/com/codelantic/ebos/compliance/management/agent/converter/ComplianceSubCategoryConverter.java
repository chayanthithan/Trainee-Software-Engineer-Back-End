package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class ComplianceSubCategoryConverter {

    private final TemperatureConverter temperatureConverter;
    private final SubCategoryCheckListConverter subCategoryCheckListConverter;
    private final SubCategoryQuestionsConverter subCategoryQuestionsConverter;
    private final SubCategoryCheckListRepository subCategoryCheckListRepository;

    private final FormSettingConfigurationRepository formSettingConfigurationRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final SubCategoryFormConfigurationsRepository subCategoryFormConfigurationsRepository;
    private final TemperatureConfigurationsRepository temperatureConfigurationsRepository;

    public ComplianceSubCategory convert(ComplianceSubCategorySaveDto complianceSubCategorySaveDto) {
        ComplianceSubCategory complianceSubCategory = ComplianceSubCategory.builder()
                .id(complianceSubCategorySaveDto.getId())
                .subCategoryName(complianceSubCategorySaveDto.getSubCategoryName())
                .complianceId(complianceSubCategorySaveDto.getComplianceId())
                .isTemperature(complianceSubCategorySaveDto.getIsTemperature())
                .isCheckList(complianceSubCategorySaveDto.getIsCheckList())
                .isForm(complianceSubCategorySaveDto.getIsForm())
                .isYesOrNo(complianceSubCategorySaveDto.getIsYesOrNo())
                .businessId(complianceSubCategorySaveDto.getBusinessId())
                .isCheckThisBoxToAddCommentsToTheForm(complianceSubCategorySaveDto.getIsCheckThisBoxToAddCommentsToTheForm())
                .isDeclarationStatement(complianceSubCategorySaveDto.getIsDeclarationStatement())
                .status(Boolean.TRUE)
                .date(LocalDate.now())
                .time(LocalTime.now())
                .build();

        if (complianceSubCategorySaveDto.getTemperatureSaveDto() != null) {
            TemperatureConfigurations temperatureConfigurations = temperatureConverter.convert(complianceSubCategorySaveDto.getTemperatureSaveDto());
            complianceSubCategory.setTemperatureConfigurations(temperatureConfigurations);
        }

        if (complianceSubCategorySaveDto.getSubCategoryCheckListSaveDto() != null) {
            Set<SubCategoryCheckList> subCategoryCheckLists = complianceSubCategorySaveDto.getSubCategoryCheckListSaveDto()
                    .stream().map(subCategoryCheckListConverter::convertToEntity)
                    .collect(Collectors.toSet());
            complianceSubCategory.setSubCategoryCheckLists(subCategoryCheckLists);
        }
        if (complianceSubCategorySaveDto.getSubCategoryQuestionsSaveDto() != null) {
            Set<SubCategoryQuestions> subCategoryQuestions = complianceSubCategorySaveDto.getSubCategoryQuestionsSaveDto()
                    .stream().map(subCategoryQuestionsConverter::convertToEntity)
                    .collect(Collectors.toSet());
            complianceSubCategory.setSubCategoryQuestions(subCategoryQuestions);
        }
        if (complianceSubCategorySaveDto.getIsForm() != null && Boolean.TRUE.equals(complianceSubCategorySaveDto.getIsForm()) && complianceSubCategorySaveDto.getFormConfigurationSaveDto() != null) {
            Set<String> inputFormConfigurationIds = complianceSubCategorySaveDto.getFormConfigurationSaveDto().stream().map(SubCategoryFormConfigurationDto::getFormSettingsConfigurationsId).collect(Collectors.toSet());
            Set<String> existingIds = formSettingConfigurationRepository.findExistingIds(inputFormConfigurationIds);
            inputFormConfigurationIds.removeAll(existingIds);
            if (!inputFormConfigurationIds.isEmpty()) {
                throw new ServiceException("Invalid FormConfigurationIds : " + inputFormConfigurationIds, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
            Set<SubCategoryFormConfigurations> subCategoryFormConfigurations = complianceSubCategorySaveDto.getFormConfigurationSaveDto()
                    .stream().map(dto -> new SubCategoryFormConfigurations(dto.getFormSettingsConfigurationsId()))
                    .collect(Collectors.toSet());
            complianceSubCategory.setSubCategoryFormConfigurations(subCategoryFormConfigurations);
        }
        return complianceSubCategory;
    }

    public GetCheckListQuestionDto convertToCheckListQuestionDto(ComplianceSubCategory complianceSubCategory) {
        GetCheckListQuestionDto.GetCheckListQuestionDtoBuilder checkListQuestionDto = GetCheckListQuestionDto.builder();

        checkListQuestionDto.isCommentAvailable(complianceSubCategory.getIsCheckThisBoxToAddCommentsToTheForm()!=null && complianceSubCategory.getIsCheckThisBoxToAddCommentsToTheForm().equals(Boolean.TRUE) ? Boolean.TRUE : Boolean.FALSE);
        checkListQuestionDto.isDeclarationAvailable(complianceSubCategory.getIsDeclarationStatement()!=null && complianceSubCategory.getIsDeclarationStatement().equals(Boolean.TRUE) ? Boolean.TRUE : Boolean.FALSE);

        if (Boolean.TRUE.equals(complianceSubCategory.getIsCheckList()) && complianceSubCategory.getSubCategoryCheckLists() != null) {
            Map<String, List<CheckListHeadingDto>> groupedCheckLists = complianceSubCategory.getSubCategoryCheckLists()
                    .stream()
                    .collect(Collectors.groupingBy(
                            SubCategoryCheckList::getHeading,
                            Collectors.mapping(subCategoryCheckListConverter::convertToCheckListHeadingDto, Collectors.toList())
                    ));

            List<CheckListDto> checkListDtoList = groupedCheckLists.entrySet().stream()
                    .map(entry -> CheckListDto.builder()
                            .heading(entry.getKey())
                            .headingLists(entry.getValue())
                            .build())
                    .toList();

            checkListQuestionDto.checkLists(checkListDtoList);
        }

        if (Boolean.TRUE.equals(complianceSubCategory.getIsYesOrNo()) && complianceSubCategory.getSubCategoryQuestions() != null) {
            Map<String, List<QuestionHeadingDto>> groupedQuestions = complianceSubCategory.getSubCategoryQuestions()
                    .stream()
                    .collect(Collectors.groupingBy(
                            SubCategoryQuestions::getHeading,
                            Collectors.mapping(subCategoryQuestionsConverter::convertToQuestionHeadingDto, Collectors.toList())
                    ));

            List<QuestionsDto> questionsDtoList = groupedQuestions.entrySet().stream()
                    .map(entry -> QuestionsDto.builder()
                            .heading(entry.getKey())
                            .headingLists(entry.getValue())
                            .build())
                    .toList();

            checkListQuestionDto.questionsLists(questionsDtoList);
        }

        if (Boolean.TRUE.equals(complianceSubCategory.getIsTemperature())) {
            TemperatureReadingConfigurationsDto temperatureReadingConfigurationsDto = temperatureConfigurationsRepository.geTemperatureConfigurationBySubCategoryId(complianceSubCategory.getId());
            if (temperatureReadingConfigurationsDto != null) {
                List<TemperatureItemDto> items = temperatureConfigurationsRepository.findAllTemperatureReadingConfigurations(temperatureReadingConfigurationsDto.getTemperatureConfigurationId());
                List<TemperatureItemDto> items1 =items.stream().sorted(Comparator.comparingInt(dto->dto.getSequence())).toList();
                temperatureReadingConfigurationsDto.setItems(items1);

                checkListQuestionDto.temperatureReadingConfigurationsDto(temperatureReadingConfigurationsDto);
                checkListQuestionDto.isRequiredQuantityBasedTempReading(temperatureReadingConfigurationsDto.getIsRequiredQuantityBasedTempReading());

                temperatureReadingConfigurationsDto.setTemperatureConfigurationId(null);
                temperatureReadingConfigurationsDto.setIsRequiredQuantityBasedTempReading(null);
            } else {
                checkListQuestionDto.isRequiredQuantityBasedTempReading(Boolean.FALSE);
            }
        }

        return checkListQuestionDto.build();
    }

    public ComplianceSubCategoryResponseDto convert(ComplianceSubCategory complianceSubCategory) {
        ComplianceSubCategoryResponseDto complianceSubCategoryResponseDto = ComplianceSubCategoryResponseDto.builder()
                .id(complianceSubCategory.getId())
                .subCategoryName(complianceSubCategory.getSubCategoryName())
                .complianceId(complianceSubCategory.getComplianceId())
                .isTemperature(complianceSubCategory.getIsTemperature())
                .isCheckList(complianceSubCategory.getIsCheckList())
                .isForm(complianceSubCategory.getIsForm())
                .isYesOrNo(complianceSubCategory.getIsYesOrNo())
                .businessId(complianceSubCategory.getBusinessId())
                .isCheckThisBoxToAddCommentsToTheForm(complianceSubCategory.getIsCheckThisBoxToAddCommentsToTheForm())
                .isDeclarationStatement(complianceSubCategory.getIsDeclarationStatement())
                .status(complianceSubCategory.getStatus())
                .build();

        if (complianceSubCategory.getIsTemperature().equals(Boolean.TRUE)) {
            TemperatureConfigurationsDto temperatureConfigurationsDto = null;
            if(complianceSubCategory.getTemperatureConfigurations()!=null) {
                temperatureConfigurationsDto = temperatureConverter.convert(complianceSubCategory.getTemperatureConfigurations());
            }
            complianceSubCategoryResponseDto.setTemperatureConfigurationsDto(temperatureConfigurationsDto);
        }
        if (Boolean.TRUE.equals(complianceSubCategory.getIsForm())) {
            List<String> formIds = subCategoryFormConfigurationsRepository.findFormSettingsConfigurationIdByComplianceSubCategoryId(complianceSubCategory.getId());
            List<FormSettingConfigurationDto> formSettingConfigurationList = formSettingConfigurationRepository.findAllByCompliance(complianceSubCategory.getId(), complianceSubCategory.getComplianceId().toString());
            complianceSubCategoryResponseDto.setFormConfigurationSaveDto(processFormSettings(formSettingConfigurationList, formIds));
        }


        if (complianceSubCategory.getIsCheckList().equals(Boolean.TRUE)) {
            Set<SubCategoryCheckListSaveDto> checkList = complianceSubCategory.getSubCategoryCheckLists().stream().map(subCategoryCheckListConverter::convertToSubCategoryCheckListSaveDto).collect(Collectors.toSet());
            complianceSubCategoryResponseDto.setSubCategoryCheckListSaveDto(checkList);
        }
        if (complianceSubCategory.getIsYesOrNo().equals(Boolean.TRUE)) {
            Set<SubCategoryQuestionsSaveDto> questions = complianceSubCategory.getSubCategoryQuestions().stream().map(subCategoryQuestionsConverter::convertToSubCategoryQuestionsSaveDto).collect(Collectors.toSet());
            complianceSubCategoryResponseDto.setSubCategoryQuestionsSaveDto(questions);
        }
        return complianceSubCategoryResponseDto;
    }

    public List<FormSettingConfigurationDto> processFormSettings(List<FormSettingConfigurationDto> formSettingConfigurationList, List<String> formIds) {
        // Update status and group by fieldCategory
        Map<String, List<FieldConfigurationDto>> groupedByCategory = formSettingConfigurationList.stream()
                .flatMap(formSettingConfiguration -> {
                    // Update the status of fieldDetails using map
                    List<FieldConfigurationDto> updatedFields = formSettingConfiguration.getFieldDetails().stream()
                            .map(field -> {
                                if (formIds.contains(field.getId())) {
                                    field.setStatus(true);  // Assuming you have a setter for status
                                }
                                return field;
                            }).toList();

                    // Return a stream of FormSettingConfigurationDto with updated fields
                    return updatedFields.stream()
                            .map(field -> new FormSettingConfigurationDto(formSettingConfiguration.getFieldCategory(), Collections.singletonList(field)));
                })
                .collect(Collectors.groupingBy(FormSettingConfigurationDto::getFieldCategory,
                        Collectors.flatMapping(dto -> dto.getFieldDetails().stream(), Collectors.toList())));

        return groupedByCategory.entrySet().stream()
                .map(entry -> new FormSettingConfigurationDto(entry.getKey(), entry.getValue()))
                .toList();
    }


    public ComplianceSubCategory convertForUpdate(ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto) {
        ComplianceSubCategory existingComplianceSubCategory = complianceSubCategoryRepository
                .findByIdAndStatus(complianceSubCategoryUpdateDto.getComplianceSubCategoryId(), true)
                .orElseThrow(() -> new ServiceException("Compliance sub category id not found",
                        ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        existingComplianceSubCategory.setId(complianceSubCategoryUpdateDto.getComplianceSubCategoryId());

        existingComplianceSubCategory.setSubCategoryName(complianceSubCategoryUpdateDto.getSubCategoryName());
        existingComplianceSubCategory.setComplianceId(complianceSubCategoryUpdateDto.getComplianceId());
        existingComplianceSubCategory.setIsTemperature(complianceSubCategoryUpdateDto.getIsTemperature());
        existingComplianceSubCategory.setIsCheckList(complianceSubCategoryUpdateDto.getIsCheckList());
        existingComplianceSubCategory.setIsForm(complianceSubCategoryUpdateDto.getIsForm());
        existingComplianceSubCategory.setIsYesOrNo(complianceSubCategoryUpdateDto.getIsYesOrNo());
        existingComplianceSubCategory.setBusinessId(complianceSubCategoryUpdateDto.getBusinessId());
        existingComplianceSubCategory.setIsCheckThisBoxToAddCommentsToTheForm(complianceSubCategoryUpdateDto.getIsCheckThisBoxToAddCommentsToTheForm());
        existingComplianceSubCategory.setIsDeclarationStatement(complianceSubCategoryUpdateDto.getIsDeclarationStatement());
        existingComplianceSubCategory.setStatus(Boolean.TRUE);

        if (complianceSubCategoryUpdateDto.getTemperatureSaveDto() != null && Boolean.TRUE.equals(complianceSubCategoryUpdateDto.getIsTemperature())) {
            TemperatureConfigurations temperatureConfigurations = temperatureConverter.convert(complianceSubCategoryUpdateDto.getTemperatureSaveDto());
            existingComplianceSubCategory.setTemperatureConfigurations(temperatureConfigurations);
        } else {
            existingComplianceSubCategory.setTemperatureConfigurations(null);
        }

        updateCheckListField(complianceSubCategoryUpdateDto, existingComplianceSubCategory);

        updateYesOrNoQuestionField(complianceSubCategoryUpdateDto, existingComplianceSubCategory);

        if (complianceSubCategoryUpdateDto.getIsForm() != null && Boolean.TRUE.equals(complianceSubCategoryUpdateDto.getIsForm())
                && complianceSubCategoryUpdateDto.getFormConfigurationSaveDto() != null) {

            Set<SubCategoryFormConfigurations> existingFormConfigurations = existingComplianceSubCategory.getSubCategoryFormConfigurations();
            Set<String> existingIds = existingFormConfigurations.stream()
                    .map(SubCategoryFormConfigurations::getFormSettingsConfigurationId)
                    .collect(Collectors.toSet());

            Set<String> newFormConfigurationIds = complianceSubCategoryUpdateDto.getFormConfigurationSaveDto()
                    .stream()
                    .map(SubCategoryFormConfigurationDto::getFormSettingsConfigurationsId)
                    .collect(Collectors.toSet());

            existingFormConfigurations.removeIf(config -> !newFormConfigurationIds.contains(config.getFormSettingsConfigurationId()));

            Set<SubCategoryFormConfigurations> newFormConfigurations = complianceSubCategoryUpdateDto.getFormConfigurationSaveDto()
                    .stream()
                    .filter(newDto -> !existingIds.contains(newDto.getFormSettingsConfigurationsId()))
                    .map(newDto -> new SubCategoryFormConfigurations(newDto.getFormSettingsConfigurationsId()))
                    .collect(Collectors.toSet());

            existingFormConfigurations.addAll(newFormConfigurations);


            existingComplianceSubCategory.setSubCategoryFormConfigurations(existingFormConfigurations);
        }

        return existingComplianceSubCategory;
    }

    private void updateYesOrNoQuestionField(ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto, ComplianceSubCategory existingComplianceSubCategory) {
        if (complianceSubCategoryUpdateDto.getSubCategoryQuestionsSaveDto() != null
                && Boolean.TRUE.equals(complianceSubCategoryUpdateDto.getIsYesOrNo())) {

            Set<SubCategoryQuestions> subCategoryQuestions = existingComplianceSubCategory.getSubCategoryQuestions();

            // Map DTOs with non-null IDs for quick lookup
            Map<String, SubCategoryQuestionsSaveDto> dtoMap = complianceSubCategoryUpdateDto.getSubCategoryQuestionsSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() != null)
                    .collect(Collectors.toMap(SubCategoryQuestionsSaveDto::getId, dto -> dto));

            // Validate ID mismatches
            complianceSubCategoryUpdateDto.getSubCategoryQuestionsSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() != null && subCategoryQuestions.stream()
                            .noneMatch(existing -> existing.getId().equals(dto.getId())))
                    .findFirst()
                    .ifPresent(dto -> {
                        throw new ServiceException("Sub category question ID mismatch: " + dto.getId(),
                                ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
                    });

            // Update existing questions or keep unchanged
            Set<SubCategoryQuestions> updatedQuestionLists = subCategoryQuestions.stream()
                    .map(existing -> {
                        SubCategoryQuestionsSaveDto matchingDto = dtoMap.get(existing.getId());
                        if (matchingDto != null) {
                            return subCategoryQuestionsConverter.convertToUpdate(matchingDto, existingComplianceSubCategory.getId());
                        }
                        return existing;
                    })
                    .collect(Collectors.toSet());

            // Add new questions with null IDs
            complianceSubCategoryUpdateDto.getSubCategoryQuestionsSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() == null)
                    .forEach(dto -> {
                        SubCategoryQuestions newQuestion = subCategoryQuestionsConverter.convertToNew(dto, existingComplianceSubCategory.getId());
                        updatedQuestionLists.add(newQuestion);
                    });

            existingComplianceSubCategory.setSubCategoryQuestions(updatedQuestionLists);
        }
    }

    private void updateCheckListField(ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto, ComplianceSubCategory existingComplianceSubCategory) {
        if (complianceSubCategoryUpdateDto.getSubCategoryCheckListSaveDto() != null
                && Boolean.TRUE.equals(complianceSubCategoryUpdateDto.getIsCheckList())) {

            Set<SubCategoryCheckList> existingCheckLists = existingComplianceSubCategory.getSubCategoryCheckLists();

            Map<String, SubCategoryCheckListSaveDto> dtoMap = complianceSubCategoryUpdateDto.getSubCategoryCheckListSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() != null)
                    .collect(Collectors.toMap(SubCategoryCheckListSaveDto::getId, dto -> dto));

            // Use noneMatch instead of negation with anyMatch
            complianceSubCategoryUpdateDto.getSubCategoryCheckListSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() != null && existingCheckLists.stream()
                            .noneMatch(existing -> existing.getId().equals(dto.getId()))) // Changed to noneMatch
                    .findFirst()
                    .ifPresent(dto -> {
                        throw new ServiceException("Sub category checklist ID mismatch: " + dto.getId(),
                                ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
                    });

            Set<SubCategoryCheckList> updatedCheckLists = existingCheckLists.stream()
                    .map(existing -> {
                        SubCategoryCheckListSaveDto matchingDto = dtoMap.get(existing.getId());
                        if (matchingDto != null) {
                            return subCategoryCheckListConverter.convertToUpdate(matchingDto, existingComplianceSubCategory.getId());
                        }
                        return existing;
                    })
                    .collect(Collectors.toSet());

            // Handle new entries with null IDs
            complianceSubCategoryUpdateDto.getSubCategoryCheckListSaveDto()
                    .stream()
                    .filter(dto -> dto.getId() == null)
                    .forEach(dto -> {
                        SubCategoryCheckList newCheckList = subCategoryCheckListConverter.convertToNew(dto, existingComplianceSubCategory.getId());
                        updatedCheckLists.add(newCheckList);
                    });


            existingComplianceSubCategory.setSubCategoryCheckLists(updatedCheckLists);
        }
    }

}
