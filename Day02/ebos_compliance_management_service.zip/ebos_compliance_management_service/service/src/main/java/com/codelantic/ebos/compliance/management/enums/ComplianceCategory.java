package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public enum ComplianceCategory {
    TEMPERATURE("Temperature"),
    CLEANING("Cleaning"),
    DELIVERY("Delivery"),
    TRAINING("Training"),
    HEALTH_AND_SAFETY("Health and Safety"),
    LICENSE_AND_PERMITS("License and Permits"),
    WASTE_MANAGEMENT("Waste Management"),
    INCIDENT("Incident"),
    VISITOR("Visitor"),
    COMPLAINT("Complaint"),
    PEST_CONTROL("Pest Control");

    private final String mappedValue;

    ComplianceCategory(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static ComplianceCategory fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        for (ComplianceCategory complianceCategory : ComplianceCategory.values()) {
            if (complianceCategory.mappedValue.equalsIgnoreCase(mappedValue)) {
                return complianceCategory;
            }
        }
        throw new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST);
    }


    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        for (ComplianceCategory complianceCategory : ComplianceCategory.values()) {
            list.add(complianceCategory.mappedValue);
        }
        return list;
    }
}
