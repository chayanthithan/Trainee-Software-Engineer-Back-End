package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.CleaningConverter;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.CleaningService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
public class CleaningAgent {
    private final CleaningService cleaningService;
    private final CleaningConverter cleaningConverter;


    public PaginatedResponseDto<CleaningOverViewDisplayDto> getAllOverViewForCleaning(CleaningOverviewSearchDto cleaningOverviewSearchDto) {
        Page<ComplianceReading> complianceReadingPage = cleaningService.getAllOverViewForCleaning(cleaningOverviewSearchDto);

        List<CleaningOverViewDisplayDto> cleaningOverViewDisplayDtos = complianceReadingPage.getContent().stream()
                .map(dto -> cleaningConverter.convertToDto(dto,cleaningOverviewSearchDto.getSubCategoryId()))
                .toList();

        List<CleaningOverViewDisplayDto> cleaningOverViewWithRowNo = IntStream.range(0,cleaningOverViewDisplayDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (cleaningOverviewSearchDto.getPage() - 1) * cleaningOverviewSearchDto.getSize();
                    cleaningOverViewDisplayDtos.get(i).setRowNo(String.format("%02d", rowNo));
                    return cleaningOverViewDisplayDtos.get(i);
                })
                .toList();

        return PaginatedResponseDto.<CleaningOverViewDisplayDto>builder()
                .data(cleaningOverViewWithRowNo)
                .currentPage(cleaningOverviewSearchDto.getPage())
                .totalPages(complianceReadingPage.getTotalPages())
                .totalItems(complianceReadingPage.getTotalElements())
                .build();
    }

    public CleaningOverViewDisplayDto getOverviewCleaningById(String complianceReadingId) {
        ComplianceReading complianceReading =  cleaningService.getOverviewCleaningById(complianceReadingId);
        return cleaningConverter.convertToDtoForOverView(complianceReading);
    }
}
