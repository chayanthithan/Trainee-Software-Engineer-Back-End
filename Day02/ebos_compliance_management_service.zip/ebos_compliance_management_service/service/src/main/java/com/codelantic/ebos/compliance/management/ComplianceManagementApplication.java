package com.codelantic.ebos.compliance.management;

import com.codelantic.ebos.user.management.UsermanagementClientConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import({UsermanagementClientConfiguration.class})
public class ComplianceManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(ComplianceManagementApplication.class, args);
    }

}