package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.WasteManagementAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/waste-management")
@RequiredArgsConstructor
public class WasteManagementController {


    private final WasteManagementAgent wasteManagementAgent;


    @PostMapping("/add-waste-type")
    public ResponseDto addWasteType(@RequestBody @Valid TypeOfWasteDto typeOfWasteDto) {
        return wasteManagementAgent.addNewWasteType(typeOfWasteDto);
    }

    @GetMapping("/waste-type")
    public List<TypeOfWasteDto> getAllVisitWasteTypeByBusinessId(@RequestParam(name = "businessId") @NotBlank(message = "Business id is required") String businessId) {
        return wasteManagementAgent.getAllWasteTypesByBusinessId(businessId);
    }

    @GetMapping("/get-all-waste-overview")
    public PaginatedResponseDto<WasteManagementOverviewDto> getAllWasteOverview(@RequestParam(value = "businessId",required = false) @NotBlank String businessId,@RequestParam(value = "complianceSubCategoryId", required = false) @NotBlank(message = "Compliance Sub Category Id is required") String complianceSubCategoryId,
                                                                                @RequestParam(value = "fromDate", required = false) @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                @RequestParam(value = "toDate", required = false) @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size){
        WasteManagementOverviewSearchDto wasteManagementOverviewSearchDto=WasteManagementOverviewSearchDto.builder()
                .page(page)
                .size(size)
                .businessId(businessId)
                .complianceSubCategoryId(complianceSubCategoryId)
                .employeeName(employeeName)
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus) : null)
                .fromDate(fromDate)
                .toDate(toDate)
                .build();

        return wasteManagementAgent.getAllWasteOverview(wasteManagementOverviewSearchDto);
    }

    @GetMapping("/get-overview-waste-by-id")
    public WasteManagementOverviewDto getOverviewWasteById( @RequestParam(value = "id") String id) {
        return wasteManagementAgent.getOverviewWasteById(id);
    }

}
