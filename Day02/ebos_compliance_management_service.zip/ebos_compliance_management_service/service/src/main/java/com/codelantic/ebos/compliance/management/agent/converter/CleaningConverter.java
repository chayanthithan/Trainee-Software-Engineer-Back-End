package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CleaningOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@RequiredArgsConstructor
public class CleaningConverter {
    private final UserManagementClient userManagementClient;
    private final CheckListReadingRepository checkListReadingRepository;
private final ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Value("${sftp.base.url}")
    private String imagePath;

    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;

    public CleaningOverViewDisplayDto convertToDto(ComplianceReading complianceReading,String id) {
        CleaningOverViewDisplayDto cleaningOverViewDisplayDto = CleaningOverViewDisplayDto.builder()
                .id(complianceReading.getId())
                .date(complianceReading.getDate())
                .time(complianceReading.getTime())
                .subCategoryName(complianceSubCategoryRepository.findBySubCategoryNameIgnoreCase(id))
                .complianceStatus(complianceReading.getComplianceStatus().getMappedValue())
                .employeeName(userManagementClient.getUserNameById(complianceReading.getCreatedBy()).getName())
                .build();

        countPendindAndTotal(complianceReading,cleaningOverViewDisplayDto);

        return cleaningOverViewDisplayDto;
    }

    public CleaningOverViewDisplayDto convertToDtoForOverView(ComplianceReading complianceReading) {
        CleaningOverViewDisplayDto cleaningOverViewDisplayDto = CleaningOverViewDisplayDto.builder()
                .id(complianceReading.getId())
                .date(complianceReading.getDate())
                .time(complianceReading.getTime())
                .subCategoryName(complianceSubCategoryRepository.findBySubCategoryNameIgnoreCase(complianceReading.getComplianceSubCategoryId()))
                .complianceStatus(complianceReading.getComplianceStatus().getMappedValue())
                .employeeName(userManagementClient.getUserNameById(complianceReading.getCreatedBy()).getName())
                .build();

        countPendindAndTotal(complianceReading,cleaningOverViewDisplayDto);
        return cleaningOverViewDisplayDto;
    }

    private void countPendindAndTotal(ComplianceReading complianceReading, CleaningOverViewDisplayDto cleaningOverViewDisplayDto) {
        TotalCheckedCountDto counts = checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(complianceReading.getId());
        Long total = counts.getTotalCount();
        Long totalChecked = counts.getCheckedCount();

        String pendingTotal = totalChecked + " / " + total;
        cleaningOverViewDisplayDto.setPendingTotal(total != 0 ? pendingTotal : "0");

        Set<ImageDescriptionDto> imageDescriptions = Stream.concat(
                        // using parallel stream for images from check list readings
                        complianceReading.getCheckListReadings().parallelStream()
                                .flatMap(checkListReading -> checkListReading.getReadingImages().parallelStream()),

                        // using parallel stream for images from sub category questions readings
                        complianceReading.getSubCategoryQuestionsReadings().parallelStream()
                                .flatMap(subCategoryQuestionsReading -> subCategoryQuestionsReading.getReadingImages().parallelStream())
                )
                .map(readingImage -> ImageDescriptionDto.builder()
                        .id(readingImage.getId())
                        .fileName(readingImage.getImageName())
                        .fullViewPath(readingImage.getImagePath())
                        .downloadPath(readingImage.getImagePath())
                        .build())
                .collect(Collectors.toSet());

        cleaningOverViewDisplayDto.setImages(imageDescriptions);
    }
}
