package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.PestControlAgent;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/pest-control")
@RequiredArgsConstructor
@Validated
public class PestControlController {

    private final PestControlAgent pestControlAgent;

    @GetMapping("/get-all")
    public PaginatedResponseDto<PestControlOverviewDto> getAll(@Valid @SpringQueryMap WasteManagementOverviewSearchDto searchDto) {
        return pestControlAgent.getAll(searchDto);
    }

    @GetMapping("/get-overview-by-id")
    public PestControlOverviewDto getOneOverViewById(@RequestParam(value = "id") String id) {
        return pestControlAgent.getOverViewById(id);
    }
}
