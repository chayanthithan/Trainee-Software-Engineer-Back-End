package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.CompliantReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.CompliantReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.CompliantReadingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CompliantReadingService {

    private final CompliantReadingConverter compliantReadingConverter;
    private final CompliantReadingRepository compliantReadingRepository;

    public ResponseDto save(CompliantReadingDto compliantReadingDto) {
        compliantReadingRepository.save(compliantReadingConverter.convert(compliantReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(CompliantReadingDto compliantReadingDto) {

        if (compliantReadingDto.getId() == null) {
            throw new ServiceException("Compliant reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        CompliantReading existingReading = compliantReadingRepository.findById(compliantReadingDto.getId()).
                orElseThrow(() -> new ServiceException("Compliant reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        compliantReadingConverter.updateConvert(existingReading, compliantReadingDto);
        compliantReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public CompliantReadingDto getById(String id, ComplianceCategory complianceCategory) {
        CompliantReading compliantReading = compliantReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return compliantReadingConverter.convert(compliantReading);
    }
}
