package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class IncidentConverter {

    private final UserManagementClient userManagementClient;

    public TypeOfIncident convert(TypeOfIncidentDto typeOfIncidentDto) {
        TypeOfIncident typeOfIncident = new TypeOfIncident();
        typeOfIncident.setId(typeOfIncidentDto.getId());
        typeOfIncident.setIncidentType(typeOfIncidentDto.getIncidentType());
        typeOfIncident.setBusinessId(typeOfIncidentDto.getBusinessId());
        return typeOfIncident;
    }

    public Department convertToEntity(DepartmentDto departmentDto) {
        Department department = new Department();
        department.setId(departmentDto.getId());
        department.setDepartmentName(departmentDto.getDepartmentName());
        department.setBusinessId(departmentDto.getBusinessId());
        return department;
    }

    public Severity convertToEntity(SeverityDto severityDto) {
        Severity severity = new Severity();
        severity.setId(severityDto.getId());
        severity.setSeverityName(severityDto.getSeverityName());
        severity.setBusinessId(severityDto.getBusinessId());
        return severity;
    }

    public Location convertToEntity(LocationDto locationDto) {
        Location location = new Location();
        location.setId(locationDto.getId());
        location.setLocationName(locationDto.getLocationName());
        location.setBusinessId(locationDto.getBusinessId());
        return location;
    }

    public IncidentOverviewDto convertToOverview(IncidentReading dto, Integer rowStartNum) {
        IncidentOverviewDto overviewDto = new IncidentOverviewDto();
        UserName userName = userManagementClient.getUserNameById(dto.getCreatedBy());
        overviewDto.setId(dto.getId());
        overviewDto.setEmployeeName(userName.getName());
        overviewDto.setComplianceStatus(dto.getComplianceStatus() != null ? dto.getComplianceStatus().getMappedValue() : null);
        overviewDto.setRowNo(rowStartNum);
        overviewDto.setDate(dto.getDate());
        overviewDto.setTime(dto.getTime());
        overviewDto.setTypeOfIncident(dto.getTypeOfIncident());
        overviewDto.setSeverity(dto.getSeverity());
        overviewDto.setDepartment(dto.getDepartment());
        overviewDto.setSupportingEvidence(dto.getSupportingEvidence());
        overviewDto.setAffectedParties(dto.getAffectedParties());
        overviewDto.setPotentialImpact(dto.getPotentialImpact());
        overviewDto.setImmediateResponse(dto.getImmediateResponse());
        overviewDto.setComments(dto.getComments());
        overviewDto.setLocation(dto.getLocation());
        overviewDto.setDescription(dto.getDescription());

        if (dto.getDocuments() != null) {
            List<String> documentList = dto.getDocuments().stream()
                    .map(Documents::getImageName)
                    .toList();
            overviewDto.setDocumentsList(documentList);
        }

        if (dto.getDocuments() != null) {
            List<ImageOrAudioNameWithLink> documentList = dto.getDocuments().stream()
                    .map(document -> {
                        ImageOrAudioNameWithLink imageOrAudioNameWithLink = new ImageOrAudioNameWithLink();
                        imageOrAudioNameWithLink.setName(document.getImageName());
                        imageOrAudioNameWithLink.setLink(document.getImagePath());
                        imageOrAudioNameWithLink.setDownloadLink(document.getImagePath());
                        return imageOrAudioNameWithLink;
                    })
                    .toList();
            overviewDto.setDocuments(documentList);
        }


        if (dto.getNotifyTo() != null) {
            List<String> notifyToList = dto.getNotifyTo().stream()
                    .map(name->userManagementClient.getUserNameById(name.getUserId()).getName())
                    .toList();
            overviewDto.setNotifyTo(notifyToList);
        }

        if (dto.getAffectedPartiesAudio() != null) {
            List<ImageOrAudioNameWithLink> affectedPartiesAudio = dto.getAffectedPartiesAudio().stream()
                    .map(audio -> {
                        ImageOrAudioNameWithLink audioLink = new ImageOrAudioNameWithLink();
                        audioLink.setName(audio.getAudio());
                        audioLink.setLink(audio.getAudioPath());
                        audioLink.setDownloadLink(audio.getAudioPath());
                        return audioLink;
                    })
                    .toList();
            overviewDto.setAffectedPartiesAudio(affectedPartiesAudio);
        }

        if (dto.getPotentialImpactsAudio() != null) {
            List<ImageOrAudioNameWithLink> potentialImpactsAudio = dto.getPotentialImpactsAudio().stream()
                    .map(audio -> {
                        ImageOrAudioNameWithLink audioLink = new ImageOrAudioNameWithLink();
                        audioLink.setName(audio.getAudio());
                        audioLink.setLink(audio.getAudioPath());
                        audioLink.setDownloadLink(audio.getAudioPath());
                        return audioLink;
                    })
                    .toList();
            overviewDto.setPotentialImpactsAudio(potentialImpactsAudio);
        }

        if (dto.getImmediateResponsesAudio() != null) {
            List<ImageOrAudioNameWithLink> immediateResponsesAudio = dto.getImmediateResponsesAudio().stream()
                    .map(audio -> {
                        ImageOrAudioNameWithLink audioLink = new ImageOrAudioNameWithLink();
                        audioLink.setName(audio.getAudio());
                        audioLink.setLink(audio.getAudioPath());
                        audioLink.setDownloadLink(audio.getAudioPath());
                        return audioLink;
                    })
                    .toList();
            overviewDto.setImmediateResponsesAudio(immediateResponsesAudio);
        }

        if (dto.getDescriptions() != null) {
            List<ImageOrAudioNameWithLink> descriptions = dto.getDescriptions().stream()
                    .map(audio -> {
                        ImageOrAudioNameWithLink audioLink = new ImageOrAudioNameWithLink();
                        audioLink.setName(audio.getAudioName());
                        audioLink.setLink(audio.getAudioPath());
                        audioLink.setLink(audio.getAudioPath());
                        return audioLink;
                    })
                    .toList();
            overviewDto.setDescriptions(descriptions);
        }


        return overviewDto;
    }
}
