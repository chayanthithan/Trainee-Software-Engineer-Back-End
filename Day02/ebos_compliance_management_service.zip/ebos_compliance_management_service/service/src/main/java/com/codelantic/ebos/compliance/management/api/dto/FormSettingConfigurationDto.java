package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor
public class FormSettingConfigurationDto {
    private String fieldCategory;
    private List<FieldConfigurationDto> fieldDetails = new ArrayList<>();

    public FormSettingConfigurationDto(String fieldCategory,String id, String fieldName, String fieldType ) {
        this.fieldCategory = fieldCategory;
        FieldConfigurationDto fieldConfigurationDto = new FieldConfigurationDto();
        fieldConfigurationDto.setId(id);
        fieldConfigurationDto.setFieldName(fieldName);
        fieldConfigurationDto.setFieldType(fieldType);
        this.fieldDetails.add(fieldConfigurationDto);
    }

    public FormSettingConfigurationDto(String fieldCategory,String id, String fieldName, String fieldType,Boolean status) {
        this.fieldCategory = fieldCategory;
        FieldConfigurationDto fieldConfigurationDto = new FieldConfigurationDto();
        fieldConfigurationDto.setId(id);
        fieldConfigurationDto.setFieldName(fieldName);
        fieldConfigurationDto.setFieldType(fieldType);
        fieldConfigurationDto.setStatus(status);
        this.fieldDetails.add(fieldConfigurationDto);
    }

    public FormSettingConfigurationDto(String fieldCategory, List<FieldConfigurationDto> fieldDetails){
        this.fieldCategory = fieldCategory;
        this.fieldDetails = fieldDetails;

    }
}
