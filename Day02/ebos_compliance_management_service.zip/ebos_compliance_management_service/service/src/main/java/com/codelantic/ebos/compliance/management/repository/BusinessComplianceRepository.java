package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.BusinessComplianceConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface BusinessComplianceRepository extends JpaRepository<BusinessComplianceConfiguration, String> {

    boolean existsByComplianceIdAndBusinessId(Integer complianceId, String businessId);

    BusinessComplianceConfiguration findByComplianceIdAndBusinessId(Integer complianceId, String businessId);

   @Transactional
   @Modifying
   void deleteByBusinessIdAndComplianceId(String businessId,Integer complianceId);

    @Query("SELECT b.complianceId FROM BusinessComplianceConfiguration b WHERE b.businessId =:businessId ")
    List<String> getComplianceId(String businessId);
}
