package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.WasteManagementReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementReadingDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.WasteManagementReadingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class WasteManagementReadingService {

    private final WasteManagementReadingConverter wasteManagementReadingConverter;
    private final WasteManagementReadingRepository wasteManagementReadingRepository;

    public ResponseDto save(WasteManagementReadingDto wasteManagementReadingDto) {
        wasteManagementReadingRepository.save(wasteManagementReadingConverter.convert(wasteManagementReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(WasteManagementReadingDto wasteManagementReadingDto) {

        if (wasteManagementReadingDto.getId() == null) {
            throw new ServiceException("Waste management reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        WasteManagementReading existingReading = wasteManagementReadingRepository.findById(wasteManagementReadingDto.getId()).
                orElseThrow(() -> new ServiceException("training reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        wasteManagementReadingConverter.updateConvert(existingReading, wasteManagementReadingDto);
        wasteManagementReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public WasteManagementReadingDto getById(String id, ComplianceCategory complianceCategory) {
        WasteManagementReading wasteManagementReading = wasteManagementReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return wasteManagementReadingConverter.convert(wasteManagementReading);
    }
}
