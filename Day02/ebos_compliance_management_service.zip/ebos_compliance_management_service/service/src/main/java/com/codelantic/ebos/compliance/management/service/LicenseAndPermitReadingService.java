package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.LicenseAndPermitReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.LicensePermitOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.LicenseAndPermitReadingRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LicenseAndPermitReadingService {

    private final LicenseAndPermitReadingRepository licenseAndPermitReadingRepository;
    private final LicenseAndPermitReadingConverter licenseAndPermitReadingConverter;
    private final UserManagementClient userManagementClient;
    private final Validations validations;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;

    public ResponseDto save(LicenseAndPermitReadingDto licenseAndPermitReadingDto) {
        licenseAndPermitReadingRepository.save(licenseAndPermitReadingConverter.convert(licenseAndPermitReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }


    public Page<LicenseAndPermitReading> getAllLicenseAndPermitReading(LicensePermitOverviewSearchDto licensePermitOverviewSearchDto) {
        userManagementClient.checkBusinessId(licensePermitOverviewSearchDto.getBusinessId());
        validations.dateValidation(licensePermitOverviewSearchDto.getFromDate(), licensePermitOverviewSearchDto.getToDate());
        Pageable paging = PageRequest.of(licensePermitOverviewSearchDto.getPage() - 1, licensePermitOverviewSearchDto.getSize());
        boolean isFound = complianceSubCategoryRepository.existsByIdAndStatus(licensePermitOverviewSearchDto.getSubCategoryId(), true);
        if (!isFound) {
            throw new ServiceException("Compliance sub category id not found", ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
        }
        return licenseAndPermitReadingRepository.getAllLicenseAndPermitReading(licensePermitOverviewSearchDto.getBusinessId(),
                licensePermitOverviewSearchDto.getFromDate(), licensePermitOverviewSearchDto.getToDate(),
                licensePermitOverviewSearchDto.getEmployeeName(), licensePermitOverviewSearchDto.getComplianceStatus(), paging,
                licensePermitOverviewSearchDto.getSubCategoryId());
    }
    public ResponseDto update(LicenseAndPermitReadingDto licenseAndPermitReadingDto) {

        if (licenseAndPermitReadingDto.getId() == null) {
            throw new ServiceException("License and permit reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        LicenseAndPermitReading existingReading = licenseAndPermitReadingRepository.findById(licenseAndPermitReadingDto.getId()).
                orElseThrow(() -> new ServiceException("License and permit reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        licenseAndPermitReadingConverter.updateConvert(existingReading, licenseAndPermitReadingDto);
        licenseAndPermitReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public LicenseAndPermitReadingDto getById(String id, ComplianceCategory complianceCategory) {
        LicenseAndPermitReading licenseAndPermitReading = licenseAndPermitReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return licenseAndPermitReadingConverter.convert(licenseAndPermitReading);
    }

    public LicenseAndPermitReading getLicenseOverviewById(String id) {
        return licenseAndPermitReadingRepository.getLicenseOverviewById(id);
    }
}
