package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Entity
@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class IncidentReading {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String typeOfIncident;
    private String severity;
    private String department;
    private String location;
    private String description;
    private String supportingEvidence;
    private String affectedParties;
    private String potentialImpact;
    private String immediateResponse;
    private String comments;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<AffectedParties> affectedPartiesAudio;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<PotentialImpact> potentialImpactsAudio;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<ImmediateResponse> immediateResponsesAudio;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<Description> descriptions;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<NotifyTo> notifyTo;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "incidentReadingId")
    private Set<Documents> documents;
    private String complianceSubCategoryId;
    private String createdBy;
    private String reviewerComments;
    @Enumerated(EnumType.STRING)
    private ComplianceStatus complianceStatus;
}
