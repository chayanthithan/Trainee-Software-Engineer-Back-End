package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.TrainingTitleAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/training")
@RequiredArgsConstructor
@Validated
public class TrainingController {

    private final TrainingTitleAgent trainingTitleAgent;

    @PostMapping("/training-title")
    public ResponseDto saveTrainingTitle(@RequestBody @Valid TrainingTitleDto trainingTitleDto){
        return trainingTitleAgent.saveTrainingTitle(trainingTitleDto);
    }

    @GetMapping("/training-title")
    public List<TrainingTitleDto> getTrainingTitles(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business Id is required") String businessId){
        return trainingTitleAgent.getTrainingTitles(businessId);
    }

    @PostMapping("/training-material")
    public ResponseDto saveTrainingMaterialUsed(@RequestBody @Valid TrainingMaterialUsedDto trainingMaterialUsedDto) {
        return trainingTitleAgent.saveTrainingMaterialUsed(trainingMaterialUsedDto);
    }

    @GetMapping("/training-material")
    public List<ViewTrainingMaterialUsedDto> getTrainingMaterialUsed(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business Id is required") String businessId){
        return trainingTitleAgent.getTrainingMaterialUsed(businessId);
    }

    @PostMapping("/training-objectives")
    public ResponseDto saveTrainingObjectives (@RequestBody @Valid TrainingObjectivesDto trainingObjectivesDto){
        return trainingTitleAgent.saveTrainingObjectives(trainingObjectivesDto);
    }

    @GetMapping("/training-objectives")
    public List<TrainingObjectivesDto> getAllTrainingObjectives (@RequestParam @NotBlank(message = "Business id is required") String businessId){
        return trainingTitleAgent.getAllTrainingObjectives(businessId);
    }

    @GetMapping("/training-overview")
    public PaginatedResponseDto<TrainingReadingDto> getAllTrainingReadings (  TrainingOverViewSearchDto trainingOverViewSearchDto){
        return trainingTitleAgent.getAllTrainingReadings(trainingOverViewSearchDto);
    }

    @GetMapping("/get-overview-training-by-id")
    public TrainingReadingDto getOverviewTrainingById(@RequestParam(value = "id") String id,@RequestParam(value = "rowNo") String rowNo) {
        return trainingTitleAgent.getOverviewTrainingById(id,rowNo);
    }
}
