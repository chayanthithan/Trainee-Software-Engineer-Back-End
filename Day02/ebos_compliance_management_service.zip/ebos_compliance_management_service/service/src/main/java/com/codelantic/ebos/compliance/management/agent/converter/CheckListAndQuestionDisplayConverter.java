package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ChecklistAndQuestionDisplayDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class CheckListAndQuestionDisplayConverter {
    private final SubCategoryCheckListRepository subCategoryCheckListRepository;
    private final SubCategoryQuestionRepository subCategoryQuestionRepository;

    public List<ChecklistAndQuestionDisplayDto> convert(ComplianceReading complianceReading) {
        List<ChecklistAndQuestionDisplayDto> checklistAndQuestionDisplayDtos = new ArrayList<>();
        int checkListIteration = 0;
        for (CheckListReading checkListReading : complianceReading.getCheckListReadings()) {
            log.info("__________________,{}", checkListReading);
            ChecklistAndQuestionDisplayDto checklistAndQuestionDisplayDto = new ChecklistAndQuestionDisplayDto();
            Optional<SubCategoryCheckList> subCategoryCheckList = Optional.empty();
            if (checkListReading.getSubCategoryCheckListId() != null) {
                subCategoryCheckList = subCategoryCheckListRepository.findById(checkListReading.getSubCategoryCheckListId());
                log.info("______________,{}",subCategoryCheckList);
            }
            int finalCheckListIteration = checkListIteration;
            subCategoryCheckList.ifPresent(categoryCheckList -> checklistAndQuestionDisplayDto.setCheckListTitle(finalCheckListIteration == 0 ? categoryCheckList.getHeading():"" ));
            subCategoryCheckList.ifPresent(categoryCheckList -> checklistAndQuestionDisplayDto.setCheckListItems(categoryCheckList.getChecklist()));
            checklistAndQuestionDisplayDto.setNote(checkListReading.getComment());
            checklistAndQuestionDisplayDto.setResponse(Boolean.TRUE.equals(checkListReading.getIsChecked()) ? "checked" : "unchecked");
            checklistAndQuestionDisplayDto.setImage(checkListReading.getReadingImages().stream().map(ReadingImages::getImageName).collect(Collectors.joining(",")));
            checklistAndQuestionDisplayDtos.add(checklistAndQuestionDisplayDto);
            checkListIteration++;

        }
        processSubCategoryQuestions(complianceReading, checklistAndQuestionDisplayDtos);
        return checklistAndQuestionDisplayDtos;
    }
    private void processSubCategoryQuestions(ComplianceReading complianceReading, List<ChecklistAndQuestionDisplayDto> checklistAndQuestionDisplayDtos) {
        int subCategoryQuestionsReadings = 0;
        for (SubCategoryQuestionsReadings questionsReadings : complianceReading.getSubCategoryQuestionsReadings()) {
            ChecklistAndQuestionDisplayDto checklistAndQuestionDisplayDto = new ChecklistAndQuestionDisplayDto();
            Optional<SubCategoryQuestions> subCategoryQuestion = Optional.empty();

            if (questionsReadings.getSubCategoryQuestionsId() != null) {
                subCategoryQuestion = subCategoryQuestionRepository.findById(questionsReadings.getSubCategoryQuestionsId());
            }
            int finalSubCategoryQuestionsReadings = subCategoryQuestionsReadings;
            subCategoryQuestion.ifPresent(question -> {
                checklistAndQuestionDisplayDto.setCheckListTitle(finalSubCategoryQuestionsReadings==0?question.getQuestion():"");
                checklistAndQuestionDisplayDto.setCheckListItems(question.getHeading());
            });
            checklistAndQuestionDisplayDto.setNote(questionsReadings.getComment());
            checklistAndQuestionDisplayDto.setResponse(Objects.equals(questionsReadings.getYesOrNo(), "Yes") ? "yes" : "No");
            checklistAndQuestionDisplayDto.setImage(questionsReadings.getReadingImages().stream().map(ReadingImages::getImageName).collect(Collectors.joining(",")));
            checklistAndQuestionDisplayDtos.add(checklistAndQuestionDisplayDto);
            subCategoryQuestionsReadings++;
        }
}
}
