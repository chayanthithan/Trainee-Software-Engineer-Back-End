package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@RequiredArgsConstructor
@Slf4j
public class HealthAndSafetyConverter {
    private final UserManagementClient userManagementClient;
    private final CheckListReadingRepository checkListReadingRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final CheckListAndQuestionDisplayConverter checkListAndQuestionDisplayConverter;
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;

    public HealthAndSafetyOverViewDisplayDto convertToDto(ComplianceReading complianceReading) {
        HealthAndSafetyOverViewDisplayDto healthAndSafetyOverViewDisplayDto = HealthAndSafetyOverViewDisplayDto.builder()
                .id(complianceReading.getId())
                .date(complianceReading.getDate())
                .time(complianceReading.getTime())
                .complianceStatus(complianceReading.getComplianceStatus() != null ? complianceReading.getComplianceStatus().getMappedValue() : null)
                .subCategoryName(complianceSubCategoryRepository.getNameUsingId(complianceReading.getComplianceSubCategoryId()))
                .employeeName(userManagementClient.getUserNameById(complianceReading.getCreatedBy()).getName())
                .checklistAndQuestionDisplays(checkListAndQuestionDisplayConverter.convert(complianceReading))

                .build();


        TotalCheckedCountDto counts = checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(complianceReading.getId());
        Long total = counts.getTotalCount();
        Long totalChecked = counts.getCheckedCount();

        String pendingTotal = totalChecked + " / " + total;
        healthAndSafetyOverViewDisplayDto.setPendingTotal(total != 0 ? pendingTotal : "0");

        Set<ImageDescriptionDto> imageDescriptions = Stream.concat(
                        // using parallel stream for images from check list readings
                        complianceReading.getCheckListReadings().parallelStream()
                                .flatMap(checkListReading -> checkListReading.getReadingImages().parallelStream()),

                        // using parallel stream for images from sub category questions readings
                        complianceReading.getSubCategoryQuestionsReadings().parallelStream()
                                .flatMap(subCategoryQuestionsReading -> subCategoryQuestionsReading.getReadingImages().parallelStream())
                )
                .map(readingImage -> ImageDescriptionDto.builder()
                        .id(readingImage.getId())
                        .fileName(readingImage.getImageName())
                        .fullViewPath(baseUrl+readingImage.getImagePath())
                        .downloadPath(downloadBaseUrl+readingImage.getImagePath())
                        .build())
                .collect(Collectors.toSet());
        healthAndSafetyOverViewDisplayDto.setImages(imageDescriptions);
        return healthAndSafetyOverViewDisplayDto;
    }
}
