package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Set;

@Entity
@Data
public class Compliance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String complianceName;
    private Boolean status;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceId")
    private Set<BusinessComplianceConfiguration> businessComplianceConfigurations;
}
