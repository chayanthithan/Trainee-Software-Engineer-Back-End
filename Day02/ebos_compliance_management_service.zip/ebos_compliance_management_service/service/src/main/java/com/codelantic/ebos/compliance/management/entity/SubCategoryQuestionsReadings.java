package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.util.Set;

@Data
@Entity
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SubCategoryQuestionsReadings {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String yesOrNo;
    private String comment;
    private String subCategoryQuestionsId;
    private String complianceReadingId;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "questionsReadingId")
    private Set<ReadingImages> readingImages;
}
