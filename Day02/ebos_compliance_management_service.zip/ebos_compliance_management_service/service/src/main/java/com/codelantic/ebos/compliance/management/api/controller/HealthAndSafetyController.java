package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.HealthAndSafetyAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RequestMapping("api/v1/health-and-safety")
@RestController
@RequiredArgsConstructor
public class HealthAndSafetyController {
    private final HealthAndSafetyAgent healthAndSafetyAgent;

    @GetMapping("/get-all-health-and-safety")
    public PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> overViewForHealthAndSafety(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                       @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                       @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                       @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                       @RequestParam(value = "complianceStatus", required = false) String complianceStatus,
                                                                                       @RequestParam(value = "page") @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                       @RequestParam(value = "size") @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                       @RequestParam(value = "subCategoryId") String subCategoryId) {
        HealthAndSafetyOverviewSearchDto healthAndSafetyOverviewSearchDto = HealthAndSafetyOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .businessId(businessId)
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName)
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus) : null)
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .build();

        return healthAndSafetyAgent.getAllOverViewForHealthAndSafety(healthAndSafetyOverviewSearchDto);

    }

    @GetMapping("/get-overview-health-and-safety-by-id")
    public HealthAndSafetyOverViewDisplayDto getOverviewHealthAndSafetyById( @RequestParam(value = "id") String id) {
        return healthAndSafetyAgent.getOverviewHealthAndSafetyById(id);
    }
}
