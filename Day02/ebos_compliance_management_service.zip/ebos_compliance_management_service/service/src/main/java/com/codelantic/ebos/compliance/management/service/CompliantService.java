package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.ComplaintTypeSaveDto;
import com.codelantic.ebos.compliance.management.api.dto.CompliantOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.entity.CompliantType;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.CompliantReadingRepository;
import com.codelantic.ebos.compliance.management.repository.CompliantTypeRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class CompliantService {

    private final CompliantTypeRepository compliantTypeRepository;
    private final UserManagementClient userManagementClient;
    private final CompliantReadingRepository compliantReadingRepository;
    private final Validations validations;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;

    public ResponseDto saveComplaintType(CompliantType compliantType) {
        compliantTypeRepository.save(compliantType);
        return ResponseDto.builder()
                .message("Complaint Type saved")
                .build();

    }

    public List<ComplaintTypeSaveDto> getComplainType(String businessId) {
        userManagementClient.checkBusinessId(businessId);
        return compliantTypeRepository.getComplainType(businessId);
    }

    public Page<CompliantReading> getAllComplaints(CompliantOverviewSearchDto compliantOverviewSearchDto) {
        validations.dateValidation(compliantOverviewSearchDto.getFromDate(), compliantOverviewSearchDto.getToDate());
        Pageable paging = PageRequest.of(compliantOverviewSearchDto.getPage() - 1, compliantOverviewSearchDto.getSize());
        boolean isFound = complianceSubCategoryRepository.existsByIdAndStatus(compliantOverviewSearchDto.getComplianceSubCategoryId(), true);
        if (!isFound) {
            throw new ServiceException("Compliance sub category id not found", ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
        }

        return compliantReadingRepository.getAllComplaints(compliantOverviewSearchDto.getBusinessId(),compliantOverviewSearchDto.getComplianceSubCategoryId(), compliantOverviewSearchDto.getFromDate(), compliantOverviewSearchDto.getToDate(), compliantOverviewSearchDto.getEmployeeName(),compliantOverviewSearchDto.getComplianceStatus(), paging);
    }

    public CompliantReading getOverviewCompliantById(String id) {
        return compliantReadingRepository.getOverviewCompliantById(id)
                .orElseThrow(() -> new ServiceException("ComplianceReading not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));


    }
}
