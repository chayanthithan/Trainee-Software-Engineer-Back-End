package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TemperatureItemDto {
    private String id;
    private String item;
    private String recommendedStartTemperature;
    private String recommendedEndTemperature;
    private TemperatureType temperatureType;
    private int sequence;
    public TemperatureItemDto(String id,String item,String recommendedStartTemperature, String recommendedEndTemperature, TemperatureType temperatureType) {
        this.id=id;
        this.item = item;
        this.recommendedStartTemperature = recommendedStartTemperature;
        this.recommendedEndTemperature = recommendedEndTemperature;
        this.temperatureType = temperatureType;
    }
    public TemperatureItemDto(String id,String item,String recommendedStartTemperature, String recommendedEndTemperature, TemperatureType temperatureType,int sequence) {
        this.id=id;
        this.item = item;
        this.recommendedStartTemperature = recommendedStartTemperature;
        this.recommendedEndTemperature = recommendedEndTemperature;
        this.temperatureType = temperatureType;
        this.sequence=sequence;
    }

}
