package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceSubCategoryConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import com.codelantic.ebos.compliance.management.service.ComplianceSubCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ComplianceSubCategoryAgent {
    private final ComplianceSubCategoryService complianceSubCategoryService;
    private final ComplianceSubCategoryConverter complianceSubCategoryConverter;

    public ResponseDto saveComplianceSubCategory(ComplianceSubCategorySaveDto complianceSubCategorySaveDto) {
        return complianceSubCategoryService.saveComplianceSubCategory(complianceSubCategorySaveDto);
    }

    public List<SubCategoryDto> getSubCategories(Integer complianceId,String businessId) {
        return complianceSubCategoryService.getSubCategories(complianceId, businessId);
    }

    public ComplianceSubCategoryResponseDto getById(String subCategoryId) {
        ComplianceSubCategory complianceSubCategory = complianceSubCategoryService.getById(subCategoryId);
        return complianceSubCategoryConverter.convert(complianceSubCategory);
    }

    public ResponseDto updateComplianceSubCategory(ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto) {
        ComplianceSubCategory complianceSubCategory = complianceSubCategoryConverter.convertForUpdate(complianceSubCategoryUpdateDto);
        return complianceSubCategoryService.updateComplianceSubCategory(complianceSubCategory);
    }

    public List<FormSettingConfigurationDto> getAllByComplianceTypeId(Integer complianceId) {
     return complianceSubCategoryService.getAllByComplianceTypeId(complianceId);
    }

    public ResponseDto updateSubCategoryStatus(String subCategoryId, Boolean status) {
        return complianceSubCategoryService.updateSubCategoryStatus(subCategoryId,status);
    }
    public GetCheckListQuestionDto getCheckListAndQuestion(String complianceSubCategoryId) {
        ComplianceSubCategory complianceSubCategory= complianceSubCategoryService.getCheckListAndQuestion(complianceSubCategoryId);
        return complianceSubCategoryConverter.convertToCheckListQuestionDto(complianceSubCategory);
    }
}
