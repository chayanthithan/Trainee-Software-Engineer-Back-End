package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TrainingObjectivesDto;
import com.codelantic.ebos.compliance.management.entity.TrainingObjectives;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TrainingObjectivesRepository extends JpaRepository<TrainingObjectives,String> {
    Boolean existsByObjectivesOfTrainingAndBusinessId(String objectivesOfTraining, String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TrainingObjectivesDto(t.id,t.objectivesOfTraining) "+
            "FROM TrainingObjectives t "+
            "WHERE t.businessId IS NULL OR t.businessId =:businessId ")
    List<TrainingObjectivesDto> getAllTrainingObjectives(String businessId);
}
