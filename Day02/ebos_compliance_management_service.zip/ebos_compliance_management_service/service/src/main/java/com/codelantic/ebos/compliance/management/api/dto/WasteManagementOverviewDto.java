package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WasteManagementOverviewDto {
    private String rowNo;
    private String subCategoryName;
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String typeOfWastage;
    private String storageLocation;
    private String disposalMethod;
    private String productName;
    private Integer quantity;
    private Double unitCost;
    private String totalWasteValue;
    private String comments;
    private String complianceStatus;
    private Set<ImageDescriptionDto> images;
}
