package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public enum SupportingEvidence {
    CCTV("CCTV"),
    WITNESS_REPORT("Accident"),
    INDICATE_LOGS_OR_REPORTS("Indicate Logs/reports ");



    private final String mappedValue;

    SupportingEvidence(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static SupportingEvidence fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        for (SupportingEvidence supportingEvidence : SupportingEvidence.values()) {
            if (supportingEvidence.mappedValue.equalsIgnoreCase(mappedValue)) {
                return supportingEvidence;
            }
        }
        throw new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST);
    }


    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        for (SupportingEvidence supportingEvidence : SupportingEvidence.values()) {
            list.add(supportingEvidence.mappedValue);
        }
        return list;
    }
}
