package com.codelantic.ebos.compliance.management.validations;

import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.*;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import static com.codelantic.ebos.compliance.management.constants.ApplicationConstants.BAD_REQUEST;

@Component
@RequiredArgsConstructor
@Slf4j
public class Validations {

    private final TypeOfIncidentRepository typeOfIncidentRepository;
    private final TrainingTitleRepository trainingTitleRepository;
    private final DepartmentRepository departmentRepository;
    private final SeverityRepository severityRepository;
    private final TrainingMaterialUsedRepository trainingMaterialUsedRepository;
    private final TrainingObjectivesRepository trainingObjectivesRepository;
    private final LocationRepositoty locationRepositoty;
    private final VisitingTypeRepository visitingTypeRepository;
    private final TypeOfWasteRepository typeOfWasteRepository;
    private final CompliantTypeRepository compliantTypeRepository;

    private final UserManagementClient userManagementClient;

    private final BusinessComplianceRepository businessComplianceRepository;

    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;

    public void checkIncidentType(String incidentType, String businessId) {
        Boolean check = typeOfIncidentRepository.existsByIncidentTypeAndBusinessId(incidentType, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Incident Type Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkDeparment(String department, String businessId) {
        Boolean check = departmentRepository.existsByDepartmentNameAndBusinessId(department, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Department Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkTrainingTitleName(String trainingTitleName, String businessId) {
        Boolean check = trainingTitleRepository.existsByTrainingTitleNameAndBusinessId(trainingTitleName, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Training Title Name Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkVisitingType(String visitingType, String businessId) {
        Boolean check = visitingTypeRepository.existsByTypeOfVisitEqualsIgnoreCaseAndBusinessId(visitingType, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Visit Type Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkWasteType(String wasteType, String businessId) {
        Boolean check = typeOfWasteRepository.existsByWastTypesEqualsIgnoreCaseAndBusinessId(wasteType, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Waste Type Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void businessValidation(String businessId) {
        if (businessId == null) {
            throw new ServiceException("BusinessId Not Exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (!userManagementClient.checkBusinessId(businessId)) {
            throw new ServiceException("BusinessId Not belongs to User", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }

    }


    public void checkTrainingMaterialUsedName(String trainingMaterialUsedName, String businessId) {
        Boolean check = trainingMaterialUsedRepository.existsByTrainingMaterialUsedNameAndBusinessId(trainingMaterialUsedName, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Training Material Used Name Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkSeverityName(String severityName, String businessId) {
        Boolean result = severityRepository.existsBySeverityNameAndBusinessId(severityName, businessId);
        if (result == Boolean.TRUE) {
            throw new ServiceException("Severity name " + severityName + ", is already exist for this business id", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkObjectivesOfTraining(String businessId, String objectivesOfTraining) {
        Boolean output = trainingObjectivesRepository.existsByObjectivesOfTrainingAndBusinessId(objectivesOfTraining, businessId);
        if (output == Boolean.TRUE) {
            throw new ServiceException("Training objective " + objectivesOfTraining + ", is already exist for this business id", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkLocation(String location, String businessId) {
        Boolean check = locationRepositoty.existsByLocationNameAndBusinessId(location, businessId);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Location Already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkComplaintType(String typeOfCompliant, String businessId) {
        Boolean check = compliantTypeRepository.existsByBusinessIdAndTypeOfCompliantEqualsIgnoreCase(businessId, typeOfCompliant);
        if (check.equals(Boolean.TRUE)) {
            throw new ServiceException("Complaint Type already exist", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkByComplianceIdAndBusinessId(Integer complianceId, String businessId) {
        boolean check = businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceId, businessId);
        if (!check) {
            throw new ServiceException("Compliance Id not found", ApplicationConstants.BAD_REQUEST, HttpStatus.NOT_FOUND);
        }
    }

    public void checkTemperatureTypeAndComplianceSubCategoryId(String temperatureType, String businessId) {
        boolean check = temperatureTypeRangeRepository.existsByTemperatureTypeAndComplianceSubCategoryId(TemperatureType.fromMappedValue(temperatureType), businessId);
        if (check) {
            throw new ServiceException("Temperature Type already exists", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }


    public void checkByComplianceSubCategoryNameDuplication(Integer complianceId, String businessId, String subCategoryName) {
        boolean check = complianceSubCategoryRepository.existsByBusinessIdAndComplianceIdAndSubCategoryNameEqualsIgnoreCase(businessId, complianceId, subCategoryName);
        if (check) {
            throw new ServiceException("SubCategory Name Duplication", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void dateValidation(LocalDate fromDate, LocalDate toDate) {
        if (fromDate != null && toDate != null) {
            if (fromDate.isAfter(toDate)) {
                throw new ServiceException("Start date must be before end date", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
            if (toDate.isAfter(LocalDate.now())) {
                throw new ServiceException("End date must be on or before current date", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
        }
        if (fromDate != null && fromDate.isAfter(LocalDate.now())) {
            throw new ServiceException("Start must be on or before current date", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void checkByComplianceSubCategoryNameDuplicationWhileUpdate(Integer complianceId, String businessId, String subcategoryName, String id) {
        String previousName = complianceSubCategoryRepository.findBySubCategoryNameIgnoreCase(id);
        log.info("previous name is " + previousName);
        if (!previousName.equalsIgnoreCase(subcategoryName)) {
            boolean check = complianceSubCategoryRepository.existsByBusinessIdAndComplianceIdAndSubCategoryNameEqualsIgnoreCase(businessId, complianceId, subcategoryName);
            if (check) {
                throw new ServiceException("SubCategory Name Duplication", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
        }
    }

    public void validateTheFileFormat(List<MultipartFile> files) {
        // Validate file extensions
        files.stream()
                .map(MultipartFile::getOriginalFilename)
                .filter(Objects::nonNull)  // Ensure the file name is not null
                .filter(fileName -> !fileName.matches("(.+\\.(?i)(jpeg|jpg|png|pdf|doc|docx))$"))
                .findFirst()
                .ifPresent(fileName -> {
                    throw new ServiceException("Only PDF, DOC, DOCX, JPG, and PNG files are allowed", BAD_REQUEST, HttpStatus.BAD_REQUEST);
                });

    }
    public void validateAudioFileFormat(List<MultipartFile> audioFiles) {
        // Validate audio file extensions
        audioFiles.stream()
                .map(MultipartFile::getOriginalFilename)
                .filter(Objects::nonNull)  // Ensure the file name is not null
                .filter(fileName -> !fileName.matches("([^\\s]+(\\.(?i)(mp3|wav))$)"))
                .findFirst()
                .ifPresent(fileName -> {
                    throw new ServiceException("Only MP3 and WAV audio files are allowed", BAD_REQUEST, HttpStatus.BAD_REQUEST);
                });
    }

    public void checkChecklistIsCommentAvailableAndIsDocumentAvailable(Boolean isCommentAvailable, Boolean isDocumentAvailable ) {
        if (isCommentAvailable != null && isDocumentAvailable != null) {
            if (!(isCommentAvailable || isDocumentAvailable)) {
                throw new ServiceException(ApplicationConstants.TOAST_MESSAGE, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ServiceException("Comment and document availability cannot be null", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

}
