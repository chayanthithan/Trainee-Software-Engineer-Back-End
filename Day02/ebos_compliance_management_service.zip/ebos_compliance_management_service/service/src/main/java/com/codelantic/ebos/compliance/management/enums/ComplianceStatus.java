package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.Stream;

public enum ComplianceStatus {
    PENDING_REVIEW("Pending Review"),
    UNDER_REVIEW("Under Review"),
    COMPLIANCE_MET("Compliance Met"),
    COMPLIANCE_NOT_MET("Compliance Not Met"),
    REQUIRES_CLARIFICATION("Requires Clarification"),
    APPROVED("Approved"),
    REJECTED("Rejected");

    private final String mappedValue;

    ComplianceStatus(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static ComplianceStatus fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        return Stream.of(ComplianceStatus.values())
                .filter(status -> status.mappedValue.equalsIgnoreCase(mappedValue))
                .findFirst()
                .orElseThrow(() -> new ServiceException(
                        "Unsupported type: " + mappedValue,
                        "Bad request",
                        HttpStatus.BAD_REQUEST));
    }

    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        return Stream.of(ComplianceStatus.values())
                .map(ComplianceStatus::getMappedValue)
                .toList();
    }
}
