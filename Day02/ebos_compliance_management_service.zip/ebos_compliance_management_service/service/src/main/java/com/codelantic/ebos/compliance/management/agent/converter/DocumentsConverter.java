package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.api.dto.DocumentsLicenseDto;
import com.codelantic.ebos.compliance.management.entity.Documents;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DocumentsConverter {

    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;

    @Value("${sftp.base.url}")
    private String imagePath;

    public Documents convert(DocumentsDto documentsDto) {
        return Documents.builder()
                .id(documentsDto.getId())
                .imageName(documentsDto.getImageName())
                .imagePath(documentsDto.getImagePath())
                .trainingReadingId(documentsDto.getTrainingReadingId())
                .licenseAndPermitReadingId(documentsDto.getLicenseAndPermitReadingId())
                .wasteManagementReadingId(documentsDto.getWasteManagementReadingId())
                .incidentReadingId(documentsDto.getIncidentReadingId())
                .visitorReadingId(documentsDto.getVisitorReadingId())
                .complaintReadingId(documentsDto.getComplaintReadingId())
                .build();
    }

    public DocumentsDto convert(Documents documents) {
        return DocumentsDto.builder()
                .id(documents.getId())
                .imageName(documents.getImageName())
                .viewImagePath(imagePath+documents.getImagePath())
                .downloadImagePath(sftpUploadPath+documents.getImagePath())
                .trainingReadingId(documents.getTrainingReadingId())
                .licenseAndPermitReadingId(documents.getLicenseAndPermitReadingId())
                .wasteManagementReadingId(documents.getWasteManagementReadingId())
                .incidentReadingId(documents.getIncidentReadingId())
                .visitorReadingId(documents.getVisitorReadingId())
                .complaintReadingId(documents.getComplaintReadingId())
                .build();
    }

    public DocumentsLicenseDto convertForLicense(Documents documents) {
        return DocumentsLicenseDto.builder()
                .id(documents.getId())
                .imageName(documents.getImageName())
                .imageViewPath(imagePath+documents.getImagePath())
                .imageDownloadPath(sftpUploadPath+documents.getImagePath())
                .build();
    }


}
