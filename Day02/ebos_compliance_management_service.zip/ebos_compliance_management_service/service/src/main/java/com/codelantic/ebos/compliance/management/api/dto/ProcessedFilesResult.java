package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class ProcessedFilesResult {
    private final List<MultipartFile> renamedFiles;
    private final List<ImageResponseDto> imageResponseDtos;

    public ProcessedFilesResult(List<MultipartFile> renamedFiles, List<ImageResponseDto> imageResponseDtos) {
        this.renamedFiles = renamedFiles;
        this.imageResponseDtos = imageResponseDtos;
    }
}
