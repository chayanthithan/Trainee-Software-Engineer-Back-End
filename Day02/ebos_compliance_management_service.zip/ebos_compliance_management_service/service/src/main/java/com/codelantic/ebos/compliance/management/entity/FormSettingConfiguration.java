package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import java.util.List;

@Entity
@Data
public class FormSettingConfiguration {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String fieldName;
    private String fieldCategory;
    private String fieldType;
    private Integer complianceId;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "formSettingsConfigurationId")
    private List<SubCategoryFormConfigurations> subCategoryFormConfigurations;
}
