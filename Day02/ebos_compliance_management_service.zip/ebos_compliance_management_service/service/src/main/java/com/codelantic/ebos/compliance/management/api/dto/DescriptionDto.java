package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DescriptionDto {
    private String id;
    private String incidentReadingId;
    private String visitorReadingId;
    private String complaintReadingId;
    private String audioName;
    private String audioPath;
    private String viewAudioPath;
    private String downloadAudioPath;
}