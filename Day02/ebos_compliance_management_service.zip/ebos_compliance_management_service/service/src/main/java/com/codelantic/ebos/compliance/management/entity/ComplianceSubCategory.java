package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComplianceSubCategory {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String subCategoryName;
    private Integer complianceId;
    private Boolean isTemperature;
    private Boolean isCheckList;
    private Boolean isForm;
    private Boolean isYesOrNo;
    private String businessId;
    private Boolean isCheckThisBoxToAddCommentsToTheForm;
    private Boolean isDeclarationStatement;
    private Boolean status;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceSubCategoryId")
    private Set<SubCategoryCheckList> subCategoryCheckLists;
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "temperatureConfigurationsId")
    private TemperatureConfigurations temperatureConfigurations;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceSubCategoryId")
    private Set<SubCategoryQuestions> subCategoryQuestions;
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceSubCategoryId")
    private Set<SubCategoryFormConfigurations> subCategoryFormConfigurations;
    private LocalDate date;
    private LocalTime time;
}
