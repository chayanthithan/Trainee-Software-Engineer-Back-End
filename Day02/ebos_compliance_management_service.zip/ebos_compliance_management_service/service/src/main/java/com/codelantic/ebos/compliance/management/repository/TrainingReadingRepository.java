package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.TrainingReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface TrainingReadingRepository extends JpaRepository<TrainingReading,String> {

    @Query("SELECT tr FROM TrainingReading tr " +
            "JOIN ComplianceSubCategory cs ON tr.complianceSubCategoryId = cs.id " +
            "WHERE tr.complianceSubCategoryId = :subCategoryId " +
            "AND (cs.businessId = :businessId) " +
            "AND (:fromDate IS NULL OR :toDate IS NULL OR tr.date BETWEEN :fromDate AND :toDate) " +
            "AND ('All' IN :trainerId OR EXISTS(SELECT t FROM tr.trainers t WHERE t.id IN :trainerId)) " +
            "AND ('All' IN :participantId OR EXISTS(SELECT p FROM tr.participants p WHERE p.id IN :participantId)) " +
            "AND ( :complianceStatus IS NULL OR  tr.complianceStatus=:complianceStatus ) " +
            "AND (:organizedBy IS NULL OR tr.organizedBy LIKE CONCAT('%', :organizedBy, '%'))")
    Page<TrainingReading> findAllTrainingReadings(@Param("businessId")String businessId,
                                                  @Param("subCategoryId")String subCategoryId,
                                                  @Param("fromDate") Date fromDate,
                                                  @Param("toDate")Date toDate,
                                                  @Param("organizedBy")String organizedBy,
                                                  @Param("trainerId")List<String> trainerId,
                                                  @Param("participantId")List<String> participantId,
                                                  @Param("complianceStatus") ComplianceStatus complianceStatus,
                                                  Pageable pageable);







}
