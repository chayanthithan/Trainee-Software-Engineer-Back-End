package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.ComplaintConverter;
import com.codelantic.ebos.compliance.management.agent.converter.CompliantOverViewConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.service.CompliantService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
public class CompliantAgent {
    private final CompliantService compliantService;
    private final ComplaintConverter complaintConverter;
    private final CompliantOverViewConverter compliantOverViewConverter;

    public ResponseDto saveComplaintType(ComplaintTypeSaveDto complaintTypeSaveDto) {
        return compliantService.saveComplaintType(complaintConverter.convertToEntity(complaintTypeSaveDto));
    }

    public List<ComplaintTypeSaveDto> getComplainType(String businessId) {
        return compliantService.getComplainType(businessId);
    }

    public PaginatedResponseDto<CompliantOverViewDto> getAllComplaints(CompliantOverviewSearchDto compliantOverviewSearchDto) {
        Page<CompliantReading> compliantReadings= compliantService.getAllComplaints(compliantOverviewSearchDto);

        List<CompliantOverViewDto> compliantOverViewDtos = compliantReadings.getContent().stream()
                .map(compliantOverViewConverter::convertToDto).toList();

        List<CompliantOverViewDto> compliantOverViewDtosWithRowNo = IntStream.range(0, compliantOverViewDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (compliantOverviewSearchDto.getPage() - 1) * compliantOverviewSearchDto.getSize();
                    compliantOverViewDtos.get(i).setRowNo(String.format("%02d", rowNo));  // Format rowNo to start from "01"
                    return compliantOverViewDtos.get(i);
                })
                .toList();

        return PaginatedResponseDto.<CompliantOverViewDto>builder()
                .data(compliantOverViewDtosWithRowNo)
                .currentPage(compliantOverviewSearchDto.getPage())
                .totalPages(compliantReadings.getTotalPages())
                .totalItems(compliantReadings.getTotalElements())
                .build();
    }

    public CompliantOverViewDto getOverviewCompliantById(String id) {
        CompliantReading compliantReading=  compliantService.getOverviewCompliantById(id);
        return compliantOverViewConverter.convertToDto(compliantReading);

    }
}
