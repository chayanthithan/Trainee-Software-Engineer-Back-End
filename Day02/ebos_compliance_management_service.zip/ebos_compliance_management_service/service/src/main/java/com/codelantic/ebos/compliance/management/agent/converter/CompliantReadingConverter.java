package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CompliantReadingDto;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CompliantReadingConverter {

    private final DocumentsConverter documentsConverter;
    private final NotifyToConverter notifyToConverter;
    private final DescriptionConverter descriptionConverter;

    public CompliantReading convert(CompliantReadingDto compliantReadingDto) {
         String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return CompliantReading.builder()
                .id(compliantReadingDto.getId())
                .fullName(compliantReadingDto.getFullName())
                .date(compliantReadingDto.getDate())
                .time(compliantReadingDto.getTime())
                .compliantType(compliantReadingDto.getCompliantType())
                .comments(compliantReadingDto.getComments())
                .complianceSubCategoryId(compliantReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .documents(compliantReadingDto.getDocuments() != null ? compliantReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(compliantReadingDto.getNotifyTo() != null ? compliantReadingDto.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .description(compliantReadingDto.getDescription())
                .descriptions(compliantReadingDto.getDescriptions() != null ? compliantReadingDto.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .complianceStatus(ComplianceStatus.fromMappedValue(compliantReadingDto.getComplianceStatus()))
                .reviewerComments(compliantReadingDto.getReviewerComments())
                .build();
    }

    public CompliantReadingDto convert(CompliantReading compliantReading) {
        return CompliantReadingDto.builder()
                .id(compliantReading.getId())
                .fullName(compliantReading.getFullName())
                .date(compliantReading.getDate())
                .time(compliantReading.getTime())
                .compliantType(compliantReading.getCompliantType())
                .comments(compliantReading.getComments())
                .documents(compliantReading.getDocuments()!=null? compliantReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(compliantReading.getNotifyTo()!=null? compliantReading.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .description(compliantReading.getDescription())
                .descriptions(compliantReading.getDescriptions()!=null? compliantReading.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .complianceStatus(compliantReading.getComplianceStatus() != null ?
                        compliantReading.getComplianceStatus().getMappedValue() : null)
                .complianceSubCategoryId(compliantReading.getComplianceSubCategoryId())
                .createdBy(compliantReading.getCreatedBy())
                .reviewerComments(compliantReading.getReviewerComments())
                .build();
    }

    public void updateConvert(CompliantReading existingReading, CompliantReadingDto compliantReadingDto) {
        existingReading.setId(compliantReadingDto.getId());
        existingReading.setFullName(compliantReadingDto.getFullName());
        existingReading.setDate(compliantReadingDto.getDate());
        existingReading.setTime(compliantReadingDto.getTime());
        existingReading.setCompliantType(compliantReadingDto.getCompliantType());
        existingReading.setComments(compliantReadingDto.getComments());
        existingReading.setReviewerComments(compliantReadingDto.getReviewerComments());

        if (compliantReadingDto.getDocuments() != null) {
            existingReading.setDocuments(compliantReadingDto.getDocuments().stream()
                    .map(documentsConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (compliantReadingDto.getNotifyTo() != null) {
            existingReading.setNotifyTo(compliantReadingDto.getNotifyTo().stream()
                    .map(notifyToConverter::convert)
                    .collect(Collectors.toSet()));
        }

        existingReading.setDescription(compliantReadingDto.getDescription());

        if (compliantReadingDto.getDescriptions() != null) {
            existingReading.setDescriptions(compliantReadingDto.getDescriptions().stream()
                    .map(descriptionConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
