package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface WasteManagementReadingRepository extends JpaRepository<WasteManagementReading,String> {

    @Query("SELECT wr FROM WasteManagementReading wr " +
            "LEFT JOIN ComplianceSubCategory cs ON cs.id = wr.complianceSubCategoryId " +
            "WHERE cs.businessId = :businessId " +
            "AND wr.complianceSubCategoryId = :complianceSubCategoryId " +
            "AND (wr.date BETWEEN :fromDate AND :toDate) " +
            "AND (:employeeName IS NULL OR wr.createdBy = :employeeName) " +
            "AND (:complianceStatus IS NULL OR wr.complianceStatus = :complianceStatus)")
    Page<WasteManagementReading> getAllWasteOverview(String businessId,String complianceSubCategoryId, String employeeName, LocalDate fromDate, LocalDate toDate, ComplianceStatus complianceStatus, Pageable paging);


    @Query("SELECT wr FROM WasteManagementReading wr " +
            " where wr.id=:id " )
    WasteManagementReading getOverviewWasteById(String id);
}
