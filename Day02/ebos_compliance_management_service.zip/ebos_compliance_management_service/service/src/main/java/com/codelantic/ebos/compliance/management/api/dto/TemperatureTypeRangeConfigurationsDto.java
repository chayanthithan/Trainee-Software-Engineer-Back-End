package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class TemperatureTypeRangeConfigurationsDto {
    private String id;
    private String temperatureConfigurationsId;
    private String items;
    private String temperatureTypeRangeId;
    private Boolean status;
    private String startTemperature;
    private String endTemperature;
    private String temperatureType;
}
