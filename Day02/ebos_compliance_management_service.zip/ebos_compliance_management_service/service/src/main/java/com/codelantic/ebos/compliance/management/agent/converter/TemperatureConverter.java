package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureReadingRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class TemperatureConverter {

    private final TemperatureReadingRepository temperatureReadingRepository;
    private final UserManagementClient userManagementClient;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final ComplianceReadingRepository complianceReadingRepository;
    private  final TemperatureReadingConverter temperatureReadingConverter;
    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;

    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;



    public TemperatureTypeRange convert(TemperatureTypeRangeDto temperatureTypeRangeDto) {
        return TemperatureTypeRange.builder()
                .id(temperatureTypeRangeDto.getId())
                .temperatureType(TemperatureType.fromMappedValue(temperatureTypeRangeDto.getTemperatureType()))
                .startTemperature(temperatureTypeRangeDto.getStartTemperature())
                .endTemperature(temperatureTypeRangeDto.getEndTemperature())
                .status(Boolean.TRUE)
                .complianceSubCategoryId(temperatureTypeRangeDto.getComplianceSubCategoryId())
                .build();
    }

    public void convert(TemperatureTypeRange existingTemperatureTypeRange, TemperatureTypeRangeDto newTemperatureTypeRange) {
        existingTemperatureTypeRange.setId(newTemperatureTypeRange.getId());
        existingTemperatureTypeRange.setTemperatureType(TemperatureType.fromMappedValue(newTemperatureTypeRange.getTemperatureType()));
        existingTemperatureTypeRange.setStartTemperature(newTemperatureTypeRange.getStartTemperature());
        existingTemperatureTypeRange.setEndTemperature(newTemperatureTypeRange.getEndTemperature());
    }

    public List<TemperatureTypeRange> convert(List<TemperatureTypeRangeDto> temperatureTypeRangeDtos) {
        return temperatureTypeRangeDtos.stream()
                .map(this::convert)
                .toList();
    }

    public TemperatureTypeRangeDto convertToDto(TemperatureTypeRange temperatureTypeRange) {
        return TemperatureTypeRangeDto.builder()
                .id(temperatureTypeRange.getId())
                .temperatureType(temperatureTypeRange.getTemperatureType() != null ? temperatureTypeRange.getTemperatureType().getMappedValue() : null)
                .startTemperature(temperatureTypeRange.getStartTemperature())
                .endTemperature(temperatureTypeRange.getEndTemperature())
                .status(temperatureTypeRange.getStatus())
                .complianceSubCategoryId(temperatureTypeRange.getComplianceSubCategoryId())
                .build();
    }

    public TemperatureConfigurations convert(TemperatureSaveDto temperatureSaveDto) {
        return TemperatureConfigurations.builder()
                .isRequiredQuantityBasedTempReading(temperatureSaveDto.getIsRequiredQuantityBasedTemperatureReading())
                .temperatureTypeRangeConfigurations(
                        temperatureSaveDto.getTemperatureTypeRangeConfigurationDtos().stream()
                                .map(dto -> TemperatureTypeRangeConfigurations.builder()
                                        .id(dto.getId())
                                        .items(dto.getItems())
                                        .status(Boolean.TRUE)
                                        .temperatureTypeRangeId(dto.getTemperatureTypeRangeId())
                                        .sequence(dto.getSequence())
                                        .build()
                                ).collect(Collectors.toSet())
                )
                .build();
    }

    public TemperatureConfigurationsDto convert(TemperatureConfigurations temperatureConfigurations) {
        List<TemperatureTypeRangeConfigurationsDto> sortedList = temperatureConfigurations
                .getTemperatureTypeRangeConfigurations()
                .stream()
                .sorted(Comparator.comparingInt(dto -> dto.getSequence()))
                .map(this::convertTemperatureTypeRange)
                .toList();
        Set<TemperatureTypeRangeConfigurationsDto> orderedSet = new LinkedHashSet<>(sortedList);

        return TemperatureConfigurationsDto.builder()
                .id(temperatureConfigurations.getId())
                .isRequiredQuantityBasedTempReading(temperatureConfigurations.getIsRequiredQuantityBasedTempReading())
                .temperatureTypeRangeConfigurations(orderedSet)
                .build();
    }

    private TemperatureTypeRangeConfigurationsDto convertTemperatureTypeRange(TemperatureTypeRangeConfigurations configurations) {
        TemperatureTypeRange temperatureTypeRange = temperatureTypeRangeRepository.findById(configurations.getTemperatureTypeRangeId()).orElse(null);
        return TemperatureTypeRangeConfigurationsDto.builder()
                .id(configurations.getId())
                .temperatureConfigurationsId(configurations.getTemperatureConfigurationsId())
                .items(configurations.getItems())
                .status(Boolean.TRUE)
                .startTemperature(temperatureTypeRange!=null? temperatureTypeRange.getStartTemperature() : null)
                .endTemperature(temperatureTypeRange!=null? temperatureTypeRange.getEndTemperature() : null)
                .temperatureTypeRangeId(configurations.getTemperatureTypeRangeId())
                .temperatureType(temperatureTypeRange != null && temperatureTypeRange.getTemperatureType() != null ? temperatureTypeRange.getTemperatureType().getMappedValue() : null)
                .build();
    }

    public TemperatureOverviewDto getAllTemperatureOverviewRow(ComplianceReading complianceReading) {
        TemperatureOverviewDto temperatureOverviewDto = new TemperatureOverviewDto();
        temperatureOverviewDto.setId(complianceReading.getId());
        temperatureOverviewDto.setSubCategoryName(complianceSubCategoryRepository.getNameUsingId(complianceReading.getComplianceSubCategoryId()));
        temperatureOverviewDto.setDate(complianceReading.getDate());
        temperatureOverviewDto.setTime(complianceReading.getTime());
        temperatureOverviewDto.setComplianceStatus(complianceReading.getComplianceStatus() != null ? complianceReading.getComplianceStatus().getMappedValue() : null);
        UserName userName = userManagementClient.getUserNameById(complianceReading.getCreatedBy());
        temperatureOverviewDto.setEmployeeName(userName.getName());

        temperatureOverviewDto.setComments(complianceReading.getComments());

        // Processing temperature readings if present
        Set<TemperatureReading> temperatureReadings = complianceReading.getTemperatureReadings();
        if (temperatureReadings != null && !temperatureReadings.isEmpty()) {
            setTemperaturesForRowDowload(temperatureOverviewDto, temperatureReadings);
        }

        return temperatureOverviewDto;
    }

    private void setTemperaturesForRowDowload(TemperatureOverviewDto temperatureOverviewDto, Set<TemperatureReading> temperatureReadings) {
        List<TemperatureTypeOverviewDto> temperatureTypeOverviewDtos = temperatureReadings.stream()
                .map(temperatureReading -> {
                    TemperatureTypeOverviewDto temperatureTypeOverviewDto = temperatureReadingRepository.getTemperatureRowData(
                            temperatureReading.getComplianceSubCategoryId(), temperatureReading.getId());
                    if (temperatureTypeOverviewDto != null) {
                        if (temperatureReading.getReadingImages() != null && !temperatureReading.getReadingImages().isEmpty()) {
                            Set<ReadingImages> readingImagesSet = temperatureReading.getReadingImages();
                            if (readingImagesSet != null && !readingImagesSet.isEmpty()) {
                                List<ImageOrAudioNameWithLink> imageOrAudioNameWithLinks = readingImagesSet.stream()
                                        .map(image -> new ImageOrAudioNameWithLink(image.getImageName(), image.getImagePath(), image.getImagePath()))
                                        .toList();
                                temperatureTypeOverviewDto.setTemperatureOverviewDownloadDto(imageOrAudioNameWithLinks);
                            }
                        }
                        if (temperatureReading.getNotifyTo() != null && !temperatureReading.getNotifyTo().isEmpty()) {

                            setNotifyToForRowDownload(temperatureReading.getNotifyTo(), temperatureTypeOverviewDto);

                        }
                    }
                    return temperatureTypeOverviewDto;
                })
                .toList();

        temperatureOverviewDto.setTemperatureTypeOverviewDtos(temperatureTypeOverviewDtos);
    }

    private void setNotifyToForRowDownload(Set<NotifyTo> notifyToSet, TemperatureTypeOverviewDto temperatureTypeOverviewDto) {
        if (notifyToSet != null && !notifyToSet.isEmpty()) {
            List<String> notifyToUsernames = notifyToSet.stream()
                    .map(NotifyTo::getUserId)
                    .map(userManagementClient::getUserNameById)
                    .map(UserName::getName)
                    .toList();
            temperatureTypeOverviewDto.setNotifyTo(notifyToUsernames);
        }
    }

    public TemperatureOverviewDto convertToTemperatureOverviewDto(ComplianceReading complianceReading) {
        String subCategoryName =complianceSubCategoryRepository.getNameUsingId(complianceReading.getComplianceSubCategoryId());
        TemperatureOverviewDto temperatureOverviewDto = new TemperatureOverviewDto();

        if (complianceReading.getCreatedBy() != null) {
            UserName userName = userManagementClient.getUserNameById(complianceReading.getCreatedBy());
            temperatureOverviewDto.setEmployeeName(userName!=null?userName.getName():null   );
        }
        temperatureOverviewDto.setRowNo(1);
        temperatureOverviewDto.setId(complianceReading.getId());
        temperatureOverviewDto.setSubCategoryName(subCategoryName);
        temperatureOverviewDto.setDate(complianceReading.getDate());
        temperatureOverviewDto.setTime(complianceReading.getTime());
        temperatureOverviewDto.setComments(complianceReading.getComments());
        temperatureOverviewDto.setComplianceStatus(complianceReading.getComplianceStatus().getMappedValue());
        temperatureOverviewDto.setTemperatureTypeOverviewDtos(
                complianceReading.getTemperatureReadings() != null ?
                        complianceReading.getTemperatureReadings().stream()
                                .map(this::convertToTemperatureTypeOverviewDto)
                                .toList()
                        : Collections.emptyList()
        );

        return temperatureOverviewDto;
    }

    private TemperatureTypeOverviewDto convertToTemperatureTypeOverviewDto(TemperatureReading temperatureReading) {
        TempreatureReadingGetDto tempreatureReadingGetDto =temperatureReadingConverter.convertTempreature(temperatureReading);
        TemperatureTypeOverviewDto temperatureTypeOverviewDto = new TemperatureTypeOverviewDto();
        temperatureTypeOverviewDto.setId(tempreatureReadingGetDto.getId());
        temperatureTypeOverviewDto.setItemName(tempreatureReadingGetDto.getItem());
        temperatureTypeOverviewDto.setTemperatureType(tempreatureReadingGetDto.getTempreatureType());
        temperatureTypeOverviewDto.setStartTemperature(tempreatureReadingGetDto.getStartTempreature());
        temperatureTypeOverviewDto.setEndTemperature(tempreatureReadingGetDto.getEndTempreature());
        temperatureTypeOverviewDto.setTemperature(tempreatureReadingGetDto.getActualReading());
        temperatureTypeOverviewDto.setQuantity(tempreatureReadingGetDto.getQuantity());
        temperatureTypeOverviewDto.setImages(tempreatureReadingGetDto.getReadingImages()!=null?tempreatureReadingGetDto.getReadingImages().stream()
                .map(ReadingImagesDto::getImageName)
                .collect(Collectors.joining(", ")):null);
        temperatureTypeOverviewDto.setNotifyTo(
                temperatureReading.getNotifyTo() != null
                        ? temperatureReading.getNotifyTo().stream()
                        .map(NotifyTo::getUserId)
                        .filter(Objects::nonNull)
                        .map(userId -> {
                            UserName userName = userManagementClient.getUserNameById(userId);
                            return userName.getName();
                        })
                        .toList()
                        : null
        );

        temperatureTypeOverviewDto.setTemperatureOverviewDownloadDto(temperatureReading.getReadingImages().stream()
                .map(image -> new ImageOrAudioNameWithLink(image.getImageName(),  baseUrl+ image.getImagePath(), downloadBaseUrl+ image.getImagePath()))
                .toList());

        return temperatureTypeOverviewDto;

    }




}
