package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCheckListQuestionDto {
    private List<CheckListDto> checkLists;
    private List<QuestionsDto> questionsLists;
    private TemperatureReadingConfigurationsDto temperatureReadingConfigurationsDto;
    private Boolean isCommentAvailable;
    private Boolean isDeclarationAvailable;
    private Boolean isRequiredQuantityBasedTempReading;
}
