package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.TypeOfWasteDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.TypeOfWaste;
import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.TypeOfWasteRepository;
import com.codelantic.ebos.compliance.management.repository.WasteManagementReadingRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WasteManagementService {

    private final Validations validations;
    private final TypeOfWasteRepository typeOfWasteRepository;
    private final UserManagementClient userManagementClient;
    private final WasteManagementReadingRepository wasteManagementReadingRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;


    public ResponseDto addNewWasteType(TypeOfWaste typeOfWaste){
        validations.businessValidation(typeOfWaste.getBusinessId());
        validations.checkWasteType(typeOfWaste.getWastTypes(),typeOfWaste.getBusinessId());
        typeOfWasteRepository.save(typeOfWaste);
        return ResponseDto.builder()
                .message("WasteType Added")
                .build();
    }

    public List<TypeOfWasteDto> getAllWasteType(String businessId){
        validations.businessValidation(businessId);
        return typeOfWasteRepository.getAllTypeOfWastes(businessId);
    }


    public Page<WasteManagementReading> getAllWasteOverview(WasteManagementOverviewSearchDto wasteManagementOverviewSearchDto) {
        validations.dateValidation(wasteManagementOverviewSearchDto.getFromDate(), wasteManagementOverviewSearchDto.getToDate());
        Pageable paging = PageRequest.of(wasteManagementOverviewSearchDto.getPage() - 1, wasteManagementOverviewSearchDto.getSize());
        boolean isFound = complianceSubCategoryRepository.existsByIdAndStatus(wasteManagementOverviewSearchDto.getComplianceSubCategoryId(), Boolean.TRUE);
        if (!isFound) {
            throw new ServiceException("Compliance sub category id not found", ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
        }

        return wasteManagementReadingRepository.getAllWasteOverview(wasteManagementOverviewSearchDto.getBusinessId(),wasteManagementOverviewSearchDto.getComplianceSubCategoryId(),wasteManagementOverviewSearchDto.getEmployeeName(),wasteManagementOverviewSearchDto.getFromDate(),wasteManagementOverviewSearchDto.getToDate(),wasteManagementOverviewSearchDto.getComplianceStatus(),paging);

    }

    public WasteManagementReading getOverviewWasteById(String id) {
        return wasteManagementReadingRepository.getOverviewWasteById(id);

    }
}
