package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TrainerDto;
import com.codelantic.ebos.compliance.management.entity.Trainer;
import org.springframework.stereotype.Component;

@Component
public class TrainerConverter {

    public Trainer convert(TrainerDto trainerDto) {
        return Trainer.builder()
                .id(trainerDto.getId())
                .trainerId(trainerDto.getTrainerId())
                .trainingReadingId(trainerDto.getTrainingReadingId())
                .build();
    }

    public TrainerDto convert(Trainer trainer) {
        return TrainerDto.builder()
                .id(trainer.getId())
                .trainerId(trainer.getTrainerId())
                .trainingReadingId(trainer.getTrainingReadingId())
                .build();
    }
}
