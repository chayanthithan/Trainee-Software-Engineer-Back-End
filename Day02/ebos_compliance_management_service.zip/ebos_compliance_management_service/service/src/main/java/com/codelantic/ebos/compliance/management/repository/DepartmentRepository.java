package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.ViewDepartmentDto;
import com.codelantic.ebos.compliance.management.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, String> {

    Boolean existsByDepartmentNameAndBusinessId(String department, String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ViewDepartmentDto(d.id,d.departmentName) " +
            "FROM Department d " +
            "WHERE d.businessId IS NULL OR d.businessId =:businessId ")
    List<ViewDepartmentDto> getAllDepartment(String businessId);
}
