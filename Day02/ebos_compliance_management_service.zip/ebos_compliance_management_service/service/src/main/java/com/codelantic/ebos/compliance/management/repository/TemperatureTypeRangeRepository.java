package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.ImageOrAudioNameWithLink;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewAllDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeRangeDto;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface TemperatureTypeRangeRepository extends JpaRepository<TemperatureTypeRange, String> {

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeRangeDto(t.id,t.temperatureType,t.startTemperature,t.endTemperature,t.status,t.complianceSubCategoryId) " +
            "FROM TemperatureTypeRange t " +
            "WHERE t.complianceSubCategoryId = :complianceSubCategoryId")
    List<TemperatureTypeRangeDto> getAllTemperatureRangeDto(String complianceSubCategoryId);


    boolean existsByTemperatureTypeAndComplianceSubCategoryId(TemperatureType temperatureType, String complianceSubCategoryId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto(tr.id,ttrc.items, ttr.temperatureType, ttr.startTemperature, ttr.endTemperature, tr.actualReading, tr.quantity) " +
            "FROM TemperatureTypeRange ttr " +
            "LEFT JOIN TemperatureTypeRangeConfigurations ttrc ON ttr.id = ttrc.temperatureTypeRangeId " +
            "LEFT JOIN TemperatureReading tr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
            "LEFT JOIN ComplianceReading cr ON tr.complianceReadingId = cr.id " +
            "LEFT JOIN NotifyTo n ON tr.id = n.temperatureReadingId " +
            "WHERE cr.businessId = :businessId " +
            "AND cr.complianceSubCategoryId = :subCategoryId " +
            "AND cr.date BETWEEN :fromDate AND :toDate " +
            "AND (:complianceStatus IS NULL OR cr.complianceStatus = :complianceStatus) " +
            "AND ('ALL' IN :employeeIds OR cr.createdBy IN :employeeIds) " +
            "AND ('ALL' IN :notifyTos OR n.userId IN :notifyTos) ")
    List<TemperatureTypeOverviewDto> getAllTemperatureTypeOverView(String businessId, String subCategoryId, LocalDate fromDate, LocalDate toDate, ComplianceStatus complianceStatus, List<String> employeeIds, List<String> notifyTos);


    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto(ttrc.id,tr.id, ttrc.items, ttr.temperatureType, ttr.startTemperature, ttr.endTemperature, tr.actualReading, tr.quantity,ttrc.sequence) " +
            "FROM TemperatureTypeRange ttr " +
            "LEFT JOIN TemperatureTypeRangeConfigurations ttrc ON ttr.id = ttrc.temperatureTypeRangeId " +
            "LEFT JOIN TemperatureReading tr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
            "LEFT JOIN ComplianceReading cr ON tr.complianceReadingId = cr.id " +
            "LEFT JOIN NotifyTo n ON tr.id = n.temperatureReadingId " +
            "WHERE cr.id = :complianceReadingId " +
            "GROUP BY ttrc.id ")
    List<TemperatureTypeOverviewDto> getTemperatureTypeOverView(String complianceReadingId);
    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewAllDto(ttrc.id,ttrc.items, ttr.temperatureType, ttr.startTemperature, ttr.endTemperature,ttrc.sequence) " +
            "FROM TemperatureTypeRange ttr " +
            "LEFT JOIN TemperatureTypeRangeConfigurations ttrc ON ttr.id = ttrc.temperatureTypeRangeId " +
            "LEFT JOIN TemperatureReading tr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
            "WHERE tr.complianceSubCategoryId = :complianceSubcategoryId " +
            "GROUP BY ttrc.id ")
    List<TemperatureTypeOverviewAllDto> getAllTemperatureTypeOverView(String complianceSubcategoryId);


    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ImageOrAudioNameWithLink(ri.imageName, ri.imagePath, ri.imagePath) " +
            "FROM ReadingImages ri " +
            "WHERE ri.temperatureReadingId = :temperatureReadingId")
    List<ImageOrAudioNameWithLink> findReadingImagesByTemperatureReadingId(String temperatureReadingId);

    List<TemperatureTypeRange> findByComplianceSubCategoryId(String complianceSubCategoryId);
}
