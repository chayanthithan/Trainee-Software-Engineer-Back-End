package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class Documents {
    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private String imageName;
    private String imagePath;
    private String trainingReadingId;
    private String licenseAndPermitReadingId;
    private String wasteManagementReadingId;
    private String incidentReadingId;
    private String visitorReadingId;
    private String complaintReadingId;
    private Integer imageNumber;

}
