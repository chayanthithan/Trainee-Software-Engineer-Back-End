package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.repository.PestControlRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PestControlService {
    private final PestControlRepository pestControlRepository;
    private final Validations validations;

    public Page<ComplianceReading> getAll(WasteManagementOverviewSearchDto searchDto) {
        validations.dateValidation(searchDto.getFromDate(), searchDto.getToDate());

        Pageable paging = PageRequest.of(searchDto.getPage() - 1, searchDto.getSize());
        return pestControlRepository.getAll(searchDto.getComplianceSubCategoryId(),
                searchDto.getEmployeeName(), searchDto.getFromDate(), searchDto.getToDate(),
                searchDto.getComplianceStatus(), paging);

    }

    public ComplianceReading getOverViewById(String id) {
        return pestControlRepository.getOverViewById(id);
    }
}
