package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CheckListReadingRepository extends JpaRepository<CheckListReading, String> {
    @Query("SELECT new com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto(count(c), sum(case when c.isChecked = true then 1 else 0 end)) " +
            "FROM CheckListReading c WHERE c.complianceReadingId = :id")
    TotalCheckedCountDto findTotalAndCheckedCountByComplianceReadingId(@Param("id") String id);

}
