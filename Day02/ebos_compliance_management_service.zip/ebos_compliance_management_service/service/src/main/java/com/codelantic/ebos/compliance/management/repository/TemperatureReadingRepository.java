package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.TemperatureReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface TemperatureReadingRepository extends JpaRepository<TemperatureReading,String> {

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureOverviewDto(c.id,c.date, c.time, c.createdBy, c.complianceStatus, c.comments,ttrc.id) " +
            "FROM TemperatureReading t " +
            "LEFT JOIN TemperatureTypeRangeConfigurations  ttrc ON t.temperatureTypeRangeConfigurationsId = ttrc.id " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE (c.businessId = :businessId) " +
            "AND (c.complianceSubCategoryId = :subCategoryId) " +
            "AND (c.date BETWEEN :fromDate AND :toDate) " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND ('ALL' IN :employeeIds OR c.createdBy IN :employeeIds) " +
            "AND ('ALL' IN :notifyTos OR n.userId IN :notifyTos) " +
            "GROUP BY c.id order by c.date DESC, c.time DESC")
    Page<TemperatureOverviewDto> getAllTemperatureOverview(String businessId, String subCategoryId, LocalDate fromDate, LocalDate toDate, Pageable pageable,ComplianceStatus complianceStatus,List<String> employeeIds,List<String> notifyTos);

    @Query("SELECT n.userId " +
            "FROM TemperatureReading t " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE c.businessId = :businessId " +
            "AND t.complianceSubCategoryId = :subCategoryId " +
            "AND c.date BETWEEN :fromDate AND :toDate " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND ('ALL' IN :employeeIds OR c.createdBy IN :employeeIds) " +
            "AND ('ALL' IN :notifyTos OR n.userId IN :notifyTos) ")
    List<String> getNotifyTo(String businessId, String subCategoryId, LocalDate fromDate, LocalDate toDate,
                             ComplianceStatus complianceStatus, List<String> employeeIds, List<String> notifyTos);


    @Query("SELECT n.userId " +
            "FROM TemperatureReading t " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE t.id = :id " +
            "AND n.userId IS NOT NULL" )
    List<String> getTemperatureNotifyTo(String id);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.DeliveryOverviewDto(c.date, c.time, c.createdBy, c.complianceStatus, c.comments) " +
            "FROM TemperatureReading t " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE (t.complianceSubCategoryId = :subCategoryId) " +
            "AND (c.date BETWEEN :fromDate AND :toDate) " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND 'ALL' IN :employeeIds OR c.createdBy IN :employeeIds " +
            "AND 'ALL' IN :notifyTos OR n.id IN :notifyTos ")
    Page<DeliveryOverviewDto> getAllDeliveryOverview( String subCategoryId, LocalDate fromDate, LocalDate toDate, Pageable pageable, ComplianceStatus complianceStatus, List<String> employeeIds, List<String> notifyTos);


    @Query("SELECT n.userId " +
            "FROM TemperatureReading t " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE (t.complianceSubCategoryId = :subCategoryId ) " +
            "AND c.date BETWEEN :fromDate AND :toDate " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND ('ALL' IN :employeeIds OR c.createdBy IN :employeeIds) " +
            "AND ('ALL' IN :notifyTos OR n.id IN :notifyTos) ")
    List<String> getNotifyTo(String subCategoryId, LocalDate fromDate, LocalDate toDate,
                             ComplianceStatus complianceStatus, List<String> employeeIds, List<String> notifyTos);


    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto(ttrc.items, ttr.temperatureType, ttr.startTemperature, ttr.endTemperature, tr.actualReading, tr.quantity) " +
            "FROM TemperatureTypeRange ttr " +
            "LEFT JOIN TemperatureTypeRangeConfigurations ttrc ON ttr.id = ttrc.temperatureTypeRangeId " +
            "LEFT JOIN TemperatureReading tr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
            "LEFT JOIN ComplianceReading cr ON tr.complianceReadingId = cr.id " +
            "WHERE cr.complianceSubCategoryId = :complianceSubCategoryId " +
            "AND tr.id = :id " )
    TemperatureTypeOverviewDto getTemperatureRowData(String complianceSubCategoryId, String id);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ImageOrAudioNameWithLinkDto(r.imageName, r.imagePath, r.imagePath )" +
            "FROM TemperatureReading t " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "LEFT JOIN ReadingImages r ON t.id = r.temperatureReadingId " +
            "WHERE c.businessId = :businessId " +
            "AND t.complianceSubCategoryId = :subCategoryId " +
            "AND c.date BETWEEN :fromDate AND :toDate " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND ('ALL' IN :employeeIds OR c.createdBy IN :employeeIds) " +
            "AND ('ALL' IN :notifyTos OR n.id IN :notifyTos) ")
    List<ImageOrAudioNameWithLinkDto> getNotifyToAndImages(String businessId, String subCategoryId, LocalDate fromDate, LocalDate toDate,
                                                           ComplianceStatus complianceStatus, List<String> employeeIds, List<String> notifyTos);

    @Query("SELECT t FROM TemperatureReading t " +
            "LEFT JOIN ComplianceReading c ON t.complianceReadingId = c.id " +
            "LEFT JOIN NotifyTo n ON t.id = n.temperatureReadingId " +
            "WHERE c.businessId = :businessId " +
            "AND (t.complianceSubCategoryId = :subCategoryId) " +
            "AND (c.date BETWEEN :fromDate AND :toDate) " +
            "AND (:complianceStatus IS NULL OR c.complianceStatus = :complianceStatus) " +
            "AND 'ALL' IN :employeeIds OR c.createdBy IN :employeeIds " +
            "AND 'ALL' IN :notifyTos OR n.userId IN :notifyTos ")
    Page<TemperatureReading> getAllTemperatureOverviewBulg(String businessId, String subCategoryId, LocalDate fromDate, LocalDate toDate,ComplianceStatus complianceStatus,List<String> employeeIds,List<String> notifyTos,Pageable pageable);

    ComplianceReading findByComplianceReadingId(String complianceReadingId);

//    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto(tr.id,ttrc.items, ttr.temperatureType, ttr.startTemperature, ttr.endTemperature, tr.actualReading, tr.quantity,ttrc.id) " +
//            "FROM  TemperatureReading tr " +
//            "LEFT JOIN ComplianceReading cr ON tr.complianceReadingId = cr.id " +
//            "LEFT JOIN TemperatureTypeRangeConfigurations ttrc ON tr.temperatureTypeRangeConfigurationsId = ttrc.id " +
//            "LEFT JOIN TemperatureTypeRange ttr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
//            "LEFT JOIN NotifyTo n ON tr.id = n.temperatureReadingId " +
//            "WHERE cr.id = :complianceReadingId")
//    List<TemperatureTypeOverviewDto> getTemperatureTypeOverView( String complianceReadingId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto(ttrc.items, ttr.startTemperature, ttr.endTemperature,ttr.temperatureType,ttrc.id) " +
            "FROM TemperatureTypeRangeConfigurations ttrc " +
            "LEFT JOIN TemperatureTypeRange ttr ON ttrc.temperatureTypeRangeId = ttr.id " +
            "LEFT JOIN TemperatureReading tr ON ttrc.id = tr.temperatureTypeRangeConfigurationsId " +
            "LEFT JOIN ComplianceReading cr ON tr.complianceReadingId = cr.id " +
            "LEFT JOIN ComplianceSubCategory cs ON ttr.complianceSubCategoryId = cs.id " +
            "WHERE ttr.complianceSubCategoryId = :complianceSubCategoryId " +
            "AND cs.businessId = :businessId " +
            "AND (ttrc.id IS NOT NULL AND tr.temperatureTypeRangeConfigurationsId IS NULL)")
    List<TemperatureTypeOverviewDto> getNotAvailableTemperatureTypeRangeConfigurations(String businessId, String complianceSubCategoryId);

}
