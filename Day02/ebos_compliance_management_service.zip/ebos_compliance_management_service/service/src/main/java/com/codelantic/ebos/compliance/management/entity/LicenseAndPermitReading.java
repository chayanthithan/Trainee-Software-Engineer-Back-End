package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Entity
@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class LicenseAndPermitReading {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String licenseOrPermitName;
    private String licenseOrPermitNumber;
    private String typeOfLicenseOrPermit;
    private String issuingAuthority;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private LocalDate renewalDate;
    private String businessName;
    private String businessAddress;
    private String holdersName;
    private String contactPhoneNumber;
    private String contactEmail;
    private String conditionsOrRestrictions;
    private LocalDate renewalApplicationDedLine;
    private LocalDate reminderDate;
    private LocalTime reminderTime;
    private String comments;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "licenseAndPermitReadingId")
    private Set<ReminderTo> reminderTos;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "licenseAndPermitReadingId")
    private Set<Documents> documents;
    private String complianceSubCategoryId;
    private String createdBy;
    private String reviewerComments;
    @Enumerated(EnumType.STRING)
    private ComplianceStatus complianceStatus;
}
