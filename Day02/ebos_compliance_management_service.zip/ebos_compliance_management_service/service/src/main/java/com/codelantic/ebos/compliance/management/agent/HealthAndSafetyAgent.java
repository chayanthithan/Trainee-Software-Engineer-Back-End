package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.HealthAndSafetyConverter;
import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.HealthAndSafetyService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
public class HealthAndSafetyAgent {
    private static final Logger log = LoggerFactory.getLogger(HealthAndSafetyAgent.class);
    private final HealthAndSafetyService healthAndSafetyService;
    private final HealthAndSafetyConverter healthAndSafetyConverter;

    public PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> getAllOverViewForHealthAndSafety(HealthAndSafetyOverviewSearchDto healthAndSafetyOverviewSearchDto) {
        Page<ComplianceReading> complianceReadingPage = healthAndSafetyService.getAllOverViewForHealthAndSafety(healthAndSafetyOverviewSearchDto);

        List<HealthAndSafetyOverViewDisplayDto> healthAndSafetyOverViewDisplayDtos = complianceReadingPage.getContent().stream()
                .map(healthAndSafetyConverter::convertToDto)
                .toList();

        List<HealthAndSafetyOverViewDisplayDto> healthAndSafetyOverViewWithRowNo = IntStream.range(0, healthAndSafetyOverViewDisplayDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (healthAndSafetyOverviewSearchDto.getPage() - 1) * healthAndSafetyOverviewSearchDto.getSize();
                    healthAndSafetyOverViewDisplayDtos.get(i).setRowNo(String.format("%02d", rowNo));
                    return healthAndSafetyOverViewDisplayDtos.get(i);
                })
                .toList();

        log.info("________test___________{}",healthAndSafetyOverViewWithRowNo);


        PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> paginatedResponseDto =  PaginatedResponseDto.<HealthAndSafetyOverViewDisplayDto>builder()
                .data(healthAndSafetyOverViewWithRowNo)
                .currentPage(healthAndSafetyOverviewSearchDto.getPage())
                .totalPages(complianceReadingPage.getTotalPages())
                .totalItems(complianceReadingPage.getTotalElements())
                .build();

        log.info("________test___________{}",paginatedResponseDto);
        return paginatedResponseDto;
    }

    public HealthAndSafetyOverViewDisplayDto getOverviewHealthAndSafetyById(String id) {
        ComplianceReading complianceReading=  healthAndSafetyService.getOverviewHealthAndSafetyById(id);
        return healthAndSafetyConverter.convertToDto(complianceReading);
    }
}
