package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewDepartmentDto {
    private String id;
    private String departmentName;
}
