package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ComplianceDto {

    private Integer id;
    private String complianceName;
    private Boolean status;

}
