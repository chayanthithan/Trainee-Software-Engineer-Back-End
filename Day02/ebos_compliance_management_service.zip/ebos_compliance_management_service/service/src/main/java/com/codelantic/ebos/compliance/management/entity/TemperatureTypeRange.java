package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.util.UUID;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TemperatureTypeRange {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    @Enumerated(EnumType.STRING)
    private TemperatureType temperatureType;
    private String startTemperature;
    private String endTemperature;
    private Boolean status;
    private String complianceSubCategoryId;

    @PrePersist
    public void prePersist() {
        if (complianceSubCategoryId == null) {
            complianceSubCategoryId = UUID.randomUUID().toString();
        }
    }

}
