package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceReadingAgent;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/compliance-reading")
@RequiredArgsConstructor
public class ComplianceReadingController {

    private final ComplianceReadingAgent complianceReadingAgent;

    @PostMapping("/save")
    public ResponseDto save(@RequestBody ComplianceReadingDto complianceReadingDto,
                            @RequestParam ComplianceCategory complianceCategory) {
        return complianceReadingAgent.save(complianceReadingDto,complianceCategory);
    }

    @PutMapping("/update")
    public ResponseDto update(@RequestBody ComplianceReadingDto complianceReadingDto,
                            @RequestParam ComplianceCategory complianceCategory) {
        return complianceReadingAgent.update(complianceReadingDto,complianceCategory);
    }
    @GetMapping("/{id}")
    public Object getById(@PathVariable("id") String id,@RequestParam ComplianceCategory complianceCategory) {
        return complianceReadingAgent.getById(id,complianceCategory);
    }
}
