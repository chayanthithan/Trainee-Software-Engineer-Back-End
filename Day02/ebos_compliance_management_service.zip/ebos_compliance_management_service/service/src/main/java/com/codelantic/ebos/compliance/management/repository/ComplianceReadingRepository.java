package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface ComplianceReadingRepository extends JpaRepository<ComplianceReading,String> {

    @Query("SELECT cr FROM ComplianceReading cr "+
            "LEFT JOIN ComplianceSubCategory cs ON cs.id = cr.complianceSubCategoryId " +
            "WHERE cs.businessId= :businessId " +
            "AND (:fromDate IS NULL OR :toDate IS NULL OR cr.date BETWEEN :fromDate AND :toDate) " +
            "AND  (:employeeName IS NULL OR cr.createdBy= :employeeName) " +
            "AND (:complianceStatus IS NULL OR cr.complianceStatus = :complianceStatus) " +
            "AND (:subCategoryId IS NULL OR cs.id = :subCategoryId) order by cr.date DESC, cr.time DESC")
    Page<ComplianceReading> getAllOverViewForCleaning(String businessId, LocalDate fromDate, LocalDate toDate, String employeeName, ComplianceStatus complianceStatus, Pageable paging, String subCategoryId);

    @Query("SELECT cr FROM ComplianceReading cr where cr.id=:id")
    Optional<ComplianceReading> getOverviewHealthAndSafetyById(String id);

    @Query("SELECT cr FROM ComplianceReading cr WHERE cr.id = :complianceReadingId")
    ComplianceReading getOverviewCleaningById(String complianceReadingId);

    @Query("SELECT cr FROM ComplianceReading cr WHERE cr.id = :complianceReadingId")
    ComplianceReading getOverviewCompliantById(String complianceReadingId);
}
