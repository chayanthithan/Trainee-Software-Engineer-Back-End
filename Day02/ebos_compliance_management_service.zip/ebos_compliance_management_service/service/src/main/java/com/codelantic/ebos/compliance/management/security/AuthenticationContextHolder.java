package com.codelantic.ebos.compliance.management.security;

import org.springframework.stereotype.Component;

@Component
public class AuthenticationContextHolder {
    private static final ThreadLocal<Authentication> CONTEXT_HOLDER = new InheritableThreadLocal();

    public static Authentication getContext() {
        return CONTEXT_HOLDER.get();
    }

    public static void setContext(Authentication authentication) {
        CONTEXT_HOLDER.set(authentication);
    }
    public static void clearContext() {
        CONTEXT_HOLDER.remove();
    }
}
