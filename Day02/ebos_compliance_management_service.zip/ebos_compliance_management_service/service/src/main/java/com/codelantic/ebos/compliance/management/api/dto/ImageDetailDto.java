package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

import java.util.List;

@Data
public class ImageDetailDto {
    private List<ImageResponseDto> imageResponseDtos;
}
