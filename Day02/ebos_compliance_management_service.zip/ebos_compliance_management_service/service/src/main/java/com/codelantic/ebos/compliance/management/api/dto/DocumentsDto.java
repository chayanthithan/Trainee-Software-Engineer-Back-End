package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentsDto {
    private String id;
    private String imageName;
    private String imagePath;
    private String viewImagePath;
    private String downloadImagePath;
    private String trainingReadingId;
    private String licenseAndPermitReadingId;
    private String wasteManagementReadingId;
    private String incidentReadingId;
    private String visitorReadingId;
    private String complaintReadingId;
}
