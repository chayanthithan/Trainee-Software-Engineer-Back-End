package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TypeOfWasteDto;
import com.codelantic.ebos.compliance.management.entity.TypeOfWaste;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class WasteManagementConverter {

    public TypeOfWaste convertToEntity(TypeOfWasteDto typeOfWasteDto){
        return TypeOfWaste.builder()
                .businessId(typeOfWasteDto.getBusinessId())
                .wastTypes(typeOfWasteDto.getWastTypes())
                .businessId(typeOfWasteDto.getBusinessId())
                .build();
    }


}
