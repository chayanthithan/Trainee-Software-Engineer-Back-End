package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.AffectedPartiesDto;
import com.codelantic.ebos.compliance.management.entity.AffectedParties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AffectedPartiesConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;

    public AffectedParties convert(AffectedPartiesDto affectedPartiesDto) {
        return AffectedParties.builder()
                .id(affectedPartiesDto.getId())
                .audio(affectedPartiesDto.getAudio())
                .audioPath(affectedPartiesDto.getAudioPath())
                .incidentReadingId(affectedPartiesDto.getIncidentReadingId())
                .build();
    }

    public AffectedPartiesDto convert(AffectedParties affectedParties) {
        return AffectedPartiesDto.builder()
                .id(affectedParties.getId())
                .audio(affectedParties.getAudio())
                .viewAudioPath(baseUrl+affectedParties.getAudioPath())
                .downloadAudioPath(downloadBaseUrl+affectedParties.getAudioPath())
                .incidentReadingId(affectedParties.getIncidentReadingId())
                .build();
    }
}
