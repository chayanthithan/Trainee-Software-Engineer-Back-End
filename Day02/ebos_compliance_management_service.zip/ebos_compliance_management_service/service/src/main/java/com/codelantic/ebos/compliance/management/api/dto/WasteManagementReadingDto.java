package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class WasteManagementReadingDto {
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String typeOfWastage;
    private String storageLocation;
    private String disposalMethod;
    private String productName;
    private Integer quantity;
    private Double unitCost;
    private String totalWasteValue;
    private String comments;
    private String subCategoryFormConfigurationsId;
    private Set<DocumentsDto> documents;
    private String complianceSubCategoryId;
    private String createdBy;
    private String complianceStatus;
    private String reviewerComments;
}
