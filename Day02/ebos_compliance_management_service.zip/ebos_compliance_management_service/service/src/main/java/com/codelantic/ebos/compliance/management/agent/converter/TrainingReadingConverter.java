package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TrainingReadingDto;
import com.codelantic.ebos.compliance.management.entity.TrainingReading;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TrainingReadingConverter {
    private final TrainerConverter trainerConverter;
    private final ParticipantsConverter participantsConverter;
    private final DocumentsConverter documentsConverter;
    private final SignatureConverter signatureConverter;
    private final SelectedTrainingTitleConverter selectedTrainingTitleConverter;
    private final UserManagementClient userManagementClient;


    public TrainingReading convert(TrainingReadingDto trainingReadingDto) {
        String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return TrainingReading.builder()
                .id(trainingReadingDto.getId())
                .organizedBy(trainingReadingDto.getOrganizedBy())
                .trainingTitle(trainingReadingDto.getTrainingTitle())
                .date(trainingReadingDto.getDate())
                .time(trainingReadingDto.getTime())
                .location(trainingReadingDto.getLocation())
                .trainingObjective(trainingReadingDto.getTrainingObjective())
                .trainingMaterialUsed(trainingReadingDto.getTrainingMaterialUsed())
                .description(trainingReadingDto.getDescription())
                .comments(trainingReadingDto.getComments())
                .complianceSubCategoryId(trainingReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .trainers(trainingReadingDto.getTrainers() != null ? trainingReadingDto.getTrainers().stream().map
                        (trainerConverter::convert).collect(Collectors.toSet()) : null)
                .participants(trainingReadingDto.getParticipants() != null ? trainingReadingDto.getParticipants().stream().map
                        (participantsConverter::convert).collect(Collectors.toSet()) : null)
                .documents(trainingReadingDto.getDocuments() != null ? trainingReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .signatures(trainingReadingDto.getSignatures() != null ? trainingReadingDto.getSignatures().stream().map
                        (signatureConverter::convert).collect(Collectors.toSet()) : null)
                .selectedTrainingTitles(trainingReadingDto.getSelectedTrainingTitles() != null ? trainingReadingDto.getSelectedTrainingTitles().stream().map
                        (selectedTrainingTitleConverter::convert).collect(Collectors.toSet()) : null)

                .build();
    }

    public TrainingReadingDto convertToDto(TrainingReading trainingReading) {
        return TrainingReadingDto.builder()
                .id(trainingReading.getId())
                .organizedBy(trainingReading.getOrganizedBy())
                .trainingTitle(trainingReading.getTrainingTitle())
                .date(trainingReading.getDate())
                .time(trainingReading.getTime())
                .location(trainingReading.getLocation())
                .trainingObjective(trainingReading.getTrainingObjective())
                .trainingMaterialUsed(trainingReading.getTrainingMaterialUsed())
                .description(trainingReading.getDescription())
                .comments(trainingReading.getComments())
                .complainceStatus(trainingReading.getComplianceStatus() != null ? trainingReading.getComplianceStatus().getMappedValue(): null)
                .createdBy(userManagementClient.getUserNameById(trainingReading.getCreatedBy()).getName())
                .complianceSubCategoryId(trainingReading.getComplianceSubCategoryId())
                .trainers(trainingReading.getTrainers() != null ? trainingReading.getTrainers().stream().map
                        (trainerConverter::convert).collect(Collectors.toSet()) : null)
                .participants(trainingReading.getParticipants() != null ? trainingReading.getParticipants().stream().map
                        (participantsConverter::convert).collect(Collectors.toSet()) : null)
                .documents(trainingReading.getDocuments() != null ? trainingReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .signatures(trainingReading.getSignatures() != null ? trainingReading.getSignatures().stream().map
                        (signatureConverter::convert).collect(Collectors.toSet()) : null)
                .selectedTrainingTitles(trainingReading.getSelectedTrainingTitles() != null ? trainingReading.getSelectedTrainingTitles().stream().map
                        (selectedTrainingTitleConverter::convert).collect(Collectors.toSet()) : null)

                .build();
    }

    public void updateConvert(TrainingReading existingReading,TrainingReadingDto newReading) {
        existingReading.setOrganizedBy(newReading.getOrganizedBy());
        existingReading.setTrainingTitle(newReading.getTrainingTitle());
        existingReading.setDate(newReading.getDate());
        existingReading.setTime(newReading.getTime());
        existingReading.setLocation(newReading.getLocation());
        existingReading.setTrainingObjective(newReading.getTrainingObjective());
        existingReading.setTrainingMaterialUsed(newReading.getTrainingMaterialUsed());
        existingReading.setDescription(newReading.getDescription());
        existingReading.setComments(newReading.getComments());
        existingReading.setTrainers(newReading.getTrainers() != null ? newReading.getTrainers().stream().map
                (trainerConverter::convert).collect(Collectors.toSet()) : null);
        existingReading.setParticipants(newReading.getParticipants() != null ? newReading.getParticipants().stream().map
                        (participantsConverter::convert).collect(Collectors.toSet()) : null);
        existingReading.setDocuments(newReading.getDocuments() != null ? newReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null);
        existingReading.setSelectedTrainingTitles(newReading.getSelectedTrainingTitles() != null ? newReading.getSelectedTrainingTitles().stream().map
                        (selectedTrainingTitleConverter::convert).collect(Collectors.toSet()) : null);
    }

    public TrainingReadingDto convertToDtoById(TrainingReading trainingReading,String rowNo) {
        return TrainingReadingDto.builder()
                .id(trainingReading.getId())
                .rowNo(rowNo)
                .organizedBy(trainingReading.getOrganizedBy())
                .trainingTitle(trainingReading.getTrainingTitle())
                .time(trainingReading.getTime())
                .location(trainingReading.getLocation())
                .date(trainingReading.getDate())
                .trainingObjective(trainingReading.getTrainingObjective())
                .trainingMaterialUsed(trainingReading.getTrainingMaterialUsed())
                .comments(trainingReading.getComments())
                .complainceStatus(trainingReading.getComplianceStatus() != null ? trainingReading.getComplianceStatus().getMappedValue(): null)
                .description(trainingReading.getDescription())
                .createdBy(userManagementClient.getUserNameById(trainingReading.getCreatedBy()).getName())
                .complianceSubCategoryId(trainingReading.getComplianceSubCategoryId())
                .documents(trainingReading.getDocuments() != null ? trainingReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .participants(trainingReading.getParticipants() != null ? trainingReading.getParticipants().stream().map
                        (participantsConverter::convert).collect(Collectors.toSet()) : null)
                .signatures(trainingReading.getSignatures() != null ? trainingReading.getSignatures().stream().map
                        (signatureConverter::convert).collect(Collectors.toSet()) : null)
                .trainers(trainingReading.getTrainers() != null ? trainingReading.getTrainers().stream().map
                        (trainerConverter::convert).collect(Collectors.toSet()) : null)
                .selectedTrainingTitles(trainingReading.getSelectedTrainingTitles() != null ? trainingReading.getSelectedTrainingTitles().stream().map
                        (selectedTrainingTitleConverter::convert).collect(Collectors.toSet()) : null)

                .build();
    }
}
