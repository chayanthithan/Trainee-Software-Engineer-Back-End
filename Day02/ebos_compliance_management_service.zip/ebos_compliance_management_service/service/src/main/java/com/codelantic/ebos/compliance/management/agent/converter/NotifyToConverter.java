package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.NotifyToDto;
import com.codelantic.ebos.compliance.management.entity.NotifyTo;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class NotifyToConverter {
    private final UserManagementClient userManagementClient;

    public NotifyTo convert(NotifyToDto notifyToDto) {
        return NotifyTo.builder()
                .id(notifyToDto.getId())
                .incidentReadingId(notifyToDto.getIncidentReadingId())
                .visitorReadingId(notifyToDto.getVisitorReadingId())
                .temperatureReadingId(notifyToDto.getTemperatureReadingId())
                .complaintReadingId(notifyToDto.getComplaintReadingId())
                .userId(notifyToDto.getUserId())
                .build();
    }

    public NotifyToDto convert(NotifyTo notifyTo) {
        if (notifyTo.getUserId() != null) {
            UserName userName = userManagementClient.getUserNameById(notifyTo.getUserId());
            return NotifyToDto.builder()
                    .id(notifyTo.getId())
                    .incidentReadingId(notifyTo.getIncidentReadingId())
                    .visitorReadingId(notifyTo.getVisitorReadingId())
                    .temperatureReadingId(notifyTo.getTemperatureReadingId())
                    .complaintReadingId(notifyTo.getComplaintReadingId())
                    .userId(notifyTo.getUserId())
                    .userName(userName != null ? userName.getName() : null)
                    .profile(userName !=null&&userName.getProfile()!=null?userName.getProfile():null)
                    .build();
        }
        return null;
    }
}
