package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.SignaturesDto;
import com.codelantic.ebos.compliance.management.entity.Signatures;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SignatureConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;
    public Signatures convert(SignaturesDto signaturesDto) {
        return Signatures.builder()
                .id(signaturesDto.getId())
                .imageName(signaturesDto.getImageName())
                .imagePath(signaturesDto.getImagePath())
                .signatureOf(signaturesDto.getSignatureOf())
                .trainingReadingId(signaturesDto.getTrainingReadingId())
                .build();
    }

    public SignaturesDto convert(Signatures signatures) {
        return SignaturesDto.builder()
                .id(signatures.getId())
                .imageName(signatures.getImageName())
                .viewImagePath(baseUrl+signatures.getImagePath())
                .downloadImagePath(downloadBaseUrl+signatures.getImagePath())
                .signatureOf(signatures.getSignatureOf())
                .trainingReadingId(signatures.getTrainingReadingId())
                .build();
    }
}
