package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
public class DeleteImageDto {
    @NotNull(message = "Download Image Path Required")
    private String imagePath;
    private String documentId;
}