package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

public enum TypeOfIncident {
    THEFT("Theft"),
    ACCIDENT("Accident");


    private final String mappedValue;

    TypeOfIncident(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static TypeOfIncident fromMappedValue(String mappedValue) {
        return (mappedValue==null ||mappedValue.isBlank())?null: Arrays.stream(TypeOfIncident.values())
                .filter(typeOfIncident -> typeOfIncident.mappedValue.equalsIgnoreCase(mappedValue))
                .findFirst()
                .orElseThrow(() -> new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST));
    }
    public String getMappedValue() {
        return mappedValue;
    }
    public static List<String> getAll() {
        return Arrays.stream(TypeOfIncident.values())
                .map(typeOfIncident -> typeOfIncident.mappedValue)
                .toList();
    }


}
