package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TemperatureTypeOverviewAllDto {
    private String id;
    private String itemName;
    private String temperatureType;
    private String startTemperature;
    private String endTemperature;
    private int sequence;


    public TemperatureTypeOverviewAllDto(String id, String itemName, TemperatureType temperatureType, String startTemperature, String endTemperature,  int sequence) {
        this.id=id;
        this.itemName = itemName;
        this.temperatureType = temperatureType.getMappedValue();
        this.startTemperature = startTemperature;
        this.endTemperature = endTemperature;
        this.sequence = sequence;

    }

}

