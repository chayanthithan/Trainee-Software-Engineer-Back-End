package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TrainingMaterialUsedDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingObjectivesDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingTitleDto;
import com.codelantic.ebos.compliance.management.entity.TrainingMaterialUsed;
import com.codelantic.ebos.compliance.management.entity.TrainingObjectives;
import com.codelantic.ebos.compliance.management.entity.TrainingTitle;
import org.springframework.stereotype.Component;

@Component
public class TrainingTitleConverter {

    public TrainingTitle convert(TrainingTitleDto trainingTitleDto) {
        TrainingTitle trainingTitle = new TrainingTitle();
        trainingTitle.setId(trainingTitleDto.getId());
        trainingTitle.setTrainingTitleName(trainingTitleDto.getTrainingTitleName());
        trainingTitle.setBusinessId(trainingTitleDto.getBusinessId());

        return trainingTitle;
    }

    public TrainingMaterialUsed convertToEntity(TrainingMaterialUsedDto trainingMaterialUsedDto) {
        TrainingMaterialUsed trainingMaterialUsed =new TrainingMaterialUsed();
        trainingMaterialUsed.setId(trainingMaterialUsedDto.getId());
        trainingMaterialUsed.setTrainingMaterialUsedName(trainingMaterialUsedDto.getTrainingMaterialUsedName());
        trainingMaterialUsed.setBusinessId(trainingMaterialUsedDto.getBusinessId());
        return trainingMaterialUsed;
    }

    public TrainingObjectives convertToEntity(TrainingObjectivesDto trainingObjectivesDto) {
        TrainingObjectives trainingObjectives =new TrainingObjectives();
        trainingObjectives.setId(trainingObjectivesDto.getId());
        trainingObjectives.setObjectivesOfTraining(trainingObjectivesDto.getObjectivesOfTraining());
        trainingObjectives.setBusinessId(trainingObjectivesDto.getBusinessId());
        return trainingObjectives;
    }
}
