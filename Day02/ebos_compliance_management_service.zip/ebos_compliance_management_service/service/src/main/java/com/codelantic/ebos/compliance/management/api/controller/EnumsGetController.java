package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.api.dto.DropDownDto;
import com.codelantic.ebos.compliance.management.service.EnumsGetService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/compliance-management-enums")
@RequiredArgsConstructor
public class EnumsGetController {
    private final EnumsGetService enumsGetService;

    @GetMapping("/compliance-status")
    public DropDownDto getAllComplianceStatus() {
        return enumsGetService.getAllComplianceStatus();
    }

    @GetMapping("/supporting-evidence")
    public DropDownDto getAllSupportingEvidence() {
        return enumsGetService.getAllSupportingEvidence();
    }

    @GetMapping("/yes-or-no")
    public DropDownDto getAllYesOrNo() {
        return enumsGetService.getAllYesOrNo();
    }

    @GetMapping("/temperature-type")
    public DropDownDto getAllTemperatureType() {
        return enumsGetService.getAllTemperatureType();
    }

    @GetMapping("/compliance-category")
    public DropDownDto getAllComplianceCategory() {
        return enumsGetService.getAllComplianceCategory();
    }
}