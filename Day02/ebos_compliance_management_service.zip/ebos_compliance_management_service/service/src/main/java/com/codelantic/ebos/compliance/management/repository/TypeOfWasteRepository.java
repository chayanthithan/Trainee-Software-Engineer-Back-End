package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TypeOfWasteDto;
import com.codelantic.ebos.compliance.management.entity.TypeOfWaste;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TypeOfWasteRepository extends JpaRepository<TypeOfWaste,String> {

    Boolean existsByWastTypesEqualsIgnoreCaseAndBusinessId(String wasteTypes,String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TypeOfWasteDto(w.id,w.wastTypes) " +
            "FROM TypeOfWaste w " +
            "WHERE w.businessId = :businessId OR w.businessId IS NULL")
    List<TypeOfWasteDto> getAllTypeOfWastes(String businessId);

}
