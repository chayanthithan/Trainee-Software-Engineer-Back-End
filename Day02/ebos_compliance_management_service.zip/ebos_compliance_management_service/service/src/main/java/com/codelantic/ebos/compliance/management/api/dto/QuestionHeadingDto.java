package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class QuestionHeadingDto {
    private String id;
    private String question;
    private Boolean isCommentAvailable;
    private Boolean isDocumentAvailable;
}
