package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceConverter;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.BusinessComplianceRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ComplianceService {


    private static final Logger log = LoggerFactory.getLogger(ComplianceService.class);
    private final BusinessComplianceRepository businessComplianceRepository;

    private final ComplianceRepository complianceRepository;

    private final Validations validations;

    private final ComplianceConverter complianceConverter;

    public ResponseDto addOrRemoveComplianceForBusiness(ComplianceConfigurationsDto complianceConfigurationsDto) {
        validations.businessValidation(complianceConfigurationsDto.getBusinessId());
        if (!complianceRepository.existsById(complianceConfigurationsDto.getComplianceId())) {
            throw new ServiceException("Compliance Not Found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        boolean check = businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceConfigurationsDto.getComplianceId(), complianceConfigurationsDto.getBusinessId());
        if (check && complianceConfigurationsDto.getStatus().equals(Boolean.TRUE)) {
            throw new ServiceException("Compliance Already Available", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (!check && complianceConfigurationsDto.getStatus().equals(Boolean.FALSE)) {
            throw new ServiceException("Compliance Not Exists For Business", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (check && complianceConfigurationsDto.getStatus().equals(Boolean.FALSE)) {
            businessComplianceRepository.deleteByBusinessIdAndComplianceId(complianceConfigurationsDto.getBusinessId(), complianceConfigurationsDto.getComplianceId());
            return new ResponseDto("Updated !");
        }
        if (!check && complianceConfigurationsDto.getStatus().equals(Boolean.TRUE)) {
            businessComplianceRepository.save(complianceConverter.convertToBusinessComplianceEntity(complianceConfigurationsDto));
        }
        return new ResponseDto("Successfully Saved !");
    }


    public List<ComplianceDto> getAllAvailableCompliance(String businessId) {
        return complianceRepository.getAllAvailableCompliance(businessId);
    }
}
