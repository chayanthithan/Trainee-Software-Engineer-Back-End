package com.codelantic.ebos.compliance.management.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.codelantic.ebos.user.management.enums.UserType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Date;

@Component
@RequiredArgsConstructor
@Slf4j
public class AuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        String url = String.valueOf(request.getRequestURL());

        String username = null;
        String userId = null;
        String userType = null;
   if (!url.contains("password") && !url.contains("/users/signup")
           && !url.contains("/industry/getAll")  && !url.contains("/feature/getAllFeatures") && !url.contains("/userManagementEnums")
           && !url.contains("/health")) {
            if (header == null || !header.startsWith("Bearer ")) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.setContentType("application/json");
                String jsonResponse = "{\n" +
                        "    \"status\": 403,\n" +
                        "    \"message\": \"Forbidden\",\n" +
                        "    \"errors\": [\n" +
                        "        \"Forbidden\"\n" +
                        "    ]\n" +
                        "}";
                response.getWriter().write(jsonResponse);
                return;
            }

            String authToken = header.substring(7);
            DecodedJWT decodedJWT = JWT.decode(authToken);

            Date expirationTime = decodedJWT.getClaim("exp").asDate();
            Date currentTime = new Date(System.currentTimeMillis());

            username = decodedJWT.getClaim("sub").asString();
            userId = decodedJWT.getClaim("user_id").asString();
            userType = decodedJWT.getClaim("user_type").asString();

            if (currentTime.after(expirationTime)) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.setContentType("application/json");

                String jsonResponse = "{\n" +
                        "    \"status\": 401,\n" +
                        "    \"message\": \"Unauthorized\",\n" +
                        "    \"errors\": [\n" +
                        "        \"Token expired\"\n" +
                        "    ]\n" +
                        "}";
                response.getWriter().write(jsonResponse);
                return;
            }

            AuthenticationContextHolder.setContext(Authentication.builder()
                    .userId(userId)
                    .userName(username)
                    .userType(UserType.valueOf(userType))
                    .build());
  }

        try {
            chain.doFilter(request, response);
        } catch (
                Exception e) {
            if (e instanceof ServletException) {
                throw (ServletException) e;
            }
        } finally {
            AuthenticationContextHolder.

                    clearContext();
        }
    }
}