package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.VisitTypeDto;
import com.codelantic.ebos.compliance.management.entity.VisitType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface VisitingTypeRepository extends JpaRepository<VisitType,String> {

    Boolean existsByTypeOfVisitEqualsIgnoreCaseAndBusinessId(String visitType,String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.VisitTypeDto(v.id,v.typeOfVisit) " +
            "FROM VisitType v " +
            "WHERE v.businessId = :businessId OR v.businessId IS NULL")
    List<VisitTypeDto> getAllVisitTypes(String businessId);


}
