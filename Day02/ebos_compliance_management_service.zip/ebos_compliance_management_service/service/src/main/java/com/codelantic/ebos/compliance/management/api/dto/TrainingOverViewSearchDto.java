package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TrainingOverViewSearchDto {
    @Positive(message = "Page should be a positive numerical value")
    private Integer page = 1;

    @Positive(message = "Size should be a positive numerical value")
    private Integer size = 10;

    private String organizedBy;
    @NotNull(message = "SubCategory Id is required")
    private String subCategoryId;

    private ComplianceStatus complianceStatus;

    @NotNull(message = "From Date is required")
    private LocalDate fromDate;

    @NotNull(message = "To Date is required")
    private LocalDate toDate;

    @NotEmpty(message = "Business Id is required")
    private String businessId;
    private List<String> trainerId;
    private List<String> participantId;

}
