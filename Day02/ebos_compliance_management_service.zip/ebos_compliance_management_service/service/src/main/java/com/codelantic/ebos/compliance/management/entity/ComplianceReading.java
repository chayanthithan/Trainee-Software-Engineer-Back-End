package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Entity
@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class ComplianceReading {
    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private String complianceSubCategoryId;
    private String createdBy;
    private String businessId;
    private String comments;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceReadingId")
    private Set<CheckListReading> checkListReadings;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceReadingId")
    private Set<SubCategoryQuestionsReadings> subCategoryQuestionsReadings;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "complianceReadingId")
    private Set<TemperatureReading> temperatureReadings;
    private LocalDate date;
    private LocalTime time;
    @Enumerated(EnumType.STRING)
    private ComplianceStatus complianceStatus;
    private String reviewerComments;
}
