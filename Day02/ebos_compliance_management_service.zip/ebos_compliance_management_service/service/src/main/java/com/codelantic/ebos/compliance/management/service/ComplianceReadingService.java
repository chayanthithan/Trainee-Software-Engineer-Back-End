package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingGetDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import static com.codelantic.ebos.compliance.management.constants.ApplicationConstants.NOT_FOUND;

@Service
@RequiredArgsConstructor
public class ComplianceReadingService {

    private final ComplianceReadingConverter complianceReadingConverter;
    private final ComplianceReadingRepository complianceReadingRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final UserManagementClient userManagementClient;

    public ResponseDto save(ComplianceReadingDto complianceReadingDto) {
        userManagementClient.checkBusinessId(complianceReadingDto.getBusinessId());
       Boolean isAvailable= complianceSubCategoryRepository.existsById(complianceReadingDto.getComplianceSubCategoryId());
        if(isAvailable.equals(Boolean.FALSE)){
            throw new ServiceException("Compliance SubCategory "+NOT_FOUND,NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        complianceReadingRepository.save(complianceReadingConverter.convert(complianceReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(ComplianceReadingDto complianceReadingDto) {
        userManagementClient.checkBusinessId(complianceReadingDto.getBusinessId());
        if (complianceReadingDto.getId() == null) {
            throw new ServiceException("Compliance reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        ComplianceReading existingReading = complianceReadingRepository.findById(complianceReadingDto.getId()).
                orElseThrow(() -> new ServiceException("Compliance reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        complianceReadingConverter.updateConvert(existingReading, complianceReadingDto);
        complianceReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public ComplianceReadingGetDto getById(String id, ComplianceCategory complianceCategory) {
        ComplianceReading complianceReading = complianceReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        String userName = userManagementClient.getUserNameById(complianceReading.getCreatedBy()).getName();
        return complianceReadingConverter.convertToDto(complianceReading,userName);
    }
}
