package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class VisitorReadingDto {
    private String id;
    private String fullName;
    private LocalDate date;
    private LocalTime time;
    private String visitType;
    private String comments;
    private String subCategoryFormConfigurationId;
    private Set<DocumentsDto> documents;
    private Set<NotifyToDto> notifyTo;
    private String description;
    private Set<DescriptionDto> descriptions;
    private String complianceSubCategoryId;
    private String createdBy;
    private String complianceStatus;
    private String reviewerComments;
}
