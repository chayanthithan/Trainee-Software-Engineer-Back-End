package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Set;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class TemperatureReadingDto {
    private String id;
    private String complianceSubCategoryId;
    private String temperatureTypeRangeConfigurationsId;
    private Integer quantity;
    private String actualReading;
    private String comments;
    private String complianceReadingId;
    private Set<ReadingImagesDto> readingImages;
    private Set<NotifyToDto> notifyTo;
    private String recommendedStartTemperature;
    private String recommendedEndTemperature;
    private String temperatureType;

    public TemperatureReadingDto(String id, Integer quantity, String actualReading, String comments, String recommendedStartTemperature, String recommendedEndTemperature, String temperatureType) {
        this.id = id;
        this.quantity = quantity;
        this.actualReading = actualReading;
        this.comments = comments;
        this.recommendedStartTemperature = recommendedStartTemperature;
        this.recommendedEndTemperature = recommendedEndTemperature;
        this.temperatureType = temperatureType;
    }
}
