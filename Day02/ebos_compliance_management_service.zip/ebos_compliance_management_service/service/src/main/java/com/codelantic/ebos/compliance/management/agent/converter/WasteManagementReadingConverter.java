package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementReadingDto;

import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class WasteManagementReadingConverter {
    private final DocumentsConverter documentsConverter;
    private final UserManagementClient userManagementClient;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;

    @Value("${sftp.base.url}")
    private String imagePath;

    public WasteManagementReading convert(WasteManagementReadingDto wasteManagementReadingDto) {
        String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return WasteManagementReading.builder()
                .id(wasteManagementReadingDto.getId())
                .date(wasteManagementReadingDto.getDate())
                .time(wasteManagementReadingDto.getTime())
                .typeOfWastage(wasteManagementReadingDto.getTypeOfWastage())
                .storageLocation(wasteManagementReadingDto.getStorageLocation())
                .disposalMethod(wasteManagementReadingDto.getDisposalMethod())
                .productName(wasteManagementReadingDto.getProductName())
                .quantity(wasteManagementReadingDto.getQuantity())
                .unitCost(wasteManagementReadingDto.getUnitCost())
                .totalWasteValue(wasteManagementReadingDto.getTotalWasteValue())
                .comments(wasteManagementReadingDto.getComments())
                .complianceSubCategoryId(wasteManagementReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .reviewerComments(wasteManagementReadingDto.getReviewerComments())
                .complianceStatus(wasteManagementReadingDto.getComplianceStatus()!=null? ComplianceStatus.fromMappedValue(wasteManagementReadingDto.getComplianceStatus()):null)
                .documents(wasteManagementReadingDto.getDocuments() != null ? wasteManagementReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public WasteManagementOverviewDto convertToDto(WasteManagementReading wasteManagementReading) {
        WasteManagementOverviewDto.WasteManagementOverviewDtoBuilder wasteManagementOverviewDto=WasteManagementOverviewDto.builder()
                .id(wasteManagementReading.getId())
                .subCategoryName(complianceSubCategoryRepository.getNameUsingId(wasteManagementReading.getComplianceSubCategoryId()))
                .date(wasteManagementReading.getDate())
                .time(wasteManagementReading.getTime())
                .typeOfWastage(wasteManagementReading.getTypeOfWastage())
                .productName(wasteManagementReading.getProductName())
                .quantity(wasteManagementReading.getQuantity())
                .unitCost(wasteManagementReading.getUnitCost())
                .totalWasteValue(wasteManagementReading.getTotalWasteValue())
                .storageLocation(wasteManagementReading.getStorageLocation())
                .disposalMethod(wasteManagementReading.getDisposalMethod())
                .comments(wasteManagementReading.getComments())
                .complianceStatus(wasteManagementReading.getComplianceStatus()!=null?wasteManagementReading.getComplianceStatus().getMappedValue():null);

        if(wasteManagementReading.getCreatedBy()!=null){
            UserName userName = userManagementClient.getUserNameById(wasteManagementReading.getCreatedBy());
            wasteManagementOverviewDto.employeeName(userName.getName());
        }

        if (wasteManagementReading.getDocuments() != null) {
            Set<ImageDescriptionDto> imageDescriptions = wasteManagementReading.getDocuments().stream() // Stream over the documents
                    .map(readingImage -> ImageDescriptionDto.builder()
                            .id(readingImage.getId())
                            .fileName(readingImage.getImageName())
                            .fullViewPath(readingImage.getImagePath())
                            .downloadPath(readingImage.getImagePath())
                            .build())
                    .collect(Collectors.toSet());

            wasteManagementOverviewDto.images(imageDescriptions);
        }


        return wasteManagementOverviewDto.build();

    }

    public WasteManagementReadingDto convert(WasteManagementReading wasteManagementReading) {
        return WasteManagementReadingDto.builder()
                .id(wasteManagementReading.getId())
                .date(wasteManagementReading.getDate())
                .typeOfWastage(wasteManagementReading.getTypeOfWastage())
                .storageLocation(wasteManagementReading.getStorageLocation())
                .disposalMethod(wasteManagementReading.getDisposalMethod())
                .productName(wasteManagementReading.getProductName())
                .quantity(wasteManagementReading.getQuantity())
                .unitCost(wasteManagementReading.getUnitCost())
                .totalWasteValue(wasteManagementReading.getTotalWasteValue())
                .comments(wasteManagementReading.getComments())
                .documents(wasteManagementReading.getDocuments()!=null? wasteManagementReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public void updateConvert(WasteManagementReading existingReading, WasteManagementReadingDto wasteManagementReadingDto) {
        existingReading.setId(wasteManagementReadingDto.getId());
        existingReading.setDate(wasteManagementReadingDto.getDate());
        existingReading.setTypeOfWastage(wasteManagementReadingDto.getTypeOfWastage());
        existingReading.setStorageLocation(wasteManagementReadingDto.getStorageLocation());
        existingReading.setDisposalMethod(wasteManagementReadingDto.getDisposalMethod());
        existingReading.setProductName(wasteManagementReadingDto.getProductName());
        existingReading.setQuantity(wasteManagementReadingDto.getQuantity());
        existingReading.setUnitCost(wasteManagementReadingDto.getUnitCost());
        existingReading.setTotalWasteValue(wasteManagementReadingDto.getTotalWasteValue());
        existingReading.setComments(wasteManagementReadingDto.getComments());

        if (wasteManagementReadingDto.getDocuments() != null) {
            existingReading.setDocuments(wasteManagementReadingDto.getDocuments().stream()
                    .map(documentsConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
