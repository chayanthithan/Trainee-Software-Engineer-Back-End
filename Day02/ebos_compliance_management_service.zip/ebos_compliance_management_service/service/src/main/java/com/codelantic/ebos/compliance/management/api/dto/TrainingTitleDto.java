package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrainingTitleDto {
    private String id;
    @NotBlank(message = "Training title name is required")
    private String trainingTitleName;
    @NotBlank(message = "Business Id is required")
    private String businessId;

    public TrainingTitleDto(String id, String trainingTitleName) {
        this.id = id;
        this.trainingTitleName = trainingTitleName;
    }

    public TrainingTitleDto(){

    }
}
