package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.SubCategoryDto;
import com.codelantic.ebos.compliance.management.api.dto.UploadDocumentDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ComplianceSubCategoryRepository extends JpaRepository<ComplianceSubCategory, String> {

    @Query("SELECT new com.codelantic.ebos.compliance.management.api.dto.SubCategoryDto(cs.id,cs.subCategoryName,cs.status) from ComplianceSubCategory cs where cs.complianceId=:complianceId " +
            "AND cs.businessId = :businessId order by cs.date desc, cs.time desc ")
    List<SubCategoryDto> getSubCategories(Integer complianceId,String businessId);


    @Transactional
    @Modifying
    @Query("UPDATE ComplianceSubCategory cs SET cs.status = :status WHERE cs.id = :subCategoryId")
    void updateSubCategoryStatus(@Param("subCategoryId") String subCategoryId, @Param("status") Boolean status);


    Optional<ComplianceSubCategory> findByIdAndStatus(String complianceSubCategoryId, boolean b);

    boolean existsByBusinessIdAndComplianceIdAndSubCategoryNameEqualsIgnoreCase(String businessId, Integer complianceId, String subCategoryName);


    @Query(nativeQuery = true, value = "SELECT c.sub_category_name FROM ebos_compliance_management.compliance_sub_category c where c.id =:id ")
    String findBySubCategoryNameIgnoreCase(String id);

    boolean existsByIdAndStatus(String subCategoryId, boolean b);

    @Query("select i.id from ComplianceSubCategory i where i.id=:id")
    Optional<String> findByIdForValidation(String id);


    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.UploadDocumentDto(cs.businessId,cs.subCategoryName,c.complianceName) " +
            "FROM ComplianceSubCategory cs JOIN Compliance c ON cs.complianceId=c.id " +
            "WHERE cs.id=:complianceSubCategoryId ")
    UploadDocumentDto getDetails(String complianceSubCategoryId);

    @Query("SELECT csc.subCategoryName FROM ComplianceSubCategory csc WHERE csc.id=:complianceSubCategoryId")
    String getNameUsingId(String complianceSubCategoryId);
}
