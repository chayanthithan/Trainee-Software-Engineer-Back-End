package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LicensePermitOverviewSearchDto {
    private Integer page;
    private Integer size;
    private String employeeName;
    private ComplianceStatus complianceStatus;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String subCategoryId;
    private String businessId;
}
