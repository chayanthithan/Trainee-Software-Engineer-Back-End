package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceSubCategoryConverter;
import com.codelantic.ebos.compliance.management.agent.converter.TemperatureConverter;
import com.codelantic.ebos.compliance.management.agent.converter.TemperatureReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.Compliance;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.FormSettingConfigurationRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class ComplianceSubCategoryService {
    private final ComplianceSubCategoryConverter complianceSubCategoryConverter;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final FormSettingConfigurationRepository formSettingConfigurationRepository;
    private final ComplianceRepository complianceRepository;
    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;
    private final TemperatureConverter temperatureConverter;

    private final UserManagementClient userManagementClient;

    private final Validations validations;

    public ResponseDto saveComplianceSubCategory(ComplianceSubCategorySaveDto complianceSubCategorySaveDto) {
        userManagementClient.checkBusinessId(complianceSubCategorySaveDto.getBusinessId());
        validations.checkByComplianceIdAndBusinessId(complianceSubCategorySaveDto.getComplianceId(), complianceSubCategorySaveDto.getBusinessId());
        validations.checkByComplianceSubCategoryNameDuplication(complianceSubCategorySaveDto.getComplianceId(),complianceSubCategorySaveDto.getBusinessId(),complianceSubCategorySaveDto.getSubCategoryName());

if(complianceSubCategorySaveDto.getSubCategoryCheckListSaveDto() != null) {
    for (SubCategoryCheckListSaveDto subCategoryCheckListSaveDto : complianceSubCategorySaveDto.getSubCategoryCheckListSaveDto()) {
        validations.checkChecklistIsCommentAvailableAndIsDocumentAvailable(subCategoryCheckListSaveDto.getIsCommentAvailable(), subCategoryCheckListSaveDto.getIsDocumentAvailable());
    }
}

if(complianceSubCategorySaveDto.getSubCategoryQuestionsSaveDto() != null) {
    for (SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto : complianceSubCategorySaveDto.getSubCategoryQuestionsSaveDto()) {
        validations.checkChecklistIsCommentAvailableAndIsDocumentAvailable(subCategoryQuestionsSaveDto.getIsCommentAvailable(), subCategoryQuestionsSaveDto.getIsDocumentAvailable());
    }
}

        ComplianceSubCategory complianceSubCategory = complianceSubCategoryConverter.convert(complianceSubCategorySaveDto);
        if (complianceSubCategory.getIsTemperature().equals(Boolean.TRUE) && complianceSubCategory.getId() == null ) {
            throw new ServiceException("Id required", "Bad request", HttpStatus.BAD_REQUEST);
        }

        ComplianceSubCategory savedSubCategory = complianceSubCategoryRepository.save(complianceSubCategory);

        if(complianceSubCategory.getIsTemperature().equals(Boolean.TRUE)) {
            List<TemperatureTypeRange> temperatureRanges = temperatureTypeRangeRepository.findByComplianceSubCategoryId(complianceSubCategory.getId())
                    .stream()
                    .map(temperatureRange -> {
                        temperatureRange.setComplianceSubCategoryId(savedSubCategory.getId());
                        return temperatureRange;
                    })
                    .toList();
            temperatureTypeRangeRepository.saveAll(temperatureRanges);
        }

        return ResponseDto.builder().message("Sub Category Saved Successfully.").build();
    }

    public List<SubCategoryDto> getSubCategories(Integer complianceId,String businessId) {
        userManagementClient.checkBusinessId(businessId);
        validations.checkByComplianceIdAndBusinessId(complianceId,businessId);
        return complianceSubCategoryRepository.getSubCategories(complianceId,businessId);
    }

    public ComplianceSubCategory getById(String subCategoryId) {
        return complianceSubCategoryRepository.findById(subCategoryId).orElseThrow(() -> new ServiceException("Sub category not found",ApplicationConstants.BAD_REQUEST,HttpStatus.NOT_FOUND));
    }

    public ResponseDto updateComplianceSubCategory(ComplianceSubCategory complianceSubCategory) {
        userManagementClient.checkBusinessId(complianceSubCategory.getBusinessId());
        validations.checkByComplianceIdAndBusinessId(complianceSubCategory.getComplianceId(), complianceSubCategory.getBusinessId());
        validations.checkByComplianceSubCategoryNameDuplicationWhileUpdate(complianceSubCategory.getComplianceId(),complianceSubCategory.getBusinessId(),complianceSubCategory.getSubCategoryName(),complianceSubCategory.getId());
        complianceSubCategoryRepository.save(complianceSubCategory);
        return ResponseDto.builder().message("Sub Category Updated Successfully.").build();
    }

    public List<FormSettingConfigurationDto> getAllByComplianceTypeId(Integer complianceId) {
        Compliance compliance = complianceRepository.findById(complianceId)
                .orElseThrow(() -> new ServiceException("Compliance id not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        log.info("compliance " + compliance);
        // Retrieve the list of FormSettingConfigurationDto
        List<FormSettingConfigurationDto> formSettingConfigurationDtoList = formSettingConfigurationRepository.findFields(complianceId);

        // Group and consolidate the field details by fieldCategory
        return formSettingConfigurationDtoList.stream()
                .flatMap(dto -> dto.getFieldDetails().stream()
                        .map(detail -> new AbstractMap.SimpleEntry<>(dto.getFieldCategory(), detail)))
                .collect(Collectors.groupingBy(
                        Map.Entry::getKey,
                        Collectors.mapping(Map.Entry::getValue, Collectors.toList())
                )).entrySet().stream()
                .map(entry -> new FormSettingConfigurationDto(entry.getKey(), entry.getValue()))
                .toList();
    }

    public ResponseDto updateSubCategoryStatus(String subCategoryId, Boolean status) {
        Optional<ComplianceSubCategory> complianceSubCategory=complianceSubCategoryRepository.findById(subCategoryId);
        if (!complianceSubCategory.isPresent()){
            throw new ServiceException("subCategory is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (complianceSubCategory.get().getStatus().equals(status)) {
            throw new ServiceException("The status has already been updated as per your request.", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        complianceSubCategoryRepository.updateSubCategoryStatus(subCategoryId, status);
        return ResponseDto.builder().message("Sub Category status Updated Successfully.").build();
    }

    public ComplianceSubCategory getCheckListAndQuestion(String complianceSubCategoryId) {
        return complianceSubCategoryRepository.findByIdAndStatus(complianceSubCategoryId, true).orElseThrow(() -> new ServiceException("Compliance sub category id not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
    }
}
