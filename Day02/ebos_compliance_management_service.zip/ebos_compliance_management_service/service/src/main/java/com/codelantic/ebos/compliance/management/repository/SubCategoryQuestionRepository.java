package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SubCategoryQuestionRepository extends JpaRepository<SubCategoryQuestions,String> {

    @Query("SELECT s.isDocumentAvailable FROM SubCategoryQuestions s WHERE s.id = :subCategoryQuestionsId")
    boolean findResultForRecord(String subCategoryQuestionsId);
}
