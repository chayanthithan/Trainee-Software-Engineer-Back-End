package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public enum YesOrNo {
    YES("Yes"),
   NO("No");


    private final String mappedValue;

    YesOrNo(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static YesOrNo fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        for (YesOrNo yesOrNo : YesOrNo.values()) {
            if (yesOrNo.mappedValue.equalsIgnoreCase(mappedValue)) {
                return yesOrNo;
            }
        }
        throw new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST);
    }


    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        for (YesOrNo yesOrNo : YesOrNo.values()) {
            list.add(yesOrNo.mappedValue);
        }
        return list;
    }
}
