package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class ParticipantsDto {
    private String id;
    private String trainingReadingId;
    private String participantId;
}
