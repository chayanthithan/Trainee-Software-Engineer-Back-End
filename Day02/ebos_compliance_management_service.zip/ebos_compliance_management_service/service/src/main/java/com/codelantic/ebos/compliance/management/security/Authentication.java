package com.codelantic.ebos.compliance.management.security;

import com.codelantic.ebos.user.management.enums.UserType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Authentication {
    private String userId;
    private String userName;
    private UserType userType;
}
