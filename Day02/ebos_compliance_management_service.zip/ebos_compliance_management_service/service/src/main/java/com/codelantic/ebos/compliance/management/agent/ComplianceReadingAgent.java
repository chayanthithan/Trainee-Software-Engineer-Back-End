package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ComplianceReadingAgent {

    private final ComplianceReadingService complianceReadingService;
    private final TrainingReadingService trainingReadingService;
    private final LicenseAndPermitReadingService licenseAndPermitReadingService;
    private final WasteManagementReadingService wasteManagementReadingService;
    private final VisitorReadingService visitorReadingService;
    private final CompliantReadingService compliantReadingService;
    private final IncidentReadingService incidentReadingService;

    public ResponseDto save(ComplianceReadingDto complianceReadingDto, ComplianceCategory complianceCategory) {

        if (complianceCategory.equals(ComplianceCategory.TRAINING) && complianceReadingDto.getTrainingReading() != null) {
            return trainingReadingService.save(complianceReadingDto.getTrainingReading());
        }
        if (complianceCategory.equals(ComplianceCategory.LICENSE_AND_PERMITS) && complianceReadingDto.getLicenseAndPermitReading() != null) {
            return licenseAndPermitReadingService.save(complianceReadingDto.getLicenseAndPermitReading());
        }
        if (complianceCategory.equals(ComplianceCategory.WASTE_MANAGEMENT) && complianceReadingDto.getWasteManagementReading() != null) {
            return wasteManagementReadingService.save(complianceReadingDto.getWasteManagementReading());
        }
        if (complianceCategory.equals(ComplianceCategory.VISITOR) && complianceReadingDto.getVisitorReading() != null) {
            return visitorReadingService.save(complianceReadingDto.getVisitorReading());
        }
        if (complianceCategory.equals(ComplianceCategory.COMPLAINT) && complianceReadingDto.getCompliantReading() != null) {
            return compliantReadingService.save(complianceReadingDto.getCompliantReading());
        }
        if (complianceCategory.equals(ComplianceCategory.INCIDENT) && complianceReadingDto.getIncidentReading() != null) {
            return incidentReadingService.save(complianceReadingDto.getIncidentReading());
        }
        return complianceReadingService.save(complianceReadingDto);
    }

    public ResponseDto update(ComplianceReadingDto complianceReadingDto, ComplianceCategory complianceCategory) {

        if (complianceCategory.equals(ComplianceCategory.TRAINING) && complianceReadingDto.getTrainingReading() != null) {
            return trainingReadingService.update(complianceReadingDto.getTrainingReading());
        }
        if (complianceCategory.equals(ComplianceCategory.LICENSE_AND_PERMITS) && complianceReadingDto.getLicenseAndPermitReading() != null) {
            return licenseAndPermitReadingService.update(complianceReadingDto.getLicenseAndPermitReading());
        }
        if (complianceCategory.equals(ComplianceCategory.WASTE_MANAGEMENT) && complianceReadingDto.getWasteManagementReading() != null) {
            return wasteManagementReadingService.update(complianceReadingDto.getWasteManagementReading());
        }
        if (complianceCategory.equals(ComplianceCategory.VISITOR) && complianceReadingDto.getVisitorReading() != null) {
            return visitorReadingService.update(complianceReadingDto.getVisitorReading());
        }
        if (complianceCategory.equals(ComplianceCategory.COMPLAINT) && complianceReadingDto.getCompliantReading() != null) {
            return compliantReadingService.update(complianceReadingDto.getCompliantReading());
        }
        if (complianceCategory.equals(ComplianceCategory.INCIDENT) && complianceReadingDto.getIncidentReading() != null) {
            return incidentReadingService.update(complianceReadingDto.getIncidentReading());
        }
        return complianceReadingService.update(complianceReadingDto);
    }

    public Object getById(String id, ComplianceCategory complianceCategory) {

        if (complianceCategory.equals(ComplianceCategory.TRAINING)) {
            return trainingReadingService.getById(id,complianceCategory);
        }
        if (complianceCategory.equals(ComplianceCategory.LICENSE_AND_PERMITS)) {
            return licenseAndPermitReadingService.getById(id,complianceCategory);
        }
        if (complianceCategory.equals(ComplianceCategory.WASTE_MANAGEMENT) ) {
            return wasteManagementReadingService.getById(id,complianceCategory);
        }
        if (complianceCategory.equals(ComplianceCategory.VISITOR) ) {
            return visitorReadingService.getById(id,complianceCategory);
        }
        if (complianceCategory.equals(ComplianceCategory.COMPLAINT)) {
            return compliantReadingService.getById(id,complianceCategory);
        }
        if (complianceCategory.equals(ComplianceCategory.INCIDENT)) {
            return incidentReadingService.getById(id,complianceCategory);
        }
        return complianceReadingService.getById(id,complianceCategory);
    }
}
