package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.DeliveryOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureTypeOverviewDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureConfigurationsRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureReadingRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserFisrtNameLastNameDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@AllArgsConstructor
@Slf4j
public class DeliveryService {
    private final UserManagementClient userManagementClient;
    private final TemperatureTypeRangeRepository temperatureTypeRangeRepository;


    private final TemperatureConfigurationsRepository temperatureConfigurationsRepository;

    private final Validations validations;
    private final TemperatureReadingRepository temperatureReadingRepository;
    private final ComplianceReadingRepository complianceReadingRepository;


    public Page<DeliveryOverviewDto> getAllDeliveryOverview(TemperatureOverviewSearchDto temperatureOverviewSearchDto) {
        Pageable pageable = PageRequest.of(temperatureOverviewSearchDto.getPage() - 1, temperatureOverviewSearchDto.getSize());
        validations.dateValidation(temperatureOverviewSearchDto.getFromDate(), temperatureOverviewSearchDto.getToDate());

        Page<DeliveryOverviewDto> deliveryOverviewDtos= temperatureReadingRepository.getAllDeliveryOverview(
                temperatureOverviewSearchDto.getSubCategoryId(),
                temperatureOverviewSearchDto.getFromDate(),
                temperatureOverviewSearchDto.getToDate(),
                pageable,
                ComplianceStatus.fromMappedValue(temperatureOverviewSearchDto.getComplianceStatus()),
                temperatureOverviewSearchDto.getEmployeeIds() != null ? temperatureOverviewSearchDto.getEmployeeIds() : List.of("ALL"),
                temperatureOverviewSearchDto.getNotifyTos() != null ? temperatureOverviewSearchDto.getNotifyTos() : List.of("ALL")
        );
        AtomicInteger rowNo = new AtomicInteger(1);

        deliveryOverviewDtos.getContent().forEach(temperatureOverviewDto -> {
            List<TemperatureTypeOverviewDto> temperatureTypeOverviewDtos = temperatureTypeRangeRepository.getAllTemperatureTypeOverView(
                    temperatureOverviewSearchDto.getBusinessId(),
                    temperatureOverviewSearchDto.getSubCategoryId(),
                    temperatureOverviewSearchDto.getFromDate(),
                    temperatureOverviewSearchDto.getToDate(),
                    ComplianceStatus.fromMappedValue(temperatureOverviewSearchDto.getComplianceStatus()),
                    temperatureOverviewSearchDto.getEmployeeIds() != null ? temperatureOverviewSearchDto.getEmployeeIds() : List.of("ALL"),
                    temperatureOverviewSearchDto.getNotifyTos() != null ? temperatureOverviewSearchDto.getNotifyTos() : List.of("ALL")
            );
            temperatureOverviewDto.setTemperatureTypeOverviewDtos(temperatureTypeOverviewDtos);
            int currentRowNo = rowNo.getAndIncrement();
            temperatureOverviewDto.setRowNo(currentRowNo);
            List<String> notifyTo = temperatureReadingRepository.getNotifyTo(
                    temperatureOverviewSearchDto.getSubCategoryId(),
                    temperatureOverviewSearchDto.getFromDate(),
                    temperatureOverviewSearchDto.getToDate(),
                    ComplianceStatus.fromMappedValue(temperatureOverviewSearchDto.getComplianceStatus()),
                    temperatureOverviewSearchDto.getEmployeeIds() != null ? temperatureOverviewSearchDto.getEmployeeIds() : List.of("ALL"),
                    temperatureOverviewSearchDto.getNotifyTos() != null ? temperatureOverviewSearchDto.getNotifyTos() : List.of("ALL")
            );
            log.info("Notify To-----{}",notifyTo);

            if (notifyTo != null && !notifyTo.isEmpty()) {
                List<String> notifyResponse = notifyTo.stream()
                        .map(notify -> {
                            UserFisrtNameLastNameDto userFisrtNameLastNameDto = userManagementClient.getUserFisrtNameLastNameById(notify);
                            return userFisrtNameLastNameDto.getName() + " " + userFisrtNameLastNameDto.getLastName();
                        })
                        .toList();
                temperatureOverviewDto.setNotify(notifyResponse);
            }
        });

        return deliveryOverviewDtos;

    }
}
