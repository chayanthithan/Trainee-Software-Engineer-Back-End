package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.sql.Time;
import java.util.Date;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TrainingReadingDto {
    private String id;
    private String organizedBy;
    private String trainingTitle;
    private Date date;
    private Time time;
    private String location;
    private String trainingObjective;
    private String trainingMaterialUsed;
    private String description;
    private String comments;
    private String subCategoryFormConfigurationsId;
    private Set<TrainerDto> trainers;
    private Set<ParticipantsDto> participants;
    private Set<DocumentsDto> documents;
    private Set<SignaturesDto> signatures;
    private Set<SelectedTrainingTitleDto> selectedTrainingTitles;
    private String complianceSubCategoryId;
    private String createdBy;
    private String rowNo;
    private String complainceStatus;

    public TrainingReadingDto(String id, String organizedBy, String trainingTitle, Date date, Time time,String location) {
        this.id = id;
        this.organizedBy = organizedBy;
        this.trainingTitle = trainingTitle;
        this.date = date;
        this.time = time;
        this.location = location;
    }
}
