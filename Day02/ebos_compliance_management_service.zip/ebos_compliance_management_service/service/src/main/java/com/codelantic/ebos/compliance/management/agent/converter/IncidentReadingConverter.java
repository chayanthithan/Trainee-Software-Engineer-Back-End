package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.IncidentReadingDto;
import com.codelantic.ebos.compliance.management.entity.IncidentReading;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class IncidentReadingConverter {

    private final AffectedPartiesConverter affectedPartiesConverter;
    private final PotentialImpactConverter potentialImpactConverter;
    private final ImmediateResponseConverter immediateResponseConverter;
    private final DescriptionConverter descriptionConverter;
    private final NotifyToConverter notifyToConverter;
    private final DocumentsConverter documentsConverter;

    public IncidentReading convert(IncidentReadingDto incidentReadingDto) {
        String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return IncidentReading.builder()
                .id(incidentReadingDto.getId())
                .date(incidentReadingDto.getDate())
                .time(incidentReadingDto.getTime())
                .typeOfIncident(incidentReadingDto.getTypeOfIncident())
                .severity(incidentReadingDto.getSeverity())
                .department(incidentReadingDto.getDepartment())
                .location(incidentReadingDto.getLocation())
                .description(incidentReadingDto.getDescription())
                .supportingEvidence(incidentReadingDto.getSupportingEvidence())
                .affectedParties(incidentReadingDto.getAffectedParties())
                .potentialImpact(incidentReadingDto.getPotentialImpact())
                .immediateResponse(incidentReadingDto.getImmediateResponse())
                .comments(incidentReadingDto.getComments())
                .complianceSubCategoryId(incidentReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .affectedPartiesAudio(incidentReadingDto.getAffectedPartiesAudio() != null ? incidentReadingDto.getAffectedPartiesAudio().stream().map
                        (affectedPartiesConverter::convert).collect(Collectors.toSet()) : null)
                .potentialImpactsAudio(incidentReadingDto.getPotentialImpactsAudio() != null ? incidentReadingDto.getPotentialImpactsAudio().stream().map
                        (potentialImpactConverter::convert).collect(Collectors.toSet()) : null)
                .immediateResponsesAudio(incidentReadingDto.getImmediateResponsesAudio() != null ? incidentReadingDto.getImmediateResponsesAudio().stream().map
                        (immediateResponseConverter::convert).collect(Collectors.toSet()) : null)
                .descriptions(incidentReadingDto.getDescriptions() != null ? incidentReadingDto.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(incidentReadingDto.getNotifyTo() != null ? incidentReadingDto.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .documents(incidentReadingDto.getDocuments() != null ? incidentReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public IncidentReadingDto convert(IncidentReading incidentReading) {
        return IncidentReadingDto.builder()
                .id(incidentReading.getId())
                .date(incidentReading.getDate())
                .typeOfIncident(incidentReading.getTypeOfIncident())
                .severity(incidentReading.getSeverity())
                .department(incidentReading.getDepartment())
                .location(incidentReading.getLocation())
                .description(incidentReading.getDescription())
                .supportingEvidence(incidentReading.getSupportingEvidence())
                .affectedParties(incidentReading.getAffectedParties())
                .potentialImpact(incidentReading.getPotentialImpact())
                .immediateResponse(incidentReading.getImmediateResponse())
                .comments(incidentReading.getComments())
                .affectedPartiesAudio(incidentReading.getAffectedPartiesAudio()!=null? incidentReading.getAffectedPartiesAudio().stream().map
                        (affectedPartiesConverter::convert).collect(Collectors.toSet()) : null)
                .potentialImpactsAudio(incidentReading.getPotentialImpactsAudio()!=null? incidentReading.getPotentialImpactsAudio().stream().map
                        (potentialImpactConverter::convert).collect(Collectors.toSet()) : null)
                .immediateResponsesAudio(incidentReading.getImmediateResponsesAudio()!=null? incidentReading.getImmediateResponsesAudio().stream().map
                        (immediateResponseConverter::convert).collect(Collectors.toSet()) : null)
                .descriptions(incidentReading.getDescriptions()!=null? incidentReading.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(incidentReading.getNotifyTo()!=null? incidentReading.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .documents(incidentReading.getDocuments()!=null? incidentReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public void updateConvert(IncidentReading existingReading, IncidentReadingDto incidentReadingDto) {
        existingReading.setId(incidentReadingDto.getId());
        existingReading.setDate(incidentReadingDto.getDate());
        existingReading.setTypeOfIncident(incidentReadingDto.getTypeOfIncident());
        existingReading.setSeverity(incidentReadingDto.getSeverity());
        existingReading.setDepartment(incidentReadingDto.getDepartment());
        existingReading.setLocation(incidentReadingDto.getLocation());
        existingReading.setDescription(incidentReadingDto.getDescription());
        existingReading.setSupportingEvidence(incidentReadingDto.getSupportingEvidence());
        existingReading.setAffectedParties(incidentReadingDto.getAffectedParties());
        existingReading.setPotentialImpact(incidentReadingDto.getPotentialImpact());
        existingReading.setImmediateResponse(incidentReadingDto.getImmediateResponse());
        existingReading.setComments(incidentReadingDto.getComments());

        if (incidentReadingDto.getAffectedPartiesAudio() != null) {
            existingReading.setAffectedPartiesAudio(incidentReadingDto.getAffectedPartiesAudio().stream()
                    .map(affectedPartiesConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (incidentReadingDto.getPotentialImpactsAudio() != null) {
            existingReading.setPotentialImpactsAudio(incidentReadingDto.getPotentialImpactsAudio().stream()
                    .map(potentialImpactConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (incidentReadingDto.getImmediateResponsesAudio() != null) {
            existingReading.setImmediateResponsesAudio(incidentReadingDto.getImmediateResponsesAudio().stream()
                    .map(immediateResponseConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (incidentReadingDto.getDescriptions() != null) {
            existingReading.setDescriptions(incidentReadingDto.getDescriptions().stream()
                    .map(descriptionConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (incidentReadingDto.getNotifyTo() != null) {
            existingReading.setNotifyTo(incidentReadingDto.getNotifyTo().stream()
                    .map(notifyToConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (incidentReadingDto.getDocuments() != null) {
            existingReading.setDocuments(incidentReadingDto.getDocuments().stream()
                    .map(documentsConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
