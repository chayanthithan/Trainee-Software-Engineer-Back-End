package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

@Data
public class TemperatureTypeRangeResponseDto {
    private String complianceSubCategoryId;
}
