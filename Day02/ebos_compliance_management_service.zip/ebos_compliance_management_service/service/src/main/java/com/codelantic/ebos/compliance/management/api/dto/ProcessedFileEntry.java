package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ProcessedFileEntry {
    private final MultipartFile renamedFile;
    private final ImageResponseDto responseDto;

    ProcessedFileEntry(MultipartFile renamedFile, ImageResponseDto responseDto) {
        this.renamedFile = renamedFile;
        this.responseDto = responseDto;
    }
}
