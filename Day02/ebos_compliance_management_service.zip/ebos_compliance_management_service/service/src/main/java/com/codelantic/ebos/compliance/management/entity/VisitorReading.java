package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Entity
@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class VisitorReading {
    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private String fullName;
    private LocalDate date;
    private LocalTime time;
    private String visitType;
    private String comments;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "visitorReadingId")
    private Set<Documents> documents;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "visitorReadingId")
    private Set<NotifyTo> notifyTo;
    private String description;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "visitorReadingId")
    private Set<Description> descriptions;
    private String createdBy;
    private String complianceSubCategoryId;
    private String reviewerComments;
    @Enumerated(EnumType.STRING)
    private ComplianceStatus complianceStatus;
}
