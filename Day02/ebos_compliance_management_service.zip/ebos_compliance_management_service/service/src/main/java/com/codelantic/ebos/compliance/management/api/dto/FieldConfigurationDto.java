package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class FieldConfigurationDto {
    private String id;
    private String fieldName;
    private String fieldType;
    private Boolean status;


}
