package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ViewTrainingMaterialUsedDto {
    private String id;
    private String trainingMaterialUsedName;
}
