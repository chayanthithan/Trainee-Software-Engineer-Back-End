package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.DeleteImageDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDetailDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.UploadDocumentsDto;
import com.codelantic.ebos.compliance.management.service.FileUploadServices;
import com.jcraft.jsch.JSchException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Component
@AllArgsConstructor
@Slf4j
public class FileUploadAgent {

    private final FileUploadServices fileUploadService;

    public ImageDetailDto uploadDocuments(UploadDocumentsDto uploadDocumentsDto, List<MultipartFile> files,String audioOrImage) throws JSchException {
        return fileUploadService.uploadDocuments(uploadDocumentsDto, files,audioOrImage);
    }

    public ResponseDto deleteImage(List<DeleteImageDto> deleteImageDtos, String saveOrUpdate) {
        return fileUploadService.delete(deleteImageDtos, saveOrUpdate);
    }

    public ResponseEntity<byte[]> downloadDocument(List<String> documentUr) throws IOException {
        return fileUploadService.downloadDocument(documentUr);
    }
    public ResponseEntity<byte[]> downloadSingleDocument(String documentUr) throws IOException, JSchException {
        return fileUploadService.downloadSingleDocument(documentUr);
    }
}
