package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.IncidentReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.IncidentReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.IncidentReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.IncidentReadingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class IncidentReadingService {

    private final IncidentReadingConverter incidentReadingConverter;
    private final IncidentReadingRepository incidentReadingRepository;

    public ResponseDto save(IncidentReadingDto incidentReadingDto) {
        incidentReadingRepository.save(incidentReadingConverter.convert(incidentReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(IncidentReadingDto incidentReadingDto) {

        if (incidentReadingDto.getId() == null) {
            throw new ServiceException("Compliant reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        IncidentReading existingReading = incidentReadingRepository.findById(incidentReadingDto.getId()).
                orElseThrow(() -> new ServiceException("Compliant reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        incidentReadingConverter.updateConvert(existingReading, incidentReadingDto);
        incidentReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public IncidentReadingDto getById(String id, ComplianceCategory complianceCategory) {
        IncidentReading incidentReading = incidentReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return incidentReadingConverter.convert(incidentReading);
    }
}
