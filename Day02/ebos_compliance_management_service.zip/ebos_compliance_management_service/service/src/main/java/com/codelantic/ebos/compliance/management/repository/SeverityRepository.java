package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.SeverityDto;
import com.codelantic.ebos.compliance.management.entity.Severity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SeverityRepository extends JpaRepository<Severity, String> {

    Boolean existsBySeverityNameAndBusinessId(String severityName, String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.SeverityDto(s.id,s.severityName) " +
            "FROM Severity s " +
            "WHERE s.businessId IS NULL OR s.businessId = :businessId ")
    List<SeverityDto> getAllSeverities(String businessId);
}
