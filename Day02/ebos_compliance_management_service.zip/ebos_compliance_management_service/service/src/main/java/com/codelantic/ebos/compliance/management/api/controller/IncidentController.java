package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.IncidentAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/incident")
@RequiredArgsConstructor
@Validated
public class IncidentController {

    private final IncidentAgent incidentAgent;

    @PostMapping("/incident-types")
    public ResponseDto saveTypeOfIncident(@RequestBody @Valid TypeOfIncidentDto typeOfIncidentDto) {
        return incidentAgent.saveTypeOfIncident(typeOfIncidentDto);
    }

    @GetMapping("/incident-types")
    public List<TypeOfIncidentDto> getAllTypeOfIncidents(@RequestParam(value = "businessId", required = false) @NotBlank(message = "Business Id is required") String businessId) {
        return incidentAgent.getAllTypeOfIncidents(businessId);
    }

    @PostMapping("/department")
    public ResponseDto saveDepartment(@RequestBody @Valid DepartmentDto departmentDto) {
        return incidentAgent.saveDepartment(departmentDto);
    }

    @GetMapping("/department")
    public List<ViewDepartmentDto> getAllDepartment(@RequestParam(value = "businessId", required = false) @NotBlank(message = "Business Id is required") String businessId) {
        return incidentAgent.getAllDepartment(businessId);
    }

    @PostMapping("/location")
    public ResponseDto saveLocation(@RequestBody @Valid LocationDto locationDto) {
        return incidentAgent.saveLocation(locationDto);
    }

    @GetMapping("/location")
    public List<LocationDto> getAllLocation(@RequestParam(value = "businessId", required = false) @NotEmpty(message = "businessId is required") String businessId) {
        return incidentAgent.getAllLocation(businessId);
    }

    @PostMapping("/severity")
    public ResponseDto saveSeverity(@RequestBody @Valid SeverityDto severityDto) {
        return incidentAgent.saveSeverity(severityDto);
    }

    @GetMapping("/severity")
    public List<SeverityDto> getAllSeverities(@RequestParam @NotBlank(message = "Business id is required") String businessId) {
        return incidentAgent.getAllSeverities(businessId);
    }

    @GetMapping("/get-all-configured-field")
    public List<FormSettingConfigurationDto> getAllConfiguredField(@RequestParam @NotBlank(message = "Compliance SubCategory Id is required") String complianceSubCategoryId) {
        return incidentAgent.getAllConfiguredField(complianceSubCategoryId);
    }

    @GetMapping("/incident-overview")
    public PaginatedResponseDto<IncidentOverviewDto> getAllIncidentOverview(
            @RequestParam(value = "subCategoryId", required = false) @NotBlank(message = "Sub Category Id is required") String subCategoryId,
            @RequestParam(value = "complianceStatus", required = false) String complianceStatus,
            @RequestParam(value = "employeeName", required = false) String employeeName,
            @RequestParam(value = "fromDate", required = false) @NotNull(message = "From date is required") LocalDate fromDate,
            @RequestParam(value = "toDate", required = false) @NotNull(message = "To date is required") LocalDate toDate,
            @RequestParam(value = "page") @Positive(message = "Page should be positive") int page, @RequestParam(value = "size") @Positive(message = "Size should be positive") int size) {

        IncidentOverviewSearchDto incidentOverviewSearchDto = IncidentOverviewSearchDto.builder()
                .subCategoryId(subCategoryId)
                .fromDate(fromDate)
                .toDate(toDate)
                .complianceStatus(ComplianceStatus.fromMappedValue(complianceStatus))
                .employeeName(employeeName)
                .page(page)
                .size(size)
                .build();
        return incidentAgent.getAllIncidentOverview(incidentOverviewSearchDto);
    }

    @GetMapping("/get-overview-by-id")
    public IncidentOverviewDto getOverViewById(@RequestParam(value = "id") String id) {
        return incidentAgent.getOverViewById(id);
    }

}
