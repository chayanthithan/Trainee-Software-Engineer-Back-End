package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.DropDownDto;
import com.codelantic.ebos.compliance.management.enums.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EnumsGetService {
    public DropDownDto getAllComplianceStatus() {
        DropDownDto dto = new DropDownDto();
        dto.setComplianceStatus(ComplianceStatus.getAll());
        return dto;
    }

    public DropDownDto getAllSupportingEvidence() {
        DropDownDto dto = new DropDownDto();
        dto.setSupportingEvidence(SupportingEvidence.getAll());
        return dto;
    }

    public DropDownDto getAllYesOrNo() {
        DropDownDto dto = new DropDownDto();
        dto.setYesOrNo(YesOrNo.getAll());
        return dto;
    }

    public DropDownDto getAllTemperatureType() {
        DropDownDto dto = new DropDownDto();
        dto.setTemperatureType(TemperatureType.getAll());
        return dto;
    }

    public DropDownDto getAllComplianceCategory() {
        DropDownDto dto = new DropDownDto();
        dto.setComplianceCategory(ComplianceCategory.getAll());
        return dto;
    }
}