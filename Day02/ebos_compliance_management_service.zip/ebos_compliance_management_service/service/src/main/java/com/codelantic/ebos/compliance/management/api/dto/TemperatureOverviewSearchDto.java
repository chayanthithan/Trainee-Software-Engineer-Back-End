package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class TemperatureOverviewSearchDto {
    private String businessId;
    private String subCategoryId;
    private LocalDate fromDate;
    private LocalDate toDate;
    private int page;
    private int size;
    private String complianceStatus;
    private List<String> employeeIds;
    private List<String> notifyTos;
}
