package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceConfigurationsDto {
    @NotNull(message = "Compliance Id is required")
    private Integer complianceId;
    @NotBlank(message = "Business Id is required")
    private String businessId;
    @NotNull(message = "Status is required")
    private Boolean status;
}
