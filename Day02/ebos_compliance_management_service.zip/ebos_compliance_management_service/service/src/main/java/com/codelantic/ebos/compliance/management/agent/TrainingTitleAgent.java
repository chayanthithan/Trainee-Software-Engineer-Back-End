package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.TrainingReadingConverter;
import com.codelantic.ebos.compliance.management.agent.converter.TrainingTitleConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.TrainingMaterialUsed;
import com.codelantic.ebos.compliance.management.entity.TrainingObjectives;
import com.codelantic.ebos.compliance.management.entity.TrainingReading;
import com.codelantic.ebos.compliance.management.entity.TrainingTitle;
import com.codelantic.ebos.compliance.management.service.TrainingReadingService;
import com.codelantic.ebos.compliance.management.service.TrainingTitleService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
public class TrainingTitleAgent {

    private final TrainingTitleConverter trainingTitleConverter;

    private final TrainingReadingConverter trainingReadingConverter;
    private final TrainingTitleService trainingTitleService;

    private final TrainingReadingService trainingReadingService;

    public ResponseDto saveTrainingTitle(TrainingTitleDto trainingTitleDto) {
        TrainingTitle trainingTitle = trainingTitleConverter.convert(trainingTitleDto);
        return trainingTitleService.saveTrainingTitle(trainingTitle);
    }

    public List<TrainingTitleDto> getTrainingTitles(String businessId) {
        return trainingTitleService.getTrainingTitles(businessId);
    }

    public ResponseDto saveTrainingMaterialUsed(TrainingMaterialUsedDto trainingMaterialUsedDto) {
        TrainingMaterialUsed trainingMaterialUsed=trainingTitleConverter.convertToEntity(trainingMaterialUsedDto);
        return trainingTitleService.saveTrainingMaterialUsed(trainingMaterialUsed);
    }

    public List<ViewTrainingMaterialUsedDto> getTrainingMaterialUsed(String businessId) {
        return trainingTitleService.getTrainingMaterialUsed(businessId);
    }

    public ResponseDto saveTrainingObjectives(TrainingObjectivesDto trainingObjectivesDto) {
        TrainingObjectives trainingObjectives = trainingTitleConverter.convertToEntity(trainingObjectivesDto);
        return trainingTitleService.saveTrainingObjectives(trainingObjectives);
    }

    public List<TrainingObjectivesDto> getAllTrainingObjectives(String businessId) {
        return trainingTitleService.getAllTrainingObjectives(businessId);
    }

    public PaginatedResponseDto<TrainingReadingDto> getAllTrainingReadings(TrainingOverViewSearchDto trainingOverViewSearchDto){

        Page<TrainingReading> trainingReadings= trainingReadingService.getAllTrainingReading(trainingOverViewSearchDto);
        List<TrainingReadingDto>readings=trainingReadings.stream().map(trainingReadingConverter::convertToDto).toList();

        int startingRowNo=(Math.max(trainingOverViewSearchDto.getPage() - 1,0)) *(trainingOverViewSearchDto.getSize())+1;
        List<TrainingReadingDto> readingsWithRowNo = IntStream.range(0, readings.size())
                .mapToObj(i -> {
                    readings.get(i).setRowNo(String.format("%02d",startingRowNo+i));
                    return readings.get(i);
                })
                .toList();

        return PaginatedResponseDto.<TrainingReadingDto>builder()
                .data(readingsWithRowNo)
                .currentPage(trainingOverViewSearchDto.getPage())
                .totalPages(trainingReadings.getTotalPages())
                .totalItems(trainingReadings.getTotalElements())
                .build();

    }

    public TrainingReadingDto getOverviewTrainingById(String id,String rowNo) {
        TrainingReading trainingReading = trainingReadingService.getOverviewTrainingById(id);
        return trainingReadingConverter.convertToDtoById(trainingReading,rowNo);
    }
}
