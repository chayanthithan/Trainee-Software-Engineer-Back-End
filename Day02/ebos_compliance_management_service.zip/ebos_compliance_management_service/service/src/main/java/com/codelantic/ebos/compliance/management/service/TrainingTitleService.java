package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingObjectivesDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingTitleDto;
import com.codelantic.ebos.compliance.management.api.dto.ViewTrainingMaterialUsedDto;
import com.codelantic.ebos.compliance.management.entity.TrainingMaterialUsed;
import com.codelantic.ebos.compliance.management.entity.TrainingObjectives;
import com.codelantic.ebos.compliance.management.entity.TrainingTitle;
import com.codelantic.ebos.compliance.management.repository.TrainingMaterialUsedRepository;
import com.codelantic.ebos.compliance.management.repository.TrainingObjectivesRepository;
import com.codelantic.ebos.compliance.management.repository.TrainingTitleRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TrainingTitleService {
    private final TrainingTitleRepository trainingTitleRepository;
    private final UserManagementClient userManagementClient;
    private final Validations validations;
    private final TrainingMaterialUsedRepository trainingMaterialUsedRepository;
    private final TrainingObjectivesRepository trainingObjectivesRepository;

    public ResponseDto saveTrainingTitle(TrainingTitle trainingTitle){
        userManagementClient.checkBusinessId(trainingTitle.getBusinessId());
        validations.checkTrainingTitleName(trainingTitle.getTrainingTitleName(),trainingTitle.getBusinessId());
        trainingTitleRepository.save(trainingTitle);

        return ResponseDto.builder().message("Training title saved").build();
    }

    public List<TrainingTitleDto> getTrainingTitles(String businessId) {
        return trainingTitleRepository.getTrainingTitles(businessId);
    }

    public ResponseDto saveTrainingMaterialUsed(TrainingMaterialUsed trainingMaterialUsed) {
        userManagementClient.checkBusinessId(trainingMaterialUsed.getBusinessId());
        validations.checkTrainingMaterialUsedName(trainingMaterialUsed.getTrainingMaterialUsedName(),trainingMaterialUsed.getBusinessId());
        trainingMaterialUsedRepository.save(trainingMaterialUsed);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Training Material Used Name saved Successfully ");
        return responseDto;
    }

    public List<ViewTrainingMaterialUsedDto> getTrainingMaterialUsed(String businessId) {
        userManagementClient.checkBusinessId(businessId);
        return trainingMaterialUsedRepository.getTrainingMaterialUsed(businessId);
    }

    public ResponseDto saveTrainingObjectives(TrainingObjectives trainingObjectives) {
        ResponseDto responseDto = new ResponseDto();

        userManagementClient.checkBusinessId(trainingObjectives.getBusinessId());
        validations.checkObjectivesOfTraining(trainingObjectives.getBusinessId(),trainingObjectives.getObjectivesOfTraining());
        trainingObjectivesRepository.save(trainingObjectives);
        responseDto.setMessage("Training Objectives name saved successfully ");
        return responseDto;
    }

    public List<TrainingObjectivesDto> getAllTrainingObjectives(String businessId) {
        userManagementClient.checkBusinessId(businessId);
        return trainingObjectivesRepository.getAllTrainingObjectives(businessId);
    }

}
