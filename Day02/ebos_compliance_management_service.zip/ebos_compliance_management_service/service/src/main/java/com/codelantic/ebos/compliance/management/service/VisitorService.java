package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitTypeDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitorSearchDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.VisitType;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.VisitingTypeRepository;
import com.codelantic.ebos.compliance.management.repository.VisitorReadingRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class VisitorService {

    private final VisitingTypeRepository visitingTypeRepository;
    private final Validations validations;
    private final VisitorReadingRepository visitorReadingRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;


    public ResponseDto addNewVisitType(VisitType visitType) {
        validations.businessValidation(visitType.getBusinessId());
        validations.checkVisitingType(visitType.getTypeOfVisit(), visitType.getBusinessId());
        visitingTypeRepository.save(visitType);
        return ResponseDto.builder()
                .message("VisitType Added")
                .build();
    }

    public List<VisitTypeDto> getAllVisitType(String businessId) {
        validations.businessValidation(businessId);
        return visitingTypeRepository.getAllVisitTypes(businessId);
    }

    public Page<VisitorReading> getVistorOverview(VisitorSearchDto visitorSearchDto) {
        boolean avalible = complianceSubCategoryRepository.existsById(visitorSearchDto.getSubCategoryId());
        if (!avalible) {
            throw new ServiceException("Sub Category Not Found", "NOT FOUND", HttpStatus.BAD_REQUEST);
        }
        boolean isAvalible = visitorReadingRepository.existsByCreatedBy(visitorSearchDto.getEmployeeId());
        if (!isAvalible) {
            throw new ServiceException("EMPLOYEE NOT FOUND", "NOT FOUND", HttpStatus.BAD_REQUEST);
        }
        LocalDate startDate = null;
        LocalDateTime endDate = null;
        if (visitorSearchDto.getFromDate() != null && visitorSearchDto.getToDate() != null) {
            startDate = LocalDate.from(visitorSearchDto.getFromDate().atStartOfDay());
            endDate = LocalDateTime.of(visitorSearchDto.getToDate(), LocalTime.MAX);
        }
        Pageable pageable = PageRequest.of(visitorSearchDto.getPage() - 1, visitorSearchDto.getSize());

        ComplianceStatus complianceStatus = ComplianceStatus.fromMappedValue(visitorSearchDto.getComplianceStatus());
        assert endDate != null;
        return visitorReadingRepository.getVistorOverview(visitorSearchDto.getBusinessId(),visitorSearchDto.getEmployeeId(), visitorSearchDto.getSubCategoryId(), complianceStatus, startDate, LocalDate.from(endDate), pageable);

    }

    public VisitorReading getRowVisitor(String id) {
        return visitorReadingRepository.findById(id).orElseThrow(() -> new ServiceException("Visitor reading id not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
    }
}
