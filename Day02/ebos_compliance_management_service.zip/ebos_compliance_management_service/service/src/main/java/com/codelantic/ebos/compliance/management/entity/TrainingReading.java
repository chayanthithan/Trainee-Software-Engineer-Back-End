package com.codelantic.ebos.compliance.management.entity;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.sql.Time;
import java.util.Date;
import java.util.Set;

@Entity
@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TrainingReading {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String organizedBy;
    private String trainingTitle;
    private Date date;
    private Time time;
    private String location;
    private String trainingObjective;
    private String trainingMaterialUsed;
    private String description;
    private String comments;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "trainingReadingId")
    private Set<Trainer> trainers;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "trainingReadingId")
    private Set<Participants> participants;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "trainingReadingId")
    private Set<Documents> documents;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "trainingReadingId")
    private Set<Signatures> signatures;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "trainingReadingId")
    private Set<SelectedTrainingTitle> selectedTrainingTitles;
    private String complianceSubCategoryId;
    private String createdBy;
    private String reviewerComments;
    @Enumerated(EnumType.STRING)
    private ComplianceStatus complianceStatus;
}
