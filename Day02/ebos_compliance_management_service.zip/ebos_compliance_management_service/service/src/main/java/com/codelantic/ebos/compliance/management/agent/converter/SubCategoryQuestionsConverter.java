package com.codelantic.ebos.compliance.management.agent.converter;


import com.codelantic.ebos.compliance.management.api.dto.QuestionHeadingDto;
import com.codelantic.ebos.compliance.management.api.dto.SubCategoryQuestionsSaveDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestions;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SubCategoryQuestionsConverter {
    private final SubCategoryQuestionRepository subCategoryQuestionRepository;

    public SubCategoryQuestions convertToEntity(SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto) {
        return SubCategoryQuestions.builder()
                .heading(subCategoryQuestionsSaveDto.getHeading())
                .question(subCategoryQuestionsSaveDto.getQuestion())
                .isCommentAvailable(subCategoryQuestionsSaveDto.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryQuestionsSaveDto.getIsDocumentAvailable())
                .status(Boolean.TRUE)
                .build();
    }

    public SubCategoryQuestionsSaveDto convertToSubCategoryQuestionsSaveDto(SubCategoryQuestions subCategoryQuestions) {
        return SubCategoryQuestionsSaveDto.builder()
                .id(subCategoryQuestions.getId())
                .heading(subCategoryQuestions.getHeading())
                .question(subCategoryQuestions.getQuestion())
                .isCommentAvailable(subCategoryQuestions.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryQuestions.getIsDocumentAvailable())
                .build();
    }

    public SubCategoryQuestions convertToUpdate(SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto, String id) {
        SubCategoryQuestions subCategoryQuestions = subCategoryQuestionRepository.findById(subCategoryQuestionsSaveDto.getId())
                .orElseThrow(() -> new ServiceException("Sub category question id not found for id: " + subCategoryQuestionsSaveDto.getId(),
                        ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST));
        if(subCategoryQuestionsSaveDto.getIsCommentAvailable() == Boolean.FALSE && subCategoryQuestionsSaveDto.getIsDocumentAvailable() == Boolean.FALSE ){
            throw new ServiceException(ApplicationConstants.TOAST_MESSAGE, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        subCategoryQuestions.setQuestion(subCategoryQuestionsSaveDto.getQuestion());
        subCategoryQuestions.setHeading(subCategoryQuestionsSaveDto.getHeading());
        subCategoryQuestions.setComplianceSubCategoryId(id);
        subCategoryQuestions.setIsCommentAvailable(subCategoryQuestionsSaveDto.getIsCommentAvailable());
        subCategoryQuestions.setIsDocumentAvailable(subCategoryQuestionsSaveDto.getIsDocumentAvailable());
        subCategoryQuestions.setStatus(Boolean.TRUE);

        return subCategoryQuestions;
    }

    public QuestionHeadingDto convertToQuestionHeadingDto(SubCategoryQuestions subCategoryQuestions) {
        return QuestionHeadingDto.builder()
                .id(subCategoryQuestions.getId())
                .question(subCategoryQuestions.getQuestion())
                .isCommentAvailable(subCategoryQuestions.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryQuestions.getIsDocumentAvailable())
                .build();
    }

    public SubCategoryQuestions convertToNew(SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto, String complianceSubCategoryId) {
        SubCategoryQuestions subCategoryQuestions = new SubCategoryQuestions();
        if(subCategoryQuestionsSaveDto.getIsCommentAvailable() == Boolean.FALSE && subCategoryQuestionsSaveDto.getIsDocumentAvailable() == Boolean.FALSE ){
            throw new ServiceException(ApplicationConstants.TOAST_MESSAGE, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        subCategoryQuestions.setQuestion(subCategoryQuestionsSaveDto.getQuestion());
        subCategoryQuestions.setHeading(subCategoryQuestionsSaveDto.getHeading());
        subCategoryQuestions.setComplianceSubCategoryId(complianceSubCategoryId);
        subCategoryQuestions.setIsCommentAvailable(subCategoryQuestionsSaveDto.getIsCommentAvailable());
        subCategoryQuestions.setIsDocumentAvailable(subCategoryQuestionsSaveDto.getIsDocumentAvailable());
        subCategoryQuestions.setStatus(Boolean.TRUE);
        return subCategoryQuestions;
    }

}
