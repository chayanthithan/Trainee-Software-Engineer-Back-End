package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceDto;
import com.codelantic.ebos.compliance.management.entity.Compliance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ComplianceRepository extends JpaRepository<Compliance, Integer> {

    boolean existsById(Integer complianceId);


@Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ComplianceDto( " +
        "c.id, c.complianceName, " +
        "CASE WHEN COUNT(bcd.id) > 0 THEN true ELSE false END) " +
        "FROM Compliance c " +
        "LEFT JOIN BusinessComplianceConfiguration bcd " +
        "ON c.id = bcd.complianceId AND bcd.businessId = :businessId " +
        "GROUP BY c.id, c.complianceName " +
        "ORDER BY c.id")
List<ComplianceDto> getAllAvailableCompliance(@Param("businessId") String businessId);

    @Query("SELECT c.complianceName FROM Compliance c WHERE c.id=:complianceId ")
    String getName(Integer complianceId);
}
