package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TemperatureTypeRangeConfigurationDto {
    private String id;
    @Size(max = 30, min = 2, message = "The Item name must be between 2 and 30 characters long.")
    @NotBlank(message = "items is required.")
    private String items;
    private Boolean status;
    @NotBlank(message = "temperatureTypeRangeId is required.")
    private String temperatureTypeRangeId;
    private int sequence;
}
