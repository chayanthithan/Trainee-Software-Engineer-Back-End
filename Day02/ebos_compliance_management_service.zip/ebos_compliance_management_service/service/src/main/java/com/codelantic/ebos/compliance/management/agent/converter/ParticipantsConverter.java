package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ParticipantsDto;
import com.codelantic.ebos.compliance.management.entity.Participants;
import org.springframework.stereotype.Component;

@Component
public class ParticipantsConverter {

    public Participants convert(ParticipantsDto participantsDto) {
        return Participants.builder()
                .id(participantsDto.getId())
                .trainingReadingId(participantsDto.getTrainingReadingId())
                .participantId(participantsDto.getParticipantId())
                .build();
    }

    public ParticipantsDto convert(Participants participants) {
        return ParticipantsDto.builder()
                .id(participants.getId())
                .trainingReadingId(participants.getTrainingReadingId())
                .participantId(participants.getParticipantId())
                .build();
    }
}
