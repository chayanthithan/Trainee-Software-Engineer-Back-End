package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.WasteManagementConverter;
import com.codelantic.ebos.compliance.management.agent.converter.WasteManagementReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.service.CompliantService;
import com.codelantic.ebos.compliance.management.service.WasteManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
public class WasteManagementAgent {

    private final WasteManagementConverter wasteManagementConverter;
    private final WasteManagementService wasteManagementService;
    private final WasteManagementReadingConverter wasteManagementReadingConverter;
    private final CompliantService compliantService;

    public ResponseDto addNewWasteType(TypeOfWasteDto typeOfWasteDto){
        return wasteManagementService.addNewWasteType(wasteManagementConverter.convertToEntity(typeOfWasteDto));
    }
    public List<TypeOfWasteDto> getAllWasteTypesByBusinessId(String businessId){
        return wasteManagementService.getAllWasteType(businessId);
    }


    public PaginatedResponseDto<WasteManagementOverviewDto> getAllWasteOverview(WasteManagementOverviewSearchDto wasteManagementOverviewSearchDto) {
        Page<WasteManagementReading> wasteManagementReadings=wasteManagementService.getAllWasteOverview(wasteManagementOverviewSearchDto);

        List<WasteManagementOverviewDto> wasteManagementOverviewDtos = wasteManagementReadings.getContent().stream()
                .map(wasteManagementReadingConverter::convertToDto).toList();

        List<WasteManagementOverviewDto> wasteManagementOverviewDtoWithRowNo = IntStream.range(0, wasteManagementOverviewDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (wasteManagementOverviewSearchDto.getPage() - 1) * wasteManagementOverviewSearchDto.getSize();
                    wasteManagementOverviewDtos.get(i).setRowNo(String.format("%02d", rowNo));  // Format rowNo to start from "01"
                    return wasteManagementOverviewDtos.get(i);
                })
                .toList();

        return PaginatedResponseDto.<WasteManagementOverviewDto>builder()
                .data(wasteManagementOverviewDtoWithRowNo)
                .currentPage(wasteManagementOverviewSearchDto.getPage())
                .totalPages(wasteManagementReadings.getTotalPages())
                .totalItems(wasteManagementReadings.getTotalElements())
                .build();

    }

    public WasteManagementOverviewDto getOverviewWasteById(String id) {
        WasteManagementReading wasteManagementReading=  wasteManagementService.getOverviewWasteById(id);
        return wasteManagementReadingConverter.convertToDto(wasteManagementReading);
    }
}
