package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.ComplaintTypeSaveDto;
import com.codelantic.ebos.compliance.management.entity.CompliantType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CompliantTypeRepository extends JpaRepository<CompliantType, String> {
    Boolean existsByBusinessIdAndTypeOfCompliantEqualsIgnoreCase(String businessId, String typeOfCompliant);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ComplaintTypeSaveDto(c.id,c.typeOfCompliant) " +
            "FROM CompliantType c " +
            "WHERE c.businessId IS NULL OR c.businessId = :businessId")
    List<ComplaintTypeSaveDto> getComplainType(String businessId);
}
