package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.Set;

@Data
@Validated
public class ComplianceSubCategoryUpdateDto {
    @NotBlank(message = "Compliance sub category id is required")
    private String complianceSubCategoryId;
    @Size(max = 30,message = "The maximum length for the Subcategory name is 30 characters.")
    private String subCategoryName;
    @NotNull(message = "Compliance Id can't be null")
    private Integer complianceId;
    private Boolean isTemperature;
    private Boolean isCheckList;
    private Boolean isForm;
    private Boolean isYesOrNo;
    @NotBlank(message = "Business Id can't be null")
    private String businessId;
    private Boolean isCheckThisBoxToAddCommentsToTheForm;
    private Boolean isDeclarationStatement;
    private Boolean status;
    @Valid
    private TemperatureSaveDto temperatureSaveDto;
    private Set<SubCategoryCheckListSaveDto> subCategoryCheckListSaveDto;
    private Set<SubCategoryQuestionsSaveDto> subCategoryQuestionsSaveDto;
    private Set<SubCategoryFormConfigurationDto> formConfigurationSaveDto;

}
