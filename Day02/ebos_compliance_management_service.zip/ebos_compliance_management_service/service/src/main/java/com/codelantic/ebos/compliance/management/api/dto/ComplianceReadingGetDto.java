package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ComplianceReadingGetDto {

    private String id;
    private String complianceSubCategoryId;
    private String createdBy;
    private String businessId;
    private String comments;
    private String complianceStatus;
    private String reviewerComments;
    private Set<CheckListReadingDto> checkListReadings;
    private Set<SubCategoryQuestionsReadingsDto> subCategoryQuestionsReadings;
    private Set<TempreatureReadingGetDto> temperatureReadings;
    private TrainingReadingDto trainingReading;
    private LicenseAndPermitReadingDto licenseAndPermitReading;
    private WasteManagementReadingDto wasteManagementReading;
    private VisitorReadingDto visitorReading;
    private CompliantReadingDto compliantReading;
    private IncidentReadingDto incidentReading;
    @JsonFormat(pattern = "dd MMMM yyyy")
    private LocalDate date;
    private LocalTime time;

}
