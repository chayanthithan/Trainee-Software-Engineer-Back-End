package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.VisitorReadingDto;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class VisitorReadingConverter {

    private final DocumentsConverter documentsConverter;
    private final NotifyToConverter notifyToConverter;
    private final DescriptionConverter descriptionConverter;

    public VisitorReading convert(VisitorReadingDto visitorReadingDto) {
        String createdBy = AuthenticationContextHolder.getContext().getUserId();
        return VisitorReading.builder()
                .id(visitorReadingDto.getId())
                .fullName(visitorReadingDto.getFullName())
                .date(visitorReadingDto.getDate())
                .time(visitorReadingDto.getTime())
                .visitType(visitorReadingDto.getVisitType())
                .comments(visitorReadingDto.getComments())
                .complianceSubCategoryId(visitorReadingDto.getComplianceSubCategoryId())
                .createdBy(createdBy)
                .complianceStatus(visitorReadingDto.getComplianceStatus()!=null? ComplianceStatus.fromMappedValue(visitorReadingDto.getComplianceStatus()):null)
                .reviewerComments(visitorReadingDto.getReviewerComments())
                .documents(visitorReadingDto.getDocuments() != null ? visitorReadingDto.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(visitorReadingDto.getNotifyTo() != null ? visitorReadingDto.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .description(visitorReadingDto.getDescription())
                .descriptions(visitorReadingDto.getDescriptions() != null ? visitorReadingDto.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public VisitorReadingDto convert(VisitorReading visitorReading) {
        return VisitorReadingDto.builder()
                .id(visitorReading.getId())
                .fullName(visitorReading.getFullName())
                .date(visitorReading.getDate())
                .time(visitorReading.getTime())
                .visitType(visitorReading.getVisitType())
                .comments(visitorReading.getComments())
                .documents(visitorReading.getDocuments() != null ? visitorReading.getDocuments().stream().map
                        (documentsConverter::convert).collect(Collectors.toSet()) : null)
                .notifyTo(visitorReading.getNotifyTo() != null ? visitorReading.getNotifyTo().stream().map
                        (notifyToConverter::convert).collect(Collectors.toSet()) : null)
                .description(visitorReading.getDescription())
                .descriptions(visitorReading.getDescriptions() != null ? visitorReading.getDescriptions().stream().map
                        (descriptionConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public void updateConvert(VisitorReading existingReading, VisitorReadingDto visitorReadingDto) {
        existingReading.setId(visitorReadingDto.getId());
        existingReading.setFullName(visitorReadingDto.getFullName());
        existingReading.setDate(visitorReadingDto.getDate());
        existingReading.setTime(visitorReadingDto.getTime());
        existingReading.setVisitType(visitorReadingDto.getVisitType());
        existingReading.setComments(visitorReadingDto.getComments());

        if (visitorReadingDto.getDocuments() != null) {
            existingReading.setDocuments(visitorReadingDto.getDocuments().stream()
                    .map(documentsConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (visitorReadingDto.getNotifyTo() != null) {
            existingReading.setNotifyTo(visitorReadingDto.getNotifyTo().stream()
                    .map(notifyToConverter::convert)
                    .collect(Collectors.toSet()));
        }

        existingReading.setDescription(visitorReadingDto.getDescription());

        if (visitorReadingDto.getDescriptions() != null) {
            existingReading.setDescriptions(visitorReadingDto.getDescriptions().stream()
                    .map(descriptionConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
