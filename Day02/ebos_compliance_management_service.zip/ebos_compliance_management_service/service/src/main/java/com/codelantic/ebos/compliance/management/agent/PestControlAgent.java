package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.PestControlConverter;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.PestControlService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@RequiredArgsConstructor
public class PestControlAgent {

    private final PestControlService pestControlService;
    private final PestControlConverter pestControlConverter;

    public PaginatedResponseDto<PestControlOverviewDto> getAll(WasteManagementOverviewSearchDto searchDto) {
        Page<ComplianceReading> pestControlOverview = pestControlService.getAll(searchDto);

        List<ComplianceReading> complianceReadingList=pestControlOverview.getContent();
        int rowStartNum=1;
        AtomicInteger rowCounter = new AtomicInteger(rowStartNum);

        List<PestControlOverviewDto> pestControlOverviewDtos=complianceReadingList.stream().map(dto ->pestControlConverter.convertFromEntity(dto,rowCounter.getAndIncrement())).toList();
        PaginatedResponseDto<PestControlOverviewDto> paginatedResponse = new PaginatedResponseDto<>();
        paginatedResponse.setData(pestControlOverviewDtos);
        paginatedResponse.setCurrentPage(searchDto.getPage());
        paginatedResponse.setTotalItems(pestControlOverview.getTotalElements());
        paginatedResponse.setTotalPages(pestControlOverview.getTotalPages());
        return paginatedResponse;
    }

    public PestControlOverviewDto getOverViewById(String id) {
        return pestControlConverter.convertFromEntity(pestControlService.getOverViewById(id),1);

    }
}
