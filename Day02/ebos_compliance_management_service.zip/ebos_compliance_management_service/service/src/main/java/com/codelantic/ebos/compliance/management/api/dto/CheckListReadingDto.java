package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class CheckListReadingDto {
    private String id;
    private String complianceReadingId;
    private String subCategoryCheckListId;
    private Boolean isChecked;
    private String comment;
    private Set<ReadingImagesDto> readingImages;
}
