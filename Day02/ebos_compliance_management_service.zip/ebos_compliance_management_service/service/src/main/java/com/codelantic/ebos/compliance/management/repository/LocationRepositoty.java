package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.LocationDto;
import com.codelantic.ebos.compliance.management.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationRepositoty extends JpaRepository<Location,String> {
     Boolean existsByLocationNameAndBusinessId(String location, String businessId);

     @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.LocationDto(l.id,l.locationName) " +
             "FROM Location l " +
             "WHERE l.businessId IS NULL OR l.businessId = :businessId")
     List<LocationDto> getAllLocation(String businessId);
}
