package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;


@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class IncidentReadingDto {
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String typeOfIncident;
    private String severity;
    private String department;
    private String location;
    private String description;
    private String supportingEvidence;
    private String affectedParties;
    private String potentialImpact;
    private String immediateResponse;
    private String comments;
    private String subCategoryFormConfigurationId;
    private Set<AffectedPartiesDto> affectedPartiesAudio;
    private Set<PotentialImpactDto> potentialImpactsAudio;
    private Set<ImmediateResponseDto> immediateResponsesAudio;
    private Set<DescriptionDto> descriptions;
    private Set<NotifyToDto> notifyTo;
    private Set<DocumentsDto> documents;
    private String complianceSubCategoryId;
    private String createdBy;
}
