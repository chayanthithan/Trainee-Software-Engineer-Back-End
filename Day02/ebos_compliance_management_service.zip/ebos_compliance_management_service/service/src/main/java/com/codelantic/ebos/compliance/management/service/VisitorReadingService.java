package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.VisitorReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitorReadingDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.VisitorReadingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class VisitorReadingService {

    private final VisitorReadingConverter visitorReadingConverter;
    private final VisitorReadingRepository visitorReadingRepository;

    public ResponseDto save(VisitorReadingDto visitorReadingDto) {
        visitorReadingRepository.save(visitorReadingConverter.convert(visitorReadingDto));
        return ResponseDto.builder().message("Saved successfully").build();
    }

    public ResponseDto update(VisitorReadingDto visitorReadingDto) {

        if (visitorReadingDto.getId() == null) {
            throw new ServiceException("Visitor reading id is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        VisitorReading existingReading = visitorReadingRepository.findById(visitorReadingDto.getId()).
                orElseThrow(() -> new ServiceException("Visitor reading is not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        visitorReadingConverter.updateConvert(existingReading, visitorReadingDto);
        visitorReadingRepository.save(existingReading);
        return ResponseDto.builder().message("Update successfully").build();
    }

    public VisitorReadingDto getById(String id, ComplianceCategory complianceCategory) {
        VisitorReading visitorReading = visitorReadingRepository.findById(id).orElseThrow(() -> new ServiceException(complianceCategory + " not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return visitorReadingConverter.convert(visitorReading);
    }
}
