package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TypeOfWasteDto {

    private String id;
    @NotBlank(message = "WasteType is required")
    private String wastTypes;
    @NotBlank(message = "BusinessId is required")
    private String businessId;

    public TypeOfWasteDto(String id, String wastTypes) {
        this.id = id;
        this.wastTypes = wastTypes;
    }
}
