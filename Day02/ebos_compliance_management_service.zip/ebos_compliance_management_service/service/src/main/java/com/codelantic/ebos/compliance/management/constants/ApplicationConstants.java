package com.codelantic.ebos.compliance.management.constants;

public interface ApplicationConstants {

    static final String BAD_REQUEST = "Bad Request";
    static final String NOT_FOUND = "Not Found";
    static final String SLASH = "/";
    static final String COMPLIANCE = "Compliance";
    static final String TOAST_MESSAGE = "An image or a note is required.";

    static final String SUB_CATEGORY_NOT_FOUND="Sub category not found";


}
