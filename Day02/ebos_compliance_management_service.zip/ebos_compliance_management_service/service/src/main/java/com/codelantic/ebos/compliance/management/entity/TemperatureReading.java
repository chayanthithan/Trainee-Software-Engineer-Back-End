package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import java.util.Set;

@Data
@Entity
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class TemperatureReading {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String complianceSubCategoryId;
    private String temperatureTypeRangeConfigurationsId;
    private Integer quantity;
    private String actualReading;
    private String comments;
    private String complianceReadingId;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "temperatureReadingId")
    private Set<ReadingImages> readingImages;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "temperatureReadingId")
    private Set<NotifyTo> notifyTo;
}
