package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SubCategoryQuestionsReadingsDto {
    private String id;
    private String yesOrNo;
    private String comment;
    private String subCategoryQuestionsId;
    private String complianceReadingId;
    private Set<ReadingImagesDto> readingImages;
}
