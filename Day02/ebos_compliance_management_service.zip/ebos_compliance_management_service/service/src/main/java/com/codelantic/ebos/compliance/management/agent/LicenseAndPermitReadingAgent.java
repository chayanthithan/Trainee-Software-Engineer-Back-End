package com.codelantic.ebos.compliance.management.agent;


import com.codelantic.ebos.compliance.management.agent.converter.LicenseAndPermitReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.LicensePermitOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.service.LicenseAndPermitReadingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
@Slf4j
public class LicenseAndPermitReadingAgent {
private final LicenseAndPermitReadingService licenseAndPermitReadingService;
private final LicenseAndPermitReadingConverter licenseAndPermitReadingConverter;


    public PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> getAllLicensePermits(LicensePermitOverviewSearchDto licensePermitOverviewSearchDto) {
        Page<LicenseAndPermitReading> compliantReadings= licenseAndPermitReadingService.getAllLicenseAndPermitReading(licensePermitOverviewSearchDto);
log.info("compliantReadings page data "+compliantReadings);
        List<LicenseAndPermitReadingOverViewDto> licenseAndPermitReadingOverViewDtos = compliantReadings.getContent().stream()
                .map(licenseAndPermitReadingConverter::convertToDto).toList();
log.info("licenseAndPermitReadingOverViewDtos size "+licenseAndPermitReadingOverViewDtos.size());
        List<LicenseAndPermitReadingOverViewDto> compliantOverViewDtosWithRowNo = IntStream.range(0, licenseAndPermitReadingOverViewDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (licensePermitOverviewSearchDto.getPage() - 1) * licensePermitOverviewSearchDto.getSize();
                    licenseAndPermitReadingOverViewDtos.get(i).setRowNo(String.format("%02d", rowNo));
                    return licenseAndPermitReadingOverViewDtos.get(i);
                })
                .toList();

        return PaginatedResponseDto.<LicenseAndPermitReadingOverViewDto>builder()
                .data(compliantOverViewDtosWithRowNo)
                .currentPage(licensePermitOverviewSearchDto.getPage())
                .totalPages(compliantReadings.getTotalPages())
                .totalItems(compliantReadings.getTotalElements())
                .build();
    }

    public LicenseAndPermitReadingOverViewDto getLicenseOverviewById(String id,String rowNo) {
        return licenseAndPermitReadingConverter.convertToDtos(licenseAndPermitReadingService.getLicenseOverviewById(id),rowNo);
    }
}
