package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.SubCategoryCheckList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SubCategoryCheckListRepository extends JpaRepository<SubCategoryCheckList, String> {

    @Query("SELECT count(s) FROM SubCategoryCheckList s WHERE s.complianceSubCategoryId = :complianceSubCategoryId AND s.status = true ")
    Long countByComplianceSubCategoryId(String complianceSubCategoryId);


    @Query("SELECT s.id FROM SubCategoryCheckList s WHERE s.complianceSubCategoryId = :complianceSubCategoryId AND s.status = true")
    List<String> findIdsByComplianceSubCategoryId(@Param("complianceSubCategoryId") String complianceSubCategoryId);

    @Query("SELECT s.isDocumentAvailable FROM SubCategoryCheckList s WHERE s.id =:subCategoryCheckListId")
    boolean findResultForRecord(String subCategoryCheckListId);
}
