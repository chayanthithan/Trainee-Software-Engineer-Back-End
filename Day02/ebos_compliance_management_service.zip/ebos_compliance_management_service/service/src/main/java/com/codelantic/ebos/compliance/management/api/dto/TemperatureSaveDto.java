package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.Set;

@Data
@Validated
public class TemperatureSaveDto {
    @Valid
    private Set<TemperatureTypeRangeConfigurationDto> temperatureTypeRangeConfigurationDtos;
    @NotNull(message = "isRequiredQuantityBasedTemperatureReading is required.")
    private Boolean isRequiredQuantityBasedTemperatureReading;
}
