package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TrainingTitleDto;
import com.codelantic.ebos.compliance.management.entity.TrainingTitle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TrainingTitleRepository extends JpaRepository<TrainingTitle,String> {

    Boolean existsByTrainingTitleNameAndBusinessId(String trainingTitleName,String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.TrainingTitleDto(t.id,t.trainingTitleName) " +
            "FROM TrainingTitle t " +
            "WHERE t.businessId IS NULL OR t.businessId = :businessId")
    List<TrainingTitleDto> getTrainingTitles(String businessId);
}
