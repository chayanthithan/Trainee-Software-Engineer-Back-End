package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class DepartmentDto {
    private String id;
    @NotBlank(message = "Department Name is required")
    private String departmentName;
    @NotBlank(message = "Business Id is required")
    private String businessId;
}
