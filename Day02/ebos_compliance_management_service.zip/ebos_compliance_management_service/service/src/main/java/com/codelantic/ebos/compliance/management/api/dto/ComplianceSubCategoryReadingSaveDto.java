package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

@Data
public class ComplianceSubCategoryReadingSaveDto {
    private String complianceSubCategoryId;
    private String createdBy;
    private String businessId;
    private String comments;
}
