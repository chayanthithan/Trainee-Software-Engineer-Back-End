package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.VisitTypeDto;
import com.codelantic.ebos.compliance.management.entity.VisitType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class VisitorConvertor {

    public VisitType convertToEntity(VisitTypeDto visitTypeDto){
        return VisitType.builder()
                .businessId(visitTypeDto.getBusinessId())
                .typeOfVisit(visitTypeDto.getTypeOfVisit())
                .build();
    }
}
