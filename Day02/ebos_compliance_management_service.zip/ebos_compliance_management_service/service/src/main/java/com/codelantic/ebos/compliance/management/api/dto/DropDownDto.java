package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DropDownDto {
    List<String> complianceStatus;
    List<String> supportingEvidence;
    List<String> yesOrNo;
    List<String> temperatureType;
    List<String> complianceCategory;

}