package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TemperatureConfigurationsDto {

    private String id;
    private Boolean isRequiredQuantityBasedTempReading;
    private Set<TemperatureTypeRangeConfigurationsDto> temperatureTypeRangeConfigurations;
}
