package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotifyToDto {
    private String id;
    private String incidentReadingId;
    private String visitorReadingId;
    private String temperatureReadingId;
    private String complaintReadingId;
    private String userId;
    private String userName;
    private String profile;
}
