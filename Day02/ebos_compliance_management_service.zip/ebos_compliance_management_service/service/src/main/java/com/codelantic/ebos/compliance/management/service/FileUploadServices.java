package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.DocumentDescriptionConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.DocumentsRepository;
import com.codelantic.ebos.compliance.management.repository.ReadingImagesRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.file.utilities.service.FileUploadService;
import com.codelantic.file.utilities.service.dto.SftpCredentialsDto;
import com.jcraft.jsch.JSchException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.codelantic.ebos.compliance.management.constants.ApplicationConstants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileUploadServices {

    private final FileUploadService fileUploadService;
    private final UserManagementClient userManagementClient;
    private final DocumentsRepository documentsRepository;
    private final DocumentDescriptionConverter documentDescriptionConverter;
    private final Validations validations;
    private final ReadingImagesRepository readingImagesRepository;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final ComplianceRepository complianceRepository;
    @Value("${sftp.password}")
    private String sftpPassword;
    @Value("${sftp.host}")
    private String sftpHost;
    @Value("${sftp.userName}")
    private String sftpUserName;
    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;
    @Value("${sftp.port}")
    private String sftpPort;

    public ImageDetailDto uploadDocuments(UploadDocumentsDto uploadDocumentsDto, List<MultipartFile> files, String mediaType) throws JSchException {
        ImageDetailDto imageDetailDto = new ImageDetailDto();
            validateInput(files, mediaType);


        boolean isAvlible = complianceSubCategoryRepository.existsById(uploadDocumentsDto.getSubCategoryId());
        if (!isAvlible) {
            throw new ServiceException("Compliance Not Found", "Not Found", HttpStatus.BAD_REQUEST);
        }

        UploadDocumentDto uploadDocumentDtos = complianceSubCategoryRepository.getDetails(uploadDocumentsDto.getSubCategoryId());
        userManagementClient.checkBusinessId(uploadDocumentDtos.getBusinessId());

        if (files.isEmpty()) {
            return new ImageDetailDto();
        }

        SftpCredentialsDto sftpCredentialsDto = createSftpCredentials();
        String savePath = createSavePath(uploadDocumentsDto, uploadDocumentDtos);
        String mediaTypeFolder = mediaType.toLowerCase();
        String uploadPath = sftpUploadPath + savePath + SLASH + mediaTypeFolder;
        String filePathToProcess = savePath + SLASH + mediaTypeFolder;
        int startingNumber = getStartingNumber(uploadDocumentsDto, uploadDocumentDtos);

        ProcessedFilesResult result = processFiles(files, uploadDocumentsDto, filePathToProcess, startingNumber, uploadDocumentDtos);

        fileUploadService.uploadToSftp(result.getRenamedFiles(), uploadPath, "SFTP", sftpCredentialsDto);

        imageDetailDto.setImageResponseDtos(result.getImageResponseDtos());
        return imageDetailDto;
    }

    private void validateInput(List<MultipartFile> files, String mediaType) {
        if (files == null || files.isEmpty() || files.stream().allMatch(MultipartFile::isEmpty)) {
            throw new ServiceException("You should add at least one file", BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (!mediaType.equalsIgnoreCase("image") && !mediaType.equalsIgnoreCase("audio")) {
            throw new IllegalArgumentException("Invalid mediaType. Must be either 'image' or 'audio'");
        }
        if (mediaType.equalsIgnoreCase("image")){
            validations.validateTheFileFormat(files);
        } else if (mediaType.equalsIgnoreCase("audio")) {
            validations.validateAudioFileFormat(files);
        }
    }

    private SftpCredentialsDto createSftpCredentials() {
        SftpCredentialsDto sftpCredentialsDto = new SftpCredentialsDto();
        sftpCredentialsDto.setUserName(sftpUserName);
        sftpCredentialsDto.setPassword(sftpPassword);
        sftpCredentialsDto.setPort(sftpPort);
        sftpCredentialsDto.setHost(sftpHost);
        return sftpCredentialsDto;
    }

    private String createSavePath(UploadDocumentsDto uploadDocumentsDto, UploadDocumentDto uploadDocumentDtos) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss");
        String formattedDateTime = LocalDateTime.now().format(formatter);

        return String.join(SLASH,
                uploadDocumentDtos.getBusinessId(),
                COMPLIANCE,
                uploadDocumentDtos.getComplianceName(),
                uploadDocumentsDto.getSubCategoryId(),
                formattedDateTime);
    }

    private int getStartingNumber(UploadDocumentsDto uploadDocumentsDto, UploadDocumentDto uploadDocumentDtos) {
        if (uploadDocumentsDto.getReadingId() == null) {
            return uploadDocumentsDto.getImageNumber() != null && uploadDocumentsDto.getImageNumber() != 0
                    ? uploadDocumentsDto.getImageNumber()
                    : 0;
        }
        return isTemperatureOrRelatedCategory(uploadDocumentDtos)
                ? readingImagesRepository.getLastImageNumber(uploadDocumentsDto.getReadingId())
                : documentsRepository.getLastImageNumber(uploadDocumentsDto.getReadingId());
    }

    private ProcessedFilesResult processFiles(List<MultipartFile> files, UploadDocumentsDto uploadDocumentsDto, String filePath, int startingNumber, UploadDocumentDto uploadDocumentDtos) {
        AtomicInteger indexCounter = new AtomicInteger(0);

        List<MultipartFile> renamedFiles = new ArrayList<>();
        List<ImageResponseDto> responseDtos = new ArrayList<>();

        files.forEach(file -> {
            int index = indexCounter.getAndIncrement();
            String newFileName = createFileName(uploadDocumentsDto, index, startingNumber, uploadDocumentDtos,file.getOriginalFilename());

            RenamedMultipartFile renamedFile = new RenamedMultipartFile(file, newFileName);
            renamedFiles.add(renamedFile);

            String displayPath = filePath + SLASH + newFileName;
            ImageResponseDto responseDto = documentDescriptionConverter.convertToDto(displayPath, newFileName, startingNumber + index + 1);
            responseDtos.add(responseDto);

            log.info("Processed file: {}", displayPath);
        });

        return new ProcessedFilesResult(renamedFiles, responseDtos);
    }




    private String createFileName(UploadDocumentsDto uploadDocumentsDto, int index, int startingNumber, UploadDocumentDto uploadDocumentDtos, String originalFileName) {
        String baseName = uploadDocumentDtos.getSubCategoryName();
        String fileExtension = getFileExtension(originalFileName);

        if (uploadDocumentsDto.getReadingId() == null && startingNumber == 0) {
            return baseName + (index == 0 ? "" : "_" + index) + fileExtension;
        }
        return baseName + "_" + (startingNumber + index) + fileExtension;
    }

    private String getFileExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0) {
            return fileName.substring(lastDotIndex);
        }
        return ""; // Return empty string if there's no extension
    }

    private boolean isTemperatureOrRelatedCategory(UploadDocumentDto uploadDocumentDtos) {
        return EnumSet.of(ComplianceCategory.TEMPERATURE, ComplianceCategory.CLEANING,
                        ComplianceCategory.DELIVERY, ComplianceCategory.PEST_CONTROL)
                .contains(uploadDocumentDtos.getComplianceName());
    }

    public ResponseDto delete(List<DeleteImageDto> deleteImageDtos, String saveOrUpdate) {
        SftpCredentialsDto sftpCredentialsDto = new SftpCredentialsDto();
        sftpCredentialsDto.setHost(sftpHost);
        sftpCredentialsDto.setPort(sftpPort);
        sftpCredentialsDto.setUserName(sftpUserName);
        sftpCredentialsDto.setPassword(sftpPassword);

        List<String> responses = deleteImageDtos.stream()
                .map(deleteImageDto -> processDelete(deleteImageDto, saveOrUpdate, sftpCredentialsDto))
                .toList();

        if (!responses.isEmpty()) {
            return new ResponseDto(String.join(", ", responses));
        }
        return new ResponseDto("Invalid Operation");
    }

    // Helper method to process each deletion
    private String processDelete(DeleteImageDto deleteImageDto, String saveOrUpdate, SftpCredentialsDto sftpCredentialsDto) {
        try {
            if ("SAVE".equalsIgnoreCase(saveOrUpdate)) {
                fileUploadService.deleteFromSftp(deleteImageDto.getImagePath(), sftpCredentialsDto, "SFTP");
                return "Successfully Deleted In Server!";
            } else if ("UPDATE".equalsIgnoreCase(saveOrUpdate)) {
                return deleteImages(deleteImageDto, sftpCredentialsDto);
            }
        } catch (JSchException | IOException e) {
            return "Failed to delete Image: " + e.getMessage();
        }
        return "Invalid Operation";
    }

    // Updated deleteImages method to return the result as a String
    private String deleteImages(DeleteImageDto deleteImageDto, SftpCredentialsDto sftpCredentialsDto) throws JSchException, IOException {
        if (deleteImageDto.getDocumentId()==null)
        {
            throw new ServiceException("Id required","Id Required",HttpStatus.BAD_REQUEST);
        }
        if (deleteImageDto.getDocumentId() != null) {
            boolean isAvailable = documentsRepository.existsByImagePathAndId(deleteImageDto.getImagePath(), deleteImageDto.getDocumentId());
            boolean isAvalibleReading = readingImagesRepository.existsByImagePathAndId(deleteImageDto.getImagePath(), deleteImageDto.getDocumentId());
            if (isAvailable) {
                int isDeleted = documentsRepository.deleteImage(deleteImageDto.getImagePath(), deleteImageDto.getDocumentId());
                if (isDeleted > 0) {
                    fileUploadService.deleteFromSftp(deleteImageDto.getImagePath(), sftpCredentialsDto, "SFTP");
                    return "Document Deleted";
                }
            }
            else if (isAvalibleReading)
            {
                int isDeleted = readingImagesRepository.deleteImage(deleteImageDto.getImagePath(), deleteImageDto.getDocumentId());
                if (isDeleted > 0) {
                    fileUploadService.deleteFromSftp(deleteImageDto.getImagePath(), sftpCredentialsDto, "SFTP");
                    return "Document Deleted";
                }
            }
            return "Failed to delete Document";
        }
        return "Document ID is missing";
    }



    public ResponseEntity<byte[]> downloadDocument(List<String> documentUr) throws IOException {
        /* set the sftp Credentials from application properties */
        SftpCredentialsDto sftpCredentialsDto = new SftpCredentialsDto();
        sftpCredentialsDto.setHost(sftpHost);
        sftpCredentialsDto.setPassword(sftpPassword);
        sftpCredentialsDto.setUserName(sftpUserName);
        sftpCredentialsDto.setPort(sftpPort);

        // Call the service to download and zip the files
        byte[] zipFile ;
        try {
            zipFile = fileUploadService.downloadAndZipFiles(documentUr, sftpCredentialsDto, "SFTP");
        } catch (JSchException e) {
            throw new ServiceException("File Download failed", "Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // Set the headers to download the zip file
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"compliance_documents.zip\"");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        // Return the zip file as a byte array in the response entity
        return new ResponseEntity<>(zipFile, headers, HttpStatus.OK);
    }

    public ResponseEntity<byte[]> downloadSingleDocument(String documentUrl) throws JSchException, IOException {
        SftpCredentialsDto sftpCredentialsDto = new SftpCredentialsDto();
        sftpCredentialsDto.setHost(sftpHost);
        sftpCredentialsDto.setPassword(sftpPassword);
        sftpCredentialsDto.setUserName(sftpUserName);
        sftpCredentialsDto.setPort(sftpPort);

        byte[] fileData = fileUploadService.downloadFromSftp(documentUrl, sftpCredentialsDto, "SFTP");

        // Define headers for file download response
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename(documentUrl.substring(documentUrl.lastIndexOf('/') + 1))
                .build());

        // Return file data as ResponseEntity with headers
        return ResponseEntity.ok()
                .headers(headers)
                .body(fileData);
    }
}
