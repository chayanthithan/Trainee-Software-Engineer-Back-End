package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceAgent;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/compliance")
@RequiredArgsConstructor
@Validated
public class ComplianceController {


    private final ComplianceAgent complianceAgent;

    @PutMapping("/business-compliance-configurations")
    public ResponseDto addOrRemoveComplianceForBusiness(@RequestBody @Valid ComplianceConfigurationsDto complianceConfigurationsDto) {
        return complianceAgent.addComplianceToBusiness(complianceConfigurationsDto);
    }

    @GetMapping("/get-all-available-compliance")
    public List<ComplianceDto> getAllAvailableCompliance(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business Id is required") String businessId){
        return complianceAgent.getAllAvailableCompliance(businessId);
    }


}
