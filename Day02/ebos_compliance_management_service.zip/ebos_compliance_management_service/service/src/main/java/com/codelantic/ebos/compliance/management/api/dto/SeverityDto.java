package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Validated
public class SeverityDto {
    private String id;
    @NotBlank(message = "Severity name is required")
    private String severityName;
    @NotBlank(message = "business id is required")
    private String businessId;

    public SeverityDto(String id, String severityName) {
        this.id = id;
        this.severityName = severityName;
    }

    public SeverityDto() {
    }
}
