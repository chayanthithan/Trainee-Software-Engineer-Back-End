package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChecklistAndQuestionDisplayDto {
    private String checkListTitle;
    private String checkListItems;
    private String response;
    private String note;
    private String image;

}
