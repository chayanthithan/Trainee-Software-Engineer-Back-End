package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TemperatureReadingConfigurationsDto {
    private List<TemperatureItemDto>items=new ArrayList<>();
    private String temperatureConfigurationId;
    private Boolean isRequiredQuantityBasedTempReading;

    public TemperatureReadingConfigurationsDto(String temperatureConfigurationId, Boolean isRequiredQuantityBasedTempReading) {
        this.temperatureConfigurationId = temperatureConfigurationId;
        this.isRequiredQuantityBasedTempReading = isRequiredQuantityBasedTempReading;
    }
}
