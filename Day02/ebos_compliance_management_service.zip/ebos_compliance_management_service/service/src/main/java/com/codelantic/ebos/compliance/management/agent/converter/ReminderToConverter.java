package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ReminderToDto;
import com.codelantic.ebos.compliance.management.entity.ReminderTo;
import org.springframework.stereotype.Component;

@Component
public class ReminderToConverter {

    public ReminderTo convert(ReminderToDto reminderToDto) {
        return ReminderTo.builder()
                .id(reminderToDto.getId())
                .licenseAndPermitReadingId(reminderToDto.getLicenseAndPermitReadingId())
                .imageName(reminderToDto.getImageName())
                .imagePath(reminderToDto.getImagePath())
                .build();
    }

    public ReminderToDto convert(ReminderTo reminderTo) {
        return ReminderToDto.builder()
                .id(reminderTo.getId())
                .licenseAndPermitReadingId(reminderTo.getLicenseAndPermitReadingId())
                .imageName(reminderTo.getImageName())
                .imagePath(reminderTo.getImagePath())
                .build();
    }
}
