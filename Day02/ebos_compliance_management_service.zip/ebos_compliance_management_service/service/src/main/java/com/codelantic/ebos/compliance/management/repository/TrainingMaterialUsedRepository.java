package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.ViewTrainingMaterialUsedDto;
import com.codelantic.ebos.compliance.management.entity.TrainingMaterialUsed;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TrainingMaterialUsedRepository extends JpaRepository<TrainingMaterialUsed,String> {
    Boolean existsByTrainingMaterialUsedNameAndBusinessId(String trainingMaterialUsedName, String businessId);

    @Query("SELECT NEW com.codelantic.ebos.compliance.management.api.dto.ViewTrainingMaterialUsedDto(t.id,t.trainingMaterialUsedName) " +
            "FROM TrainingMaterialUsed t " +
            "WHERE t.businessId IS NULL OR t.businessId = :businessId ")
    List<ViewTrainingMaterialUsedDto> getTrainingMaterialUsed(String businessId);
}
