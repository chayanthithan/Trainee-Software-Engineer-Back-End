package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public enum TrainingObjectives {
    FOOD_AND_SAFETY("Food And Safety"),
    ACCIDENT("Accident");


    private final String mappedValue;

    TrainingObjectives(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static TrainingObjectives fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        for (TrainingObjectives trainingObjectives : TrainingObjectives.values()) {
            if (trainingObjectives.mappedValue.equalsIgnoreCase(mappedValue)) {
                return trainingObjectives;
            }
        }
        throw new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST);
    }


    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        for (TrainingObjectives trainingObjectives : TrainingObjectives.values()) {
            list.add(trainingObjectives.mappedValue);
        }
        return list;
    }
}
