package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.SubCategoryFormConfigurations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SubCategoryFormConfigurationsRepository extends JpaRepository<SubCategoryFormConfigurations,String> {

    Boolean existsByComplianceSubCategoryId(String complianceSubCategoryId);

    @Query("select s.formSettingsConfigurationId from SubCategoryFormConfigurations s where s.complianceSubCategoryId=:complianceSubCategoryId")
    List<String> findFormSettingsConfigurationIdByComplianceSubCategoryId(String complianceSubCategoryId);
}
