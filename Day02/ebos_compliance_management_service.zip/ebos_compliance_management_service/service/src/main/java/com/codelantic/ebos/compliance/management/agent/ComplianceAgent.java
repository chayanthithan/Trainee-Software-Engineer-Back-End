package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ComplianceAgent {

    private final ComplianceService complianceService;

    public ResponseDto addComplianceToBusiness(ComplianceConfigurationsDto complianceConfigurationsDto) {
       return complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto);

    }

    public List<ComplianceDto> getAllAvailableCompliance(String businessId) {
        return complianceService.getAllAvailableCompliance(businessId);
    }
}
