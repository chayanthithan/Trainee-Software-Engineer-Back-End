package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CheckListHeadingDto;
import com.codelantic.ebos.compliance.management.api.dto.SubCategoryCheckListSaveDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.SubCategoryCheckList;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;


@Component
@RequiredArgsConstructor
@Slf4j
public class SubCategoryCheckListConverter {
    private final SubCategoryCheckListRepository subCategoryCheckListRepository;

    public SubCategoryCheckList convertToEntity(SubCategoryCheckListSaveDto subCategoryCheckListSaveDto) {
        return SubCategoryCheckList.builder()
                .heading(subCategoryCheckListSaveDto.getHeading())
                .checklist(subCategoryCheckListSaveDto.getCheckList())
                .isCommentAvailable(subCategoryCheckListSaveDto.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryCheckListSaveDto.getIsDocumentAvailable())
                .status(Boolean.TRUE)
                .build();
    }

    public SubCategoryCheckListSaveDto convertToSubCategoryCheckListSaveDto(SubCategoryCheckList subCategoryCheckList) {
        return SubCategoryCheckListSaveDto.builder()
                .id(subCategoryCheckList.getId())
                .heading(subCategoryCheckList.getHeading())
                .checkList(subCategoryCheckList.getChecklist())
                .isCommentAvailable(subCategoryCheckList.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryCheckList.getIsDocumentAvailable())
                .build();
    }


    public SubCategoryCheckList convertToUpdate(SubCategoryCheckListSaveDto dto, String complianceSubCategoryId) {
        SubCategoryCheckList subCategoryCheckList = subCategoryCheckListRepository.findById(dto.getId())
                .orElseThrow(() -> new ServiceException("Sub category checklist not found for id: " + dto.getId(),
                        ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST));
        if(dto.getIsCommentAvailable() == Boolean.FALSE && dto.getIsDocumentAvailable() == Boolean.FALSE ){
            throw new ServiceException(ApplicationConstants.TOAST_MESSAGE, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        subCategoryCheckList.setChecklist(dto.getCheckList());
        subCategoryCheckList.setHeading(dto.getHeading());
        subCategoryCheckList.setComplianceSubCategoryId(complianceSubCategoryId);
        subCategoryCheckList.setIsCommentAvailable(dto.getIsCommentAvailable());
        subCategoryCheckList.setIsDocumentAvailable(dto.getIsDocumentAvailable());
        subCategoryCheckList.setStatus(Boolean.TRUE);

        return subCategoryCheckList;
    }

    public CheckListHeadingDto convertToCheckListHeadingDto(SubCategoryCheckList subCategoryCheckList) {
        return CheckListHeadingDto.builder()
                .id(subCategoryCheckList.getId())
                .checkList(subCategoryCheckList.getChecklist())
                .isCommentAvailable(subCategoryCheckList.getIsCommentAvailable())
                .isDocumentAvailable(subCategoryCheckList.getIsDocumentAvailable())
                .build();
    }

    public SubCategoryCheckList convertToNew(SubCategoryCheckListSaveDto dto, String complianceSubCategoryId) {
        SubCategoryCheckList subCategoryCheckList = new SubCategoryCheckList();
        if(dto.getIsCommentAvailable() == Boolean.FALSE && dto.getIsDocumentAvailable() == Boolean.FALSE ){
            throw new ServiceException(ApplicationConstants.TOAST_MESSAGE, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        subCategoryCheckList.setChecklist(dto.getCheckList());
        subCategoryCheckList.setHeading(dto.getHeading());
        subCategoryCheckList.setComplianceSubCategoryId(complianceSubCategoryId);
        subCategoryCheckList.setIsCommentAvailable(dto.getIsCommentAvailable());
        subCategoryCheckList.setIsDocumentAvailable(dto.getIsDocumentAvailable());
        subCategoryCheckList.setStatus(Boolean.TRUE);
        return subCategoryCheckList;
    }

}
