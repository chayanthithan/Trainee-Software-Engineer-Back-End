package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.api.dto.TemperatureItemDto;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRangeConfigurations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TemperatureTypeRangeConfigurationsRepository extends JpaRepository<TemperatureTypeRangeConfigurations,String> {




}
