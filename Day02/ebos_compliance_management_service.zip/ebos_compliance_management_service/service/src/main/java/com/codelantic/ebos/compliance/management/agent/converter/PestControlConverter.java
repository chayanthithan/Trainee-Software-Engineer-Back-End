package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
@RequiredArgsConstructor

public class PestControlConverter {
    private final UserManagementClient userManagementClient;
    private final CheckListReadingRepository checkListReadingRepository;


    public PestControlOverviewDto convertFromEntity(ComplianceReading dto, int andIncrement) {
        PestControlOverviewDto pestControlOverviewDto = PestControlOverviewDto.builder().build();
        UserName userName = userManagementClient.getUserNameById(dto.getCreatedBy());
        pestControlOverviewDto.setId(dto.getId());
        pestControlOverviewDto.setRowNo(andIncrement);
        pestControlOverviewDto.setDate(dto.getDate());
        pestControlOverviewDto.setTime(dto.getTime());
        pestControlOverviewDto.setEmployeeName(userName.getName());
        pestControlOverviewDto.setComplianceStatus(dto.getComplianceStatus().getMappedValue());

        TotalCheckedCountDto counts = checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(dto.getId());
        Long total = counts.getTotalCount();
        Long totalChecked = counts.getCheckedCount();

        String pendingOverTotal = totalChecked + " / " + total;
        pestControlOverviewDto.setPendingOverTotal(total != 0 ? pendingOverTotal : "0");
        Set<ImageDescriptionDto> imageDescriptions = Stream.concat(
                        // using parallel stream for images from check list readings
                        dto.getCheckListReadings().parallelStream()
                                .flatMap(checkListReading -> checkListReading.getReadingImages().parallelStream()),

                        // using parallel stream for images from sub category questions readings
                        dto.getSubCategoryQuestionsReadings().parallelStream()
                                .flatMap(subCategoryQuestionsReading -> subCategoryQuestionsReading.getReadingImages().parallelStream())
                )
                .map(readingImage -> ImageDescriptionDto.builder()
                        .id(readingImage.getId())
                        .fileName(readingImage.getImageName())
                        .fullViewPath(readingImage.getImagePath())
                        .downloadPath(readingImage.getImagePath())
                        .build())
                .collect(Collectors.toSet());
        pestControlOverviewDto.setImages(imageDescriptions);
        return pestControlOverviewDto;

    }


}
