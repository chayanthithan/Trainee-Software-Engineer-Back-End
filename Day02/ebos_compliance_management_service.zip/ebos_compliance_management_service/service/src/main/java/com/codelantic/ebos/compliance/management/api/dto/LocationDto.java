package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocationDto {
    private String id;
    @NotBlank(message = "locationName Id is required")
    private String locationName;
    @NotBlank(message = "Business Id is required")
    private String businessId;

    public LocationDto(String id,String locationName) {
        this.locationName = locationName;
        this.id = id;
    }

    public LocationDto() {

    }
}
