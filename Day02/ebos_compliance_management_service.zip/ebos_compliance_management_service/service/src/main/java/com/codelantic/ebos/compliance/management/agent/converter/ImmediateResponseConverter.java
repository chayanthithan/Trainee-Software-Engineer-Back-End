package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ImmediateResponseDto;
import com.codelantic.ebos.compliance.management.entity.ImmediateResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ImmediateResponseConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;
    public ImmediateResponse convert(ImmediateResponseDto immediateResponseDto) {
        return ImmediateResponse.builder()
                .id(immediateResponseDto.getId())
                .audio(immediateResponseDto.getAudio())
                .audioPath(immediateResponseDto.getAudioPath())
                .incidentReadingId(immediateResponseDto.getIncidentReadingId())
                .build();
    }

    public ImmediateResponseDto convert(ImmediateResponse immediateResponse) {
        return ImmediateResponseDto.builder()
                .id(immediateResponse.getId())
                .audio(immediateResponse.getAudio())
                .viewAudioPath(baseUrl+immediateResponse.getAudioPath())
                .downloadAudioPath(downloadBaseUrl+immediateResponse.getAudioPath())
                .incidentReadingId(immediateResponse.getIncidentReadingId())
                .build();
    }
}
