package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CheckListReadingDto;
import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class CheckListReadingConverter {

    private final ReadingImagesConverter readingImagesConverter;
    private final SubCategoryCheckListRepository subCategoryCheckListRepository;

    public CheckListReading convert(CheckListReadingDto checkListReadingDto) {

        boolean result = subCategoryCheckListRepository.findResultForRecord(checkListReadingDto.getSubCategoryCheckListId());
        if(result && checkListReadingDto.getReadingImages().isEmpty()){
            throw new ServiceException("Image needs to be uploaded", "Bad request", HttpStatus.BAD_REQUEST);
        }
        return CheckListReading.builder()
                .id(checkListReadingDto.getId())
                .complianceReadingId(checkListReadingDto.getComplianceReadingId())
                .subCategoryCheckListId(checkListReadingDto.getSubCategoryCheckListId())
                .isChecked(checkListReadingDto.getIsChecked())
                .comment(checkListReadingDto.getComment())
                .readingImages(checkListReadingDto.getReadingImages()!=null? checkListReadingDto.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null )
                .build();
    }

    public CheckListReadingDto convert(CheckListReading checkListReading) {
        return CheckListReadingDto.builder()
                .id(checkListReading.getId())
                .complianceReadingId(checkListReading.getComplianceReadingId())
                .subCategoryCheckListId(checkListReading.getSubCategoryCheckListId())
                .isChecked(checkListReading.getIsChecked())
                .comment(checkListReading.getComment())
                .readingImages(checkListReading.getReadingImages()!=null? checkListReading.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null )
                .build();
    }
}
