package com.codelantic.ebos.compliance.management.api.dto;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class RenamedMultipartFile implements MultipartFile {
    private final MultipartFile delegate;
    private final String filename;

    public RenamedMultipartFile(MultipartFile delegate, String filename) {
        this.delegate = delegate;
        this.filename = filename;
    }

    @Override
    public String getName() {
        return delegate.getName();
    }

    @Override
    public String getOriginalFilename() {
        return filename;
    }

    @Override
    public String getContentType() {
        return delegate.getContentType();
    }

    @Override
    public boolean isEmpty() {
        return delegate.isEmpty();
    }

    @Override
    public long getSize() {
        return delegate.getSize();
    }

    @Override
    public byte[] getBytes() throws IOException {
        return delegate.getBytes();
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return delegate.getInputStream();
    }

    @Override
    public void transferTo(File dest) throws IOException, IllegalStateException {
        try (InputStream in = delegate.getInputStream()) {
            Files.copy(in, dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    // Spring 5.0+ method
    public void transferTo(Path dest) throws IOException, IllegalStateException {
        try (InputStream in = delegate.getInputStream()) {
            Files.copy(in, dest, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    // Additional helper methods

    public MultipartFile getDelegate() {
        return delegate;
    }

    @Override
    public String toString() {
        return "RenamedMultipartFile{" +
                "originalName='" + delegate.getOriginalFilename() + '\'' +
                ", newName='" + filename + '\'' +
                ", contentType='" + getContentType() + '\'' +
                ", size=" + getSize() +
                '}';
    }
}
