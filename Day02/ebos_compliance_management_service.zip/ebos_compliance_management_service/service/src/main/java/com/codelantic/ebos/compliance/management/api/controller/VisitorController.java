package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.VisitorAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/visitor")
@RequiredArgsConstructor
public class VisitorController {

    private final VisitorAgent visitorAgent;


    @PostMapping("/save-visit-type")
    public ResponseDto saveVisitType(@RequestBody @Valid VisitTypeDto visitTypeDto) {
        return visitorAgent.addNewVisitorType(visitTypeDto);
    }

    @GetMapping("/visit-type")
    public List<VisitTypeDto> getAllVisitTypeByBusinessId(@RequestParam(name = "businessId") @NotBlank(message = "Business id is required") String businessId) {
        return visitorAgent.getAllVisitTypeByBusinessId(businessId);
    }

    @GetMapping("/get-visitor-overview")
    public PaginatedResponseDto<VisitorOverviewDto> getVistorOverview(
            @RequestParam(value = "businessId") String businessId,
            @RequestParam(value = "subCategoryId") String subCategoryId,
            @RequestParam(value = "fromDate") LocalDate fromDate,
            @RequestParam(value = "toDate") LocalDate toDate,
            @RequestParam(value = "employeeId", required = false) String employeeId,
            @RequestParam(value = "complianceStatus", required = false) String complianceStatus,
            @RequestParam(value = "page", required = false) @Positive(message = "Page number must be positive") Integer page,
            @RequestParam(value = "size", required = false) @Positive(message = "Size must be positive") Integer size
    ) {
        VisitorSearchDto visitorSearchDto = VisitorSearchDto.builder()
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeId(employeeId)
                .complianceStatus(complianceStatus)
                .page(page)
                .size(size)
                .build();
        return visitorAgent.getVistorOverview(visitorSearchDto);
    }

    @GetMapping("/get-row-visitor")
    public VisitorOverviewDto getRowVisitor(@RequestParam(value = "id",required = false) @NotBlank(message = "Id is required") String id){
        return visitorAgent.getRowVisitor(id);
    }


}
