package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingGetDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ComplianceReadingConverter {

    private final CheckListReadingConverter checkListReadingConverter;
    private final SubCategoryQuestionsReadingsConverter subCategoryQuestionsReadingsConverter;
    private final TemperatureReadingConverter temperatureReadingConverter;

    public ComplianceReading convert(ComplianceReadingDto complianceReadingDto) {
        return ComplianceReading.builder()
                .id(complianceReadingDto.getId())
                .complianceSubCategoryId(complianceReadingDto.getComplianceSubCategoryId())
                .createdBy(AuthenticationContextHolder.getContext().getUserId())
                .businessId(complianceReadingDto.getBusinessId())
                .comments(complianceReadingDto.getComments())
                .reviewerComments(complianceReadingDto.getReviewerComments())
                .complianceStatus(complianceReadingDto.getComplianceStatus()!=null ? ComplianceStatus.fromMappedValue(complianceReadingDto.getComplianceStatus()) : null)
                .checkListReadings(complianceReadingDto.getCheckListReadings() != null ? complianceReadingDto.getCheckListReadings().stream().map
                        (checkListReadingConverter::convert).collect(Collectors.toSet()) : null)
                .subCategoryQuestionsReadings(complianceReadingDto.getSubCategoryQuestionsReadings()!=null? complianceReadingDto.getSubCategoryQuestionsReadings().stream().map
                        (subCategoryQuestionsReadingsConverter::convert).collect(Collectors.toSet()) : null)
                .temperatureReadings(complianceReadingDto.getTemperatureReadings()!=null ? complianceReadingDto.getTemperatureReadings().stream().map
                        (temperatureReadingConverter::convert).collect(Collectors.toSet()) : null)
                .date(LocalDate.now())
                .time(LocalTime.now())
                .build();

    }

    public ComplianceReadingDto convert(ComplianceReading complianceReading,String userName) {
        return ComplianceReadingDto.builder()
                .id(complianceReading.getId())
                .complianceSubCategoryId(complianceReading.getComplianceSubCategoryId())
                .createdBy(userName)
                .businessId(complianceReading.getBusinessId())
                .comments(complianceReading.getComments())
                .reviewerComments(complianceReading.getReviewerComments())
                .complianceStatus(complianceReading.getComplianceStatus()!=null ? complianceReading.getComplianceStatus().getMappedValue() : null)
                .checkListReadings(complianceReading.getCheckListReadings() != null ? complianceReading.getCheckListReadings().stream().map
                        (checkListReadingConverter::convert).collect(Collectors.toSet()) : null)
                .subCategoryQuestionsReadings(complianceReading.getSubCategoryQuestionsReadings()!=null? complianceReading.getSubCategoryQuestionsReadings().stream().map
                        (subCategoryQuestionsReadingsConverter::convert).collect(Collectors.toSet()) : null)
                .temperatureReadings(complianceReading.getTemperatureReadings()!=null ? complianceReading.getTemperatureReadings().stream().map
                        (temperatureReadingConverter::convert).collect(Collectors.toSet()) : null)
                .date(LocalDate.now())
                .time(LocalTime.now())
                .build();

    }
    public ComplianceReadingGetDto convertToDto(ComplianceReading complianceReading, String userName) {
        return ComplianceReadingGetDto.builder()
                .id(complianceReading.getId())
                .complianceSubCategoryId(complianceReading.getComplianceSubCategoryId())
                .createdBy(userName)
                .businessId(complianceReading.getBusinessId())
                .comments(complianceReading.getComments())
                .reviewerComments(complianceReading.getReviewerComments())
                .complianceStatus(complianceReading.getComplianceStatus()!=null?complianceReading.getComplianceStatus().getMappedValue() : null)
                .checkListReadings(complianceReading.getCheckListReadings() != null ? complianceReading.getCheckListReadings().stream().map
                        (checkListReadingConverter::convert).collect(Collectors.toSet()) : null)
                .subCategoryQuestionsReadings(complianceReading.getSubCategoryQuestionsReadings()!=null? complianceReading.getSubCategoryQuestionsReadings().stream().map
                        (subCategoryQuestionsReadingsConverter::convert).collect(Collectors.toSet()) : null)
                .temperatureReadings(complianceReading.getTemperatureReadings()!=null ? complianceReading.getTemperatureReadings().stream().map
                        (temperatureReadingConverter::convertTempreature).sorted(Comparator.comparingInt(dto->dto.getSequence())).collect(Collectors.toCollection(LinkedHashSet::new)) : null)
                .date(complianceReading.getDate())
                .time(complianceReading.getTime())
                .build();

    }

    public void updateConvert(ComplianceReading existingReading, ComplianceReadingDto complianceReadingDto) {
        existingReading.setId(complianceReadingDto.getId());
        existingReading.setComplianceSubCategoryId(complianceReadingDto.getComplianceSubCategoryId());
        existingReading.setBusinessId(complianceReadingDto.getBusinessId());
        existingReading.setComments(complianceReadingDto.getComments());
        existingReading.setReviewerComments(complianceReadingDto.getReviewerComments());
        existingReading.setComplianceStatus(complianceReadingDto.getComplianceStatus()!=null? ComplianceStatus.fromMappedValue(complianceReadingDto.getComplianceStatus()) : null);

        if (complianceReadingDto.getCheckListReadings() != null) {
            existingReading.setCheckListReadings(complianceReadingDto.getCheckListReadings().stream()
                    .map(checkListReadingConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (complianceReadingDto.getSubCategoryQuestionsReadings() != null) {
            existingReading.setSubCategoryQuestionsReadings(complianceReadingDto.getSubCategoryQuestionsReadings().stream()
                    .map(subCategoryQuestionsReadingsConverter::convert)
                    .collect(Collectors.toSet()));
        }

        if (complianceReadingDto.getTemperatureReadings() != null) {
            existingReading.setTemperatureReadings(complianceReadingDto.getTemperatureReadings().stream()
                    .map(temperatureReadingConverter::convert)
                    .collect(Collectors.toSet()));
        }
    }
}
