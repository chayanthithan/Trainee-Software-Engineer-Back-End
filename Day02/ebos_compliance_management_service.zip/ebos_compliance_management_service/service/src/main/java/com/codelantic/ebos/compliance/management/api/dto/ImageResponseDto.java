package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

@Data
public class ImageResponseDto {
    private String fileName;
    private String filePath;
    private String downloadPath;
    private String imageViewPath;
    private int imageNumber;

}
