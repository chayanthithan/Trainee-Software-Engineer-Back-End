package com.codelantic.ebos.compliance.management.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Data
@Validated
public class TemperatureTypeRangeUpdateDto {

    @NotBlank(message = "Compliance Subcategory Id required")
    private String complianceSubcategoryId;
    @Valid
    private List<TemperatureTypeRangeDto> temperatureTypeRangeDtoList;
}
