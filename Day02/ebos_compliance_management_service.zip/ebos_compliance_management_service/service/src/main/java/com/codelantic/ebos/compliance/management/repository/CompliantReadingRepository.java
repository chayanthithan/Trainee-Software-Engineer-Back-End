package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface CompliantReadingRepository extends JpaRepository<CompliantReading,String> {

    @Query("SELECT cr FROM CompliantReading cr " +
            "LEFT JOIN ComplianceSubCategory cs ON cs.id = cr.complianceSubCategoryId " +
            "WHERE cs.businessId = :businessId " +
            "AND cr.complianceSubCategoryId = :complianceSubCategoryId " +
            "AND (:fromDate IS NULL OR :toDate IS NULL OR cr.date BETWEEN :fromDate AND :toDate) " +
            "AND (:employeeName IS NULL OR cr.createdBy = :employeeName) " +
            "AND (:complianceStatus IS NULL OR cr.complianceStatus= :complianceStatus)")
    Page<CompliantReading> getAllComplaints(String businessId,String complianceSubCategoryId, LocalDate fromDate, LocalDate toDate, String employeeName, ComplianceStatus complianceStatus, Pageable paging);

    @Query("SELECT cr FROM CompliantReading cr " +
            "WHERE cr.id = :id " )
    Optional<CompliantReading> getOverviewCompliantById(String id);

}
