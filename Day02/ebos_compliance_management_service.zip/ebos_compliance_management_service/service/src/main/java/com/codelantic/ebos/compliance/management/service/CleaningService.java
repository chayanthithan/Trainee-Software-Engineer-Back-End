package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.CleaningOverviewSearchDto;
import com.codelantic.ebos.compliance.management.constants.ApplicationConstants;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CleaningService {
    private final UserManagementClient userManagementClient;
    private final Validations validations;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final ComplianceReadingRepository complianceReadingRepository;


    public Page<ComplianceReading> getAllOverViewForCleaning(CleaningOverviewSearchDto cleaningOverviewSearchDto) {
        userManagementClient.checkBusinessId(cleaningOverviewSearchDto.getBusinessId());
        validations.dateValidation(cleaningOverviewSearchDto.getFromDate(), cleaningOverviewSearchDto.getToDate());
        Pageable paging = PageRequest.of(cleaningOverviewSearchDto.getPage() - 1, cleaningOverviewSearchDto.getSize());
        boolean isFound = complianceSubCategoryRepository.existsByIdAndStatus(cleaningOverviewSearchDto.getSubCategoryId(), true);
        if (!isFound) {
            throw new ServiceException("Compliance sub category id not found", ApplicationConstants.NOT_FOUND, HttpStatus.BAD_REQUEST);
        }

        return complianceReadingRepository.getAllOverViewForCleaning(cleaningOverviewSearchDto.getBusinessId(),
                cleaningOverviewSearchDto.getFromDate(), cleaningOverviewSearchDto.getToDate(),
                cleaningOverviewSearchDto.getEmployeeName(), cleaningOverviewSearchDto.getComplianceStatus(), paging,
                cleaningOverviewSearchDto.getSubCategoryId());
    }

    public ComplianceReading getOverviewCleaningById(String complianceReadingId) {
        ComplianceReading complianceReading = complianceReadingRepository.findById(complianceReadingId).orElseThrow(()-> new ServiceException("Compliance reading id not found",ApplicationConstants.NOT_FOUND,HttpStatus.BAD_REQUEST));
        log.info("ComplianceReading "+complianceReading);
        return complianceReadingRepository.getOverviewCleaningById(complianceReadingId);
    }
}
