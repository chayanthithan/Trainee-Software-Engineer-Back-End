package com.codelantic.ebos.compliance.management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Data
@Entity
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class ReadingImages {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private String id;
    private String imageName;
    private String imagePath;
    private String questionsReadingId;
    private String checklistReadingId;
    private String temperatureReadingId;
    private Integer imageNumber;

}
