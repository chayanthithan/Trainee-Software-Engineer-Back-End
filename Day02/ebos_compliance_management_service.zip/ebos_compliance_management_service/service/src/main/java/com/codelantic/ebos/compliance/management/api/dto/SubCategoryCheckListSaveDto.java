package com.codelantic.ebos.compliance.management.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubCategoryCheckListSaveDto {
    private String id;
    private String heading;
    private String checkList;
    private Boolean isCommentAvailable;
    private Boolean isDocumentAvailable;
    private Boolean status;
}
