package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ReadingImagesDto;
import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ReadingImagesConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;
    public ReadingImages convert(ReadingImagesDto readingImagesDto) {
        return ReadingImages.builder()
                .id(readingImagesDto.getId())
                .imageName(readingImagesDto.getImageName())
                .imagePath(readingImagesDto.getImagePath())
                .questionsReadingId(readingImagesDto.getQuestionsReadingId())
                .checklistReadingId(readingImagesDto.getChecklistReadingId())
                .temperatureReadingId(readingImagesDto.getTemperatureReadingId())
                .build();
    }

    public ReadingImagesDto convert(ReadingImages readingImages) {
        return ReadingImagesDto.builder()
                .id(readingImages.getId())
                .imageName(readingImages.getImageName())
                .viewImagePath(readingImages.getImagePath()!=null?baseUrl+readingImages.getImagePath():null)
                .downloadImagePath(readingImages.getImagePath()!=null?downloadBaseUrl+readingImages.getImagePath():null)
                .imagePath(readingImages.getImagePath())
                .questionsReadingId(readingImages.getQuestionsReadingId())
                .checklistReadingId(readingImages.getChecklistReadingId())
                .temperatureReadingId(readingImages.getTemperatureReadingId())
                .build();
    }

}