package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface VisitorReadingRepository extends JpaRepository<VisitorReading, String> {
    @Query("SELECT vr " +
            "FROM VisitorReading vr " +
            "JOIN ComplianceSubCategory cs ON cs.id = vr.complianceSubCategoryId " +
            "WHERE vr.complianceSubCategoryId = :subCategoryId " +
            "AND cs.businessId = :businessId " +
            "AND :employeeId IS NULL OR vr.createdBy = :employeeId " +
            "AND (:complianceStatus IS NULL OR vr.complianceStatus = :complianceStatus) " +
            "AND ((:startDate IS NULL AND :endDate IS NULL) OR (vr.date BETWEEN :startDate AND :endDate))")
    Page<VisitorReading> getVistorOverview(String businessId,String employeeId, String subCategoryId, ComplianceStatus complianceStatus, LocalDate startDate,LocalDate endDate, Pageable pageable);

    boolean existsByCreatedBy(String employeeId);
}
