package com.codelantic.ebos.compliance.management.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HealthAndSafetyOverViewDisplayDto {
    private String rowNo;
    private String subCategoryName;
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String pendingTotal;
    private String complianceStatus;
    private List<ChecklistAndQuestionDisplayDto> checklistAndQuestionDisplays;
    private Set<ImageDescriptionDto> images;
}
