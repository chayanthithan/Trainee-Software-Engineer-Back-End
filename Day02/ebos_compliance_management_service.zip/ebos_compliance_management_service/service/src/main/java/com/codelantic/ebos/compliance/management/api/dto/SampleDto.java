package com.codelantic.ebos.compliance.management.api.dto;

import lombok.Data;

import java.util.List;

@Data
public class SampleDto {
    private String rowNo;
    private List<VisitorOverviewDto> data;
}
