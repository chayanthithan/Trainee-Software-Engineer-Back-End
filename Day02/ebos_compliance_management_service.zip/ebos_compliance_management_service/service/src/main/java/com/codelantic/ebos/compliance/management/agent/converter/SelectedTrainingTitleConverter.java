package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.SelectedTrainingTitleDto;
import com.codelantic.ebos.compliance.management.entity.SelectedTrainingTitle;
import org.springframework.stereotype.Component;

@Component
public class SelectedTrainingTitleConverter {

    public SelectedTrainingTitle convert(SelectedTrainingTitleDto selectedTrainingTitleDto) {
        return SelectedTrainingTitle.builder()
                .id(selectedTrainingTitleDto.getId())
                .trainingTitleId(selectedTrainingTitleDto.getTrainingTitleId())
                .trainingReadingId(selectedTrainingTitleDto.getTrainingReadingId())
                .build();
    }

    public SelectedTrainingTitleDto convert(SelectedTrainingTitle selectedTrainingTitle) {
        return SelectedTrainingTitleDto.builder()
                .id(selectedTrainingTitle.getId())
                .trainingTitleId(selectedTrainingTitle.getTrainingTitleId())
                .trainingReadingId(selectedTrainingTitle.getTrainingReadingId())
                .build();
    }
}
