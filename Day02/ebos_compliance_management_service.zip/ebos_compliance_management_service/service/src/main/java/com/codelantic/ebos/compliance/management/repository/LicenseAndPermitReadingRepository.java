package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface LicenseAndPermitReadingRepository extends JpaRepository<LicenseAndPermitReading,String> {
    @Query("SELECT lp FROM LicenseAndPermitReading lp " +
            "LEFT JOIN ComplianceSubCategory cs ON cs.id = lp.complianceSubCategoryId " +
            "WHERE cs.businessId = :businessId " +
            "AND (:fromDate IS NULL OR :toDate IS NULL OR lp.issueDate BETWEEN :fromDate AND :toDate) " +
            "AND (:employeeName IS NULL OR lp.createdBy = :employeeName) " +
            "AND (:status IS NULL OR lp.complianceStatus = :status) " +
            "AND (:subCategoryId IS NULL OR cs.id = :subCategoryId) ")
    Page<LicenseAndPermitReading> getAllLicenseAndPermitReading(String businessId, LocalDate fromDate,
                                                                LocalDate toDate, String employeeName,
                                                                ComplianceStatus status,Pageable paging,
                                                                String subCategoryId);

    @Query("SELECT l FROM LicenseAndPermitReading l WHERE l.id=:id")
    LicenseAndPermitReading getLicenseOverviewById(String id);
}
