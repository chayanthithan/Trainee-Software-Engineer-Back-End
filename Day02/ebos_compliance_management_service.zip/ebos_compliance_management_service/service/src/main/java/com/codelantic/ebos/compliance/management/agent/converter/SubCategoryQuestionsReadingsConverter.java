package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.SubCategoryQuestionsReadingsDto;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestionsReadings;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class SubCategoryQuestionsReadingsConverter {
    private final ReadingImagesConverter readingImagesConverter;
private final SubCategoryQuestionRepository subCategoryQuestionRepository;

    public SubCategoryQuestionsReadings convert(SubCategoryQuestionsReadingsDto readingsDto) {

        boolean result = subCategoryQuestionRepository.findResultForRecord(readingsDto.getSubCategoryQuestionsId());
        if(result && readingsDto.getReadingImages().isEmpty()){
            throw new ServiceException("Image needs to be uploaded", "Bad request", HttpStatus.BAD_REQUEST);
        }
        return SubCategoryQuestionsReadings.builder()
                .id(readingsDto.getId())
                .yesOrNo(readingsDto.getYesOrNo())
                .comment(readingsDto.getComment())
                .subCategoryQuestionsId(readingsDto.getSubCategoryQuestionsId())
                .complianceReadingId(readingsDto.getComplianceReadingId())
                .readingImages(readingsDto.getReadingImages()!=null? readingsDto.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }

    public SubCategoryQuestionsReadingsDto convert(SubCategoryQuestionsReadings readings) {
        return SubCategoryQuestionsReadingsDto.builder()
                .id(readings.getId())
                .yesOrNo(readings.getYesOrNo())
                .comment(readings.getComment())
                .subCategoryQuestionsId(readings.getSubCategoryQuestionsId())
                .complianceReadingId(readings.getComplianceReadingId())
                .readingImages(readings.getReadingImages()!=null? readings.getReadingImages().stream().map
                        (readingImagesConverter::convert).collect(Collectors.toSet()) : null)
                .build();
    }
}
