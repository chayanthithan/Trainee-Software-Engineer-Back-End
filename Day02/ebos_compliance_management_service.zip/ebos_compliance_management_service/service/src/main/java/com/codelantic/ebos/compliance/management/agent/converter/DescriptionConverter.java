package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DescriptionDto;
import com.codelantic.ebos.compliance.management.entity.Description;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DescriptionConverter {
    @Value("${sftp.base.url}")
    private String baseUrl;

    @Value("${sftp.uploadPath}")
    private String downloadBaseUrl;

    public Description convert(DescriptionDto descriptionDto) {
        return Description.builder()
                .id(descriptionDto.getId())
                .incidentReadingId(descriptionDto.getIncidentReadingId())
                .visitorReadingId(descriptionDto.getVisitorReadingId())
                .complaintReadingId(descriptionDto.getComplaintReadingId())
                .audioName(descriptionDto.getAudioName())
                .audioPath(descriptionDto.getAudioPath())
                .build();
    }

    public DescriptionDto convert(Description description) {
        return DescriptionDto.builder()
                .id(description.getId())
                .incidentReadingId(description.getIncidentReadingId())
                .visitorReadingId(description.getVisitorReadingId())
                .complaintReadingId(description.getComplaintReadingId())
                .audioName(description.getAudioName())
                .viewAudioPath(baseUrl+description.getAudioPath())
                .downloadAudioPath(downloadBaseUrl+description.getAudioPath())
                .build();
    }
}
