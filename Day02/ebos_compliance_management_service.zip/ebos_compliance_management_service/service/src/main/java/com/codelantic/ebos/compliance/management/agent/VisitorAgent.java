package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.CompliantOverViewConverter;
import com.codelantic.ebos.compliance.management.agent.converter.VisitorConvertor;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.service.VisitorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.IntStream;

@Component
@RequiredArgsConstructor
@Slf4j
public class VisitorAgent {

    private final VisitorConvertor visitorConvertor;
    private final VisitorService visitorService;
    private final CompliantOverViewConverter compliantOverViewConverter;

    public ResponseDto addNewVisitorType(VisitTypeDto visitTypeDto){
        return visitorService.addNewVisitType(visitorConvertor.convertToEntity(visitTypeDto));
    }
    public List<VisitTypeDto>getAllVisitTypeByBusinessId(String businessId){
        return visitorService.getAllVisitType(businessId);
    }

    public PaginatedResponseDto<VisitorOverviewDto> getVistorOverview(VisitorSearchDto visitorSearchDto) {
        Page<VisitorReading> visitorReadingPage=visitorService.getVistorOverview(visitorSearchDto);
        List<VisitorOverviewDto> visitorOverviewDtos = visitorReadingPage.getContent().stream()
                .map(compliantOverViewConverter::convertToVisitorDto).toList();

        List<VisitorOverviewDto> visitorOverviewDtoList = IntStream.range(0, visitorOverviewDtos.size())
                .mapToObj(i -> {
                    int rowNo = i + 1 + (visitorSearchDto.getPage() - 1) * visitorSearchDto.getSize();
                    visitorOverviewDtos.get(i).setRowNo(String.format("%02d", rowNo));  // Format rowNo to start from "01"
                    return visitorOverviewDtos.get(i);
                })
                .toList();

        return PaginatedResponseDto.<VisitorOverviewDto>builder()
                .data(visitorOverviewDtoList)
                .currentPage(visitorSearchDto.getPage())
                .totalPages(visitorReadingPage.getTotalPages())
                .totalItems(visitorReadingPage.getTotalElements())
                .build();
    }

    public VisitorOverviewDto getRowVisitor(String id) {
        VisitorReading visitorReading=visitorService.getRowVisitor(id);
        return compliantOverViewConverter.convertToVisitorDto(visitorReading);
    }
}
