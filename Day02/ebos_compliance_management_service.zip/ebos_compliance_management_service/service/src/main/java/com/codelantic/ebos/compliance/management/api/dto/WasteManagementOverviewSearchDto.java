package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Validated
public class WasteManagementOverviewSearchDto {
    @NotNull(message = "Page is required")
    @Positive(message = "Page should be positive numerical value")
    private Integer page;
    @NotNull(message = "Size is required")
    @Positive(message = "size should be positive numerical value")
    private Integer size;
    private String businessId;
    private String employeeName;
    private ComplianceStatus complianceStatus;
    @NotNull(message = "From Date is required")
    private LocalDate fromDate;
    @NotNull(message = "To Date is required")
    private LocalDate toDate;
    @NotBlank(message = "Compliance Sub Category Id is required")
    private String complianceSubCategoryId;
}
