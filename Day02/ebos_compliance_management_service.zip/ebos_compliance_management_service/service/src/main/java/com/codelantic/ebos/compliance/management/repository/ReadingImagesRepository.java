package com.codelantic.ebos.compliance.management.repository;

import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ReadingImagesRepository extends JpaRepository<ReadingImages, String> {
    @Query("SELECT COALESCE(MAX(ri.imageNumber), 0) FROM ReadingImages ri " +
            "WHERE ri.questionsReadingId = :readingId " +
            "OR ri.checklistReadingId = :readingId " +
            "OR ri.temperatureReadingId = :readingId")
    Integer getLastImageNumber(@Param("readingId") String readingId);

    boolean existsByImagePathAndId(String imagePath, String documentId);

    @Modifying
    @Transactional
    @Query("DELETE FROM ReadingImages d WHERE d.imagePath = :imagePath AND d.id = :documentId")
    int deleteImage(String imagePath, String documentId);
}
