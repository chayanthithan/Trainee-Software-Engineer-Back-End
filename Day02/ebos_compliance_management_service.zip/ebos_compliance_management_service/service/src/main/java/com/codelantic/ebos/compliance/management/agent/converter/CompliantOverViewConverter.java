package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.AudioDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.CompliantOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitorOverviewDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.VisitingTypeRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class CompliantOverViewConverter {
    @Value("${sftp.base.url}")
    private String imagePath;

    private final UserManagementClient userManagementClient;
    private final ComplianceSubCategoryRepository complianceSubCategoryRepository;
    private final VisitingTypeRepository visitingTypeRepository;
    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;


    public CompliantOverViewDto convertToDto(CompliantReading compliantReading) {
        CompliantOverViewDto.CompliantOverViewDtoBuilder compliantOverViewDto = CompliantOverViewDto.builder()
                .id(compliantReading.getId())
                .subCategoryName(complianceSubCategoryRepository.getNameUsingId(compliantReading.getComplianceSubCategoryId()))
                .date(compliantReading.getDate())
                .time(compliantReading.getTime())
                .fullName(compliantReading.getFullName())
                .compliantType(compliantReading.getCompliantType())
                .description(compliantReading.getDescription())
                .comments(compliantReading.getComments())
                .complianceStatus(compliantReading.getComplianceStatus()!=null?compliantReading.getComplianceStatus().getMappedValue():null);

        if (compliantReading.getCreatedBy() != null) {
            UserName userName = userManagementClient.getUserNameById(compliantReading.getCreatedBy());
            compliantOverViewDto.employeeName(userName.getName());
        }
        if (compliantReading.getDocuments() != null) {
            Set<ImageDescriptionDto> imageDescriptions = compliantReading.getDocuments().stream() // Stream over the documents
                    .map(readingImage -> ImageDescriptionDto.builder()
                            .id(readingImage.getId())
                            .fileName(readingImage.getImageName())
                            .fullViewPath(readingImage.getImagePath())
                            .downloadPath(readingImage.getImagePath())
                            .build())
                    .collect(Collectors.toSet());

            compliantOverViewDto.images(imageDescriptions); // Set the images in the DTO
        }


        if (compliantReading.getNotifyTo() != null) {
            List<String> notifyToUsernames = compliantReading.getNotifyTo().stream()
                    .map(NotifyTo::getUserId)
                    .map(userManagementClient::getUserNameById)
                    .map(UserName::getName)
                    .toList();
            compliantOverViewDto.notifyTo(notifyToUsernames);
        }

        if (compliantReading.getDescriptions() != null) {
            Set<AudioDescriptionDto> audioDescriptionDtos = compliantReading.getDescriptions().stream() // Stream over the documents
                    .map(readingAudio -> AudioDescriptionDto.builder()
                            .id(readingAudio.getId())
                            .fileName(readingAudio.getAudioName())
                            .fullViewPath(readingAudio.getAudioPath())
                            .downloadPath(readingAudio.getAudioPath())
                            .build())
                    .collect(Collectors.toSet());

            compliantOverViewDto.audios(audioDescriptionDtos); // Set the images in the DTO
        }

        return compliantOverViewDto.build();


    }

    public VisitorOverviewDto convertToVisitorDto(VisitorReading visitorReading) {
        VisitorOverviewDto.VisitorOverviewDtoBuilder visitorOverviewDtoBuilder = VisitorOverviewDto.builder()
                .id(visitorReading.getId())
                .subCategoryName(complianceSubCategoryRepository.getNameUsingId(visitorReading.getComplianceSubCategoryId()))
                .date(visitorReading.getDate())
                .time(visitorReading.getTime())
                .fullName(visitorReading.getFullName())
                .description(visitorReading.getDescription())
                .comments(visitorReading.getComments())
                .complianceStatus(visitorReading.getComplianceStatus().getMappedValue());

       if(visitorReading.getVisitType()!=null){
           Optional<VisitType> visitType=visitingTypeRepository.findById(visitorReading.getVisitType());
           visitType.ifPresent(type -> visitorOverviewDtoBuilder.visitorType(type.getTypeOfVisit()));
       }

        if (visitorReading.getCreatedBy() != null) {
            UserName userName = userManagementClient.getUserNameById(visitorReading.getCreatedBy());
            visitorOverviewDtoBuilder.employeeName(userName.getName());
        }

        if (visitorReading.getDocuments() != null) {
            Set<ImageDescriptionDto> imageDescriptions = visitorReading.getDocuments().stream() // Stream over the documents
                    .map(readingImage -> ImageDescriptionDto.builder()
                            .id(readingImage.getId())
                            .fileName(readingImage.getImageName())
                            .fullViewPath(readingImage.getImagePath())
                            .downloadPath(readingImage.getImagePath())
                            .build())
                    .collect(Collectors.toSet());

            visitorOverviewDtoBuilder.images(imageDescriptions);
        }

        if (visitorReading.getNotifyTo() != null) {
            List<String> notifyToUsernames = visitorReading.getNotifyTo().stream()
                    .map(NotifyTo::getUserId)
                    .map(userManagementClient::getUserNameById)
                    .map(UserName::getName)
                    .toList();
            visitorOverviewDtoBuilder.notifyTo(notifyToUsernames);
        }

        if (visitorReading.getDescriptions() != null) {
            Set<AudioDescriptionDto> audioDescriptionDtos = visitorReading.getDescriptions().stream() // Stream over the documents
                    .map(readingAudio -> AudioDescriptionDto.builder()
                            .id(readingAudio.getId())
                            .fileName(readingAudio.getAudioName())
                            .fullViewPath(readingAudio.getAudioPath())
                            .downloadPath(readingAudio.getAudioPath())
                            .build())
                    .collect(Collectors.toSet());

            visitorOverviewDtoBuilder.audios(audioDescriptionDtos); // Set the images in the DTO
        }


        return visitorOverviewDtoBuilder.build();


    }

}
