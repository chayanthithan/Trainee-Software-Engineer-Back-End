ALTER TABLE `ebos_compliance_management`.`temperature_type_range_configurations`
    CHANGE COLUMN `order` `sequence` INT(11) NULL DEFAULT 0 ;