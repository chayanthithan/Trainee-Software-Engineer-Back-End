/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `affected_parties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `affected_parties`
(
  `id` varchar
(255) NOT NULL,
  `audio` varchar
(255) DEFAULT NULL,
  `audio_path` varchar
(255) DEFAULT NULL,
  `incident_reading_id` varchar
(255) DEFAULT NULL,
  PRIMARY KEY
(`id`),
  KEY `FKr4qyqt3tb9326l4gign8l1o4x`
(`incident_reading_id`),
  CONSTRAINT `FKr4qyqt3tb9326l4gign8l1o4x` FOREIGN KEY
(`incident_reading_id`) REFERENCES `incident_reading`
(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `business_compliance_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `business_compliance_configuration`
(
  `id` varchar
(255) NOT NULL,
  `business_id` varchar
(255) DEFAULT NULL,
  `compliance_id` int DEFAULT NULL,
  PRIMARY KEY
(`id`),
  KEY `zsdfdgfbmnm`
(`compliance_id`),
  CONSTRAINT `zsdfdgfbmnm` FOREIGN KEY
(`compliance_id`) REFERENCES `compliance`
(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `check_list_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `check_list_reading`
(
  `id` varchar
(255) NOT NULL,
  `comment` varchar
(255) DEFAULT NULL,
  `compliance_reading_id` varchar
(255) DEFAULT NULL,
  `is_checked` tinyint DEFAULT NULL,
  `sub_category_check_list_id` varchar
(255) DEFAULT NULL,
  PRIMARY KEY
(`id`),
  KEY `FKpbd7r9wbetugh0iut9d181k29`
(`sub_category_check_list_id`),
  KEY `FKd8yldryj69uqb8i2w9c4w3qtj`
(`compliance_reading_id`),
  CONSTRAINT `FKd8yldryj69uqb8i2w9c4w3qtj` FOREIGN KEY
(`compliance_reading_id`) REFERENCES `compliance_reading`
(`id`),
  CONSTRAINT `FKpbd7r9wbetugh0iut9d181k29` FOREIGN KEY
(`sub_category_check_list_id`) REFERENCES `sub_category_check_list`
(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `compliance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `compliance`
(
  `id` int NOT NULL,
  `compliance_name` varchar
(255) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  PRIMARY KEY
(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `compliance_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `compliance_reading`
(
  `id` varchar
(255) NOT NULL,
  `business_id` varchar
(255) DEFAULT NULL,
  `comments` varchar
(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar
(255) DEFAULT NULL,
  `created_by` varchar
(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `compliance_status` varchar
(255) DEFAULT NULL,
  `reviewer_comments` varchar
(255) DEFAULT NULL,
  PRIMARY KEY
(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `compliance_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `compliance_sub_category` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `compliance_id` int DEFAULT NULL,
  `is_check_list` tinyint DEFAULT NULL,
  `is_check_this_box_to_add_comments_to_the_form` tinyint DEFAULT NULL,
  `is_declaration_statement` tinyint DEFAULT NULL,
  `is_form` tinyint DEFAULT NULL,
  `is_temperature` tinyint DEFAULT NULL,
  `is_yes_or_no` tinyint DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `sub_category_name` varchar(255) DEFAULT NULL,
  `temperature_configurations_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKtk9hbwqn7ods8ebgqyiw6pyia` (`temperature_configurations_id`),
  CONSTRAINT `FKtk9hbwqn7ods8ebgqyiw6pyia` FOREIGN KEY (`temperature_configurations_id`) REFERENCES `temperature_configurations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `compliant_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `compliant_reading` (
  `id` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `compliant_type` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `description` varchar(1500) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `compliant_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `compliant_type` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `type_of_compliant` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `department` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `department_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `description` (
  `id` varchar(255) NOT NULL,
  `audio_name` varchar(255) DEFAULT NULL,
  `audio_path` varchar(255) DEFAULT NULL,
  `incident_reading_id` varchar(255) DEFAULT NULL,
  `visitor_reading_id` varchar(255) DEFAULT NULL,
  `complaint_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh4t4hihbnmpx6n2uuycoot2ls` (`incident_reading_id`),
  KEY `description_fk2_idx` (`complaint_reading_id`),
  KEY `description_fk3_idx` (`visitor_reading_id`),
  CONSTRAINT `FKh4t4hihbnmpx6n2uuycoot2ls` FOREIGN KEY (`incident_reading_id`) REFERENCES `incident_reading` (`id`),
  CONSTRAINT `description_fk2` FOREIGN KEY (`complaint_reading_id`) REFERENCES `compliant_reading` (`id`),
  CONSTRAINT `description_fk3` FOREIGN KEY (`visitor_reading_id`) REFERENCES `visitor_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `documents` (
  `id` varchar(255) NOT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `complaint_reading_id` varchar(255) DEFAULT NULL,
  `incident_reading_id` varchar(255) DEFAULT NULL,
  `license_and_permit_reading_id` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  `visitor_reading_id` varchar(255) DEFAULT NULL,
  `waste_management_reading_id` varchar(255) DEFAULT NULL,
  `image_number` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKppwuu9klwvkpentbyufmt2j51` (`waste_management_reading_id`),
  KEY `FKpqsvgrecokkgjd5ss1l1rnwn5` (`visitor_reading_id`),
  KEY `FKqg6bt81h11uwvgcnun3slkkes` (`training_reading_id`),
  KEY `FK9gjj7outt7bj2sasktblaldro` (`license_and_permit_reading_id`),
  KEY `FKtpo3f5e4sm1vv0qixpg35nwym` (`incident_reading_id`),
  KEY `FK1gvttps5i99a1hjoxf3uh5f7t` (`complaint_reading_id`),
  CONSTRAINT `FK1gvttps5i99a1hjoxf3uh5f7t` FOREIGN KEY (`complaint_reading_id`) REFERENCES `compliant_reading` (`id`),
  CONSTRAINT `FK9gjj7outt7bj2sasktblaldro` FOREIGN KEY (`license_and_permit_reading_id`) REFERENCES `license_and_permit_reading` (`id`),
  CONSTRAINT `FKppwuu9klwvkpentbyufmt2j51` FOREIGN KEY (`waste_management_reading_id`) REFERENCES `waste_management_reading` (`id`),
  CONSTRAINT `FKpqsvgrecokkgjd5ss1l1rnwn5` FOREIGN KEY (`visitor_reading_id`) REFERENCES `visitor_reading` (`id`),
  CONSTRAINT `FKqg6bt81h11uwvgcnun3slkkes` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`),
  CONSTRAINT `FKtpo3f5e4sm1vv0qixpg35nwym` FOREIGN KEY (`incident_reading_id`) REFERENCES `incident_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `form_setting_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `form_setting_configuration` (
  `id` varchar(255) NOT NULL,
  `compliance_id` int DEFAULT NULL,
  `field_category` varchar(255) DEFAULT NULL,
  `field_name` varchar(255) DEFAULT NULL,
  `field_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `immediate_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `immediate_response` (
  `id` varchar(255) NOT NULL,
  `audio` varchar(255) DEFAULT NULL,
  `audio_path` varchar(255) DEFAULT NULL,
  `incident_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKoc2hkq1illlc468i7xrh5ljfl` (`incident_reading_id`),
  CONSTRAINT `FKoc2hkq1illlc468i7xrh5ljfl` FOREIGN KEY (`incident_reading_id`) REFERENCES `incident_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `incident_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `incident_reading` (
  `id` varchar(255) NOT NULL,
  `affected_parties` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `immediate_response` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `potential_impact` varchar(255) DEFAULT NULL,
  `severity` varchar(255) DEFAULT NULL,
  `supporting_evidence` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `type_of_incident` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `license_and_permit_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `license_and_permit_reading` (
  `id` varchar(255) NOT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `conditions_or_restrictions` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone_number` varchar(255) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `holders_name` varchar(255) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `issuing_authority` varchar(255) DEFAULT NULL,
  `license_or_permit_name` varchar(255) DEFAULT NULL,
  `license_or_permit_number` varchar(255) DEFAULT NULL,
  `reminder_date` date DEFAULT NULL,
  `reminder_time` time DEFAULT NULL,
  `renewal_application_ded_line` date DEFAULT NULL,
  `renewal_date` date DEFAULT NULL,
  `type_of_license_or_permit` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `location` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `location_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `notify_to`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `notify_to` (
  `id` varchar(255) NOT NULL,
  `complaint_reading_id` varchar(255) DEFAULT NULL,
  `incident_reading_id` varchar(255) DEFAULT NULL,
  `temperature_reading_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `visitor_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6oeefv61dw411ymtrwjttyp59` (`visitor_reading_id`),
  KEY `FK3bbxgv8fqybwnwc62jw8qafja` (`temperature_reading_id`),
  KEY `FK21u7uxxu1m7ecgdnpeog9c55l` (`incident_reading_id`),
  KEY `FKlyytg9lmubrvl5h6g3j8o5pdl` (`complaint_reading_id`),
  CONSTRAINT `FK21u7uxxu1m7ecgdnpeog9c55l` FOREIGN KEY (`incident_reading_id`) REFERENCES `incident_reading` (`id`),
  CONSTRAINT `FK3bbxgv8fqybwnwc62jw8qafja` FOREIGN KEY (`temperature_reading_id`) REFERENCES `temperature_reading` (`id`),
  CONSTRAINT `FK6oeefv61dw411ymtrwjttyp59` FOREIGN KEY (`visitor_reading_id`) REFERENCES `visitor_reading` (`id`),
  CONSTRAINT `FKlyytg9lmubrvl5h6g3j8o5pdl` FOREIGN KEY (`complaint_reading_id`) REFERENCES `compliant_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `participants` (
  `id` varchar(255) NOT NULL,
  `participant_id` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlfx13owo0o1f18wqo9vl58j2n` (`training_reading_id`),
  CONSTRAINT `FKlfx13owo0o1f18wqo9vl58j2n` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `potential_impact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `potential_impact` (
  `id` varchar(255) NOT NULL,
  `audio` varchar(255) DEFAULT NULL,
  `audio_path` varchar(255) DEFAULT NULL,
  `incident_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKb7hmhsnkf70mcaifffduwvbd1` (`incident_reading_id`),
  CONSTRAINT `FKb7hmhsnkf70mcaifffduwvbd1` FOREIGN KEY (`incident_reading_id`) REFERENCES `incident_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `reading_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `reading_images` (
  `id` varchar(255) NOT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `checklist_reading_id` varchar(255) DEFAULT NULL,
  `questions_reading_id` varchar(255) DEFAULT NULL,
  `temperature_reading_id` varchar(255) DEFAULT NULL,
  `image_number` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKia0qfv7hxey53164w4rfc6ylf` (`temperature_reading_id`),
  KEY `FKjdqh9fj6raarjurspeh6ihuch` (`questions_reading_id`),
  KEY `FK7jrh73nimx1fl3scl4vbnju0u` (`checklist_reading_id`),
  CONSTRAINT `FK7jrh73nimx1fl3scl4vbnju0u` FOREIGN KEY (`checklist_reading_id`) REFERENCES `check_list_reading` (`id`),
  CONSTRAINT `FKia0qfv7hxey53164w4rfc6ylf` FOREIGN KEY (`temperature_reading_id`) REFERENCES `temperature_reading` (`id`),
  CONSTRAINT `FKjdqh9fj6raarjurspeh6ihuch` FOREIGN KEY (`questions_reading_id`) REFERENCES `sub_category_questions_readings` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `reminder_to`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `reminder_to` (
  `id` varchar(255) NOT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `license_and_permit_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKagx8oyc5xkxuibmc2n3u5xggj` (`license_and_permit_reading_id`),
  CONSTRAINT `FKagx8oyc5xkxuibmc2n3u5xggj` FOREIGN KEY (`license_and_permit_reading_id`) REFERENCES `license_and_permit_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `selected_training_objectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `selected_training_objectives` (
  `id` varchar(255) NOT NULL,
  `training_objectives_id` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk1_idx` (`training_objectives_id`),
  KEY `fk2_idx` (`training_reading_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`training_objectives_id`) REFERENCES `training_objectives` (`id`),
  CONSTRAINT `fk2` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `selected_training_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `selected_training_title` (
  `id` varchar(255) NOT NULL,
  `training_title_id` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk1_idx` (`training_title_id`),
  KEY `fk2_idx` (`training_reading_id`),
  CONSTRAINT `selected_training_title_fk1` FOREIGN KEY (`training_title_id`) REFERENCES `training_title` (`id`),
  CONSTRAINT `selected_training_title_fk2` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `severity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `severity` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `severity_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `signatures` (
  `id` varchar(255) NOT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_path` varchar(1024) DEFAULT NULL,
  `signature_of` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfdxoe2wy03xo6mwcu6o16v0pr` (`training_reading_id`),
  CONSTRAINT `FKfdxoe2wy03xo6mwcu6o16v0pr` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sub_category_check_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `sub_category_check_list` (
  `id` varchar(255) NOT NULL,
  `checklist` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `is_comment_available` tinyint DEFAULT NULL,
  `is_document_available` tinyint DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKourypwbfgdr2qwwkgqydyl3f4` (`compliance_sub_category_id`),
  CONSTRAINT `FKourypwbfgdr2qwwkgqydyl3f4` FOREIGN KEY (`compliance_sub_category_id`) REFERENCES `compliance_sub_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sub_category_form_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `sub_category_form_configurations` (
  `id` varchar(255) NOT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `form_settings_configuration_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKasxxmtul0oqm8dx61kskk075i` (`form_settings_configuration_id`),
  CONSTRAINT `FKasxxmtul0oqm8dx61kskk075i` FOREIGN KEY (`form_settings_configuration_id`) REFERENCES `form_setting_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sub_category_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `sub_category_questions` (
  `id` varchar(255) NOT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `is_comment_available` tinyint DEFAULT NULL,
  `is_document_available` tinyint DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpurnf250ayera0yf06cmkmwos` (`compliance_sub_category_id`),
  CONSTRAINT `FKpurnf250ayera0yf06cmkmwos` FOREIGN KEY (`compliance_sub_category_id`) REFERENCES `compliance_sub_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `sub_category_questions_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `sub_category_questions_readings` (
  `id` varchar(255) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `compliance_reading_id` varchar(255) DEFAULT NULL,
  `sub_category_questions_id` varchar(255) DEFAULT NULL,
  `yes_or_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKam6txa8vywe7xp7wo2rr43svs` (`sub_category_questions_id`),
  KEY `FKhb8n126ttppjmvnw3in7suyrx` (`compliance_reading_id`),
  CONSTRAINT `FKam6txa8vywe7xp7wo2rr43svs` FOREIGN KEY (`sub_category_questions_id`) REFERENCES `sub_category_questions` (`id`),
  CONSTRAINT `FKhb8n126ttppjmvnw3in7suyrx` FOREIGN KEY (`compliance_reading_id`) REFERENCES `compliance_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `temperature_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `temperature_configurations` (
  `id` varchar(255) NOT NULL,
  `is_required_quantity_based_temp_reading` bit DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `temperature_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `temperature_reading` (
  `id` varchar(255) NOT NULL,
  `actual_reading` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `compliance_reading_id` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `temperature_type_range_configurations_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_temp_reading_idx` (`compliance_reading_id`),
  CONSTRAINT `fk_temp_reading` FOREIGN KEY (`compliance_reading_id`) REFERENCES `compliance_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `temperature_type_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `temperature_type_range` (
  `id` varchar(255) NOT NULL,
  `end_temperature` varchar(255) DEFAULT NULL,
  `start_temperature` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `temperature_type` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `temperature_type_range_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `temperature_type_range_configurations` (
  `id` varchar(255) NOT NULL,
  `items` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `temperature_configurations_id` varchar(255) DEFAULT NULL,
  `temperature_type_range_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKje53qhi2wev3erj9dahvu738o` (`temperature_configurations_id`),
  CONSTRAINT `FKje53qhi2wev3erj9dahvu738o` FOREIGN KEY (`temperature_configurations_id`) REFERENCES `temperature_configurations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `trainer` (
  `id` varchar(255) NOT NULL,
  `trainer_id` varchar(255) DEFAULT NULL,
  `training_reading_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfycy4gbvdq9o29mix143592ce` (`training_reading_id`),
  CONSTRAINT `FKfycy4gbvdq9o29mix143592ce` FOREIGN KEY (`training_reading_id`) REFERENCES `training_reading` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `training_material_used`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `training_material_used` (
  `id` varchar(255) NOT NULL,
  `training_material_used_name` varchar(255) DEFAULT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `training_objectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `training_objectives` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `objectives_of_training` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `training_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `training_reading` (
  `id` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `organized_by` varchar(255) DEFAULT NULL,
  `sub_category_form_configurations_id` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `training_material_used` varchar(255) DEFAULT NULL,
  `training_objective` varchar(255) DEFAULT NULL,
  `training_title` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpnrmhncu2j6eu2rx4wnimcnbw` (`sub_category_form_configurations_id`),
  CONSTRAINT `FKpnrmhncu2j6eu2rx4wnimcnbw` FOREIGN KEY (`sub_category_form_configurations_id`) REFERENCES `sub_category_form_configurations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `training_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `training_title` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `training_title_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `type_of_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `type_of_incident` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `incident_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `type_of_waste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `type_of_waste` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `wast_types` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `visit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `visit_type` (
  `id` varchar(255) NOT NULL,
  `business_id` varchar(255) DEFAULT NULL,
  `type_of_visit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `visitor_reading` (
  `id` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `visit_type` varchar(255) DEFAULT NULL,
  `description` varchar(1500) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `waste_management_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
CREATE TABLE `waste_management_reading` (
  `id` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `disposal_method` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `storage_location` varchar(255) DEFAULT NULL,
  `total_waste_value` varchar(255) DEFAULT NULL,
  `type_of_wastage` varchar(255) DEFAULT NULL,
  `unit_cost` double DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `compliance_sub_category_id` varchar(255) DEFAULT NULL,
  `compliance_status` varchar(255) DEFAULT NULL,
  `reviewer_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
