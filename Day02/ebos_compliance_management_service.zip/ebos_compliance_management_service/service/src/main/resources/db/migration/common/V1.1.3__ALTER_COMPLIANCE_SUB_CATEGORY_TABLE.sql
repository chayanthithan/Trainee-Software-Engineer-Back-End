ALTER TABLE `ebos_compliance_management`.`compliance_sub_category`
ADD COLUMN `date` DATE NULL AFTER `temperature_configurations_id`,
ADD COLUMN `time` TIME NULL AFTER `date`;
