ALTER TABLE `ebos_compliance_management`.`temperature_type_range_configurations`
    ADD COLUMN `order` INT NULL DEFAULT 0 AFTER `temperature_type_range_id`;