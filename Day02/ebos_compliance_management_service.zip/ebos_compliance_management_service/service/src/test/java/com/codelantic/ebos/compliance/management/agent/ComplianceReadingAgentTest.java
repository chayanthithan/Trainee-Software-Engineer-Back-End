package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceReadingAgentTest {

    @InjectMocks
    ComplianceReadingAgent complianceReadingAgent;
    @Mock
    TrainingReadingService trainingReadingService;
    @Mock
    LicenseAndPermitReadingService licenseAndPermitReadingService;
    @Mock
    WasteManagementReadingService wasteManagementReadingService;
    @Mock
    VisitorReadingService visitorReadingService;
    @Mock
    CompliantReadingService compliantReadingService;
    @Mock
    IncidentReadingService newIncidentReadingService;
    ComplianceReadingDto newComplianceReadingDto;
    ResponseDto newResponseDto;

    @BeforeEach
    void setUp() {

        newResponseDto = new ResponseDto();


        newComplianceReadingDto = ComplianceReadingDto.builder()
                .trainingReading(new TrainingReadingDto())
                .licenseAndPermitReading(new LicenseAndPermitReadingDto())
                .wasteManagementReading(new WasteManagementReadingDto())
                .visitorReading(new VisitorReadingDto())
                .compliantReading(new CompliantReadingDto())
                .incidentReading(new IncidentReadingDto())
                .build();
    }

    @Test
    void save() {
        ComplianceReadingDto complianceReadingDto = new ComplianceReadingDto();
        TrainingReadingDto trainingReadingDto = new TrainingReadingDto();
        trainingReadingDto.setId("tf");
        complianceReadingDto.setTrainingReading(trainingReadingDto);
        ResponseDto responseDto = new ResponseDto();

        Mockito.when(trainingReadingService.save(complianceReadingDto.getTrainingReading())).thenReturn(responseDto);


        assertNotNull(complianceReadingAgent.save(complianceReadingDto, ComplianceCategory.TRAINING));
    }

    @Test
    void save1() {


        LicenseAndPermitReadingDto licenseAndPermitReadingDto = new LicenseAndPermitReadingDto();
        licenseAndPermitReadingDto.setId("r");
        newComplianceReadingDto.setLicenseAndPermitReading(licenseAndPermitReadingDto);
        Mockito.when(licenseAndPermitReadingService.save(newComplianceReadingDto.getLicenseAndPermitReading())).thenReturn(newResponseDto);

        assertNotNull(complianceReadingAgent.save(newComplianceReadingDto, ComplianceCategory.LICENSE_AND_PERMITS));
    }

    @Test
    void save2() {
        newComplianceReadingDto.setWasteManagementReading(new WasteManagementReadingDto());
        Mockito.when(wasteManagementReadingService.save(newComplianceReadingDto.getWasteManagementReading())).thenReturn(newResponseDto);
        assertNotNull(complianceReadingAgent.save(newComplianceReadingDto, ComplianceCategory.WASTE_MANAGEMENT));
    }

    @Test
    void save3() {

        newComplianceReadingDto.setVisitorReading(new VisitorReadingDto());
        Mockito.when(visitorReadingService.save(newComplianceReadingDto.getVisitorReading())).thenReturn(newResponseDto);
        assertNotNull(complianceReadingAgent.save(newComplianceReadingDto, ComplianceCategory.VISITOR));
    }

    @Test
    void save4() {

        newComplianceReadingDto.setCompliantReading(new CompliantReadingDto());
        Mockito.when(compliantReadingService.save(newComplianceReadingDto.getCompliantReading())).thenReturn(newResponseDto);
        assertNotNull(complianceReadingAgent.save(newComplianceReadingDto, ComplianceCategory.COMPLAINT));
    }

    @Test
    void save5() {

        newComplianceReadingDto.setIncidentReading(new IncidentReadingDto());
        Mockito.when(newIncidentReadingService.save(newComplianceReadingDto.getIncidentReading())).thenReturn(newResponseDto);

        assertNotNull(complianceReadingAgent.save(newComplianceReadingDto, ComplianceCategory.INCIDENT));
    }

    @Test
    void update() {
        Mockito.when(trainingReadingService.update(newComplianceReadingDto.getTrainingReading())).thenReturn(newResponseDto);
        assertNotNull(complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.TRAINING));

    }

    @Test
    void update1() {
        Mockito.when(licenseAndPermitReadingService.update(Mockito.any(LicenseAndPermitReadingDto.class))).thenReturn(newResponseDto);
        ResponseDto result = complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.LICENSE_AND_PERMITS);
        assertNotNull(result);
    }

    @Test
    void update2() {
        Mockito.when(wasteManagementReadingService.update(Mockito.any(WasteManagementReadingDto.class))).thenReturn(newResponseDto);
        ResponseDto result = complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.WASTE_MANAGEMENT);
        assertNotNull(result);
        Mockito.verify(wasteManagementReadingService, Mockito.times(1)).update(Mockito.any(WasteManagementReadingDto.class));
    }

    @Test
    void update3() {
        Mockito.when(visitorReadingService.update(Mockito.any(VisitorReadingDto.class))).thenReturn(newResponseDto);
        ResponseDto result = complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.VISITOR);
        assertNotNull(result);
        Mockito.verify(visitorReadingService, Mockito.times(1)).update(Mockito.any(VisitorReadingDto.class));
    }

    @Test
    void update4() {
        Mockito.when(compliantReadingService.update(Mockito.any(CompliantReadingDto.class))).thenReturn(newResponseDto);
        ResponseDto result = complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.COMPLAINT);
        assertNotNull(result);
        Mockito.verify(compliantReadingService, Mockito.times(1)).update(Mockito.any(CompliantReadingDto.class));
    }

    @Test
    void update5() {
        Mockito.when(newIncidentReadingService.update(Mockito.any(IncidentReadingDto.class))).thenReturn(newResponseDto);
        ResponseDto result = complianceReadingAgent.update(newComplianceReadingDto, ComplianceCategory.INCIDENT);
        assertNotNull(result);
        Mockito.verify(newIncidentReadingService, Mockito.times(1)).update(Mockito.any(IncidentReadingDto.class));
    }


    @Test
    void getById1() {
        TrainingReadingDto expectedTrainingReadingDto = new TrainingReadingDto();
        Mockito.when(trainingReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedTrainingReadingDto);

        TrainingReadingDto actualTrainingReadingDto = (TrainingReadingDto) complianceReadingAgent.getById("id1", ComplianceCategory.TRAINING);
        assertNotNull(actualTrainingReadingDto);
        assertEquals(expectedTrainingReadingDto, actualTrainingReadingDto);
    }

    @Test
    void getById2() {
        LicenseAndPermitReadingDto expectedLicenseAndPermitReadingDto = new LicenseAndPermitReadingDto();
        Mockito.when(licenseAndPermitReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedLicenseAndPermitReadingDto);

        LicenseAndPermitReadingDto actualLicenseAndPermitReadingDto = (LicenseAndPermitReadingDto) complianceReadingAgent.getById("id2", ComplianceCategory.LICENSE_AND_PERMITS);
        assertNotNull(actualLicenseAndPermitReadingDto);
        assertEquals(expectedLicenseAndPermitReadingDto, actualLicenseAndPermitReadingDto);
    }

    @Test
    void getById3() {
        WasteManagementReadingDto expectedWasteManagementReadingDto = new WasteManagementReadingDto();
        Mockito.when(wasteManagementReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedWasteManagementReadingDto);

        WasteManagementReadingDto actualWasteManagementReadingDto = (WasteManagementReadingDto) complianceReadingAgent.getById("id3", ComplianceCategory.WASTE_MANAGEMENT);
        assertNotNull(actualWasteManagementReadingDto);
        assertEquals(expectedWasteManagementReadingDto, actualWasteManagementReadingDto);
    }

    @Test
    void getById4() {
        VisitorReadingDto expectedVisitorReadingDto = new VisitorReadingDto();
        Mockito.when(visitorReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedVisitorReadingDto);

        VisitorReadingDto actualVisitorReadingDto = (VisitorReadingDto) complianceReadingAgent.getById("id4", ComplianceCategory.VISITOR);
        assertNotNull(actualVisitorReadingDto);
        assertEquals(expectedVisitorReadingDto, actualVisitorReadingDto);
    }

    @Test
    void getById5() {
        CompliantReadingDto expectedCompliantReadingDto = new CompliantReadingDto();
        Mockito.when(compliantReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedCompliantReadingDto);

        CompliantReadingDto actualCompliantReadingDto = (CompliantReadingDto) complianceReadingAgent.getById("id5", ComplianceCategory.COMPLAINT);
        assertNotNull(actualCompliantReadingDto);
        assertEquals(expectedCompliantReadingDto, actualCompliantReadingDto);
    }

    @Test
    void getById6() {
        IncidentReadingDto expectedIncidentReadingDto = new IncidentReadingDto();
        Mockito.when(newIncidentReadingService.getById(Mockito.anyString(), Mockito.any(ComplianceCategory.class))).thenReturn(expectedIncidentReadingDto);

        IncidentReadingDto actualIncidentReadingDto = (IncidentReadingDto) complianceReadingAgent.getById("id6", ComplianceCategory.INCIDENT);
        assertNotNull(actualIncidentReadingDto);
        assertEquals(expectedIncidentReadingDto, actualIncidentReadingDto);
    }


}