package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.api.dto.NotifyToDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitorReadingDto;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class VisitorReadingConverterTest {

    @InjectMocks
    VisitorReadingConverter visitorReadingConverter;

    @Mock
    DocumentsConverter documentsConverter;
    @Mock
    NotifyToConverter notifyToConverter;
    @Mock
    DescriptionConverter descriptionConverter;

    @Test
    void convert() {
        Authentication authentication = Authentication.builder().build();
        authentication.setUserId("Nijanthan");
        AuthenticationContextHolder.setContext(authentication);

        VisitorReadingDto visitorReadingDto = new VisitorReadingDto();
        Set<DocumentsDto> documents = new HashSet<>();
        visitorReadingDto.setDocuments(documents);

        Set<NotifyToDto> notifyTo = new HashSet<>();
        visitorReadingDto.setNotifyTo(notifyTo);

        Set<DescriptionDto> descriptions = new HashSet<>();
        visitorReadingDto.setDescriptions(descriptions);

        assertNotNull(visitorReadingConverter.convert(visitorReadingDto));

    }

    @Test
    void testConvert() {
        VisitorReading visitorReading = VisitorReading.builder()
                .fullName("John Doe")
                .date(LocalDate.of(2024, 10, 9))
                .time(LocalTime.of(10, 30))
                .visitType("Business")
                .comments("Scheduled visit")
                .description("Visit for project discussion")
                .createdBy("admin")
                .complianceSubCategoryId("subCat123")
                .reviewerComments("Reviewed and approved")
                .complianceStatus(ComplianceStatus.APPROVED)
                .documents(Collections.emptySet())
                .notifyTo(Collections.emptySet())
                .descriptions(Collections.emptySet())
                .build();
        assertEquals(visitorReading.getId(), visitorReadingConverter.convert(visitorReading).getId());
    }

    @Test
    void updateConvert() {
        VisitorReading visitorReading = new VisitorReading();
        Set<DocumentsDto> documents = new HashSet<>();
        documents.add(DocumentsDto.builder().id("1").build());
        Set<NotifyToDto> notifyTo = new HashSet<>();
        notifyTo.add(NotifyToDto.builder().id("1").build());

        Set<DescriptionDto> descriptions = new HashSet<>();
        descriptions.add(DescriptionDto.builder().id("1").build());


        VisitorReadingDto visitorReadingDto = VisitorReadingDto.builder()
                .fullName("John Doe")
                .date(LocalDate.of(2024, 10, 9))
                .time(LocalTime.of(10, 30))
                .visitType("Business")
                .comments("Scheduled visit")
                .description("Visit for project discussion")
                .createdBy("admin")
                .complianceSubCategoryId("subCat123")
                .documents(documents)
                .notifyTo(notifyTo)
                .descriptions(descriptions)
                .build();
        visitorReadingConverter.updateConvert(visitorReading, visitorReadingDto);
        assertNotNull(visitorReadingDto);
        assertNotNull(visitorReading.getDocuments());
        assertNotNull(visitorReading.getNotifyTo());
        assertNotNull(visitorReading.getDescriptions());

    }
}