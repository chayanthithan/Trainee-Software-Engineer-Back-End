package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class HealthAndSafetyConverterTest {

    @InjectMocks
    HealthAndSafetyConverter healthAndSafetyConverter;

    @Mock
    UserManagementClient userManagementClient;

    @Mock
    CheckListReadingRepository checkListReadingRepository;

    @Mock
    ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Mock
    CheckListAndQuestionDisplayConverter checkListAndQuestionDisplayConverter;

    private ComplianceReading complianceReading;
    private UserName userName;
    private ReadingImages readingImage1;
    private ReadingImages readingImage2;

    @BeforeEach
    void setUp() {
        complianceReading = new ComplianceReading();
        complianceReading.setId("test-id");
        complianceReading.setDate(LocalDate.now());
        complianceReading.setTime(LocalTime.now());
        complianceReading.setCreatedBy("user123");
        complianceReading.setComplianceStatus(ComplianceStatus.APPROVED);
        complianceReading.setComplianceSubCategoryId("subcat-123");

        userName = new UserName();
        userName.setName("John Doe");

        // Setup reading images
        readingImage1 = new ReadingImages();
        readingImage1.setId("image1");
        readingImage1.setImageName("test1.jpg");
        readingImage1.setImagePath("/view/test1.jpg");
        readingImage1.setImagePath("/download/test1.jpg");

        readingImage2 = new ReadingImages();
        readingImage2.setId("image2");
        readingImage2.setImageName("test2.jpg");
        readingImage2.setImagePath("/view/test2.jpg");
        readingImage2.setImagePath("/download/test2.jpg");

        when(userManagementClient.getUserNameById("user123")).thenReturn(userName);
        when(complianceSubCategoryRepository.getNameUsingId("subcat-123")).thenReturn("Safety Category 1");
    }

    @Test
    void convertToDto_WithAllFieldsAndImages() {
        // Arrange
        Set<CheckListReading> checkListReadings = new HashSet<>();
        CheckListReading checkListReading = new CheckListReading();
        Set<ReadingImages> checkListImages = new HashSet<>();
        checkListImages.add(readingImage1);
        checkListReading.setReadingImages(checkListImages);
        checkListReadings.add(checkListReading);
        complianceReading.setCheckListReadings(checkListReadings);

        Set<SubCategoryQuestionsReadings> subCategoryReadings = new HashSet<>();
        SubCategoryQuestionsReadings subCategoryReading = new SubCategoryQuestionsReadings();
        Set<ReadingImages> subCategoryImages = new HashSet<>();
        subCategoryImages.add(readingImage2);
        subCategoryReading.setReadingImages(subCategoryImages);
        subCategoryReadings.add(subCategoryReading);
        complianceReading.setSubCategoryQuestionsReadings(subCategoryReadings);

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId("test-id"))
                .thenReturn(new TotalCheckedCountDto(5L, 3L));

        // Act
        HealthAndSafetyOverViewDisplayDto result = healthAndSafetyConverter.convertToDto(complianceReading);

        // Assert
        assertNotNull(result);
        assertEquals("test-id", result.getId());
        assertEquals(complianceReading.getDate(), result.getDate());
        assertEquals(complianceReading.getTime(), result.getTime());
        assertEquals(ComplianceStatus.APPROVED.getMappedValue(), result.getComplianceStatus());
        assertEquals("John Doe", result.getEmployeeName());
        assertEquals("Safety Category 1", result.getSubCategoryName());
        // Verify images
        assertNotNull(result.getImages());
        assertEquals(2, result.getImages().size());
        assertTrue(result.getImages().stream()
                .map(ImageDescriptionDto::getId)
                .anyMatch(id -> id.equals("image1")));
        assertTrue(result.getImages().stream()
                .map(ImageDescriptionDto::getId)
                .anyMatch(id -> id.equals("image2")));
    }

    @Test
    void convertToDto_WithEmptyReadings() {
        // Arrange
        complianceReading.setCheckListReadings(Collections.emptySet());
        complianceReading.setSubCategoryQuestionsReadings(Collections.emptySet());

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId("test-id"))
                .thenReturn(new TotalCheckedCountDto(0L, 0L));

        // Act
        HealthAndSafetyOverViewDisplayDto result = healthAndSafetyConverter.convertToDto(complianceReading);

        // Assert
        assertNotNull(result);
        assertEquals("0", result.getPendingTotal());
        assertTrue(result.getImages().isEmpty());
        assertEquals("Safety Category 1", result.getSubCategoryName());
    }

    @Test
    void convertToDto_WithNullCollections() {
        // Arrange
        complianceReading.setCheckListReadings(null);
        complianceReading.setSubCategoryQuestionsReadings(null);

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId("test-id"))
                .thenReturn(new TotalCheckedCountDto(0L, 0L));

        // Act & Assert
        assertThrows(NullPointerException.class, () -> healthAndSafetyConverter.convertToDto(complianceReading));
    }

    @Test
    void convertToDto_WithMultipleImagesInSameReading() {
        // Arrange
        Set<CheckListReading> checkListReadings = new HashSet<>();
        CheckListReading checkListReading = new CheckListReading();
        Set<ReadingImages> checkListImages = new HashSet<>();
        checkListImages.add(readingImage1);
        checkListImages.add(readingImage2);
        checkListReading.setReadingImages(checkListImages);
        checkListReadings.add(checkListReading);
        complianceReading.setCheckListReadings(checkListReadings);
        complianceReading.setSubCategoryQuestionsReadings(new HashSet<>());

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId("test-id"))
                .thenReturn(new TotalCheckedCountDto(5L, 3L));

        // Act
        HealthAndSafetyOverViewDisplayDto result = healthAndSafetyConverter.convertToDto(complianceReading);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.getImages().size());
        assertEquals("Safety Category 1", result.getSubCategoryName());
        assertTrue(result.getImages().stream()
                .anyMatch(img -> img.getFileName().equals("test1.jpg")));
        assertTrue(result.getImages().stream()
                .anyMatch(img -> img.getFileName().equals("test2.jpg")));
    }

    @Test
    void convertToDto_WithLargeNumberOfParallelImages() {
        // Arrange
        Set<CheckListReading> checkListReadings = createLargeCheckListReadings(50);
        Set<SubCategoryQuestionsReadings> subCategoryReadings = createLargeSubCategoryReadings(50);

        complianceReading.setCheckListReadings(checkListReadings);
        complianceReading.setSubCategoryQuestionsReadings(subCategoryReadings);

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId("test-id"))
                .thenReturn(new TotalCheckedCountDto(100L, 75L));

        // Act
        HealthAndSafetyOverViewDisplayDto result = healthAndSafetyConverter.convertToDto(complianceReading);

        // Assert
        assertNotNull(result);
        assertEquals(100, result.getImages().size());
    }

    private Set<CheckListReading> createLargeCheckListReadings(int count) {
        Set<CheckListReading> readings = new HashSet<>();
        for (int i = 0; i < count; i++) {
            CheckListReading reading = new CheckListReading();
            Set<ReadingImages> images = new HashSet<>();
            ReadingImages image = new ReadingImages();
            image.setId("cl-image-" + i);
            image.setImageName("cl-test" + i + ".jpg");
            image.setImagePath("/view/cl-test" + i + ".jpg");
            image.setImagePath("/download/cl-test" + i + ".jpg");
            images.add(image);
            reading.setReadingImages(images);
            readings.add(reading);
        }
        return readings;
    }

    private Set<SubCategoryQuestionsReadings> createLargeSubCategoryReadings(int count) {
        Set<SubCategoryQuestionsReadings> readings = new HashSet<>();
        for (int i = 0; i < count; i++) {
            SubCategoryQuestionsReadings reading = new SubCategoryQuestionsReadings();
            Set<ReadingImages> images = new HashSet<>();
            ReadingImages image = new ReadingImages();
            image.setId("sc-image-" + i);
            image.setImageName("sc-test" + i + ".jpg");
            image.setImagePath("/view/sc-test" + i + ".jpg");
            image.setImagePath("/download/sc-test" + i + ".jpg");
            images.add(image);
            reading.setReadingImages(images);
            readings.add(reading);
        }
        return readings;
    }
}