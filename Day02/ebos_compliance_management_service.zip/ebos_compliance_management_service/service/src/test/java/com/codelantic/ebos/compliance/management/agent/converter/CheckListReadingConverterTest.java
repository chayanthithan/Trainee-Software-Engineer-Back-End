package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CheckListReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ReadingImagesDto;
import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CheckListReadingConverterTest {

    @InjectMocks
    CheckListReadingConverter checkListReadingConverter;

    @Mock
    ReadingImagesConverter readingImagesConverter;

    @Mock
    SubCategoryCheckListRepository subCategoryCheckListRepository;

    @Test
    void convert() {
        CheckListReadingDto checkListReadingDto= new CheckListReadingDto();
        Set<ReadingImagesDto> readingImages= new HashSet<>();
        checkListReadingDto.setReadingImages(readingImages);
        checkListReadingDto.setSubCategoryCheckListId("88");
        Mockito.when(subCategoryCheckListRepository.findResultForRecord(checkListReadingDto.getSubCategoryCheckListId())).thenReturn(false);

        assertNotNull(checkListReadingConverter.convert(checkListReadingDto));
    }

    @Test
    void convert2() {
        CheckListReading checkListReading = new CheckListReading();
        Set<ReadingImages> readingImages = new HashSet<>();
        checkListReading.setReadingImages(readingImages);
        checkListReading.setSubCategoryCheckListId("66");
        assertNotNull(checkListReadingConverter.convert(checkListReading));

    }
}