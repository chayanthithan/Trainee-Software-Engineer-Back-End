package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DepartmentDto;
import com.codelantic.ebos.compliance.management.api.dto.LocationDto;
import com.codelantic.ebos.compliance.management.api.dto.SeverityDto;
import com.codelantic.ebos.compliance.management.api.dto.TypeOfIncidentDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class IncidentConverterTest {

    @InjectMocks
    IncidentConverter incidentConverter;

    @Mock
    UserManagementClient userManagementClient;

    @Test
    void convert(){
        TypeOfIncidentDto typeOfIncidentDto = new TypeOfIncidentDto();
        typeOfIncidentDto.setId("1");
        typeOfIncidentDto.setIncidentType("Nijanthan");
        typeOfIncidentDto.setBusinessId("1");
        assertNotNull(incidentConverter.convert(typeOfIncidentDto));
    }
    @Test
    void convertToEntity(){
        assertNotNull(incidentConverter.convertToEntity(new DepartmentDto()));
    }

    @Test
    void convertToEntitySeverity(){
        assertNotNull(incidentConverter.convertToEntity(new SeverityDto()));
    }

    @Test
    void convertToEntityLocation(){
        assertNotNull(incidentConverter.convertToEntity(new LocationDto()));
    }

    @Test
    void convertToOverview(){
        IncidentReading dto=new IncidentReading();
        dto.setCreatedBy("1");
        Integer rowStartNum=1;

        Set<Documents> documentsSet=new HashSet<>();
        Documents documents=new Documents();
        documents.setId("1");
        documentsSet.add(documents);
        dto.setDocuments(documentsSet);

        Set<NotifyTo> notifyTos=new HashSet<>();
        NotifyTo notifyTo=new NotifyTo();
        notifyTo.setId("1");
        notifyTo.setUserId("1");
        notifyTos.add(notifyTo);
        dto.setNotifyTo(notifyTos);

        Set<AffectedParties> affectedParties=new HashSet<>();
        AffectedParties affectedParties1=new AffectedParties();
        affectedParties1.setId("1");
        affectedParties.add(affectedParties1);
        dto.setAffectedPartiesAudio(affectedParties);

        Set<PotentialImpact> potentialImpacts=new HashSet<>();
        PotentialImpact potentialImpact=new PotentialImpact();
        potentialImpact.setId("1");
        potentialImpacts.add(potentialImpact);
        dto.setPotentialImpactsAudio(potentialImpacts);

        Set<ImmediateResponse> immediateResponses=new HashSet<>();
        ImmediateResponse immediateResponse=new ImmediateResponse();
        immediateResponse.setId("1");
        immediateResponses.add(immediateResponse);
        dto.setImmediateResponsesAudio(immediateResponses);

        Set<Description> descriptions=new HashSet<>();
        Description description=new Description();
        description.setId("1");
        descriptions.add(description);
        dto.setDescriptions(descriptions);

        UserName userName=new UserName();
        userName.setName("mithuja");
        Mockito.when( userManagementClient.getUserNameById(dto.getCreatedBy())).thenReturn(userName);
        Mockito.when(userManagementClient.getUserNameById(notifyTo.getUserId())).thenReturn(userName);

        assertNotNull(incidentConverter.convertToOverview(dto,rowStartNum));

    }

}
