package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.TrainingReadingConverter;
import com.codelantic.ebos.compliance.management.agent.converter.TrainingTitleConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.TrainingMaterialUsed;
import com.codelantic.ebos.compliance.management.entity.TrainingObjectives;
import com.codelantic.ebos.compliance.management.entity.TrainingReading;
import com.codelantic.ebos.compliance.management.entity.TrainingTitle;
import com.codelantic.ebos.compliance.management.service.TrainingReadingService;
import com.codelantic.ebos.compliance.management.service.TrainingTitleService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrainingAgentTest {

    @InjectMocks
    TrainingTitleAgent trainingTitleAgent;

    @Mock
    TrainingTitleConverter trainingTitleConverter;

    @Mock
    TrainingTitleService trainingTitleService;

    @Mock
    TrainingReadingService trainingReadingService;

    @Mock
    TrainingReadingConverter trainingReadingConverter;

    @Test
    void saveTrainingTitle() {
        TrainingTitleDto trainingTitleDto = new TrainingTitleDto();
        TrainingTitle trainingTitle = new TrainingTitle();
        when(trainingTitleConverter.convert(trainingTitleDto)).thenReturn(trainingTitle);
        when(trainingTitleService.saveTrainingTitle(trainingTitle)).thenReturn(new ResponseDto());
        assertNotNull(trainingTitleAgent.saveTrainingTitle(trainingTitleDto));
    }

    @Test
    void getTrainingTitles() {
        String businessId = "1";
        when(trainingTitleService.getTrainingTitles(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingTitleAgent.getTrainingTitles(businessId));
    }

    @Test
    void saveTrainingMaterialUsed() {
        TrainingMaterialUsedDto trainingMaterialUsedDto = new TrainingMaterialUsedDto();
        TrainingMaterialUsed trainingMaterialUsed = new TrainingMaterialUsed();
        when(trainingTitleConverter.convertToEntity(trainingMaterialUsedDto)).thenReturn(trainingMaterialUsed);
        when(trainingTitleService.saveTrainingMaterialUsed(trainingMaterialUsed)).thenReturn(new ResponseDto());
        assertNotNull(trainingTitleAgent.saveTrainingMaterialUsed(trainingMaterialUsedDto));
    }

    @Test
    void getTrainingMaterialUsed() {
        String businessId = "1";
        when(trainingTitleService.getTrainingMaterialUsed(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingTitleAgent.getTrainingMaterialUsed(businessId));
    }

    @Test
    void saveTrainingObjectives() {
        TrainingObjectivesDto trainingObjectivesDto = new TrainingObjectivesDto();
        TrainingObjectives trainingObjectives = new TrainingObjectives();
        when(trainingTitleConverter.convertToEntity(trainingObjectivesDto)).thenReturn(trainingObjectives);
        when(trainingTitleService.saveTrainingObjectives(trainingObjectives)).thenReturn(new ResponseDto());
        assertNotNull(trainingTitleAgent.saveTrainingObjectives(trainingObjectivesDto));
    }

    @Test
    void getAllTrainingObjectives() {
        String businessId = "1";
        when(trainingTitleService.getAllTrainingObjectives(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingTitleAgent.getAllTrainingObjectives(businessId));
    }

    @Test
    void getAllTrainingReadings() {
        String businessId = "1";
        String subCategoryId = "subCategoryId";
        TrainingOverViewSearchDto trainingOverViewSearchDto = TrainingOverViewSearchDto
                .builder()
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .fromDate(LocalDate.of(2024, 9, 1))
                .toDate(LocalDate.of(2024, 10, 1))
                .organizedBy("organizedBy")
                .participantId(List.of("participantId"))
                .trainerId(List.of("trainerId"))
                .complianceStatus(null)
                .page(1)
                .size(10)
                .build();
        TrainingReading trainingReading = new TrainingReading();
        TrainingReadingDto trainingReadingDto = new TrainingReadingDto();
        Page<TrainingReading> trainingReadings = new PageImpl<>(List.of(trainingReading));
        when(trainingReadingService.getAllTrainingReading(trainingOverViewSearchDto)).thenReturn(trainingReadings);
        when(trainingReadingConverter.convertToDto(trainingReading)).thenReturn((trainingReadingDto));
        assertNotNull(trainingTitleAgent.getAllTrainingReadings(trainingOverViewSearchDto));
    }
    @Test
    void getOverviewTrainingById(){
        TrainingReading trainingReading = new TrainingReading();
        when(trainingReadingService.getOverviewTrainingById("1")).thenReturn(trainingReading);
        when(trainingReadingConverter.convertToDtoById(trainingReading,"")).thenReturn(new TrainingReadingDto());
        assertNotNull(trainingTitleAgent.getOverviewTrainingById("1",""));
    }
}
