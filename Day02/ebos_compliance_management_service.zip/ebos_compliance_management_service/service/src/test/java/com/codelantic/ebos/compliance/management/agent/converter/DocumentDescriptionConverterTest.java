package com.codelantic.ebos.compliance.management.agent.converter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DocumentDescriptionConverterTest {

    @InjectMocks
    DocumentDescriptionConverter documentDescriptionConverter;

    @Value("${sftp.uploadPath}")
    private String sftpUploadPath;
    @Value("${sftp.base.url}")
    private String imagePath;

    @Test
    void convertToDto(){
        int i=1;
        assertNotNull(documentDescriptionConverter.convertToDto("Message", "Img",i));
    }

}