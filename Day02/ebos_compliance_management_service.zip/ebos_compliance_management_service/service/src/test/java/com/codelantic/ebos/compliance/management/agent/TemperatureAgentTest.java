package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.TemperatureConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.TemperatureTypeRange;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.compliance.management.service.TemperatureService;
import com.codelantic.ebos.compliance.management.validations.Validations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TemperatureAgentTest {

    @InjectMocks
    TemperatureAgent temperatureAgent;

    @Mock
    TemperatureService temperatureService;

    @Mock
    TemperatureConverter temperatureConverter;

    @Mock
    TemperatureTypeRangeRepository temperatureTypeRangeRepository;

    @Mock
    Validations validations;

    @Test
    void saveTemperatureTypeRange_NewTemperatureTypes_ShouldSaveSuccessfully() {
        // Arrange
        TemperatureTypeRangeDto dto1 = new TemperatureTypeRangeDto();
        dto1.setTemperatureType("AMBIENT");
        TemperatureTypeRangeDto dto2 = new TemperatureTypeRangeDto();
        dto2.setTemperatureType("COLD");

        TemperatureTypeRange entity1 = new TemperatureTypeRange();
        entity1.setTemperatureType(TemperatureType.AMBIENT);
        TemperatureTypeRange entity2 = new TemperatureTypeRange();
        entity2.setTemperatureType(TemperatureType.COOL);

        when(temperatureConverter.convert(dto1)).thenReturn(entity1);
        when(temperatureConverter.convert(dto2)).thenReturn(entity2);
        when(temperatureService.saveTemperatureTypeRange(anyList())).thenReturn(List.of(entity1, entity2));

        TemperatureTypeRangeResponseDto result = temperatureAgent.saveTemperatureTypeRange(List.of(dto1, dto2));

        assertNotNull(result);

    }

    @Test
    void saveTemperatureTypeRange_DuplicateTemperatureType_ShouldThrowException() {
        // Arrange
        TemperatureTypeRangeDto dto1 = new TemperatureTypeRangeDto();
        dto1.setTemperatureType("AMBIENT");
        TemperatureTypeRangeDto dto2 = new TemperatureTypeRangeDto();
        dto2.setTemperatureType("AMBIENT"); // Duplicate

        List<TemperatureTypeRangeDto> temperatureTypeRangeDtos = List.of(dto1, dto2);

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () ->
                // Single invocation of the method that may throw an exception
                temperatureAgent.saveTemperatureTypeRange(temperatureTypeRangeDtos)
        );

        assertEquals("Duplicate temperature type 'AMBIENT' found in the request", exception.getMessage());
    }


    @Test
    void saveTemperatureTypeRange_UpdateExistingTemperatureType_ShouldValidateAndSave() {
        // Arrange
        TemperatureTypeRangeDto dto = new TemperatureTypeRangeDto();
        dto.setId("1L");
        dto.setTemperatureType("AMBIENT");
        dto.setComplianceSubCategoryId("subcategory1");

        TemperatureTypeRange existingEntity = new TemperatureTypeRange();
        existingEntity.setId("1L");
        existingEntity.setTemperatureType(TemperatureType.AMBIENT);

        when(temperatureTypeRangeRepository.findById(dto.getId())).thenReturn(Optional.of(existingEntity));
        doNothing().when(validations).checkTemperatureTypeAndComplianceSubCategoryId(dto.getTemperatureType(), dto.getComplianceSubCategoryId());

        when(temperatureService.saveTemperatureTypeRange(anyList())).thenReturn(List.of(existingEntity));

        TemperatureTypeRangeResponseDto result = temperatureAgent.saveTemperatureTypeRange(List.of(dto));

        assertNotNull(result);
    }

    @Test
    void updateTemperatureTypeRange() {
        TemperatureTypeRangeUpdateDto temperatureTypeRangeUpdateDto = new TemperatureTypeRangeUpdateDto();
        when(temperatureService.updateTemperatureTypeRange(temperatureTypeRangeUpdateDto)).thenReturn(new TemperatureTypeRangeResponseDto());
        assertNotNull(temperatureAgent.updateTemperatureTypeRange(temperatureTypeRangeUpdateDto));
    }

    @Test
    void getAllTemperatureRangeDto_ShouldReturnTemperatureRanges() {

        String businessId = "business123";
        List<TemperatureTypeRangeDto> mockDtoList = new ArrayList<>();
        mockDtoList.add(new TemperatureTypeRangeDto());
        when(temperatureService.getAllTemperatureRangeDto(businessId)).thenReturn(mockDtoList);

        // Act
        List<TemperatureTypeRangeDto> result = temperatureAgent.getAllTemperatureRangeDto(businessId);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void getAllTemperatureReadingConfigurations_ShouldReturnConfigurations() {
        String subCategoryId = "subCategoryId";
        TemperatureReadingConfigurationsDto mockConfig = new TemperatureReadingConfigurationsDto();
        when(temperatureService.getAllTemperatureReadingConfigurations(subCategoryId)).thenReturn(mockConfig);

        // Act
        TemperatureReadingConfigurationsDto result = temperatureAgent.getAllTemperatureReadingConfigurations(subCategoryId);

        // Assert
        assertNotNull(result);
    }

    @Test
    void getAllTemperatureOverview_ShouldReturnPaginatedResponse() {
        // Arrange
        TemperatureOverviewSearchDto searchDto = TemperatureOverviewSearchDto.builder().build();
        searchDto.setPage(1);
        searchDto.setSize(10);

        List<TemperatureOverviewDto> temperatureList = List.of(new TemperatureOverviewDto(), new TemperatureOverviewDto());
        Pageable pageable = PageRequest.of(searchDto.getPage() - 1, searchDto.getSize());
        Page<TemperatureOverviewDto> temperaturePage = new PageImpl<>(temperatureList, pageable, 20);

        when(temperatureService.getAllTemperatureOverview(searchDto)).thenReturn(temperaturePage);

        // Act
        PaginatedResponseDto<TemperatureOverviewDto> result = temperatureAgent.getAllTemperatureOverview(searchDto);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.getData().size());
        assertEquals(1, result.getCurrentPage());
        assertEquals(20, result.getTotalItems());
    }

    @Test
    void saveTemperatureTypeRange_WhenTemperatureTypeRangeNotFound_ShouldThrowException() {
        // Arrange
        TemperatureTypeRangeDto dto = new TemperatureTypeRangeDto();
        dto.setId("1L");

        when(temperatureTypeRangeRepository.findById(dto.getId())).thenReturn(Optional.empty());

        // Prepare the data to pass into the method
        List<TemperatureTypeRangeDto> temperatureTypeRangeDtos = List.of(dto);

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () ->
                // Single invocation inside the lambda
                temperatureAgent.saveTemperatureTypeRange(temperatureTypeRangeDtos)
        );

        assertEquals("Temperature Type Range not found", exception.getMessage());
    }

    @Test
    void getAllTemperatureOverviewRow() {
        when(temperatureService.getAllTemperatureOverviewRow(any(String.class))).thenReturn(new ComplianceReading());
        when(temperatureConverter.getAllTemperatureOverviewRow(any(ComplianceReading.class))).thenReturn(new TemperatureOverviewDto());
        assertNotNull(temperatureAgent.getAllTemperatureOverviewRow("1"));

    }


    @Test
    void getAllTemperatureOverviewRowById(){
        String id = "1";
        when(temperatureService.getAllTemperatureOverviewRowById(id)).thenReturn(new TemperatureOverviewDto());
        assertNotNull(temperatureAgent.getAllTemperatureOverviewRowById(id));
    }

}



