package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TrainingMaterialUsedDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingObjectivesDto;
import com.codelantic.ebos.compliance.management.api.dto.TrainingTitleDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class TrainingConverterTest {

    @InjectMocks
    TrainingTitleConverter trainingTitleConverter;

    @Test
    void convert() {
        TrainingTitleDto trainingTitleDto = new TrainingTitleDto();
        trainingTitleDto.setId("1");
        trainingTitleDto.setTrainingTitleName("Nijanthan");
        trainingTitleDto.setBusinessId("1");
        assertNotNull(trainingTitleConverter.convert(trainingTitleDto));
    }

    @Test
    void convertToEntity() {
        assertNotNull(trainingTitleConverter.convertToEntity(new TrainingMaterialUsedDto()));
    }

@Test
    void convertToEntity1(){
        assertNotNull(trainingTitleConverter.convertToEntity(new TrainingObjectivesDto()));
}
}
