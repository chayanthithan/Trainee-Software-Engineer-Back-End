package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.TrainingTitleAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrainingTitleControllerTest {

    @InjectMocks
    TrainingController trainingController;

    @Mock
    TrainingTitleAgent trainingTitleAgent;

    @Test
    void saveTrainingTitle(){
        TrainingTitleDto trainingTitleDto = new TrainingTitleDto();
        when(trainingTitleAgent.saveTrainingTitle(trainingTitleDto)).thenReturn(new ResponseDto());
        assertNotNull(trainingController.saveTrainingTitle(trainingTitleDto));
    }

    @Test
    void getTrainingTitles(){
        String businessId = "1";
        when(trainingTitleAgent.getTrainingTitles(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingController.getTrainingTitles(businessId));
    }
    @Test
    void saveTrainingMaterialUsed(){

        when(trainingTitleAgent.saveTrainingMaterialUsed(new TrainingMaterialUsedDto())).thenReturn(new ResponseDto());
        assertNotNull(trainingController.saveTrainingMaterialUsed(new TrainingMaterialUsedDto()));
    }

    @Test
    void getTrainingMaterialUsed(){
        String businessId = "1";
        when(trainingTitleAgent.getTrainingMaterialUsed(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingController.getTrainingMaterialUsed(businessId));
    }

    @Test
    void saveTrainingObjectives(){
        when(trainingTitleAgent.saveTrainingObjectives(new TrainingObjectivesDto())).thenReturn(new ResponseDto());
        assertNotNull(trainingController.saveTrainingObjectives(new TrainingObjectivesDto()));
    }

    @Test
    void getAllTrainingObjectives(){
        String businessId = "1";
        when(trainingTitleAgent.getAllTrainingObjectives(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(trainingController.getAllTrainingObjectives(businessId));
    }

    @Test
    void getTrainingOverView(){
        String businessId = "1";
        String subCategoryId = "subCategoryId";
        TrainingOverViewSearchDto trainingOverViewSearchDto= TrainingOverViewSearchDto
                .builder()
                .businessId(businessId)
                .subCategoryId(subCategoryId)
                .fromDate(LocalDate.of(2024,9,1))
                .toDate(LocalDate.of(2024,10,1))
                .organizedBy("organizedBy")
                .participantId(List.of("participantId"))
                .trainerId(List.of("trainerId"))
                .complianceStatus(null)
                .page(1)
                .size(10)
                .build();
        when(trainingTitleAgent.getAllTrainingReadings(trainingOverViewSearchDto)).thenReturn(PaginatedResponseDto.<TrainingReadingDto>builder().data(List.of(new TrainingReadingDto())).build());
        assertNotNull (trainingController.getAllTrainingReadings(trainingOverViewSearchDto));
    }
    @Test
    void  getOverviewTrainingById(){
        when(trainingTitleAgent.getOverviewTrainingById("1","")).thenReturn(new TrainingReadingDto());
        assertNotNull(trainingController.getOverviewTrainingById("1",""));
    }


}

