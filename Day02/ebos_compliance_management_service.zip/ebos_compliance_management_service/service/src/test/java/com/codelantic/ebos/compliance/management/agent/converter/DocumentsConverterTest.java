package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.entity.Documents;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class DocumentsConverterTest {

    @InjectMocks
    DocumentsConverter documentsConverter;

    @Test
    void convert(){
        DocumentsDto dto = new DocumentsDto();
        dto.setId("1L");
        dto.setImageName("sample.jpg");
        dto.setViewImagePath("/path/to/sample.jpg");
        dto.setTrainingReadingId("2L");
        dto.setLicenseAndPermitReadingId("3L");
        dto.setWasteManagementReadingId("4L");
        dto.setIncidentReadingId("5L");
        dto.setVisitorReadingId("6L");
        dto.setComplaintReadingId("7L");

        assertNotNull(documentsConverter.convert(dto));
    }

    @Test
    void convertDocumentsDto(){
        assertNotNull(documentsConverter.convert(new Documents()));
    }

    @Test
    void convertForLicense(){
        Documents documents=new Documents();
        assertNotNull(documentsConverter.convertForLicense(documents));
    }
}
