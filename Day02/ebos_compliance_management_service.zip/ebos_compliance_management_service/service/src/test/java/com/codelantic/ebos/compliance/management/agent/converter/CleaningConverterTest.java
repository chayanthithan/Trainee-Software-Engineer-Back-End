package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CleaningOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestionsReadings;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class CleaningConverterTest {

    @InjectMocks
    private CleaningConverter cleaningConverter;

    @Mock
    private UserManagementClient userManagementClient;

    @Mock
    private CheckListReadingRepository checkListReadingRepository;
    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;


    @Test
    void convertToDto() {
        ComplianceReading complianceReading = new ComplianceReading();
        complianceReading.setId("id");
        complianceReading.setCreatedBy("Aju");
        complianceReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        CleaningOverViewDisplayDto expectedDto = CleaningOverViewDisplayDto.builder()
                .id(complianceReading.getId())
                .complianceStatus(complianceReading.getComplianceStatus().getMappedValue())
                .employeeName("Test User")
                .build();

        TotalCheckedCountDto counts = new TotalCheckedCountDto(5L, 4L);

        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(complianceReading.getId()))
                .thenReturn(counts);
        when(complianceSubCategoryRepository.findBySubCategoryNameIgnoreCase(complianceReading.getId()))
                .thenReturn("aju");
        when(userManagementClient.getUserNameById("Aju")).thenReturn(new UserName());
        Set<CheckListReading> checkListRead = new HashSet<>();
        CheckListReading checkListReading = new CheckListReading();
        Set<ReadingImages> readImages = new HashSet<>();
        ReadingImages readingImages = new ReadingImages();
        checkListRead.add(checkListReading);
        checkListReading.setReadingImages(readImages);
        complianceReading.setCheckListReadings(checkListRead);

        Set<SubCategoryQuestionsReadings> questionRead = new HashSet<>();
        SubCategoryQuestionsReadings subCategoryQuestionsReadings = new SubCategoryQuestionsReadings();

        readImages.add(readingImages);
        subCategoryQuestionsReadings.setReadingImages(readImages);
        questionRead.add(subCategoryQuestionsReadings);
        complianceReading.setSubCategoryQuestionsReadings(questionRead);
        CleaningOverViewDisplayDto actualDto = cleaningConverter.convertToDto(complianceReading, "id");

        assertNotNull(actualDto);
        assertEquals(expectedDto.getComplianceStatus(), actualDto.getComplianceStatus());

    }

    @Test
    void convertToDtoForOverView() {
        CheckListReading checkListReading = new CheckListReading();
        Set<CheckListReading> checkListReadings = new HashSet<>();
        checkListReadings.add(checkListReading);
        SubCategoryQuestionsReadings subCategoryQuestionsReading = new SubCategoryQuestionsReadings();
        Set<ReadingImages> readingImages = new HashSet<>();
        ReadingImages readingImage = new ReadingImages();
        checkListReading.setReadingImages(readingImages);


        readingImages.add(readingImage);
        subCategoryQuestionsReading.setReadingImages(readingImages);
        Set<SubCategoryQuestionsReadings> subCategoryQuestionsReadings = new HashSet<>();
        subCategoryQuestionsReadings.add(subCategoryQuestionsReading);
        ComplianceReading complianceReading = ComplianceReading.builder()
                .id("ajith")
                .date(LocalDate.now())
                .time(LocalTime.now())
                .complianceStatus(ComplianceStatus.APPROVED)
                .complianceSubCategoryId("1")
                .createdBy("ajith")
                .checkListReadings(checkListReadings)
                .subCategoryQuestionsReadings(subCategoryQuestionsReadings)
                .build();
        TotalCheckedCountDto totalCheckedCountDto = new TotalCheckedCountDto(4L, 5L);
        when(complianceSubCategoryRepository.findBySubCategoryNameIgnoreCase(anyString())).thenReturn("ajith");
        when(userManagementClient.getUserNameById(anyString())).thenReturn(new UserName());
        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(anyString())).thenReturn(totalCheckedCountDto);
        assertNotNull(cleaningConverter.convertToDtoForOverView(complianceReading));
    }
}