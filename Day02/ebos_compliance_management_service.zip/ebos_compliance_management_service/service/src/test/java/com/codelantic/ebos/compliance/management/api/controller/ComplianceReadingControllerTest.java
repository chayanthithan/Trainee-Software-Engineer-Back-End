package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceReadingAgent;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceReadingControllerTest {

    @InjectMocks
    ComplianceReadingController controller;

    @Mock
    ComplianceReadingAgent complianceReadingAgent;

    @Test
    void save(){
        ComplianceReadingDto complianceReadingDto = new ComplianceReadingDto();

        Mockito.when(complianceReadingAgent.save(complianceReadingDto,ComplianceCategory.CLEANING)).thenReturn(new ResponseDto());
        assertNotNull(controller.save(complianceReadingDto,ComplianceCategory.CLEANING));
    }

    @Test
    void update() {
        ComplianceReadingDto complianceReadingDto = new ComplianceReadingDto();
        Mockito.when(complianceReadingAgent.update(complianceReadingDto, ComplianceCategory.CLEANING))
                .thenReturn(new ResponseDto());
        assertNotNull(controller.update(complianceReadingDto, ComplianceCategory.CLEANING));

    }

    @Test
    void getById() {
        Mockito.when(complianceReadingAgent.getById("1", ComplianceCategory.CLEANING))
                .thenReturn(new Object());
        assertNotNull(controller.getById("1", ComplianceCategory.CLEANING));
    }


}
