package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.NotifyToDto;
import com.codelantic.ebos.compliance.management.api.dto.ReadingImagesDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.TempreatureReadingGetDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeConfigurationsRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TemperatureReadingConverterTest {

    @InjectMocks
    private TemperatureReadingConverter temperatureReadingConverter;

    @Mock
    private ReadingImagesConverter readingImagesConverter;

    @Mock
    private NotifyToConverter notifyToConverter;
    @Mock
    private TemperatureTypeRangeConfigurationsRepository temperatureTypeRangeConfigurationsRepository;

    @Mock
    private TemperatureTypeRangeRepository temperatureTypeRangeRepository;



    @Test
    void testConvertEntityToDto() {
        TemperatureReadingDto temperatureReadingDto = new TemperatureReadingDto();
        ReadingImagesDto mockReadingImagesDto = ReadingImagesDto.builder().build();
        NotifyToDto mockNotifyToDto = NotifyToDto.builder().build();

        // Add mock data to the collections in the DTO
        temperatureReadingDto.setReadingImages(new HashSet<>(Collections.singletonList(mockReadingImagesDto)));
        temperatureReadingDto.setNotifyTo(new HashSet<>(Collections.singletonList(mockNotifyToDto)));

        // Mocking the behavior of the converters
        when(readingImagesConverter.convert(mockReadingImagesDto)).thenReturn(new ReadingImages());
        when(notifyToConverter.convert(mockNotifyToDto)).thenReturn(NotifyTo.builder().build());

        // Convert DTO to Entity
        TemperatureReading result = temperatureReadingConverter.convert(temperatureReadingDto);

        // Assertions
        assertEquals(temperatureReadingDto.getId(), result.getId());
        assertEquals(temperatureReadingDto.getComplianceSubCategoryId(), result.getComplianceSubCategoryId());
        assertEquals(temperatureReadingDto.getTemperatureTypeRangeConfigurationsId(), result.getTemperatureTypeRangeConfigurationsId());
        assertEquals(temperatureReadingDto.getQuantity(), result.getQuantity());
        assertEquals(temperatureReadingDto.getActualReading(), result.getActualReading());
        assertEquals(temperatureReadingDto.getComments(), result.getComments());
        assertEquals(temperatureReadingDto.getComplianceReadingId(), result.getComplianceReadingId());
        assertEquals(1, result.getReadingImages().size()); // Assuming convert returns a single ReadingImages
        assertEquals(1, result.getNotifyTo().size()); // Assuming convert returns a single NotifyTo
    }

    @Test
    void ConvertEntityToDto() {
        ReadingImages mockReadingImages = new ReadingImages();
        NotifyTo mockNotifyTo = new NotifyTo();

        TemperatureReading temperatureReadingWithValidData = TemperatureReading.builder()
                .id("1")
                .complianceSubCategoryId("subCatId")
                .temperatureTypeRangeConfigurationsId("typeRangeId")
                .quantity(5)
                .actualReading("25")
                .comments("Sample comment")
                .complianceReadingId("compReadId")
                .readingImages(new HashSet<>(Collections.singletonList(mockReadingImages)))
                .notifyTo(new HashSet<>(Collections.singletonList(mockNotifyTo)))
                .build();

        when(readingImagesConverter.convert(mockReadingImages)).thenReturn(ReadingImagesDto.builder().build());
        when(notifyToConverter.convert(mockNotifyTo)).thenReturn(NotifyToDto.builder().build());

        TemperatureReadingDto result = temperatureReadingConverter.convert(temperatureReadingWithValidData);

        assertEquals(temperatureReadingWithValidData.getId(), result.getId());
        assertEquals(temperatureReadingWithValidData.getComplianceSubCategoryId(), result.getComplianceSubCategoryId());
        assertEquals(temperatureReadingWithValidData.getTemperatureTypeRangeConfigurationsId(), result.getTemperatureTypeRangeConfigurationsId());
        assertEquals(temperatureReadingWithValidData.getQuantity(), result.getQuantity());
        assertEquals(temperatureReadingWithValidData.getActualReading(), result.getActualReading());
        assertEquals(temperatureReadingWithValidData.getComments(), result.getComments());
        assertEquals(temperatureReadingWithValidData.getComplianceReadingId(), result.getComplianceReadingId());
        assertEquals(1, result.getReadingImages().size());
        assertEquals(1, result.getNotifyTo().size());

        temperatureReadingWithValidData.setReadingImages(null);
        temperatureReadingWithValidData.setNotifyTo(null);

        result = temperatureReadingConverter.convert(temperatureReadingWithValidData);

        assertNull(result.getReadingImages());
        assertNull(result.getNotifyTo());

        temperatureReadingWithValidData.setReadingImages(new HashSet<>());
        temperatureReadingWithValidData.setNotifyTo(new HashSet<>());

        result = temperatureReadingConverter.convert(temperatureReadingWithValidData);

        assertEquals(0, result.getReadingImages().size());
        assertEquals(0, result.getNotifyTo().size());
    }

    @Test
    void testConvertTemperature_Success() {
        TemperatureReading temperatureReading = new TemperatureReading();
        temperatureReading.setId("1");
        temperatureReading.setComplianceSubCategoryId("10");
        temperatureReading.setTemperatureTypeRangeConfigurationsId("100");
        temperatureReading.setQuantity(5);
        temperatureReading.setActualReading("22.5");
        temperatureReading.setComplianceReadingId("200");
        temperatureReading.setReadingImages(Set.of(ReadingImages.builder().build()));
        temperatureReading.setNotifyTo(Set.of(new NotifyTo()));

        TemperatureTypeRangeConfigurations mockConfig = new TemperatureTypeRangeConfigurations();
        mockConfig.setItems("Test Item");
        mockConfig.setTemperatureTypeRangeId("300");

        TemperatureTypeRange mockRange = new TemperatureTypeRange();
        mockRange.setStartTemperature("20.0");
        mockRange.setEndTemperature("30.0");
        mockRange.setTemperatureType(TemperatureType.HOT);

        when(temperatureTypeRangeConfigurationsRepository.findById("100"))
                .thenReturn(Optional.of(mockConfig));
        when(temperatureTypeRangeRepository.findById("300"))
                .thenReturn(Optional.of(mockRange));
        when(notifyToConverter.convert(any(NotifyTo.class)))
                .thenReturn(NotifyToDto.builder().build());

        TempreatureReadingGetDto result = temperatureReadingConverter.convertTempreature(temperatureReading);

        assertNotNull(result);


    }

    @Test
    void testConvertTemperature_ConfigurationNotFound() {
        when(temperatureTypeRangeConfigurationsRepository.findById(anyString()))
                .thenReturn(Optional.empty());

        TemperatureReading temperatureReading = new TemperatureReading();
        temperatureReading.setTemperatureTypeRangeConfigurationsId("100");

        ServiceException exception = assertThrows(ServiceException.class,
                () -> temperatureReadingConverter.convertTempreature(temperatureReading));

        assertEquals("TemperatureTypeRangeConfigurations Not Found", exception.getMessage());
    }

    @Test
    void testConvertTemperature_RangeNotFound() {
        TemperatureTypeRangeConfigurations mockConfig = new TemperatureTypeRangeConfigurations();
        mockConfig.setTemperatureTypeRangeId("300");

        when(temperatureTypeRangeConfigurationsRepository.findById("100"))
                .thenReturn(Optional.of(mockConfig));
        when(temperatureTypeRangeRepository.findById(anyString()))
                .thenReturn(Optional.empty());

        TemperatureReading temperatureReading = new TemperatureReading();
        temperatureReading.setTemperatureTypeRangeConfigurationsId("100");

        ServiceException exception = assertThrows(ServiceException.class,
                () -> temperatureReadingConverter.convertTempreature(temperatureReading));

        assertEquals("temperatureTypeRange Not Found", exception.getMessage());
    }


}
