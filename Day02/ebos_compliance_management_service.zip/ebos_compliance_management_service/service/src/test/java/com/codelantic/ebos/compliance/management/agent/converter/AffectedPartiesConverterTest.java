package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.AffectedPartiesDto;
import com.codelantic.ebos.compliance.management.entity.AffectedParties;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class AffectedPartiesConverterTest {

    @InjectMocks
    AffectedPartiesConverter affectedPartiesConverter;

    @Test
    void convert() {
        assertNotNull(affectedPartiesConverter.convert(new AffectedPartiesDto()));
    }

    @Test
    void convert2() {
        AffectedParties affectedParties = new AffectedParties();
        assertNotNull(affectedPartiesConverter.convert(affectedParties));
    }
}