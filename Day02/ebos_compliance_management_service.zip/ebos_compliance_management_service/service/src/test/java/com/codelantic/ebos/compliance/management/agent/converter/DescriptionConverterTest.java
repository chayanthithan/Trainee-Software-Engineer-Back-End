package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DescriptionDto;
import com.codelantic.ebos.compliance.management.entity.Description;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class DescriptionConverterTest {
@InjectMocks
    DescriptionConverter descriptionConverter;

    @Test
    void convert() {
        assertNotNull(descriptionConverter.convert(new DescriptionDto()));
    }

    @Test
    void convertToDto(){
        assertNotNull(descriptionConverter.convert(new Description()));
    }
}