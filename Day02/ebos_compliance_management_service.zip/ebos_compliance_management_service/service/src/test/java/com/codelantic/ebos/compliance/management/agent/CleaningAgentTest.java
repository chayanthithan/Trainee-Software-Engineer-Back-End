package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.CleaningConverter;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.CleaningService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CleaningAgentTest {
    @InjectMocks
    private CleaningAgent cleaningAgent;
    @Mock
    private CleaningService cleaningService;
    @Mock
    private CleaningConverter cleaningConverter;


    @Test
    void getAllOverViewForCleaning() {
        CleaningOverviewSearchDto cleaningOverviewSearchDto = CleaningOverviewSearchDto.builder()
                .subCategoryId("ii")
                .page(1)
                .size(10)
                .build();

        List<ComplianceReading> complianceReadings = Collections.singletonList(new ComplianceReading()); // Mock one ComplianceReading
        Page<ComplianceReading> compliantReadingsPage = new PageImpl<>(complianceReadings);

        CleaningOverViewDisplayDto cleaningOverViewDisplayDto = new CleaningOverViewDisplayDto();
        Mockito.when(cleaningService.getAllOverViewForCleaning(cleaningOverviewSearchDto)).thenReturn(compliantReadingsPage);
        Mockito.when(cleaningConverter.convertToDto(new ComplianceReading(), "ii")).thenReturn(cleaningOverViewDisplayDto);

        PaginatedResponseDto<CleaningOverViewDisplayDto> response = cleaningAgent.getAllOverViewForCleaning(cleaningOverviewSearchDto);

        assertNotNull(response);
        assertEquals(1, response.getData().size());
        assertEquals(1, response.getCurrentPage());
        assertEquals(1, response.getTotalPages());
        assertEquals(1, response.getTotalItems());
    }

    @Test
    void getOverviewCleaningById() {
        String complianceReadingId = "";
        ComplianceReading complianceReading = new ComplianceReading();
        Mockito.when(cleaningService.getOverviewCleaningById(complianceReadingId)).thenReturn(complianceReading);
        Mockito.when(cleaningConverter.convertToDtoForOverView(complianceReading)).thenReturn(new CleaningOverViewDisplayDto());
        assertNotNull(cleaningAgent.getOverviewCleaningById(complianceReadingId));
    }
}