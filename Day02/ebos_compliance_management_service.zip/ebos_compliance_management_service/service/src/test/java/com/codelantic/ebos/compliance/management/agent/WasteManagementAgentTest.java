package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.WasteManagementConverter;
import com.codelantic.ebos.compliance.management.agent.converter.WasteManagementReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.TypeOfWaste;
import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.service.WasteManagementService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WasteManagementAgentTest {

    @Mock
    private WasteManagementConverter wasteManagementConverter;
    @Mock
    private WasteManagementService wasteManagementService;

    @InjectMocks
    private WasteManagementAgent wasteManagementAgent;

    @Mock
    WasteManagementReadingConverter wasteManagementReadingConverter;

    @Test
    void addNewWasteType() {
        TypeOfWaste typeOfWaste = new TypeOfWaste();
        TypeOfWasteDto typeOfWasteDto = new TypeOfWasteDto("id", "type");
        when(wasteManagementConverter.convertToEntity(typeOfWasteDto)).thenReturn(typeOfWaste);
        when(wasteManagementService.addNewWasteType(typeOfWaste)).thenReturn(ResponseDto.builder().build());
        assertNotNull(wasteManagementAgent.addNewWasteType(typeOfWasteDto));


    }

    @Test
    void getAllWasteTypesByBusinessId() {
        String businessId = "businessId";
        TypeOfWasteDto typeOfWasteDto = new TypeOfWasteDto("id", "type");
        when(wasteManagementService.getAllWasteType(businessId)).thenReturn(List.of(typeOfWasteDto));
        assertNotNull(wasteManagementAgent.getAllWasteTypesByBusinessId(businessId));
    }

    @Test
    void getAllWasteOverview() {
        StringBuilder complianceSubCategoryId = new StringBuilder("1");
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = LocalDate.now();
        StringBuilder employeeName = new StringBuilder("1");
        StringBuilder complianceStatus = new StringBuilder("Pending Review");
        Integer page = 1;
        Integer size = 5;

        WasteManagementOverviewSearchDto wasteManagementOverviewSearchDto = WasteManagementOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .complianceSubCategoryId(complianceSubCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName.toString())
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus.toString()) : null)
                .build();

        WasteManagementReading wasteManagementReading = new WasteManagementReading();
        wasteManagementReading.setId("1");
        List<WasteManagementReading> wasteManagementReadings = new ArrayList<>();
        wasteManagementReadings.add(wasteManagementReading);
        Page<WasteManagementReading> wasteManagementReadings1 = new PageImpl<>(wasteManagementReadings);

        when(wasteManagementService.getAllWasteOverview(wasteManagementOverviewSearchDto)).thenReturn(wasteManagementReadings1);

        WasteManagementOverviewDto wasteManagementOverviewDto = new WasteManagementOverviewDto();
        when(wasteManagementReadingConverter.convertToDto(any(WasteManagementReading.class)))
                .thenReturn(wasteManagementOverviewDto);

        PaginatedResponseDto<WasteManagementOverviewDto> response = wasteManagementAgent.getAllWasteOverview(wasteManagementOverviewSearchDto);

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().get(0).getRowNo()); // Check if the row number was set
    }

    @Test
    void getOverviewWasteById() {
        when(wasteManagementService.getOverviewWasteById(anyString())).thenReturn(new WasteManagementReading());
        when(wasteManagementReadingConverter.convertToDto(any(WasteManagementReading.class))).thenReturn(new WasteManagementOverviewDto());
        assertNotNull(wasteManagementAgent.getOverviewWasteById("1"));
    }
}