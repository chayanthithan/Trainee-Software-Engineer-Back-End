package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.IncidentConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.service.IncidentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IncidentAgentTest {

    @InjectMocks
    IncidentAgent incidentAgent;

    @Mock
    IncidentConverter incidentConverter;

    @Mock
    IncidentService incidentService;

    @Test
    void saveTypeOfIncident() {
        TypeOfIncident typeOfIncident = new TypeOfIncident();
        typeOfIncident.setBusinessId("1");
        TypeOfIncidentDto typeOfIncidentDto = new TypeOfIncidentDto();
        typeOfIncidentDto.setId("1");
        when(incidentConverter.convert(typeOfIncidentDto)).thenReturn(typeOfIncident);
        when(incidentService.saveTypeOfIncident(typeOfIncident)).thenReturn(new ResponseDto());
        assertNotNull(incidentAgent.saveTypeOfIncident(typeOfIncidentDto));
    }

    @Test
    void getAllTypeOfIncidents() {
        String businessId = "1";
        when(incidentService.getAllTypeOfIncidents(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentAgent.getAllTypeOfIncidents(businessId));
    }

    @Test
    void saveDeparment() {
        when(incidentConverter.convertToEntity(new DepartmentDto())).thenReturn(new Department());
        when(incidentService.saveDepartment(new Department())).thenReturn(new ResponseDto());
        assertNotNull(incidentAgent.saveDepartment(new DepartmentDto()));
    }

    @Test
    void getAllDepartment() {
        String businessId = "1";
        when(incidentService.getAllDepartment(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentAgent.getAllDepartment(businessId));
    }

    @Test
    void saveLocation() {
        Location locationDto = new Location();
        locationDto.setBusinessId("1");
        LocationDto dto = new LocationDto();
        dto.setId("1");
        when(incidentConverter.convertToEntity(dto)).thenReturn(locationDto);
        when(incidentService.saveLocation(locationDto)).thenReturn(new ResponseDto());
        assertNotNull(incidentAgent.saveLocation(dto));
    }

    @Test
    void getAllLocation() {
        String businessId = "1";
        when(incidentService.getAllLocation(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentAgent.getAllLocation(businessId));
    }

    @Test
    void saveSeverity() {
        SeverityDto severityDto = new SeverityDto();
        severityDto.setBusinessId("1");
        Severity severity = new Severity();
        severity.setId("1");
        when(incidentConverter.convertToEntity(severityDto)).thenReturn(severity);
        when(incidentService.saveSeverity(severity)).thenReturn(new ResponseDto());
        assertNotNull(incidentAgent.saveSeverity(severityDto));
    }

    @Test
    void getAllSeverities() {
        String businessId = "1";
        when(incidentService.getAllSeverities(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentAgent.getAllSeverities(businessId));
    }

    @Test
    void getAllConfiguredField() {
        String complianceSubCategoryId = "1";
        when(incidentService.getAllConfiguredField(complianceSubCategoryId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentAgent.getAllConfiguredField(complianceSubCategoryId));
    }

    @Test
    void getAllIncidentOverview() {
        IncidentOverviewSearchDto incidentOverviewSearchDto = IncidentOverviewSearchDto.builder()
                .page(1)
                .size(20)
                .build();
        List<IncidentReading> incidentReadings = Collections.emptyList();
        Page<IncidentReading> incidentOverviewDtos = new PageImpl<>(incidentReadings);
        when(incidentService.getAllIncidentOverview(Mockito.any(IncidentOverviewSearchDto.class))).thenReturn(incidentOverviewDtos);
        assertNotNull(incidentAgent.getAllIncidentOverview(incidentOverviewSearchDto));


    }

    @Test
    void getOverViewById() {
        when(incidentService.getOverViewById(anyString())).thenReturn(new IncidentReading());
        when(incidentConverter.convertToOverview(incidentService.getOverViewById("1"), 1)).thenReturn(new IncidentOverviewDto());
        assertNotNull(incidentAgent.getOverViewById("1"));

    }
}
