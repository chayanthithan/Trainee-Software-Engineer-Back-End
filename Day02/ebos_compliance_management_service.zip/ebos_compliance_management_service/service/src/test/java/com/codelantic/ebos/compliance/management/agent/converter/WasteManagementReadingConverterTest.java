package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementReadingDto;
import com.codelantic.ebos.compliance.management.entity.Documents;
import com.codelantic.ebos.compliance.management.entity.WasteManagementReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WasteManagementReadingConverterTest {

    @InjectMocks
    WasteManagementReadingConverter wasteManagementReadingConverter;

    @Mock
    DocumentsConverter documentsConverter;

    @Mock
    UserManagementClient userManagementClient;
    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Test
    void ab(){
        WasteManagementReading wasteManagementReading = new WasteManagementReading();
        Set<Documents> nvg = new HashSet<>();
        Documents documents = new Documents();
        nvg.add(documents);
        wasteManagementReading.setDocuments(nvg);

        Mockito.when(documentsConverter.convert(documents)).thenReturn(new DocumentsDto());
        assertNotNull(wasteManagementReadingConverter.convert(wasteManagementReading));
    }
    @Test
    void convert() {
        Authentication authentication = Authentication.builder().build();
        authentication.setUserId("Nijanthan");
        AuthenticationContextHolder.setContext(authentication);

        WasteManagementReadingDto dto = new WasteManagementReadingDto();
        dto.setId("1L");
        dto.setDate(LocalDate.now());
        dto.setTypeOfWastage("Plastic");
        dto.setStorageLocation("Warehouse A");
        dto.setDisposalMethod("Recycling");
        dto.setProductName("Plastic Bottles");
        dto.setQuantity(100);
        dto.setUnitCost(234.4);
        dto.setTotalWasteValue("3525.2");
        dto.setComments("Sample waste management entry");
        dto.setSubCategoryFormConfigurationsId("2L");
        dto.setDocuments(new HashSet<>());

        assertNotNull(wasteManagementReadingConverter.convert(dto));
    }

    @Test
    void testConvertToDto() {
        WasteManagementReading wasteManagementReading = new WasteManagementReading();
        wasteManagementReading.setId("1");
        wasteManagementReading.setDate(LocalDate.of(2023, 10, 2));
        wasteManagementReading.setTime(LocalTime.now());
        wasteManagementReading.setComments("Comments on the compliant");
        wasteManagementReading.setComplianceStatus(ComplianceStatus.APPROVED);

        wasteManagementReading.setCreatedBy("user123");
        UserName createdByUser = new UserName();
        createdByUser.setName("John Creator");

        Documents doc1 = new Documents();
        doc1.setImageName("image1.png");
        doc1.setImagePath("/path/image1.png");

        Documents doc2 = new Documents();
        doc2.setImageName("image2.png");
        doc2.setImagePath("/path/image2.png");

        Set<Documents> documents = new HashSet<>();
        documents.add(doc1);
        documents.add(doc2);

        wasteManagementReading.setDocuments(documents);

        when(userManagementClient.getUserNameById("user123")).thenReturn(createdByUser);
        WasteManagementOverviewDto resultDto = wasteManagementReadingConverter.convertToDto(wasteManagementReading);

        assertNotNull(resultDto);
    }

    @Test
    void updateConvert() {
        WasteManagementReading existingReading = new WasteManagementReading();
        WasteManagementReadingDto wasteManagementReadingDto = WasteManagementReadingDto.builder()
                .id("1")
                .date(LocalDate.of(2024, 1, 2))
                .typeOfWastage("Type B")
                .storageLocation("Location B")
                .disposalMethod("Method B")
                .productName("Product B")
                .quantity(20)
                .unitCost(10.0)
                .totalWasteValue("20")
                .documents(new HashSet<>())
                .build();
        wasteManagementReadingConverter.updateConvert(existingReading, wasteManagementReadingDto);
        assertEquals(wasteManagementReadingDto.getId(), existingReading.getId());


    }

    @Test
    void testConvert() {
        WasteManagementReadingDto wasteManagementReadingDto = WasteManagementReadingDto.builder()
                .id("1")
                .date(LocalDate.of(2024, 1, 2))
                .typeOfWastage("Type B")
                .storageLocation("Location B")
                .disposalMethod("Method B")
                .productName("Product B")
                .quantity(20)
                .unitCost(10.0)
                .totalWasteValue("20")
                .documents(new HashSet<>())
                .build();
        Authentication authentication = Authentication.builder().build();
        authentication.setUserId("Nijanthan");
        AuthenticationContextHolder.setContext(authentication);
        assertNotNull(wasteManagementReadingConverter.convert(wasteManagementReadingDto));

    }
}
