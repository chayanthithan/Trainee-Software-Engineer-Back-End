package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.LicenseAndPermitReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.LicensePermitOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.service.LicenseAndPermitReadingService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LicenseAndPermitReadingAgentTest {
    @InjectMocks
    private LicenseAndPermitReadingAgent licenseAndPermitReadingAgent;
    @Mock
    private  LicenseAndPermitReadingService licenseAndPermitReadingService;
    @Mock
    private  LicenseAndPermitReadingConverter licenseAndPermitReadingConverter;

@Test
void getAllLicensePermits_withData() {
    LicensePermitOverviewSearchDto licensePermitOverviewSearchDto = LicensePermitOverviewSearchDto.builder().page(1).size(10).build();
    LicenseAndPermitReading readingEntity = new LicenseAndPermitReading();
    List<LicenseAndPermitReading> licenseAndPermitReadingList = List.of(readingEntity);
    Page<LicenseAndPermitReading> compliantReadings = new PageImpl<>(licenseAndPermitReadingList);
    LicenseAndPermitReadingOverViewDto dto = new LicenseAndPermitReadingOverViewDto();

    when(licenseAndPermitReadingService.getAllLicenseAndPermitReading(licensePermitOverviewSearchDto)).thenReturn(compliantReadings);
    when(licenseAndPermitReadingConverter.convertToDto(readingEntity)).thenReturn(dto);
    PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> result = licenseAndPermitReadingAgent.getAllLicensePermits(licensePermitOverviewSearchDto);
    assertNotNull(result);
    assertFalse(result.getData().isEmpty());
    assertEquals(1, result.getData().size());
    assertEquals(1, result.getCurrentPage());
    assertEquals(1, result.getTotalPages());
    assertEquals(1, result.getTotalItems());
    assertEquals("01", result.getData().get(0).getRowNo());
}

    @Test
    void getLicenseOverviewById() {
    when(licenseAndPermitReadingService.getLicenseOverviewById(anyString())).thenReturn(new LicenseAndPermitReading());
    when(licenseAndPermitReadingConverter.convertToDtos(any(LicenseAndPermitReading.class),anyString())).thenReturn(new LicenseAndPermitReadingOverViewDto());
    assertNotNull(licenseAndPermitReadingAgent.getLicenseOverviewById("1","1"));
    }
}