package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.SelectedTrainingTitleDto;
import com.codelantic.ebos.compliance.management.entity.SelectedTrainingTitle;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class SelectedTrainingTitleConverterTest {
    @InjectMocks
    SelectedTrainingTitleConverter selectedTrainingTitleConverter;

    @Test
    void convert() {
        assertNotNull(selectedTrainingTitleConverter.convert(new SelectedTrainingTitleDto()));
    }

    @Test
    void convertt() {
        assertNotNull(selectedTrainingTitleConverter.convert(new SelectedTrainingTitle()));
    }
}