package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ParticipantsDto;
import com.codelantic.ebos.compliance.management.entity.Participants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class ParticipantsConverterTest {
@InjectMocks
    ParticipantsConverter participantsConverter;

    @Test
    void convert() {
        assertNotNull(participantsConverter.convert(new ParticipantsDto()));
    }

    @Test
    void convertt() {
        assertNotNull(participantsConverter.convert(new Participants()));
    }
}