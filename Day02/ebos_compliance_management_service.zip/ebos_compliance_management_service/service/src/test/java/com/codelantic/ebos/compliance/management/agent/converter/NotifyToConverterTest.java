package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.NotifyToDto;
import com.codelantic.ebos.compliance.management.entity.NotifyTo;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotifyToConverterTest {
    @InjectMocks
    NotifyToConverter notifyToConverter;
    @Mock
    UserManagementClient userManagementClient;

    @Test
    void convert() {
        assertNotNull(notifyToConverter.convert(NotifyToDto.builder().build()));
    }

    @Test
    void testConvert() {
        when(userManagementClient.getUserNameById("user654")).thenReturn(new UserName());
        NotifyTo notifyTo = NotifyTo.builder()
                .id("1")
                .incidentReadingId("incident123")
                .visitorReadingId("visitor456")
                .temperatureReadingId("temp789")
                .complaintReadingId("complaint987")
                .userId("user654")
                .build();
        assertNotNull(notifyToConverter.convert(notifyTo));

    }
}