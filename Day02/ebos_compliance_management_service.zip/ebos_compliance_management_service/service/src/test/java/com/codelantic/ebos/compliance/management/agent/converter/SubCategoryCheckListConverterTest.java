package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CheckListHeadingDto;
import com.codelantic.ebos.compliance.management.api.dto.SubCategoryCheckListSaveDto;

import com.codelantic.ebos.compliance.management.entity.SubCategoryCheckList;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SubCategoryCheckListConverterTest {

    @InjectMocks
    SubCategoryCheckListConverter subCategoryCheckListConverter;

    @Mock
    SubCategoryCheckListRepository subCategoryCheckListRepository;

    private SubCategoryCheckList subCategoryCheckList;
    private SubCategoryCheckListSaveDto subCategoryCheckListSaveDto;

    @BeforeEach
    void setUp() {
        subCategoryCheckList = SubCategoryCheckList.builder()
                .id("1")
                .heading("Sample Heading")
                .checklist("Sample Checklist")
                .isCommentAvailable(true)
                .isDocumentAvailable(true)
                .status(true)
                .build();

        subCategoryCheckListSaveDto = SubCategoryCheckListSaveDto.builder()
                .id("1")
                .heading("Sample Heading")
                .checkList("Sample Checklist")
                .isCommentAvailable(true)
                .isDocumentAvailable(true)
                .build();
    }

    @Test
    void convertToEntity_withValidInput() {
        SubCategoryCheckList result = subCategoryCheckListConverter.convertToEntity(subCategoryCheckListSaveDto);

        assertNotNull(result);
        assertEquals(subCategoryCheckListSaveDto.getHeading(), result.getHeading());
        assertEquals(subCategoryCheckListSaveDto.getCheckList(), result.getChecklist());
        assertEquals(subCategoryCheckListSaveDto.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryCheckListSaveDto.getIsDocumentAvailable(), result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToSubCategoryCheckListSaveDto_withValidInput() {
        SubCategoryCheckListSaveDto result = subCategoryCheckListConverter.convertToSubCategoryCheckListSaveDto(subCategoryCheckList);

        assertNotNull(result);
        assertEquals(subCategoryCheckList.getId(), result.getId());
        assertEquals(subCategoryCheckList.getHeading(), result.getHeading());
        assertEquals(subCategoryCheckList.getChecklist(), result.getCheckList());
        assertEquals(subCategoryCheckList.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryCheckList.getIsDocumentAvailable(), result.getIsDocumentAvailable());
    }

    @Test
    void convertToUpdate_withValidInput() {
        when(subCategoryCheckListRepository.findById(subCategoryCheckListSaveDto.getId()))
                .thenReturn(Optional.of(subCategoryCheckList));

        SubCategoryCheckList result = subCategoryCheckListConverter.convertToUpdate(subCategoryCheckListSaveDto, "2");

        assertNotNull(result);
        assertEquals(subCategoryCheckListSaveDto.getCheckList(), result.getChecklist());
        assertEquals(subCategoryCheckListSaveDto.getHeading(), result.getHeading());
        assertEquals("2", result.getComplianceSubCategoryId());
        assertEquals(subCategoryCheckListSaveDto.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryCheckListSaveDto.getIsDocumentAvailable(), result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToUpdate_withInvalidId() {
        when(subCategoryCheckListRepository.findById(subCategoryCheckListSaveDto.getId()))
                .thenReturn(Optional.empty());

        ServiceException exception = assertThrows(ServiceException.class, () ->
                subCategoryCheckListConverter.convertToUpdate(subCategoryCheckListSaveDto, "2"));

        assertEquals("Sub category checklist not found for id: 1", exception.getMessage());

        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }

    @Test
    void convertToCheckListDto_withValidInput() {
        CheckListHeadingDto result = subCategoryCheckListConverter.convertToCheckListHeadingDto(subCategoryCheckList);

        assertNotNull(result);
        assertEquals(subCategoryCheckList.getId(), result.getId());
        assertEquals(subCategoryCheckList.getChecklist(), result.getCheckList());
        assertEquals(subCategoryCheckList.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryCheckList.getIsDocumentAvailable(), result.getIsDocumentAvailable());
    }

    @Test
    void convertToEntity_withNullValues() {
        SubCategoryCheckListSaveDto nullDto = SubCategoryCheckListSaveDto.builder()
                .id(null)
                .heading(null)
                .checkList(null)
                .isCommentAvailable(null)
                .isDocumentAvailable(null)
                .build();

        SubCategoryCheckList result = subCategoryCheckListConverter.convertToEntity(nullDto);

        assertNull(result.getHeading());
        assertNull(result.getChecklist());
        assertNull(result.getIsCommentAvailable());
        assertNull(result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToNew(){
        SubCategoryCheckListSaveDto dto = SubCategoryCheckListSaveDto.builder()
                .checkList("gbr")
                .heading(" f")
                .isCommentAvailable(true)
                .build();
        String complianceSubCategoryId = "ddt";
        assertNotNull(subCategoryCheckListConverter.convertToNew(dto,complianceSubCategoryId));
    }
}
