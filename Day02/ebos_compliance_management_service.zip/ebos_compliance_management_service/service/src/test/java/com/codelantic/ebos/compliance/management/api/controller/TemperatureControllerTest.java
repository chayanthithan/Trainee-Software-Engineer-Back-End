package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.TemperatureAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TemperatureControllerTest {

    @InjectMocks
    TemperatureController temperatureController;

    @Mock
    TemperatureAgent temperatureAgent;

    @Test
    void saveTemperatureTypeRange() {
        List<TemperatureTypeRangeDto> temperatureTypeRangeDto = new ArrayList<>();
        when(temperatureAgent.saveTemperatureTypeRange(temperatureTypeRangeDto)).thenReturn(new TemperatureTypeRangeResponseDto());
        assertNotNull(temperatureController.saveTemperatureTypeRange(temperatureTypeRangeDto));
    }

    @Test
    void updateTemperatureTypeRange() {
        TemperatureTypeRangeUpdateDto temperatureTypeRangeUpdateDto = new TemperatureTypeRangeUpdateDto();
        when(temperatureAgent.updateTemperatureTypeRange(temperatureTypeRangeUpdateDto)).thenReturn(new TemperatureTypeRangeResponseDto());
        assertNotNull(temperatureController.updateTemperatureTypeRange(temperatureTypeRangeUpdateDto));
    }

    @Test
    void getAllTemperatureRangeDto() {
        String businessId = "1";
        when(temperatureAgent.getAllTemperatureRangeDto(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(temperatureController.getAllTemperatureRangeDto(businessId));
    }

    @Test
    void getAllTemperatureReadingConfigurations() {
        String subCategoryId = "subCategoryId";
        when(temperatureAgent.getAllTemperatureReadingConfigurations(subCategoryId)).thenReturn(new TemperatureReadingConfigurationsDto());
        assertNotNull(temperatureController.getAllTemperatureReadingConfigurations(subCategoryId));
    }

    @Test
    void getAllTemperatureOverview() {
        String businessId = "51d08357-9c4f-4d6c-a391-89db99edfff8";
        String subCategoryId = "02537399-0835-4650-8a4f-bb193aa06b34";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        LocalDate toDate = LocalDate.of(2023, 12, 31);
        ComplianceStatus complianceStatus = ComplianceStatus.COMPLIANCE_MET;
        List<String> employeeIds = new ArrayList<>();
        List<String> notifyTos = new ArrayList<>();
        int page = 1;
        int size = 10;
        assertNull(temperatureController.getAllTemperatureOverview(businessId, subCategoryId, fromDate, toDate, page, size, complianceStatus.getMappedValue(), employeeIds, notifyTos));
    }

    @Test
    void getAllTemperatureOverviewRow() {
        when(temperatureAgent.getAllTemperatureOverviewRow(anyString())).thenReturn(new TemperatureOverviewDto());
        assertNotNull(temperatureController.getAllTemperatureOverviewRow("1"));
    }

    @Test
    void getAllTemperatureOverviewRowById(){
        when(temperatureAgent.getAllTemperatureOverviewRowById(anyString())).thenReturn(new TemperatureOverviewDto());
        assertNotNull(temperatureController.getAllTemperatureOverviewRowById("1"));
    }

}
