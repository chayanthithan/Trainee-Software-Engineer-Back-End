package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.DeliveryAgent;
import com.codelantic.ebos.compliance.management.api.dto.DeliveryOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureOverviewSearchDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(MockitoExtension.class)
class DeliveryControllerTest {

    @InjectMocks
    DeliveryController deliveryController;

    @Mock
    DeliveryAgent deliveryAgent;

    @Test
    void getAllDeliveryOverview(){
        StringBuilder subCategoryId=new StringBuilder("1");
        LocalDate fromDate=LocalDate.now();
        LocalDate toDate=LocalDate.now();
        int page=1;
        int size=10;
        String complianceStatus= ComplianceStatus.UNDER_REVIEW.getMappedValue();
        List<String> employeeIds=new ArrayList<>();
        List<String> notifyTos=new ArrayList<>();

        TemperatureOverviewSearchDto deliverySearchDto = TemperatureOverviewSearchDto.builder()
                .subCategoryId(subCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .page(page)
                .size(size)
                .complianceStatus(complianceStatus)
                .employeeIds(employeeIds)
                .notifyTos(notifyTos)
                .build();

        PaginatedResponseDto<DeliveryOverviewDto> deliveryOverviewDtoPaginatedResponseDto=new PaginatedResponseDto<>();
        Mockito.when(deliveryAgent.getAllDeliveryOverview(deliverySearchDto)).thenReturn(deliveryOverviewDtoPaginatedResponseDto);
        assertNotNull(deliveryController.getAllDeliveryOverview(subCategoryId.toString(),fromDate,toDate,page,size,complianceStatus,employeeIds,notifyTos));

    }

}