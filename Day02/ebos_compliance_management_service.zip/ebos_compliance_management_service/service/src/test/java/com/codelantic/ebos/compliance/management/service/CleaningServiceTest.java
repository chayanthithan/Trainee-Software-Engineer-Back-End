package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.api.dto.CleaningOverviewSearchDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
class CleaningServiceTest {
    @InjectMocks
    private CleaningService cleaningService;
    @Mock
    private UserManagementClient userManagementClient;
    @Mock
    private Validations validations;
    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;
    @Mock
    private ComplianceReadingRepository complianceReadingRepository;
    private CleaningOverviewSearchDto cleaningOverviewSearchDto;


    @BeforeEach
    void setUp() {
        cleaningOverviewSearchDto = CleaningOverviewSearchDto.builder()
                .page(1)
                .size(10)
                .employeeName("John Doe")
                .complianceStatus(ComplianceStatus.COMPLIANCE_MET)
                .fromDate(LocalDate.of(2024, 1, 1))
                .toDate(LocalDate.of(2024, 12, 31))
                .businessId("1")
                .subCategoryId("A1")
                .build();
        Mockito.when(userManagementClient.checkBusinessId(anyString())).thenReturn(true);

        Mockito.doNothing()
                .doThrow(new RuntimeException("Date validation failed on second invocation"))
                .when(validations).dateValidation(any(LocalDate.class), any(LocalDate.class));
        Pageable paging = PageRequest.of(0, 10);
        Page<ComplianceReading> mockPage = new PageImpl<>(Collections.emptyList());
        Mockito.when(complianceReadingRepository.getAllOverViewForCleaning(
                anyString(), any(LocalDate.class), any(LocalDate.class), anyString(),
                any(ComplianceStatus.class), eq(paging), anyString())).thenReturn(mockPage);
    }

    @AfterEach
    void cleanUp() {
        Mockito.reset(userManagementClient, validations, complianceSubCategoryRepository, complianceReadingRepository);
    }


    @Test
    void getAllOverViewForCleaning() {
        Mockito.when(complianceSubCategoryRepository.existsByIdAndStatus(anyString(), eq(true))).thenReturn(true);
        Page<ComplianceReading> response = cleaningService.getAllOverViewForCleaning(cleaningOverviewSearchDto);
        assertNotNull(response);

    }

    @Test
    void checkException() {
        Mockito.when(complianceSubCategoryRepository.existsByIdAndStatus(anyString(), eq(true))).thenReturn(false);
        assertThrows(ServiceException.class, () -> cleaningService.getAllOverViewForCleaning(cleaningOverviewSearchDto));

    }


    @Test
    void getOverviewCleaningById(){
        String complianceReadingId ="";
        ComplianceReading complianceReading = new ComplianceReading();
        Mockito.when(complianceReadingRepository.findById(complianceReadingId)).thenReturn(Optional.of(complianceReading));
        Mockito.when(complianceReadingRepository.getOverviewCleaningById(complianceReadingId)).thenReturn(complianceReading);
        assertNotNull(cleaningService.getOverviewCleaningById(complianceReadingId));
    }
}