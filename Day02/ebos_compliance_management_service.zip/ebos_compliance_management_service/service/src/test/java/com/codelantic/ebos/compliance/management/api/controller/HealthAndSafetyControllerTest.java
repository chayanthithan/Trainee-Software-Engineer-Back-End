package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.HealthAndSafetyAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HealthAndSafetyControllerTest {
    @InjectMocks
    HealthAndSafetyController healthAndSafetyController;
    @Mock
    HealthAndSafetyAgent healthAndSafetyAgent;

    @Test
    void overViewForCleaning() {

        String businessId = "51d08357-9c4f-4d6c-a391-89db99edfff8";
        LocalDate fromDate = LocalDate.now().minusDays(30);
        LocalDate toDate = LocalDate.now();
        String employeeName = "John Doe";
        ComplianceStatus complianceStatus = ComplianceStatus.APPROVED;
        Integer page = 1;
        Integer size = 10;
        String subCategoryId = "sub-12345";

        PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> paginatedResponseDto = new PaginatedResponseDto<>();


        when(healthAndSafetyAgent.getAllOverViewForHealthAndSafety(Mockito.any(HealthAndSafetyOverviewSearchDto.class)))
                .thenReturn(paginatedResponseDto);
        PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> response = healthAndSafetyController.overViewForHealthAndSafety(
                businessId, fromDate, toDate, employeeName, complianceStatus.getMappedValue(), page, size, subCategoryId
        );
        assertNotNull(response);
        Mockito.verify(healthAndSafetyAgent).getAllOverViewForHealthAndSafety(Mockito.any(HealthAndSafetyOverviewSearchDto.class));

    }


    @Test
    void getOverviewHealthAndSafetyById() {
        when(healthAndSafetyAgent.getOverviewHealthAndSafetyById(anyString())).thenReturn(new HealthAndSafetyOverViewDisplayDto());
        assertNotNull(healthAndSafetyController.getOverviewHealthAndSafetyById("1"));
    }
}