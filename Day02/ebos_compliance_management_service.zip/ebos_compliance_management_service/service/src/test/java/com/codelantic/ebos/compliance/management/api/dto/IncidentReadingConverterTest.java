package com.codelantic.ebos.compliance.management.api.dto;

import com.codelantic.ebos.compliance.management.agent.converter.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class IncidentReadingConverterTest {

    @Mock
    ImmediateResponseConverter immediateResponseConverter;
    @Mock
    DescriptionConverter descriptionConverter;
    @Mock
    NotifyToConverter notifyToConverter;
    @Mock
    DocumentsConverter documentsConverter;
    @Mock
    AffectedPartiesConverter affectedPartiesConverter;
    @InjectMocks
    private IncidentReadingConverter incidentReadingConverter;
    @Mock
    private PotentialImpactConverter potentialImpactConverter;

    @Test
    void convert() {
        Authentication authentication = Authentication.builder().build();
        authentication.setUserId("Nijanthan");
        AuthenticationContextHolder.setContext(authentication);

        IncidentReadingDto incidentReadingDto = new IncidentReadingDto();

        Set<AffectedPartiesDto> affectedPartiesAudio = new HashSet<>();
        incidentReadingDto.setAffectedPartiesAudio(affectedPartiesAudio);

        Set<PotentialImpactDto> potentialImpactsAudio = new HashSet<>();
        incidentReadingDto.setPotentialImpactsAudio(potentialImpactsAudio);

        Set<ImmediateResponseDto> immediateResponsesAudio = new HashSet<>();
        incidentReadingDto.setImmediateResponsesAudio(immediateResponsesAudio);

        Set<DescriptionDto> descriptions = new HashSet<>();
        incidentReadingDto.setDescriptions(descriptions);

        Set<NotifyToDto> notifyTo = new HashSet<>();
        incidentReadingDto.setNotifyTo(notifyTo);

        Set<DocumentsDto> documents = new HashSet<>();
        incidentReadingDto.setDocuments(documents);

        assertNotNull(incidentReadingConverter.convert(incidentReadingDto));
    }

    @Test
    void convertIncidentReadingDto() {
        IncidentReading incidentReading = new IncidentReading();
        incidentReading.setId("1");
        Set<AffectedParties> affectedParties = new HashSet<>();
        AffectedParties affectedParties1 = new AffectedParties();
        affectedParties1.setId("1");
        affectedParties.add(affectedParties1);
        incidentReading.setAffectedPartiesAudio(affectedParties);
        Set<PotentialImpact> potentialImpacts = new HashSet<>();
        PotentialImpact potentialImpact = new PotentialImpact();
        potentialImpact.setId("1");
        potentialImpacts.add(potentialImpact);
        incidentReading.setPotentialImpactsAudio(potentialImpacts);
        Set<ImmediateResponse> immediateResponses = new HashSet<>();
        ImmediateResponse immediateResponse = new ImmediateResponse();
        immediateResponse.setId("1");
        immediateResponses.add(immediateResponse);
        incidentReading.setImmediateResponsesAudio(immediateResponses);
        Set<Description> descriptions = new HashSet<>();
        Description description = new Description();
        description.setId("1");
        descriptions.add(description);
        incidentReading.setDescriptions(descriptions);
        Set<NotifyTo> notifyTos = new HashSet<>();
        NotifyTo notifyTo = new NotifyTo();
        notifyTo.setId("1");
        notifyTos.add(notifyTo);
        incidentReading.setNotifyTo(notifyTos);
        Set<Documents> documents = new HashSet<>();
        Documents documents1 = new Documents();
        documents1.setId("1");
        documents.add(documents1);
        incidentReading.setDocuments(documents);
        assertNotNull(incidentReadingConverter.convert(incidentReading));
    }

    @Test
    void updateConvert() {
        IncidentReading existingReading = new IncidentReading();
        IncidentReadingDto incidentReadingDto = new IncidentReadingDto();
        Set<AffectedPartiesDto> affectedPartiesDtos = new HashSet<>();
        incidentReadingDto.setAffectedPartiesAudio(affectedPartiesDtos);

        Set<PotentialImpactDto> potentialImpactDtos = new HashSet<>();
        PotentialImpactDto potentialImpactDto = new PotentialImpactDto();
        potentialImpactDtos.add(potentialImpactDto);
        incidentReadingDto.setPotentialImpactsAudio(potentialImpactDtos);

        Set<ImmediateResponseDto> immediateResponses = new HashSet<>();
        incidentReadingDto.setImmediateResponsesAudio(immediateResponses);

        Set<DescriptionDto> descriptions = new HashSet<>();
        incidentReadingDto.setDescriptions(descriptions);

        Set<NotifyToDto> notifyToDtos = new HashSet<>();
        incidentReadingDto.setNotifyTo(notifyToDtos);

        Set<DocumentsDto> documents = new HashSet<>();
        incidentReadingDto.setDocuments(documents);

        incidentReadingConverter.updateConvert(existingReading, incidentReadingDto);
        int x = 6;
        assertEquals(6, x);
    }
}