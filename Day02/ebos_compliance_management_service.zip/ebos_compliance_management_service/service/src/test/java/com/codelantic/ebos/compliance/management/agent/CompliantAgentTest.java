package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.ComplaintConverter;
import com.codelantic.ebos.compliance.management.agent.converter.CompliantOverViewConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.entity.CompliantType;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.service.CompliantService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CompliantAgentTest {

    @InjectMocks
    CompliantAgent compliantAgent;

    @Mock
    CompliantService compliantService;

    @Mock
    ComplaintConverter complaintConverter;

    @Mock
    CompliantOverViewConverter compliantOverViewConverter;

    @Test
    void saveComplaintType() {
        ComplaintTypeSaveDto complaintTypeSaveDto = new ComplaintTypeSaveDto();
        complaintTypeSaveDto.setBusinessId("1");
        complaintTypeSaveDto.setTypeOfCompliant("new type");
        CompliantType compliantType = new CompliantType();
        compliantType.setBusinessId("1");
        compliantType.setTypeOfCompliant("new type");
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Complaint Type saved");
        when(complaintConverter.convertToEntity(complaintTypeSaveDto)).thenReturn(compliantType);
        when(compliantService.saveComplaintType(compliantType)).thenReturn(responseDto);
        ResponseDto responseDto1 = compliantAgent.saveComplaintType(complaintTypeSaveDto);
        assertEquals("Complaint Type saved", responseDto1.getMessage());
    }

    @Test
    void getComplainType() {
        StringBuilder businessId = new StringBuilder();
        businessId.append("1");
        List<ComplaintTypeSaveDto> complaintTypeSaveDtos = new ArrayList<>();
        when(compliantService.getComplainType(businessId.toString())).thenReturn(complaintTypeSaveDtos);
        assertNotNull(compliantAgent.getComplainType(businessId.toString()));
    }

    @Test
    void getAllComplaints() {
        StringBuilder complianceSubCategoryId = new StringBuilder("1");
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = LocalDate.now();
        StringBuilder employeeName = new StringBuilder("1");
        StringBuilder complianceStatus = new StringBuilder("Pending Review");
        Integer page = 1;
        Integer size = 5;

        CompliantOverviewSearchDto compliantOverviewSearchDto = CompliantOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .complianceSubCategoryId(complianceSubCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName.toString())
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus.toString()) : null)
                .build();

        CompliantReading compliantReading = new CompliantReading();
        compliantReading.setId("1");
        List<CompliantReading> compliantReadings = new ArrayList<>();
        compliantReadings.add(compliantReading);
        Page<CompliantReading> compliantReadingsPage = new PageImpl<>(compliantReadings);

        when(compliantService.getAllComplaints(compliantOverviewSearchDto)).thenReturn(compliantReadingsPage);

        CompliantOverViewDto compliantOverViewDto = new CompliantOverViewDto();
        when(compliantOverViewConverter.convertToDto(Mockito.any(CompliantReading.class)))
                .thenReturn(compliantOverViewDto);

        PaginatedResponseDto<CompliantOverViewDto> response = compliantAgent.getAllComplaints(compliantOverviewSearchDto);

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().get(0).getRowNo()); // Check if the row number was set
    }


    @Test
    void getOverviewCompliantById() {
        when(compliantService.getOverviewCompliantById(anyString())).thenReturn(new CompliantReading());
        when(compliantOverViewConverter.convertToDto(any(CompliantReading.class))).thenReturn(new CompliantOverViewDto());
        assertNotNull(compliantAgent.getOverviewCompliantById("1"));

    }
}