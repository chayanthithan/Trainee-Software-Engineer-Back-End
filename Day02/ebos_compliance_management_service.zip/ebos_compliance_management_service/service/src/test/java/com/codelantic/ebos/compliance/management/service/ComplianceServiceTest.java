package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceConverter;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.BusinessComplianceRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceRepository;
import com.codelantic.ebos.compliance.management.validations.Validations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(MockitoExtension.class)
class ComplianceServiceTest {

    @Mock
    private  BusinessComplianceRepository businessComplianceRepository;

    @Mock
    private  ComplianceRepository complianceRepository;

    @Mock
    private  Validations validations;

    @Mock
    private  ComplianceConverter complianceConverter;

    @InjectMocks
    private ComplianceService complianceService;

    @Test
    void addOrRemoveComplianceForBusiness() {
        String businessId="businessId";
        Integer complianceId=123;
        boolean status=true;
        ComplianceConfigurationsDto complianceConfigurationsDto=new ComplianceConfigurationsDto();
        complianceConfigurationsDto.setBusinessId(businessId);
        complianceConfigurationsDto.setStatus(status);
        complianceConfigurationsDto.setComplianceId(complianceId);

        //case 1 compliance not found
        Mockito.when(complianceRepository.existsById(complianceId)).thenReturn(false);
        assertThrows(ServiceException.class,()->complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));

        //case 2 compliance duplication
        Mockito.when(complianceRepository.existsById(complianceId)).thenReturn(true);
        Mockito.when(businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceId,businessId)).thenReturn(true);
        assertThrows(ServiceException.class,()->complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));

        //case 3 add new
        Mockito.when(businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceId,businessId)).thenReturn(false);
        assertDoesNotThrow(()->complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));

        //case 4 delete existing compliance
        Mockito.when(businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceId,businessId)).thenReturn(true);
        complianceConfigurationsDto.setStatus(false);
        assertDoesNotThrow(()->complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));

        //case 5 delete non-existing compliance
        Mockito.when(businessComplianceRepository.existsByComplianceIdAndBusinessId(complianceId,businessId)).thenReturn(false);
        assertThrows(ServiceException.class,()->complianceService.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));

    }
    @Test
    void getAllAvailableCompliance() {
        String businessId="51d08357-9c4f-4d6c-a391-89db99edfff8";
        Mockito.when(complianceRepository.getAllAvailableCompliance(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(complianceService.getAllAvailableCompliance(businessId));
    }
}