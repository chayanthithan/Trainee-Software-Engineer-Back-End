package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.LicenseAndPermitReadingAgent;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.LicensePermitOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LicenseAndPermitsControllerTest {
    @Mock
    private LicenseAndPermitReadingAgent licenseAndPermitReadingAgent;
    @InjectMocks
    private LicenseAndPermitsController licenseAndPermitsControllerTest;

    @Test
    void overViewForLicenseAndPermitReading() {
        String businessId = "1";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        LocalDate toDate = LocalDate.of(2023, 12, 31);
        String employeeName = "John Doe";
        String complianceStatus = "Pending Review";
        Integer page = 1;
        Integer size = 10;
        String subCategoryId = "1";
        PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> paginatedResponseDto = new PaginatedResponseDto<>();
        when(licenseAndPermitReadingAgent.getAllLicensePermits(Mockito.any(LicensePermitOverviewSearchDto.class))).thenReturn(paginatedResponseDto);
        PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> response = licenseAndPermitsControllerTest.overViewForLicenseAndPermitReading(businessId, fromDate, toDate, employeeName, complianceStatus, page, size, subCategoryId);
        assertNotNull(response);

    }

    @Test
    void getLicenseOverviewById() {
        when(licenseAndPermitReadingAgent.getLicenseOverviewById(anyString(),anyString())).thenReturn(new LicenseAndPermitReadingOverViewDto());
        assertNotNull(licenseAndPermitsControllerTest.getLicenseOverviewById("1","1"));
    }
}