package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.WasteManagementAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WasteManagementControllerTest {

    @Mock
    private WasteManagementAgent wasteManagementAgent;

    @InjectMocks
    private WasteManagementController wasteManagementController;
    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Test
    void addVisitType() {
        TypeOfWasteDto typeOfWasteDto=new TypeOfWasteDto("id","type");
        Mockito.when(wasteManagementAgent.addNewWasteType(typeOfWasteDto)).thenReturn(ResponseDto.builder().build());
        assertNotNull(wasteManagementController.addWasteType(typeOfWasteDto));

    }

    @Test
    void getAllWasteTypeByBusinessId() {
        String businessId="businessId";
        TypeOfWasteDto typeOfWasteDto=new TypeOfWasteDto("id","type");
        Mockito.when(wasteManagementAgent.getAllWasteTypesByBusinessId(businessId)).thenReturn(List.of(typeOfWasteDto));
        assertNotNull(wasteManagementController.getAllVisitWasteTypeByBusinessId(businessId));
    }

    @Test
    void getAllWasteOverview(){
        StringBuilder complianceSubCategoryId=new StringBuilder("1");
        StringBuilder businessId=new StringBuilder("1");
        LocalDate fromDate=LocalDate.now();
        LocalDate toDate=LocalDate.now();
        StringBuilder employeeName=new StringBuilder("1");
        StringBuilder complianceStatus=new StringBuilder("Pending Review");
        Integer page=1;
        Integer size=5;
        WasteManagementOverviewSearchDto wasteManagementOverviewDto = WasteManagementOverviewSearchDto
                .builder()
                .page(page)
                .size(size)
                .businessId(businessId.toString())
                .complianceSubCategoryId(complianceSubCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName.toString())
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus.toString()) : null)
                .build();
        PaginatedResponseDto<WasteManagementOverviewDto> compliantOverViewDtoPaginatedResponseDto=new PaginatedResponseDto<>();
        Mockito.when(wasteManagementAgent.getAllWasteOverview(wasteManagementOverviewDto)).thenReturn(compliantOverViewDtoPaginatedResponseDto);
        assertNotNull(wasteManagementController.getAllWasteOverview(businessId.toString(),complianceSubCategoryId.toString(),fromDate,toDate,employeeName.toString(),complianceStatus.toString(),page,size));
    }

    @Test
    void getOverviewWasteById() {
        when(wasteManagementAgent.getOverviewWasteById(anyString())).thenReturn(new WasteManagementOverviewDto());
        assertNotNull(wasteManagementController.getOverviewWasteById("1"));

    }
}