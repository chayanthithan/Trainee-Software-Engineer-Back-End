package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.FileUploadAgent;
import com.codelantic.ebos.compliance.management.api.dto.DeleteImageDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDetailDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.UploadDocumentsDto;
import com.jcraft.jsch.JSchException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FileUploadControllerTest {

    @InjectMocks
    FileUploadController fileUploadController;

    @Mock
    FileUploadAgent fileUploadAgent;

    @Test
    void uploadDocuments_success() throws JSchException {
        // Arrange
        List<MultipartFile> files = new ArrayList<>();
        files.add(Mockito.mock(MultipartFile.class));
        String audioOrImage = "IMAGE";
        ImageDetailDto imageDetailDto = new ImageDetailDto();

        when(fileUploadAgent.uploadDocuments(any(UploadDocumentsDto.class), eq(files), eq(audioOrImage)))
                .thenReturn(imageDetailDto);
        ImageDetailDto result = fileUploadController.uploadDocuments(files, "subCategoryId", "subCategoryName", 7, audioOrImage);

        assertNotNull(result);
        Mockito.verify(fileUploadAgent).uploadDocuments(any(UploadDocumentsDto.class), eq(files), eq(audioOrImage));
    }

    @Test
    void deleteImage_success() {
        // Arrange
        List<DeleteImageDto> deleteImageDtos = new ArrayList<>();
        deleteImageDtos.add(new DeleteImageDto());
        String saveOrUpdate = "SAVE";

        when(fileUploadAgent.deleteImage(deleteImageDtos, saveOrUpdate)).thenReturn(new ResponseDto());
        ResponseDto response = fileUploadController.deleteImage(deleteImageDtos, saveOrUpdate);
        assertNotNull(response);

    }

    @Test
    void downloadDocument() throws IOException {
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(HttpStatus.OK);
        when(fileUploadAgent.downloadDocument(Collections.singletonList("documentUrl"))).thenReturn(responseEntity);
        assertNotNull(fileUploadController.downloadDocument(Collections.singletonList("documentUrl")));
    }


    @Test
    void testDownloadSingleDocument_Success() throws IOException, JSchException {
        // Arrange
        String documentUrl = "testDirectory/testDocument.pdf";
        byte[] mockFileData = "Mock file content".getBytes();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename("testDocument.pdf")
                .build());
        ResponseEntity<byte[]> mockResponse = new ResponseEntity<>(mockFileData, headers, HttpStatus.OK);

        // Mock the agent's method
        when(fileUploadAgent.downloadSingleDocument(documentUrl)).thenReturn(mockResponse);

        // Act
        ResponseEntity<byte[]> response = fileUploadController.downloadSingleDocument(documentUrl);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }
}
