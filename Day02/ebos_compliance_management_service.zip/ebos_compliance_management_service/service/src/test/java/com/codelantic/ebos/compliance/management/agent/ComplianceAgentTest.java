package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import com.codelantic.ebos.compliance.management.service.ComplianceService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceAgentTest {

    @Mock
    private ComplianceService complianceService;

    @InjectMocks
    private ComplianceAgent complianceAgent;

    @Test
    void addOrRemoveComplianceToBusiness() {
        ComplianceConfigurationsDto complianceConfigurationsDto=new ComplianceConfigurationsDto();
        assertDoesNotThrow(() -> complianceAgent.addComplianceToBusiness(complianceConfigurationsDto));
    }
    @Test
    void getAllAvailableCompliance() {
        String businessId="51d08357-9c4f-4d6c-a391-89db99edfff8";
        Mockito.when(complianceService.getAllAvailableCompliance(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(complianceAgent.getAllAvailableCompliance(businessId));
    }
}