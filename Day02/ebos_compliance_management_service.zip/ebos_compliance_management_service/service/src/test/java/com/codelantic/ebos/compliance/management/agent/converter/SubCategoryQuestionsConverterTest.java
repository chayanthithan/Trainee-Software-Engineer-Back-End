package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.QuestionHeadingDto;
import com.codelantic.ebos.compliance.management.api.dto.SubCategoryQuestionsSaveDto;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestions;
import com.codelantic.ebos.compliance.management.exception.ServiceException;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SubCategoryQuestionsConverterTest {

    @InjectMocks
    SubCategoryQuestionsConverter subCategoryQuestionsConverter;

    @Mock
    SubCategoryQuestionRepository subCategoryQuestionRepository;

    private SubCategoryQuestions subCategoryQuestions;
    private SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto;

    @BeforeEach
    void setUp() {
        subCategoryQuestions = SubCategoryQuestions.builder()
                .id("1")
                .heading("Sample Heading")
                .question("Sample Question")
                .isCommentAvailable(true)
                .isDocumentAvailable(true)
                .status(true)
                .build();

        subCategoryQuestionsSaveDto = SubCategoryQuestionsSaveDto.builder()
                .id("1")
                .heading("Sample Heading")
                .question("Sample Question")
                .isCommentAvailable(true)
                .isDocumentAvailable(true)
                .build();
    }

    @Test
    void convertToEntity_withValidInput() {
        SubCategoryQuestions result = subCategoryQuestionsConverter.convertToEntity(subCategoryQuestionsSaveDto);

        assertNotNull(result);
        assertEquals(subCategoryQuestionsSaveDto.getHeading(), result.getHeading());
        assertEquals(subCategoryQuestionsSaveDto.getQuestion(), result.getQuestion());
        assertEquals(subCategoryQuestionsSaveDto.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryQuestionsSaveDto.getIsDocumentAvailable(), result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToSubCategoryQuestionsSaveDto_withValidInput() {
        SubCategoryQuestionsSaveDto result = subCategoryQuestionsConverter.convertToSubCategoryQuestionsSaveDto(subCategoryQuestions);

        assertNotNull(result);
        assertEquals(subCategoryQuestions.getId(), result.getId());
        assertEquals(subCategoryQuestions.getHeading(), result.getHeading());
        assertEquals(subCategoryQuestions.getQuestion(), result.getQuestion());
        assertEquals(subCategoryQuestions.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryQuestions.getIsDocumentAvailable(), result.getIsDocumentAvailable());
    }

    @Test
    void convertToUpdate_withValidInput() {
        when(subCategoryQuestionRepository.findById(subCategoryQuestionsSaveDto.getId()))
                .thenReturn(Optional.of(subCategoryQuestions));

        SubCategoryQuestions result = subCategoryQuestionsConverter.convertToUpdate(subCategoryQuestionsSaveDto, "2");

        assertNotNull(result);
        assertEquals(subCategoryQuestionsSaveDto.getQuestion(), result.getQuestion());
        assertEquals(subCategoryQuestionsSaveDto.getHeading(), result.getHeading());
        assertEquals("2", result.getComplianceSubCategoryId());
        assertEquals(subCategoryQuestionsSaveDto.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryQuestionsSaveDto.getIsDocumentAvailable(), result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToUpdate_withInvalidId() {
        when(subCategoryQuestionRepository.findById(subCategoryQuestionsSaveDto.getId()))
                .thenReturn(Optional.empty());

        ServiceException exception = assertThrows(ServiceException.class, () ->
                subCategoryQuestionsConverter.convertToUpdate(subCategoryQuestionsSaveDto, "2"));

        assertEquals("Sub category question id not found for id: 1", exception.getMessage());

        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }

    @Test
    void convertToQuestionHeadingDto_withValidInput() {
        QuestionHeadingDto result = subCategoryQuestionsConverter.convertToQuestionHeadingDto(subCategoryQuestions);

        assertNotNull(result);
        assertEquals(subCategoryQuestions.getId(), result.getId());
        assertEquals(subCategoryQuestions.getQuestion(), result.getQuestion());
        assertEquals(subCategoryQuestions.getIsCommentAvailable(), result.getIsCommentAvailable());
        assertEquals(subCategoryQuestions.getIsDocumentAvailable(), result.getIsDocumentAvailable());
    }

    @Test
    void convertToEntity_withNullValues() {
        SubCategoryQuestionsSaveDto nullDto = SubCategoryQuestionsSaveDto.builder()
                .id(null)
                .heading(null)
                .question(null)
                .isCommentAvailable(null)
                .isDocumentAvailable(null)
                .build();

        SubCategoryQuestions result = subCategoryQuestionsConverter.convertToEntity(nullDto);

        assertNull(result.getHeading());
        assertNull(result.getQuestion());
        assertNull(result.getIsCommentAvailable());
        assertNull(result.getIsDocumentAvailable());
        assertTrue(result.getStatus());
    }

    @Test
    void convertToNew(){
        SubCategoryQuestionsSaveDto dto = SubCategoryQuestionsSaveDto.builder()
                .question("gbr")
                .heading(" f")
                .isCommentAvailable(true)
                .build();
        String complianceSubCategoryId = "ddt";
        assertNotNull(subCategoryQuestionsConverter.convertToNew(dto,complianceSubCategoryId));
    }
}
