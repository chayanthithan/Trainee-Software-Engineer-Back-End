package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceAgent;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceControllerTest {

    @Mock
    private ComplianceAgent complianceAgent;

    @InjectMocks
    private ComplianceController complianceController;

    @Test
    void addOrRemoveComplianceForBusiness() {
        ComplianceConfigurationsDto complianceConfigurationsDto = new ComplianceConfigurationsDto();
        assertDoesNotThrow(() -> complianceController.addOrRemoveComplianceForBusiness(complianceConfigurationsDto));
    }

    @Test
    void getAllAvailableCompliance() {
        String businessId="51d08357-9c4f-4d6c-a391-89db99edfff8";
        Mockito.when(complianceAgent.getAllAvailableCompliance(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(complianceController.getAllAvailableCompliance(businessId));
    }
}