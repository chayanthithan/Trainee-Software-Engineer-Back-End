package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CompliantOverViewDto;
import com.codelantic.ebos.compliance.management.api.dto.VisitorOverviewDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.VisitingTypeRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CompliantOverViewConverterTest {
    @Mock
    private UserManagementClient userManagementClient;

    @InjectMocks
    private CompliantOverViewConverter compliantOverViewConverter; // The class where convertToDto is defined

    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;
    @Mock
    VisitingTypeRepository visitingTypeRepository;
    @Test
    void testConvertToDto() {
        CompliantReading compliantReading = new CompliantReading();
        compliantReading.setId("1");
        compliantReading.setDate(LocalDate.of(2023,10,02));
        compliantReading.setTime(LocalTime.now());
        compliantReading.setFullName("John Doe");
        compliantReading.setCompliantType("TypeA");
        compliantReading.setDescription("Description of the compliant");
        compliantReading.setComments("Comments on the compliant");
        compliantReading.setComplianceStatus(ComplianceStatus.APPROVED);

        compliantReading.setCreatedBy("user123");
        UserName createdByUser = new UserName();
        createdByUser.setName("John Creator");

        Set<NotifyTo> notifyToList=new HashSet<>();
        NotifyTo notifyTo=NotifyTo.builder().userId("user456").build();
        notifyToList.add(notifyTo);

        UserName notifyUser1 = new UserName();
        notifyUser1.setName("User 456");

        UserName notifyUser2 = new UserName();
        notifyUser2.setName("User 789");

        compliantReading.setNotifyTo(notifyToList);

        Documents doc1 = new Documents();
        doc1.setImageName("image1.png");
        doc1.setImagePath("/path/image1.png");

        Documents doc2 = new Documents();
        doc2.setImageName("image2.png");
        doc2.setImagePath("/path/image2.png");

        Set<Documents> documents=new HashSet<>();
        documents.add(doc1);
        documents.add(doc2);

        compliantReading.setDocuments(documents);

        Description desc1 = new Description();
        desc1.setAudioName("audio1.mp3");
        desc1.setAudioPath("/path/audio1.mp3");

        Description desc2 = new Description();
        desc2.setAudioName("audio2.mp3");
        desc2.setAudioPath("/path/audio2.mp3");

        Set<Description> descriptions=new HashSet<>();
        descriptions.add(desc1);
        descriptions.add(desc2);

        compliantReading.setDescriptions(descriptions);

        when(userManagementClient.getUserNameById("user123")).thenReturn(createdByUser);
        when(userManagementClient.getUserNameById("user456")).thenReturn(notifyUser1);

        CompliantOverViewDto resultDto = compliantOverViewConverter.convertToDto(compliantReading);

        assertNotNull(resultDto);
        assertEquals("1", resultDto.getId());
        assertEquals("John Doe", resultDto.getFullName());
        assertEquals("TypeA", resultDto.getCompliantType());
        assertEquals("Description of the compliant", resultDto.getDescription());
        assertEquals("Comments on the compliant", resultDto.getComments());
        assertEquals("John Creator", resultDto.getEmployeeName());
    }

    @Test
    void convertToVisitorDto_AllFieldsPopulated() {
        // Arrange
        VisitorReading visitorReading = new VisitorReading();
        visitorReading.setId("1");
        visitorReading.setDate(LocalDate.now());
        visitorReading.setTime(LocalTime.now());
        visitorReading.setFullName("Jane Doe");
        visitorReading.setVisitType("Type B");
        visitorReading.setDescription("Visitor Description");
        visitorReading.setComments("Visitor Comments");
        visitorReading.setCreatedBy("user1");
        visitorReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        Documents document = new Documents();
        document.setImageName("visitor_image.jpg");
        document.setImagePath("/path/to/visitor_image.jpg");
        // Set a Set of documents
        visitorReading.setDocuments(Set.of(document));

        NotifyTo notifyTo = new NotifyTo();
        notifyTo.setUserId("user2");
        // Set a Set of notifyTo
        visitorReading.setNotifyTo(Set.of(notifyTo));

        Description description = new Description();
        description.setAudioName("visitor_audio.mp3");
        description.setAudioPath("/path/to/visitor_audio.mp3");
        // Set a Set of descriptions
        visitorReading.setDescriptions(Set.of(description));

        when(userManagementClient.getUserNameById("user1")).thenReturn(new UserName());
        when(userManagementClient.getUserNameById("user2")).thenReturn(new UserName());

        // Act
        VisitorOverviewDto result = compliantOverViewConverter.convertToVisitorDto(visitorReading);

        // Assert
        assertNotNull(result);
    }

    @Test
    void convertToVisitorDto_NullFields() {
        // Arrange
        VisitorReading visitorReading = new VisitorReading();
        visitorReading.setId("1");
        visitorReading.setDate(LocalDate.now());
        visitorReading.setTime(LocalTime.now());
        visitorReading.setFullName("Jane Doe");
        visitorReading.setVisitType("Type B");
        visitorReading.setDescription("Visitor Description");
        visitorReading.setComments("Visitor Comments");
        visitorReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        // Act
        VisitorOverviewDto result = compliantOverViewConverter.convertToVisitorDto(visitorReading);

        // Assert
        assertNotNull(result);

    }

}