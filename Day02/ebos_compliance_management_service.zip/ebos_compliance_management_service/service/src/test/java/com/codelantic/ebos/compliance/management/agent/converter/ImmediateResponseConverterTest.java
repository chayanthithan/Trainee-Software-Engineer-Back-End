package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ImmediateResponseDto;
import com.codelantic.ebos.compliance.management.entity.ImmediateResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;

import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class ImmediateResponseConverterTest {
@InjectMocks
    ImmediateResponseConverter immediateResponseConverter;

    @Test
    void convert() {
        assertNotNull(immediateResponseConverter.convert(new ImmediateResponseDto()));
    }

    @Test
    void convertImmediateResponseDto(){
        assertNotNull(immediateResponseConverter.convert(new ImmediateResponse()));
    }
}