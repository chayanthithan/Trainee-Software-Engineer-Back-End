package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.VisitorAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VisitorControllerTest {

    @Mock
    private VisitorAgent visitorAgent;

    @InjectMocks
    private VisitorController visitorControllerTest;

    @Test
    void saveVisitType() {
        VisitTypeDto visitTypeDto = new VisitTypeDto("id", "type");
        when(visitorAgent.addNewVisitorType(visitTypeDto)).thenReturn(ResponseDto.builder().build());
        assertNotNull(visitorControllerTest.saveVisitType(visitTypeDto));
    }

    @Test
    void getAllVisitTypeByBusinessId() {
        String businessId = "businessId";
        VisitTypeDto visitTypeDto = new VisitTypeDto("id", "type");
        when(visitorAgent.getAllVisitTypeByBusinessId(businessId)).thenReturn(List.of(visitTypeDto));
        assertNotNull(visitorControllerTest.getAllVisitTypeByBusinessId(businessId));

    }

    @Test
    void testGetVistorOverview() {
        // Arrange
        String businessId = "business123";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        LocalDate toDate = LocalDate.of(2023, 12, 31);
        String employeeId = "employee123";
        String complianceStatus = "COMPLIANT";
        Integer page = 1;
        Integer size = 10;

        PaginatedResponseDto<VisitorOverviewDto> mockResponse = new PaginatedResponseDto<>();
        when(visitorAgent.getVistorOverview(any(VisitorSearchDto.class))).thenReturn(mockResponse);

        // Act
        PaginatedResponseDto<VisitorOverviewDto> result = visitorControllerTest.getVistorOverview(
                "1",businessId, fromDate, toDate, employeeId, complianceStatus, page, size);

        // Assert
        assertNotNull(result);
        assertEquals(mockResponse, result);


    }

    @Test
    void getRowVisitor() {
        when(visitorAgent.getRowVisitor("1")).thenReturn(new VisitorOverviewDto());
        assertNotNull(visitorControllerTest.getRowVisitor("1"));
    }
}