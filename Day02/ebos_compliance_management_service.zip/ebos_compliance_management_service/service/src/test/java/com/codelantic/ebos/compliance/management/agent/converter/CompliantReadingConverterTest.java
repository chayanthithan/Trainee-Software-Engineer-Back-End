package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.CompliantReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.DescriptionDto;
import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.api.dto.NotifyToDto;
import com.codelantic.ebos.compliance.management.entity.CompliantReading;
import com.codelantic.ebos.compliance.management.entity.NotifyTo;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertNotNull;
@ExtendWith(MockitoExtension.class)
class CompliantReadingConverterTest {

    @InjectMocks
    CompliantReadingConverter converter;

    @Mock
    DocumentsConverter documentsConverter;

    @Mock
    NotifyToConverter notifyToConverter;

    @Mock
    DescriptionConverter descriptionConverter;

    @Test
    void convert() {
        AuthenticationContextHolder.setContext(Authentication.builder().userId("userId").build());
        CompliantReadingDto compliantReadingDto= new CompliantReadingDto();

        Set<DocumentsDto> documents= new HashSet<>();
        compliantReadingDto.setDocuments(documents);

        Set<NotifyToDto> notifyTo= new HashSet<>();
        compliantReadingDto.setNotifyTo(notifyTo);

        Set<DescriptionDto> description= new HashSet<>();
        compliantReadingDto.setDescriptions(description);

        assertNotNull(converter.convert(compliantReadingDto));
    }

    @Test
    void convert2() {
        CompliantReading compliantReading = new CompliantReading();
        compliantReading.setDocuments(new HashSet<>());

        Set<NotifyTo> notifyTo=new HashSet<>();
        compliantReading.setNotifyTo(notifyTo);
        compliantReading.setDescriptions(new HashSet<>());
        compliantReading.setComplianceStatus(ComplianceStatus.APPROVED);
        assertNotNull(converter.convert(compliantReading));
    }

    @Test
    void updateConvert(){
        CompliantReading compliantReading = new CompliantReading();

        compliantReading.setDocuments(new HashSet<>());
        compliantReading.setNotifyTo(new HashSet<>());
        compliantReading.setDescriptions(new HashSet<>());

        compliantReading.setComplianceStatus(ComplianceStatus.APPROVED);


        CompliantReadingDto compliantReadingDto= new CompliantReadingDto();
        compliantReadingDto.setDocuments(new HashSet<>());
        compliantReadingDto.setNotifyTo(new HashSet<>());
        compliantReadingDto.setDescriptions(new HashSet<>());


        converter.updateConvert(compliantReading,compliantReadingDto);
        assertNotNull(compliantReadingDto.getDocuments());
    }
}