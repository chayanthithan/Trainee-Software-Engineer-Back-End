package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceSubCategoryConverter;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import com.codelantic.ebos.compliance.management.service.ComplianceSubCategoryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceSubCategoryAgentTest {

    @InjectMocks
    ComplianceSubCategoryAgent complianceSubCategoryAgent;

    @Mock
    ComplianceSubCategoryService complianceSubCategoryService;

    @Mock
    ComplianceSubCategoryConverter complianceSubCategoryConverter;


    @Test
    void saveComplianceSubCategory() {
        ComplianceSubCategorySaveDto complianceSubCategorySaveDto= new ComplianceSubCategorySaveDto();
        Mockito.when(complianceSubCategoryService.saveComplianceSubCategory(complianceSubCategorySaveDto)).thenReturn(new ResponseDto());
        assertNotNull(complianceSubCategoryAgent.saveComplianceSubCategory(complianceSubCategorySaveDto));
    }

    @Test
    void getSubCategories() {
        Integer complianceId=1;
        StringBuilder bId= new StringBuilder("id");

        Mockito.when(complianceSubCategoryService.getSubCategories(complianceId,bId.toString())).thenReturn(new ArrayList<>());
        assertNotNull(complianceSubCategoryAgent.getSubCategories(complianceId,bId.toString()));
    }

    @Test
    void updateSubCategoryStatus() {
        StringBuilder subCategoryId=new StringBuilder("id");
        Boolean status=Boolean.TRUE;

        Mockito.when(complianceSubCategoryService.updateSubCategoryStatus(subCategoryId.toString(),status)).thenReturn(new ResponseDto());
        assertNotNull(complianceSubCategoryAgent.updateSubCategoryStatus(subCategoryId.toString(),status));
    }

    @Test
    void getCheckListAndQuestion(){
        StringBuilder complianceSubCategoryId=new StringBuilder("1");
        ComplianceSubCategory complianceSubCategory=ComplianceSubCategory.builder().id(complianceSubCategoryId.toString()).build();
        Mockito.when(complianceSubCategoryService.getCheckListAndQuestion(complianceSubCategoryId.toString())).thenReturn(complianceSubCategory);
        GetCheckListQuestionDto getCheckListQuestionDto=GetCheckListQuestionDto.builder().build();
        Mockito.when(complianceSubCategoryConverter.convertToCheckListQuestionDto(complianceSubCategory)).thenReturn(getCheckListQuestionDto);
        assertNotNull(complianceSubCategoryAgent.getCheckListAndQuestion(complianceSubCategoryId.toString()));
    }

    @Test
    void getAllByComplianceTypeId(){
        Integer complianceId =1;
        Mockito.when(complianceSubCategoryService.getAllByComplianceTypeId(complianceId)).thenReturn(new ArrayList<>());
        assertNotNull(complianceSubCategoryAgent.getAllByComplianceTypeId(complianceId));
    }

    @Test
    void getById(){
        StringBuilder subCategoryId=new StringBuilder("1");
        ComplianceSubCategory complianceSubCategory=new ComplianceSubCategory();
        complianceSubCategory.setId(subCategoryId.toString());
        Mockito.when(complianceSubCategoryService.getById(subCategoryId.toString())).thenReturn(complianceSubCategory);
        ComplianceSubCategoryResponseDto complianceSubCategoryResponseDto=ComplianceSubCategoryResponseDto.builder().build();
        Mockito.when(complianceSubCategoryConverter.convert(complianceSubCategory)).thenReturn(complianceSubCategoryResponseDto);
        assertNotNull(complianceSubCategoryAgent.getById(subCategoryId.toString()));
    }

    @Test
    void updateComplianceSubCategory(){
        ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto=new ComplianceSubCategoryUpdateDto();
        ComplianceSubCategory complianceSubCategory=new ComplianceSubCategory();
        Mockito.when(complianceSubCategoryConverter.convertForUpdate(complianceSubCategoryUpdateDto)).thenReturn(complianceSubCategory);
        ResponseDto responseDto=new ResponseDto();
        Mockito.when(complianceSubCategoryService.updateComplianceSubCategory(complianceSubCategory)).thenReturn(responseDto);
        assertNotNull(complianceSubCategoryAgent.updateComplianceSubCategory(complianceSubCategoryUpdateDto));

    }
}