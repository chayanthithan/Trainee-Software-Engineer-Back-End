package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.IncidentAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IncidentControllerTest {

    @InjectMocks
    IncidentController incidentController;

    @Mock
    IncidentAgent incidentAgent;

    @Test
    void saveIncident() {
        TypeOfIncidentDto typeOfIncidentDto = new TypeOfIncidentDto();
        typeOfIncidentDto.setId("1");
        when(incidentAgent.saveTypeOfIncident(typeOfIncidentDto)).thenReturn(new ResponseDto());
        assertNotNull(incidentController.saveTypeOfIncident(typeOfIncidentDto));
    }

    @Test
    void getAllTypeOfIncidents() {
        String businessId = "1";
        when(incidentAgent.getAllTypeOfIncidents(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentController.getAllTypeOfIncidents(businessId));
    }

    @Test
    void saveDepatment() {

        when(incidentAgent.saveDepartment(new DepartmentDto())).thenReturn(new ResponseDto());
        assertNotNull(incidentController.saveDepartment(new DepartmentDto()));
    }

    @Test
    void getAllDepartment() {
        String businessId = "1";
        when(incidentAgent.getAllDepartment(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentController.getAllDepartment(businessId));
    }

    @Test
    void saveLocation() {
        LocationDto locationDto = new LocationDto();
        locationDto.setId("1");
        when(incidentAgent.saveLocation(locationDto)).thenReturn(new ResponseDto());
        assertNotNull(incidentController.saveLocation(locationDto));
    }

    @Test
    void getAllLocation() {
        String businessId = "1";
        when(incidentAgent.getAllLocation(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentController.getAllLocation(businessId));
    }

    @Test
    void saveSeverity() {
        SeverityDto severityDto = new SeverityDto();
        severityDto.setId("1");
        when(incidentAgent.saveSeverity(severityDto)).thenReturn(new ResponseDto());
        assertNotNull(incidentController.saveSeverity(severityDto));
    }

    @Test
    void getAllSeverities() {
        String businessId = "1";
        when(incidentAgent.getAllSeverities(businessId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentController.getAllSeverities(businessId));
    }

    @Test
    void getAllConfiguredField() {
        String complianceSubCategoryId = "1";
        when(incidentAgent.getAllConfiguredField(complianceSubCategoryId)).thenReturn(new ArrayList<>());
        assertNotNull(incidentController.getAllConfiguredField(complianceSubCategoryId));
    }

    @Test
    void getAllIncidentOverview() {
        StringBuilder subCategoryId = new StringBuilder("1");
        StringBuilder complianceStatus = new StringBuilder(ComplianceStatus.UNDER_REVIEW.getMappedValue());
        StringBuilder employeeName = new StringBuilder("mithuja");
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = LocalDate.now();
        int page = 1;
        int size = 10;

        IncidentOverviewSearchDto incidentOverviewSearchDto = IncidentOverviewSearchDto.builder()
                .subCategoryId(subCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .complianceStatus(ComplianceStatus.fromMappedValue(complianceStatus.toString()))
                .employeeName(employeeName.toString())
                .page(page)
                .size(size)
                .build();

        PaginatedResponseDto<IncidentOverviewDto> incidentOverviewDtoPaginatedResponseDto = new PaginatedResponseDto<>();
        when(incidentAgent.getAllIncidentOverview(incidentOverviewSearchDto)).thenReturn(incidentOverviewDtoPaginatedResponseDto);
        assertNotNull(incidentController.getAllIncidentOverview(subCategoryId.toString(), complianceStatus.toString(), employeeName.toString(), fromDate, toDate, page, size));

    }

    @Test
    void getOverViewById() {
        when(incidentAgent.getOverViewById(anyString())).thenReturn(new IncidentOverviewDto());
        assertNotNull(incidentController.getOverViewById("1"));

    }
}
