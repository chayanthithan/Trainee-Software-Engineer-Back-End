package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.ComplianceSubCategoryAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ComplianceSubCategoryControllerTest {

    @InjectMocks
    private ComplianceSubCategoryController complianceSubCategoryController;

    @Mock
    private ComplianceSubCategoryAgent complianceSubCategoryAgent;


    @Test
    void saveComplianceSubCategory() {
        ComplianceSubCategorySaveDto complianceSubCategorySaveDto= new ComplianceSubCategorySaveDto();
        Mockito.when(complianceSubCategoryAgent.saveComplianceSubCategory(complianceSubCategorySaveDto)).thenReturn(new ResponseDto());
        assertNotNull(complianceSubCategoryController.saveComplianceSubCategory(complianceSubCategorySaveDto));
    }

    @Test
    void getSubCategories() {
        Integer complianceId=1;
        StringBuilder bId= new StringBuilder("id");

        Mockito.when(complianceSubCategoryAgent.getSubCategories(complianceId,bId.toString())).thenReturn(new ArrayList<>());
        assertNotNull(complianceSubCategoryController.getSubCategories(complianceId,bId.toString()));
    }


    @Test
    void updateSubCategoryStatus() {
        StringBuilder subCategoryId=new StringBuilder("id");
        Boolean status=Boolean.TRUE;
        Mockito.when(complianceSubCategoryAgent.updateSubCategoryStatus(subCategoryId.toString(),status)).thenReturn(new ResponseDto());
        assertNotNull(complianceSubCategoryController.updateSubCategoryStatus(subCategoryId.toString(),status));
    }

    @Test
    void getCheckListAndQuestion(){
        GetCheckListQuestionDto getCheckListQuestionDto=GetCheckListQuestionDto.builder().build();
        StringBuilder complianceSubCategoryId=new StringBuilder("1");
        Mockito.when(complianceSubCategoryAgent.getCheckListAndQuestion(complianceSubCategoryId.toString())).thenReturn(getCheckListQuestionDto);
        assertNotNull(complianceSubCategoryController.getCheckListAndQuestion(complianceSubCategoryId.toString()));

    }

    @Test
    void getAllByComplianceTypeId(){
        Integer complianceId =1;
        Mockito.when(complianceSubCategoryAgent.getAllByComplianceTypeId(complianceId)).thenReturn(new ArrayList<>());
        assertNotNull(complianceSubCategoryController.getAllByComplianceTypeId(complianceId));
    }

    @Test
    void getById() {

        Mockito.when(complianceSubCategoryAgent.getById("1")).thenReturn(ComplianceSubCategoryResponseDto.builder().build());
        assertNotNull(complianceSubCategoryController.getById("1"));
    }

    @Test
    void updateComplianceSubCategory() {
        ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto = new ComplianceSubCategoryUpdateDto();
        Mockito.when(complianceSubCategoryAgent.updateComplianceSubCategory(complianceSubCategoryUpdateDto)).thenReturn(new ResponseDto());
        assertNotNull(complianceSubCategoryController.updateComplianceSubCategory(complianceSubCategoryUpdateDto));
    }

}