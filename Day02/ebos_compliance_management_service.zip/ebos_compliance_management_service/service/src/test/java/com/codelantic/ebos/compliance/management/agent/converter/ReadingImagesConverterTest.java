package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ReadingImagesDto;
import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ReadingImagesConverterTest {

    @InjectMocks
    ReadingImagesConverter readingImagesConverter;


    @Test
    void convert() {
        ReadingImagesDto readingImagesDto = ReadingImagesDto.builder().build();
        assertNotNull(readingImagesConverter.convert(readingImagesDto));
    }

    @Test
    void convertt() {

        assertNotNull(readingImagesConverter.convert(new ReadingImages()));
    }
}