package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ComplianceConfigurationsDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ComplianceConverterTest {
    @InjectMocks
    ComplianceConverter complianceConverter;

    @Test
    void convertToBusinessComplianceEntity() {
        assertNotNull(complianceConverter.convertToBusinessComplianceEntity(new ComplianceConfigurationsDto()));
    }
}