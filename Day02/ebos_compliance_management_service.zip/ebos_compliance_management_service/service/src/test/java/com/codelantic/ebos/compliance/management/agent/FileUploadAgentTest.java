package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.DeleteImageDto;
import com.codelantic.ebos.compliance.management.api.dto.ImageDetailDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.UploadDocumentsDto;
import com.codelantic.ebos.compliance.management.service.FileUploadServices;
import com.jcraft.jsch.JSchException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FileUploadAgentTest {

    @InjectMocks
    FileUploadAgent fileUploadAgent;

    @Mock
    FileUploadServices fileUploadService;

    @Test
    void uploadDocuments_success() throws JSchException {
        // Arrange
        UploadDocumentsDto uploadDocumentsDto = UploadDocumentsDto.builder().build();
        List<MultipartFile> files = new ArrayList<>();
        String audioOrImage = "IMAGE";
        ImageDetailDto imageDetailDto = new ImageDetailDto();

        when(fileUploadService.uploadDocuments(uploadDocumentsDto, files, audioOrImage))
                .thenReturn(imageDetailDto);

        // Act
        ImageDetailDto result = fileUploadAgent.uploadDocuments(uploadDocumentsDto, files, audioOrImage);

        // Assert
        assertNotNull(result);
        Mockito.verify(fileUploadService).uploadDocuments(uploadDocumentsDto, files, audioOrImage);
    }

    @Test
    void uploadDocuments_throwsJSchException() throws JSchException {
        // Arrange
        UploadDocumentsDto uploadDocumentsDto = UploadDocumentsDto.builder().build();
        List<MultipartFile> files = new ArrayList<>();
        String audioOrImage = "IMAGE";

        when(fileUploadService.uploadDocuments(uploadDocumentsDto, files, audioOrImage))
                .thenThrow(new JSchException("Connection error"));

        // Act & Assert
        JSchException exception = assertThrows(JSchException.class,
                () -> fileUploadAgent.uploadDocuments(uploadDocumentsDto, files, audioOrImage));

        assertEquals("Connection error", exception.getMessage());
    }

    @Test
    void deleteImage_success() {
        // Arrange
        List<DeleteImageDto> deleteImageDtos = new ArrayList<>();
        deleteImageDtos.add(new DeleteImageDto());
        String saveOrUpdate = "SAVE";
        ResponseDto responseDto = new ResponseDto();

        when(fileUploadService.delete(deleteImageDtos, saveOrUpdate))
                .thenReturn(responseDto);

        ResponseDto result = fileUploadAgent.deleteImage(deleteImageDtos, saveOrUpdate);
        assertNotNull(result);
        Mockito.verify(fileUploadService).delete(deleteImageDtos, saveOrUpdate);
    }
    @Test
    void downloadDocument() throws IOException {
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(HttpStatus.OK);
        when(fileUploadService.downloadDocument(Collections.singletonList("documentUrl"))).thenReturn(responseEntity );
        assertNotNull(fileUploadAgent.downloadDocument(Collections.singletonList("documentUrl")));
    }

    @Test
    void testDownloadSingleDocument_Success() throws IOException, JSchException {
        // Arrange
        String documentUrl = "testDirectory/testDocument.pdf";
        byte[] mockFileData = "Mock file content".getBytes();

        // Define expected response with headers and mock file data
        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment().filename("testDocument.pdf").build());
        ResponseEntity<byte[]> mockResponse = new ResponseEntity<>(mockFileData, headers, HttpStatus.OK);

        // Mock the fileUploadService's downloadSingleDocument method
        when(fileUploadService.downloadSingleDocument(documentUrl)).thenReturn(mockResponse);

        // Act
        ResponseEntity<byte[]> response = fileUploadAgent.downloadSingleDocument(documentUrl);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }
}
