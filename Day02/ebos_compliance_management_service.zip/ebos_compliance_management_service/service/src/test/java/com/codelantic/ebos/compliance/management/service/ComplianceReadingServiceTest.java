package com.codelantic.ebos.compliance.management.service;

import com.codelantic.ebos.compliance.management.agent.converter.ComplianceReadingConverter;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ComplianceReadingGetDto;
import com.codelantic.ebos.compliance.management.api.dto.ResponseDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceCategory;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ComplianceReadingServiceTest {

    @InjectMocks
    ComplianceReadingService complianceReadingService;

    @Mock
    ComplianceReadingConverter complianceReadingConverter;

    @Mock
    ComplianceReadingRepository complianceReadingRepository;
    @Mock
    UserManagementClient userManagementClient;
    @Mock
    ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Test
    void save() {
        ComplianceReadingDto complianceReadingDto = new ComplianceReadingDto();
        Mockito.when(complianceSubCategoryRepository.existsById(complianceReadingDto.getComplianceSubCategoryId())).thenReturn(Boolean.TRUE);
        assertNotNull(complianceReadingService.save(complianceReadingDto));

    }

    @Test
    void update() {

        ComplianceReadingDto complianceReadingDto = ComplianceReadingDto.builder()
                .id("some-valid-id")
                .businessId("1")
                .build();
        ComplianceReading existingReading = new ComplianceReading();
        existingReading.setId("some-valid-id");
        Mockito.when(complianceReadingRepository.findById(complianceReadingDto.getId()))
                .thenReturn(Optional.of(existingReading));
        Mockito.doNothing().when(complianceReadingConverter).updateConvert(existingReading, complianceReadingDto);
        Mockito.when(complianceReadingRepository.save(existingReading)).thenReturn(existingReading);
        ResponseDto response = complianceReadingService.update(complianceReadingDto);
        assertNotNull(response);
        verify(complianceReadingRepository).save(existingReading);
        verify(complianceReadingConverter).updateConvert(existingReading, complianceReadingDto);

    }

    @Test
    void getById() {
        ComplianceReading reading = new ComplianceReading();
        reading.setCreatedBy("id");
        String userName = "name";

        UserName userName1 = new UserName();
        userName1.setName("name");

        Mockito.when(complianceReadingRepository.findById("1")).thenReturn(Optional.of(reading));
        when(userManagementClient.getUserNameById(reading.getCreatedBy())).thenReturn(userName1);
        Mockito.when(complianceReadingConverter.convertToDto(reading,userName)).thenReturn(new ComplianceReadingGetDto());
        assertNotNull(complianceReadingService.getById("1", ComplianceCategory.CLEANING));
    }
}