package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.codelantic.ebos.compliance.management.repository.ComplianceReadingRepository;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureReadingRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureTypeRangeRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TemperatureConverterTest {

    @InjectMocks
    TemperatureConverter temperatureConverter;
    @Mock
    ComplianceSubCategoryRepository complianceSubCategoryRepository;
    @Mock
    UserManagementClient userManagementClient;
    @Mock
    TemperatureReadingRepository temperatureReadingRepository;
    @Mock
    ComplianceReadingRepository complianceReadingRepository;
    @Mock
    TemperatureReadingConverter temperatureReadingConverter;
    @Mock
    TemperatureTypeRangeRepository temperatureTypeRangeRepository;

    @Test
    void convert() {
        TemperatureTypeRangeDto temperatureTypeRangeDto = new TemperatureTypeRangeDto();
        temperatureTypeRangeDto.setId("1");
        temperatureTypeRangeDto.setTemperatureType("Cool");
        temperatureTypeRangeDto.setStartTemperature("0");
        temperatureTypeRangeDto.setEndTemperature("100");
        temperatureTypeRangeDto.setStatus(Boolean.TRUE);
        temperatureTypeRangeDto.setComplianceSubCategoryId("1");

        TemperatureTypeRange result = temperatureConverter.convert(temperatureTypeRangeDto);

        assertNotNull(result);
        assertEquals("1", result.getId());
        assertEquals("Cool", result.getTemperatureType().getMappedValue());
        assertEquals("0", result.getStartTemperature());
        assertEquals("100", result.getEndTemperature());
        assertTrue(result.getStatus());
        assertEquals("1", result.getComplianceSubCategoryId());
    }

    @Test
    void testConvertToDto() {
        TemperatureTypeRange temperatureTypeRange = new TemperatureTypeRange();
        temperatureTypeRange.setId("1");
        temperatureTypeRange.setTemperatureType(TemperatureType.fromMappedValue("Cool"));
        temperatureTypeRange.setStartTemperature("0");
        temperatureTypeRange.setEndTemperature("100");
        temperatureTypeRange.setStatus(Boolean.TRUE);
        temperatureTypeRange.setComplianceSubCategoryId("1");

        TemperatureTypeRangeDto dto = temperatureConverter.convertToDto(temperatureTypeRange);

        assertNotNull(dto);
        assertEquals("1", dto.getId());
        assertEquals("Cool", dto.getTemperatureType());
        assertEquals("0", dto.getStartTemperature());
        assertEquals("100", dto.getEndTemperature());
        assertTrue(dto.getStatus());
        assertEquals("1", dto.getComplianceSubCategoryId());
    }

    @Test
    void testConvert_WithValidInput() {
        TemperatureSaveDto temperatureSaveDto = new TemperatureSaveDto();
        temperatureSaveDto.setIsRequiredQuantityBasedTemperatureReading(true);

        TemperatureTypeRangeConfigurationDto config1 = TemperatureTypeRangeConfigurationDto.builder()
                .id("1L")
                .items("gsgs")
                .temperatureTypeRangeId("100L")
                .build();

        TemperatureTypeRangeConfigurationDto config2 = TemperatureTypeRangeConfigurationDto.builder()
                .id("2L")
                .items("dgjfjgdj")
                .temperatureTypeRangeId("200L")
                .build();

        Set<TemperatureTypeRangeConfigurationDto> configSet = new HashSet<>();
        configSet.add(config1);
        configSet.add(config2);
        temperatureSaveDto.setTemperatureTypeRangeConfigurationDtos(configSet);

        TemperatureConfigurations result = temperatureConverter.convert(temperatureSaveDto);

        assertNotNull(result);
        assertTrue(result.getIsRequiredQuantityBasedTempReading());

        Set<TemperatureTypeRangeConfigurations> configurations = result.getTemperatureTypeRangeConfigurations();
        assertEquals(2, configurations.size());

        for (TemperatureTypeRangeConfigurations config : configurations) {
            TemperatureTypeRangeConfigurationDto originalDto = temperatureSaveDto.getTemperatureTypeRangeConfigurationDtos().stream()
                    .filter(dto -> dto.getId().equals(config.getId()))
                    .findFirst()
                    .orElse(null);

            assertNotNull(originalDto);
            assertEquals(originalDto.getId(), config.getId());
            assertEquals(originalDto.getItems(), config.getItems());
            assertTrue(config.getStatus());
            assertEquals(originalDto.getTemperatureTypeRangeId(), config.getTemperatureTypeRangeId());
        }
    }

    @Test
    void testConvertTemperatureConfigurations() {
        TemperatureSaveDto temperatureSaveDto = new TemperatureSaveDto();
        temperatureSaveDto.setIsRequiredQuantityBasedTemperatureReading(true);

        TemperatureTypeRangeConfigurationDto config1 = TemperatureTypeRangeConfigurationDto.builder()
                .id("1L")
                .items("gsgs")
                .temperatureTypeRangeId("100L")
                .build();

        Set<TemperatureTypeRangeConfigurationDto> configSet = new HashSet<>();
        configSet.add(config1);
        temperatureSaveDto.setTemperatureTypeRangeConfigurationDtos(configSet);

        TemperatureConfigurations result = temperatureConverter.convert(temperatureSaveDto);
        assertNotNull(result);
        assertTrue(result.getIsRequiredQuantityBasedTempReading());
        assertEquals(1, result.getTemperatureTypeRangeConfigurations().size());
    }

    @Test
    void testConvertTemperatureConfigurationsDto() {
        TemperatureConfigurations temperatureConfigurations = new TemperatureConfigurations();
        temperatureConfigurations.setId("1L");
        temperatureConfigurations.setIsRequiredQuantityBasedTempReading(true);

        TemperatureTypeRangeConfigurations tempConfig = new TemperatureTypeRangeConfigurations();
        tempConfig.setId("1L");
        tempConfig.setTemperatureConfigurationsId("1L");
        tempConfig.setItems("Item1");
        tempConfig.setStatus(true);
        tempConfig.setTemperatureTypeRangeId("100L");

        Set<TemperatureTypeRangeConfigurations> tempConfigSet = new HashSet<>();
        tempConfigSet.add(tempConfig);
        temperatureConfigurations.setTemperatureTypeRangeConfigurations(tempConfigSet);

        when(temperatureTypeRangeRepository.findById("100L")).thenReturn(Optional.of(new TemperatureTypeRange()));

        TemperatureConfigurationsDto dto = temperatureConverter.convert(temperatureConfigurations);

        assertNotNull(dto);
        assertEquals("1L", dto.getId());
        assertTrue(dto.getIsRequiredQuantityBasedTempReading());
        assertEquals(1, dto.getTemperatureTypeRangeConfigurations().size());
    }

    @Test
    void testConvert_UpdateExistingTemperatureTypeRange() {
        // Arrange
        TemperatureTypeRange existingTemperatureTypeRange = new TemperatureTypeRange();
        existingTemperatureTypeRange.setId("1");
        existingTemperatureTypeRange.setTemperatureType(TemperatureType.fromMappedValue("Warm"));
        existingTemperatureTypeRange.setStartTemperature("10");
        existingTemperatureTypeRange.setEndTemperature("50");

        TemperatureTypeRangeDto newTemperatureTypeRangeDto = new TemperatureTypeRangeDto();
        newTemperatureTypeRangeDto.setId("1");
        newTemperatureTypeRangeDto.setTemperatureType("Cool");
        newTemperatureTypeRangeDto.setStartTemperature("5");
        newTemperatureTypeRangeDto.setEndTemperature("45");

        // Act
        temperatureConverter.convert(existingTemperatureTypeRange, newTemperatureTypeRangeDto);

        // Assert
        assertEquals("1", existingTemperatureTypeRange.getId());
        assertEquals("Cool", existingTemperatureTypeRange.getTemperatureType().getMappedValue());
        assertEquals("5", existingTemperatureTypeRange.getStartTemperature());
        assertEquals("45", existingTemperatureTypeRange.getEndTemperature());
    }

    @Test
    void testConvert_ListOfTemperatureTypeRangeDtos() {
        // Arrange
        TemperatureTypeRangeDto dto1 = new TemperatureTypeRangeDto();
        dto1.setId("1");
        dto1.setTemperatureType(TemperatureType.COOL.getMappedValue());
        dto1.setStartTemperature("0");
        dto1.setEndTemperature("10");
        TemperatureTypeRangeDto dto2 = new TemperatureTypeRangeDto();
        dto2.setId("2");
        dto2.setTemperatureType("Warm");
        dto2.setStartTemperature("11");
        dto2.setEndTemperature("20");

        List<TemperatureTypeRangeDto> dtoList = List.of(dto1, dto2);

        // Act
        List<TemperatureTypeRange> result = temperatureConverter.convert(dtoList);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());

    }

    @Test
    void getAllTemperatureOverviewRow() {
        TemperatureReading temperatureReading = new TemperatureReading();
        temperatureReading.setComplianceSubCategoryId("1");
        temperatureReading.setId("1");
        Set<TemperatureReading> tempreatureReadings = new HashSet<>();
        tempreatureReadings.add(temperatureReading);
        ReadingImages readingImages = new ReadingImages();
        readingImages.setImageName("ajith");
        readingImages.setImagePath("/hello");
        readingImages.setImagePath("/download");
        Set<ReadingImages> readingImages1 = new HashSet<>();
        readingImages1.add(readingImages);
        temperatureReading.setReadingImages(readingImages1);
        Set<NotifyTo> notifyToSet = new HashSet<>();
        NotifyTo notifyTo = new NotifyTo();
        notifyTo.setUserId("ajith");
        notifyToSet.add(notifyTo);
        temperatureReading.setNotifyTo(notifyToSet);

        ComplianceReading complianceReading = ComplianceReading.builder()
                .id("some-unique-id")
                .complianceSubCategoryId("subCategory123")
                .createdBy("creatorId123")
                .businessId("businessId456")
                .comments("All compliance checks passed.")
                .checkListReadings(new HashSet<>())
                .subCategoryQuestionsReadings(new HashSet<>())
                .temperatureReadings(tempreatureReadings)
                .date(LocalDate.of(2024, 1, 1))
                .time(LocalTime.of(10, 0))
                .complianceStatus(ComplianceStatus.APPROVED)
                .reviewerComments("Reviewed and approved.")
                .build();
        when(complianceSubCategoryRepository.getNameUsingId(anyString())).thenReturn("ajith");
        when(userManagementClient.getUserNameById(anyString())).thenReturn(new UserName());
        when(temperatureReadingRepository.getTemperatureRowData(anyString(), anyString())).thenReturn(new TemperatureTypeOverviewDto());
        when(userManagementClient.getUserNameById(anyString())).thenReturn(new UserName());
        assertNotNull(temperatureConverter.getAllTemperatureOverviewRow(complianceReading));


    }

    @Test
    void convertToTemperatureOverviewDto(){

        UserName userName = new UserName();
        userName.setName("kamal");
        ReadingImages readingImages = new ReadingImages();
        TemperatureReading temperatureReading = new TemperatureReading();
        temperatureReading.setId("1");
        temperatureReading.setQuantity(4);
        temperatureReading.setReadingImages(Set.of(readingImages));

        TempreatureReadingGetDto tempreatureReadingGetDto = new TempreatureReadingGetDto();
        tempreatureReadingGetDto.setId("1");
        tempreatureReadingGetDto.setQuantity(4);
        tempreatureReadingGetDto.setItem("tewst");
        tempreatureReadingGetDto.setTemperatureType(TemperatureType.COOL.getMappedValue());
        tempreatureReadingGetDto.setActualReading("2");
        tempreatureReadingGetDto.setTemperatureType("Frozen");
        tempreatureReadingGetDto.setReadingImages(Set.of(ReadingImagesDto.builder().build()));
        ComplianceReading complianceReading = new ComplianceReading();
        complianceReading.setComplianceSubCategoryId("1");
        complianceReading.setId("1");
        complianceReading.setCreatedBy("creatorId123");
        complianceReading.setComplianceStatus(ComplianceStatus.APPROVED);
        complianceReading.setTemperatureReadings(Set.of(temperatureReading));
        when(complianceSubCategoryRepository.getNameUsingId(complianceReading.getComplianceSubCategoryId())).thenReturn("ajith");
        when(userManagementClient.getUserNameById(complianceReading.getCreatedBy())).thenReturn(userName);
        when(temperatureReadingConverter.convertTempreature(temperatureReading)).thenReturn(tempreatureReadingGetDto);
        assertNotNull(temperatureConverter.convertToTemperatureOverviewDto(complianceReading));
    }

}
