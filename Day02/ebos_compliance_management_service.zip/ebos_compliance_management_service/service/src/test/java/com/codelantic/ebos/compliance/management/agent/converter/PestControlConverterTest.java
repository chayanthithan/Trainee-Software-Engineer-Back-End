package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TotalCheckedCountDto;
import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.ReadingImages;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestionsReadings;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.CheckListReadingRepository;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PestControlConverterTest {
    @Mock
    private UserManagementClient userManagementClient;
    @Mock
    private CheckListReadingRepository checkListReadingRepository;
    @InjectMocks
    private PestControlConverter pestControlConverter;

    @Test
    void convertFromEntity() {
        Set<ReadingImages> readingImages = new HashSet<>();
        ReadingImages readingImage = new ReadingImages();
        readingImages.add(readingImage);
        CheckListReading checkListReading = new CheckListReading();
        checkListReading.setReadingImages(readingImages);
        Set<CheckListReading> checkListReadings = new HashSet<>();
        checkListReadings.add(checkListReading);
        SubCategoryQuestionsReadings subCategoryQuestionsReadings = new SubCategoryQuestionsReadings();
        subCategoryQuestionsReadings.setReadingImages(readingImages);
        subCategoryQuestionsReadings.setReadingImages(readingImages);
        Set<SubCategoryQuestionsReadings> subCategoryQusetionReadings = new HashSet<>();
        subCategoryQusetionReadings.add(subCategoryQuestionsReadings);
        ComplianceReading complianceReading = ComplianceReading.builder()
                .id("1")
                .date(LocalDate.now())
                .time(LocalTime.now())
                .createdBy("ajith")
                .complianceStatus(ComplianceStatus.APPROVED)
                .checkListReadings(checkListReadings)
                .subCategoryQuestionsReadings(subCategoryQusetionReadings)
                .build();
        when(userManagementClient.getUserNameById(anyString())).thenReturn(new UserName());
        when(checkListReadingRepository.findTotalAndCheckedCountByComplianceReadingId(anyString())).thenReturn(new TotalCheckedCountDto(4L, 5L));
        assertNotNull(pestControlConverter.convertFromEntity(complianceReading, 1));
    }
}