package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.SubCategoryQuestionsReadingsDto;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestionsReadings;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SubCategoryQuestionsReadingsConverterTest {
    @InjectMocks
    SubCategoryQuestionsReadingsConverter subCategoryQuestionsReadingsConverter;
    @Mock
    ReadingImagesConverter readingImagesConverter;
    @Mock
    SubCategoryQuestionRepository subCategoryQuestionRepository;

    @Test
    void convert() {
        SubCategoryQuestionsReadingsDto readingsDto = new SubCategoryQuestionsReadingsDto();
        readingsDto.setReadingImages(new HashSet<>());
        readingsDto.setSubCategoryQuestionsId("88");
        Mockito.when(subCategoryQuestionRepository.findResultForRecord(readingsDto.getSubCategoryQuestionsId())).thenReturn(false);
        assertNotNull(subCategoryQuestionsReadingsConverter.convert(readingsDto));
    }

    @Test
    void convertTo() {
        SubCategoryQuestionsReadings readingsDto = new SubCategoryQuestionsReadings();
        readingsDto.setReadingImages(new HashSet<>());
        assertNotNull(subCategoryQuestionsReadingsConverter.convert(readingsDto));
    }
}