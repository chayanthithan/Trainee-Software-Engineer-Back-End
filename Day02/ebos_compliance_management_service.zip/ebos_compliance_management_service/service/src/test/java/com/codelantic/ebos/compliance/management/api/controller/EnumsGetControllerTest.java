package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.api.dto.DropDownDto;
import com.codelantic.ebos.compliance.management.service.EnumsGetService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class EnumsGetControllerTest {

    @Mock
    private EnumsGetService enumsGetService;

    @InjectMocks
    private EnumsGetController enumsGetController;

    @Test
    void getAllComplianceStatus() {
        DropDownDto dto = new DropDownDto();
        Mockito.when(enumsGetService.getAllComplianceStatus()).thenReturn(dto);
        assertNotNull(enumsGetController.getAllComplianceStatus());
    }

    @Test
    void getAllSupportingEvidence() {
        DropDownDto dto = new DropDownDto();
        Mockito.when(enumsGetService.getAllSupportingEvidence()).thenReturn(dto);
        assertNotNull(enumsGetController.getAllSupportingEvidence());
    }

    @Test
    void getAllYesOrNo() {
        DropDownDto dto = new DropDownDto();
        Mockito.when(enumsGetService.getAllYesOrNo()).thenReturn(dto);
        assertNotNull(enumsGetController.getAllYesOrNo());
    }

    @Test
    void getAllTemperatureType() {
        DropDownDto dto = new DropDownDto();
        Mockito.when(enumsGetService.getAllTemperatureType()).thenReturn(dto);
        assertNotNull(enumsGetController.getAllTemperatureType());
    }

    @Test
    void getAllComplianceCategory() {
        DropDownDto dto = new DropDownDto();
        Mockito.when(enumsGetService.getAllComplianceCategory()).thenReturn(dto);
        assertNotNull(enumsGetController.getAllComplianceCategory());

    }
}
