package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.TrainingReadingDto;
import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Time;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class TrainingReadingConverterTest {

    @InjectMocks
    TrainingReadingConverter trainingReadingConverter;

    @Mock
    TrainerConverter trainerConverter;

    @Mock
    ParticipantsConverter participantsConverter;

    @Mock
    DocumentsConverter documentsConverter;

    @Mock
    SignatureConverter signatureConverter;

    @Mock
    UserManagementClient userManagementClient;

    @Mock
    SelectedTrainingTitleConverter selectedTrainingTitleConverter;

    private Authentication authentication;

    @BeforeEach
    void setUp() {
        // Setup authentication context for tests
        authentication = Authentication.builder().userId("Nijanthan").build();
        AuthenticationContextHolder.setContext(authentication);
    }

    @Test
    void convert() {
        TrainingReadingDto dto = new TrainingReadingDto();
        dto.setId("1L");
        dto.setOrganizedBy("Organization X");
        dto.setTrainingTitle("Sample Training");
        dto.setDate(new Date());
        dto.setTime(Time.valueOf(LocalTime.now()));
        dto.setLocation("Sample Location");
        dto.setTrainingObjective("Sample Objective");
        dto.setTrainingMaterialUsed("Sample Material");
        dto.setDescription("Sample Description");
        dto.setComments("Sample Comments");
        dto.setComplianceSubCategoryId("2L");
        dto.setTrainers(new HashSet<>());
        dto.setParticipants(new HashSet<>());
        dto.setDocuments(new HashSet<>());
        dto.setSignatures(new HashSet<>());
        dto.setSelectedTrainingTitles(new HashSet<>());

        TrainingReading result = trainingReadingConverter.convert(dto);

        assertNotNull(result);
        assertEquals(dto.getId(), result.getId());
        assertEquals(dto.getOrganizedBy(), result.getOrganizedBy());
        assertEquals(dto.getTrainingTitle(), result.getTrainingTitle());
        assertEquals(dto.getDate(), result.getDate());
        assertEquals(dto.getTime(), result.getTime());
        assertEquals(dto.getLocation(), result.getLocation());
        assertEquals(dto.getTrainingObjective(), result.getTrainingObjective());
        assertEquals(dto.getTrainingMaterialUsed(), result.getTrainingMaterialUsed());
        assertEquals(dto.getDescription(), result.getDescription());
        assertEquals(dto.getComments(), result.getComments());
        assertEquals(authentication.getUserId(), result.getCreatedBy());
    }

    @Test
    void convertWithNull(){

        TrainingReadingDto dto = new TrainingReadingDto();
        dto.setId(null);
        dto.setOrganizedBy(null);
        dto.setTrainingTitle(null);
        dto.setDate(null);
        dto.setTime(null);
        dto.setLocation(null);
        dto.setTrainingObjective(null);
        dto.setTrainingMaterialUsed(null);
        dto.setDescription(null);
        dto.setComments(null);
        dto.setComplianceSubCategoryId(null);
        dto.setTrainers(null);
        dto.setParticipants(null);
        dto.setDocuments(null);
        dto.setSignatures(null);
        dto.setSelectedTrainingTitles(null);
        dto.setCreatedBy(null);


        assertNotNull(trainingReadingConverter.convert(dto));
    }

    @Test
    void convertToDto() {
        TrainingReading trainingReading = new TrainingReading();
        trainingReading.setId("1L");
        trainingReading.setOrganizedBy("Organization X");
        trainingReading.setTrainingTitle("Sample Training");
        trainingReading.setDate(new Date());
        trainingReading.setTime(Time.valueOf(LocalTime.now()));
        trainingReading.setLocation("Sample Location");
        trainingReading.setTrainingObjective("Sample Objective");
        trainingReading.setTrainingMaterialUsed("Sample Material");
        trainingReading.setDescription("Sample Description");
        trainingReading.setComments("Sample Comments");
        trainingReading.setTrainers(new HashSet<>());
        trainingReading.setParticipants(new HashSet<>());
        trainingReading.setDocuments(new HashSet<>());
        trainingReading.setSignatures(new HashSet<>());
        trainingReading.setSelectedTrainingTitles(new HashSet<>());
        UserName userName=new UserName();
        userName.setName("mithuja");
        Mockito.when(userManagementClient.getUserNameById(trainingReading.getCreatedBy()))
                .thenReturn(userName);
        TrainingReadingDto result = trainingReadingConverter.convertToDto(trainingReading);

        assertNotNull(result);
        assertEquals(trainingReading.getId(), result.getId());
        assertEquals(trainingReading.getOrganizedBy(), result.getOrganizedBy());
        assertEquals(trainingReading.getTrainingTitle(), result.getTrainingTitle());
        assertEquals(trainingReading.getDate(), result.getDate());
        assertEquals(trainingReading.getTime(), result.getTime());
        assertEquals(trainingReading.getLocation(), result.getLocation());
        assertEquals(trainingReading.getTrainingObjective(), result.getTrainingObjective());
        assertEquals(trainingReading.getTrainingMaterialUsed(), result.getTrainingMaterialUsed());
        assertEquals(trainingReading.getDescription(), result.getDescription());
        assertEquals(trainingReading.getComments(), result.getComments());
    }

    @Test
    void updateConvert_withNullFields() {
        // Arrange
        TrainingReading existingReading = new TrainingReading();
        existingReading.setOrganizedBy("Old Organization");
        existingReading.setTrainingTitle("Old Title");

        TrainingReadingDto newReading = new TrainingReadingDto();
        newReading.setOrganizedBy(null);  // Testing null input
        newReading.setTrainingTitle(null);
        newReading.setDate(null);
        newReading.setTime(null);
        newReading.setLocation(null);
        newReading.setTrainingObjective(null);
        newReading.setTrainingMaterialUsed(null);
        newReading.setDescription(null);
        newReading.setComments(null);
        newReading.setTrainers(null); // Testing null collection
        newReading.setParticipants(null);
        newReading.setDocuments(null);
        newReading.setSelectedTrainingTitles(null);

        // Act
        trainingReadingConverter.updateConvert(existingReading, newReading);

        // Assert
        assertNull(existingReading.getOrganizedBy());
        assertNull(existingReading.getTrainingTitle());
        assertNull(existingReading.getDate());
        assertNull(existingReading.getTime());
        assertNull(existingReading.getLocation());
        assertNull(existingReading.getTrainingObjective());
        assertNull(existingReading.getTrainingMaterialUsed());
        assertNull(existingReading.getDescription());
        assertNull(existingReading.getComments());
        assertNull(existingReading.getTrainers());
        assertNull(existingReading.getParticipants());
        assertNull(existingReading.getDocuments());
        assertNull(existingReading.getSelectedTrainingTitles());
    }
    @Test
    void updateConvert_withEmptyCollections() {
        // Arrange
        TrainingReading existingReading = new TrainingReading();
        existingReading.setTrainers(new HashSet<>());
        existingReading.setParticipants(new HashSet<>());
        existingReading.setDocuments(new HashSet<>());
        existingReading.setSelectedTrainingTitles(new HashSet<>());

        TrainingReadingDto newReading = new TrainingReadingDto();
        newReading.setTrainers(new HashSet<>()); // Empty collection
        newReading.setParticipants(new HashSet<>());
        newReading.setDocuments(new HashSet<>());
        newReading.setSelectedTrainingTitles(new HashSet<>());

        // Act
        trainingReadingConverter.updateConvert(existingReading, newReading);

        // Assert
        assertNotNull(existingReading.getTrainers());
        assertTrue(existingReading.getTrainers().isEmpty());
        assertNotNull(existingReading.getParticipants());
        assertTrue(existingReading.getParticipants().isEmpty());
        assertNotNull(existingReading.getDocuments());
        assertTrue(existingReading.getDocuments().isEmpty());
        assertNotNull(existingReading.getSelectedTrainingTitles());
        assertTrue(existingReading.getSelectedTrainingTitles().isEmpty());
    }

    @Test
    void convertToDtoById(){
        String rowNo = "test";

        Set<Trainer> trainers = new HashSet<>();
        Set<Participants> participants = new HashSet<>();
        Set<Documents> documents = new HashSet<>();
        Set<TrainingTitle> trainingTitles = new HashSet<>();
        Set<Signatures> signatures = new HashSet<>();

//        Enum
        ComplianceStatus complianceStatus =ComplianceStatus.APPROVED;

        TrainingReading trainingReading = new TrainingReading();
        trainingReading.setId("1");
        trainingReading.setCreatedBy("test");
        trainingReading.setOrganizedBy("Organization");
        trainingReading.setTrainingTitle("Software Training");
        trainingReading.setTime(null);
        trainingReading.setLocation("Room A");
        trainingReading.setDate(null);
        trainingReading.setTrainingObjective("Learn Mockito");
        trainingReading.setTrainingMaterialUsed("Slides");
        trainingReading.setComments("Good session");
        trainingReading.setComplianceStatus(complianceStatus);
        trainingReading.setComplianceStatus(null);
        trainingReading.setComplianceSubCategoryId("1");
        trainingReading.setTrainers(trainers);
        trainingReading.setParticipants(participants);
        trainingReading.setDocuments(documents);
        trainingReading.setTrainingTitle(trainingTitles.toString());
        trainingReading.setSignatures(signatures);

        UserName userName=new UserName();
        userName.setName("mithuja");



        Mockito.when(userManagementClient.getUserNameById(trainingReading.getCreatedBy()))
                .thenReturn(userName);

        assertNotNull(trainingReadingConverter.convertToDtoById(trainingReading,rowNo));

    }
}
