package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.HealthAndSafetyConverter;
import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.HealthAndSafetyOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.HealthAndSafetyService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HealthAndSafetyAgentTest {
    @InjectMocks
    HealthAndSafetyAgent healthAndSafetyAgent;
    @Mock
    HealthAndSafetyService healthAndSafetyService;
    @Mock
    HealthAndSafetyConverter healthAndSafetyConverter;

    @Test
    void getAllOverViewForCleaning() {
        HealthAndSafetyOverviewSearchDto healthAndSafetyOverviewSearchDto = HealthAndSafetyOverviewSearchDto.builder()
                .page(1)
                .size(10)
                .build();

        List<ComplianceReading> complianceReadings = Collections.singletonList(new ComplianceReading()); // Mock one ComplianceReading
        Page<ComplianceReading> compliantReadingsPage = new PageImpl<>(complianceReadings);

        HealthAndSafetyOverViewDisplayDto cleaningOverViewDisplayDto = new HealthAndSafetyOverViewDisplayDto();
        when(healthAndSafetyService.getAllOverViewForHealthAndSafety(healthAndSafetyOverviewSearchDto)).thenReturn(compliantReadingsPage);
        when(healthAndSafetyConverter.convertToDto(Mockito.any(ComplianceReading.class))).thenReturn(cleaningOverViewDisplayDto);

        PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> response = healthAndSafetyAgent.getAllOverViewForHealthAndSafety(healthAndSafetyOverviewSearchDto);

        assertNotNull(response);

    }

    @Test
    void getOverviewHealthAndSafetyById() {
        ComplianceReading complianceReading = new ComplianceReading();
        when(healthAndSafetyService.getOverviewHealthAndSafetyById(anyString())).thenReturn(new ComplianceReading());
        when(healthAndSafetyConverter.convertToDto(complianceReading)).thenReturn(new HealthAndSafetyOverViewDisplayDto());
        assertNotNull(healthAndSafetyAgent.getOverviewHealthAndSafetyById("1"));
    }
}