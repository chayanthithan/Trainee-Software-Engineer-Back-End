package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.VisitTypeDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class VisitorConvertorTest {
@InjectMocks
    VisitorConvertor visitorConvertor;

    @Test
    void convertToEntity() {
        assertNotNull(visitorConvertor.convertToEntity(new VisitTypeDto("df","f")));
    }
}