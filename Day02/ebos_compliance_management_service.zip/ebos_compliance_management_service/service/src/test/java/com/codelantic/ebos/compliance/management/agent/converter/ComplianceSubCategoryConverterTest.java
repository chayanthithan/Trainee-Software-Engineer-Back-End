package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.ComplianceSubCategory;
import com.codelantic.ebos.compliance.management.entity.SubCategoryCheckList;
import com.codelantic.ebos.compliance.management.entity.SubCategoryFormConfigurations;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestions;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import com.codelantic.ebos.compliance.management.repository.FormSettingConfigurationRepository;
import com.codelantic.ebos.compliance.management.repository.SubCategoryFormConfigurationsRepository;
import com.codelantic.ebos.compliance.management.repository.TemperatureConfigurationsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anySet;

@ExtendWith(MockitoExtension.class)
class ComplianceSubCategoryConverterTest {

    @InjectMocks
    ComplianceSubCategoryConverter complianceSubCategoryConverter;

    @Mock
    SubCategoryCheckListConverter subCategoryCheckListConverter;
    @Mock
    SubCategoryQuestionsConverter subCategoryQuestionsConverter;
    @Mock
    TemperatureConfigurationsRepository temperatureConfigurationsRepository;
    @Mock
    private FormSettingConfigurationRepository formSettingConfigurationRepository;
    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;
    @Mock
    private TemperatureConverter temperatureConverter;
    @Mock
    private SubCategoryFormConfigurationsRepository subCategoryFormConfigurationsRepository;


    @Test
    void convert() {
        ComplianceSubCategorySaveDto complianceSubCategorySaveDto = new ComplianceSubCategorySaveDto();
        complianceSubCategorySaveDto.setSubCategoryName("Test SubCategory");
        complianceSubCategorySaveDto.setComplianceId(2);
        complianceSubCategorySaveDto.setIsForm(true);
        complianceSubCategorySaveDto.setBusinessId("businessId");

        TemperatureSaveDto temperatureSaveDto = new TemperatureSaveDto();
        complianceSubCategorySaveDto.setTemperatureSaveDto(temperatureSaveDto);

        Set<SubCategoryCheckListSaveDto> subCategoryCheckListSaveDto = new HashSet<>();
        complianceSubCategorySaveDto.setSubCategoryCheckListSaveDto(subCategoryCheckListSaveDto);
        Set<SubCategoryQuestionsSaveDto> subCategoryQuestionsSaveDto = new HashSet<>();
        complianceSubCategorySaveDto.setSubCategoryQuestionsSaveDto(subCategoryQuestionsSaveDto);

        SubCategoryFormConfigurationDto formConfigurationDto = new SubCategoryFormConfigurationDto();
        formConfigurationDto.setFormSettingsConfigurationsId("configId1");
        Set<SubCategoryFormConfigurationDto> formConfigurationDtos = new HashSet<>();
        formConfigurationDtos.add(formConfigurationDto);
        complianceSubCategorySaveDto.setFormConfigurationSaveDto(formConfigurationDtos);

        Set<String> existingIds = new HashSet<>(Collections.singleton("configId1"));
        Mockito.when(formSettingConfigurationRepository.findExistingIds(anySet())).thenReturn(existingIds);

        ComplianceSubCategory complianceSubCategory = complianceSubCategoryConverter.convert(complianceSubCategorySaveDto);

        assertEquals("Test SubCategory", complianceSubCategory.getSubCategoryName());
        assertEquals(2, complianceSubCategory.getComplianceId());
        assertTrue(complianceSubCategory.getIsForm());

        Mockito.verify(formSettingConfigurationRepository).findExistingIds(anySet());
    }

    @Test
    void convertToCheckListQuestionDto() {
        SubCategoryCheckList subCategoryCheckList = SubCategoryCheckList.builder()
                .heading("Health and Safety")  // Heading for grouping
                .checklist("Use Proper Lifting Techniques")
                .isCommentAvailable(true)
                .isDocumentAvailable(false)
                .build();

        Set<SubCategoryCheckList> subCategoryCheckLists = new HashSet<>();
        subCategoryCheckLists.add(subCategoryCheckList);

        SubCategoryQuestions subCategoryQuestions = SubCategoryQuestions.builder()
                .heading("Health and Safety")  // Heading for grouping
                .question("Are safety helmets available?")
                .isCommentAvailable(true)
                .isDocumentAvailable(false)
                .build();

        Set<SubCategoryQuestions> subCategoryQuestions1 = new HashSet<>();
        subCategoryQuestions1.add(subCategoryQuestions);

        TemperatureReadingConfigurationsDto temperatureReadingConfigurationsDto = new TemperatureReadingConfigurationsDto();
        temperatureReadingConfigurationsDto.setIsRequiredQuantityBasedTempReading(true);

        Mockito.when(temperatureConfigurationsRepository.geTemperatureConfigurationBySubCategoryId("1"))
                .thenReturn(temperatureReadingConfigurationsDto);

        ComplianceSubCategory complianceSubCategory = ComplianceSubCategory.builder()
                .id("1")
                .isCheckList(true)
                .isYesOrNo(true)
                .isTemperature(true)
                .subCategoryCheckLists(subCategoryCheckLists)
                .subCategoryQuestions(subCategoryQuestions1)
                .isDeclarationStatement(Boolean.TRUE)
                .isCheckThisBoxToAddCommentsToTheForm(Boolean.TRUE)
                .build();

        GetCheckListQuestionDto result = complianceSubCategoryConverter.convertToCheckListQuestionDto(complianceSubCategory);

        assertNotNull(result);
        assertNotNull(result.getCheckLists());
        assertEquals(1, result.getCheckLists().size());
    }

    @Test
    void convert2() {
        ComplianceSubCategory complianceSubCategory = new ComplianceSubCategory();
        complianceSubCategory.setSubCategoryName("Test SubCategory");
        complianceSubCategory.setComplianceId(2);
        complianceSubCategory.setIsForm(true);
        complianceSubCategory.setBusinessId("businessId");
        complianceSubCategory.setIsTemperature(true);
        complianceSubCategory.setIsCheckList(true);
        complianceSubCategory.setIsYesOrNo(true);

        Set<SubCategoryCheckList> subCategoryCheckLists = new HashSet<>();
        SubCategoryCheckList subCategoryCheckList = new SubCategoryCheckList();
        subCategoryCheckLists.add(subCategoryCheckList);
        complianceSubCategory.setSubCategoryCheckLists(subCategoryCheckLists);

        Set<SubCategoryQuestions> subCategoryQuestions = new HashSet<>();
        SubCategoryQuestions subCategoryQuestions1 = new SubCategoryQuestions();
        subCategoryQuestions.add(subCategoryQuestions1);
        complianceSubCategory.setSubCategoryQuestions(subCategoryQuestions);

        SubCategoryFormConfigurationDto formConfigurationDto = new SubCategoryFormConfigurationDto();
        formConfigurationDto.setFormSettingsConfigurationsId("configId1");
        Set<SubCategoryFormConfigurationDto> formConfigurationDtos = new HashSet<>();
        formConfigurationDtos.add(formConfigurationDto);

        assertNotNull(complianceSubCategoryConverter.convert(complianceSubCategory));
    }

    @Test
    void processFormSettings() {

        List<FormSettingConfigurationDto> formSettingConfigurationList = new ArrayList<>();
        List<String> formIds = Collections.singletonList("field1");

        FieldConfigurationDto field1 = new FieldConfigurationDto();
        field1.setId("field1");
        field1.setStatus(false);

        FieldConfigurationDto field2 = new FieldConfigurationDto();
        field2.setId("field2");
        field2.setStatus(false);

        FieldConfigurationDto field3 = new FieldConfigurationDto(); // Added definition for field3
        field3.setId("field3");
        field3.setStatus(false);

        FormSettingConfigurationDto formSetting1 = new FormSettingConfigurationDto("Category 1", Arrays.asList(field1, field2));
        FormSettingConfigurationDto formSetting2 = new FormSettingConfigurationDto("Category 2", Collections.singletonList(field3));

        formSettingConfigurationList.add(formSetting1);
        formSettingConfigurationList.add(formSetting2);

        List<FormSettingConfigurationDto> result = complianceSubCategoryConverter.processFormSettings(formSettingConfigurationList, formIds);

        assertNotNull(result);
        assertEquals(2, result.size());

    }

    @Test
    void convertForUpdate() {
        ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto = new ComplianceSubCategoryUpdateDto();
        complianceSubCategoryUpdateDto.setIsTemperature(true);
        complianceSubCategoryUpdateDto.setTemperatureSaveDto(new TemperatureSaveDto());
        complianceSubCategoryUpdateDto.setIsForm(true);

        Set<SubCategoryFormConfigurationDto> formConfigurationSaveDto = new HashSet<>();
        SubCategoryFormConfigurationDto subCategoryFormConfigurationDto = new SubCategoryFormConfigurationDto();
        subCategoryFormConfigurationDto.setFormSettingsConfigurationsId("configId1");
        formConfigurationSaveDto.add(subCategoryFormConfigurationDto);
        complianceSubCategoryUpdateDto.setFormConfigurationSaveDto(formConfigurationSaveDto);

        ComplianceSubCategory existingComplianceSubCategory = new ComplianceSubCategory();
        Set<SubCategoryFormConfigurations> subCategoryFormConfigurations = new HashSet<>();
        SubCategoryFormConfigurations subCategoryFormConfigurations1 = new SubCategoryFormConfigurations();
        subCategoryFormConfigurations.add(subCategoryFormConfigurations1);
        existingComplianceSubCategory.setSubCategoryFormConfigurations(subCategoryFormConfigurations);

        Mockito.when(complianceSubCategoryRepository.findByIdAndStatus(complianceSubCategoryUpdateDto.getComplianceSubCategoryId(), true)).thenReturn(Optional.of(existingComplianceSubCategory));

        assertNotNull(complianceSubCategoryConverter.convertForUpdate(complianceSubCategoryUpdateDto));
    }

    @Test
    void updateYesOrNoQuestionField() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto = new ComplianceSubCategoryUpdateDto();
        complianceSubCategoryUpdateDto.setIsYesOrNo(true);

        Set<SubCategoryQuestionsSaveDto> subCategoryQuestionsSaveDto = new HashSet<>();
        SubCategoryQuestionsSaveDto subCategoryQuestionsSaveDto1 = SubCategoryQuestionsSaveDto.builder().id("id").build();
        subCategoryQuestionsSaveDto.add(subCategoryQuestionsSaveDto1);
        complianceSubCategoryUpdateDto.setSubCategoryQuestionsSaveDto(subCategoryQuestionsSaveDto);

        ComplianceSubCategory existingComplianceSubCategory = new ComplianceSubCategory();
        existingComplianceSubCategory.setId("id");
        Set<SubCategoryQuestions> subCategoryQuestions = new HashSet<>();
        SubCategoryQuestions subCategoryQuestions1 = new SubCategoryQuestions();
        subCategoryQuestions1.setId("id");
        subCategoryQuestions.add(subCategoryQuestions1);
        existingComplianceSubCategory.setSubCategoryQuestions(subCategoryQuestions);

        Method method = ComplianceSubCategoryConverter.class.getDeclaredMethod("updateYesOrNoQuestionField", ComplianceSubCategoryUpdateDto.class, ComplianceSubCategory.class);
        method.setAccessible(true);
        method.invoke(complianceSubCategoryConverter, complianceSubCategoryUpdateDto, existingComplianceSubCategory);
        assertNotNull(existingComplianceSubCategory);
    }


    @Test
    void updateCheckListField() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        ComplianceSubCategoryUpdateDto complianceSubCategoryUpdateDto = new ComplianceSubCategoryUpdateDto();
        complianceSubCategoryUpdateDto.setIsCheckList(true);
        Set<SubCategoryCheckListSaveDto> subCategoryCheckListSaveDto = new HashSet<>();
        complianceSubCategoryUpdateDto.setSubCategoryCheckListSaveDto(subCategoryCheckListSaveDto);

        ComplianceSubCategory existingComplianceSubCategory = new ComplianceSubCategory();
        Set<SubCategoryCheckList> subCategoryCheckLists = new HashSet<>();
        SubCategoryCheckList subCategoryCheckList1 = new SubCategoryCheckList();
        subCategoryCheckList1.setId("id");
        subCategoryCheckLists.add(subCategoryCheckList1);
        existingComplianceSubCategory.setSubCategoryCheckLists(subCategoryCheckLists);


        Method method = ComplianceSubCategoryConverter.class.getDeclaredMethod("updateCheckListField", ComplianceSubCategoryUpdateDto.class, ComplianceSubCategory.class);
        method.setAccessible(true);
        method.invoke(complianceSubCategoryConverter, complianceSubCategoryUpdateDto, existingComplianceSubCategory);
        assertNotNull(existingComplianceSubCategory);

    }

}