package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ReminderToDto;
import com.codelantic.ebos.compliance.management.entity.ReminderTo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ReminderToConverterTest {

    @InjectMocks
    ReminderToConverter reminderToConverter;

    @Test
    void convert(){
        ReminderToDto reminderToDto = new ReminderToDto();
        reminderToDto.setId("reg4342");
        reminderToDto.setLicenseAndPermitReadingId("dwr434");
        reminderToDto.setImageName("nijanthan");
        reminderToDto.setImagePath("path");

        assertNotNull(reminderToConverter.convert(reminderToDto));

    }  @Test
    void convertt(){
        ReminderTo reminderToDto = new ReminderTo();
        reminderToDto.setId("reg4342");
        reminderToDto.setLicenseAndPermitReadingId("dwr434");
        reminderToDto.setImageName("nijanthan");
        reminderToDto.setImagePath("path");

        assertNotNull(reminderToConverter.convert(reminderToDto));

    }
}
