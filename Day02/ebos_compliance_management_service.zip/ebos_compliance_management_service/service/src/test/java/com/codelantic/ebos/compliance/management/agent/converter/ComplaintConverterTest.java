package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.ComplaintTypeSaveDto;
import com.codelantic.ebos.compliance.management.entity.CompliantType;
import com.codelantic.ebos.compliance.management.validations.Validations;
import com.codelantic.ebos.user.management.UserManagementClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ComplaintConverterTest {

    @InjectMocks
    ComplaintConverter complaintConverter;

    @Mock
    UserManagementClient userManagementClient;

    @Mock
    Validations validations;

    @Test
    void convertToEntity() {
        ComplaintTypeSaveDto complaintTypeSaveDto = new ComplaintTypeSaveDto();
        complaintTypeSaveDto.setBusinessId("1");
        complaintTypeSaveDto.setTypeOfCompliant("new type");

        CompliantType compliantType = new CompliantType();
        compliantType.setBusinessId("1");
        compliantType.setTypeOfCompliant("new type");

        CompliantType compliantType1 = complaintConverter.convertToEntity(complaintTypeSaveDto);
        assertEquals(compliantType1.getBusinessId(), complaintTypeSaveDto.getBusinessId());
    }

}