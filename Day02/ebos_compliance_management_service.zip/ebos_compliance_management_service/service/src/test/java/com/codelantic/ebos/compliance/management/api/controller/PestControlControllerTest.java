package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.PestControlAgent;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PestControlControllerTest {

    @Mock
    PestControlAgent pestControlAgent;
    @InjectMocks
    PestControlController pestControlController;

    @Test
    void getAll() {
        WasteManagementOverviewSearchDto searchDto = WasteManagementOverviewSearchDto.builder()
                .complianceStatus(ComplianceStatus.fromMappedValue("Under Review"))
                .build();
        when(pestControlAgent.getAll(searchDto)).thenReturn(new PaginatedResponseDto<>());
        assertNotNull(pestControlController.getAll(searchDto));
    }

    @Test
    void getOneOverViewById() {
        when(pestControlAgent.getOverViewById(anyString())).thenReturn(new PestControlOverviewDto());
        assertNotNull(pestControlController.getOneOverViewById("1"));
    }
}