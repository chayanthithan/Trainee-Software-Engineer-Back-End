package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.api.dto.DeliveryOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.TemperatureOverviewSearchDto;
import com.codelantic.ebos.compliance.management.service.DeliveryService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DeliveryAgentTest {

    @InjectMocks
    DeliveryAgent deliveryAgent;

    @Mock
    DeliveryService deliveryService;

    @Test
    void getAllDeliveryOverview(){
        TemperatureOverviewSearchDto deliverySearchDto=TemperatureOverviewSearchDto.builder().build();
        List<DeliveryOverviewDto> deliveryOverviewDtos=new ArrayList<>();
        Page<DeliveryOverviewDto> deliveryOverviewDtos1=new PageImpl<>(deliveryOverviewDtos);
        Mockito.when(deliveryService.getAllDeliveryOverview(deliverySearchDto)).thenReturn(deliveryOverviewDtos1);
        assertNotNull(deliveryAgent.getAllDeliveryOverview(deliverySearchDto));

    }

}