package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.CompliantAgent;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.repository.ComplianceSubCategoryRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CompliantControllerTest {

    @InjectMocks
    CompliantController compliantController;

    @Mock
    CompliantAgent compliantAgent;

    @Mock
    private ComplianceSubCategoryRepository complianceSubCategoryRepository;

    @Test
    void saveComplaintType() {
        ComplaintTypeSaveDto complaintTypeSaveDto = new ComplaintTypeSaveDto();
        complaintTypeSaveDto.setBusinessId("1");
        complaintTypeSaveDto.setTypeOfCompliant("new type");
        when(compliantAgent.saveComplaintType(complaintTypeSaveDto)).thenReturn(new ResponseDto());
        assertNotNull(compliantController.saveComplaintType(complaintTypeSaveDto));
    }

    @Test
    void getComplainType() {
        StringBuilder businessId = new StringBuilder();
        businessId.append("1");
        List<ComplaintTypeSaveDto> complaintTypeSaveDtos = new ArrayList<>();
        when(compliantAgent.getComplainType(businessId.toString())).thenReturn(complaintTypeSaveDtos);
        assertNotNull(compliantController.getComplainType(businessId.toString()));

    }

    @Test
    void getAllComplaints() {
        StringBuilder complianceSubCategoryId = new StringBuilder("1");
        StringBuilder businessId = new StringBuilder("1");
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = LocalDate.now();
        StringBuilder employeeName = new StringBuilder("1");
        StringBuilder complianceStatus = new StringBuilder("Pending Review");
        Integer page = 1;
        Integer size = 5;
        CompliantOverviewSearchDto compliantOverviewSearchDto = CompliantOverviewSearchDto
                .builder()
                .businessId(businessId.toString())
                .page(page)
                .size(size)
                .complianceSubCategoryId(complianceSubCategoryId.toString())
                .fromDate(fromDate)
                .toDate(toDate)
                .employeeName(employeeName.toString())
                .complianceStatus(complianceStatus != null ? ComplianceStatus.fromMappedValue(complianceStatus.toString()) : null)
                .build();
        PaginatedResponseDto<CompliantOverViewDto> compliantOverViewDtoPaginatedResponseDto = new PaginatedResponseDto<>();
        when(compliantAgent.getAllComplaints(compliantOverviewSearchDto)).thenReturn(compliantOverViewDtoPaginatedResponseDto);
        assertNotNull(compliantController.getAllComplaints(businessId.toString(), complianceSubCategoryId.toString(), fromDate, toDate, employeeName.toString(), complianceStatus.toString(), page, size));
    }


    @Test
    void getOverviewCompliantById() {
        when(compliantAgent.getOverviewCompliantById(anyString())).thenReturn(new CompliantOverViewDto());
        assertNotNull(compliantController.getOverviewCompliantById("id"));
    }
}