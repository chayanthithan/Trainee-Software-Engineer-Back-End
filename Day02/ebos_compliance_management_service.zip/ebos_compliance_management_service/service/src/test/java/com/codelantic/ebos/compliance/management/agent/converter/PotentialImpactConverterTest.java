package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.PotentialImpactDto;
import com.codelantic.ebos.compliance.management.entity.PotentialImpact;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class PotentialImpactConverterTest {
    @InjectMocks
    PotentialImpactConverter potentialImpactConverter;

    @Test
    void convert() {
        assertNotNull(potentialImpactConverter.convert(new PotentialImpactDto()));
    }

    @Test
    void testConvert() {
        PotentialImpact potentialImpact = PotentialImpact.builder()
                .id("1")
                .audio("audio")
                .audioPath("/path")
                .incidentReadingId("1")
                .build();
        assertNotNull(potentialImpactConverter.convert(potentialImpact));
    }
}