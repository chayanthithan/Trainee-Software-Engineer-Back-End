package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.CheckListReading;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.entity.SubCategoryQuestionsReadings;
import com.codelantic.ebos.compliance.management.entity.TemperatureReading;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ComplianceReadingConverterTest {
    @InjectMocks
    private ComplianceReadingConverter complianceReadingConverter;

    @Mock
    CheckListReadingConverter checkListReadingConverter;

    @Mock
    SubCategoryQuestionsReadingsConverter subCategoryQuestionsReadingsConverter;

    @Mock
    TemperatureReadingConverter temperatureReadingConverter;

    @Test
    void convert() {
        ComplianceReadingDto complianceReadingDto= new ComplianceReadingDto();
        Set<CheckListReadingDto> checkListReadings= new HashSet<>();
        complianceReadingDto.setCheckListReadings(checkListReadings);

        Set<SubCategoryQuestionsReadingsDto> subCategoryQuestionsReadings= new HashSet<>();
        complianceReadingDto.setSubCategoryQuestionsReadings(subCategoryQuestionsReadings);

        Set<TemperatureReadingDto> temperatureReadings= new HashSet<>();
        complianceReadingDto.setTemperatureReadings(temperatureReadings);
        AuthenticationContextHolder.setContext(Authentication.builder().userId("id").build());
        assertNotNull(complianceReadingConverter.convert(complianceReadingDto));
    }

    @Test
    void convert2() {
        String userName = "test";
        ComplianceReading complianceReading = new ComplianceReading();
        complianceReading.setId("id");
        complianceReading.setComplianceSubCategoryId("subcategory");
        complianceReading.setBusinessId("businessId");
        complianceReading.setComments("Test comments");
        complianceReading.setReviewerComments("Test reviewer comments");
        complianceReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        Set<CheckListReading> checkListReadings = new HashSet<>();
        complianceReading.setCheckListReadings(checkListReadings);

        Set<SubCategoryQuestionsReadings> subCategoryQuestionsReadings = new HashSet<>();
        complianceReading.setSubCategoryQuestionsReadings(subCategoryQuestionsReadings);

        Set<TemperatureReading> temperatureReadings = new HashSet<>();
        complianceReading.setTemperatureReadings(temperatureReadings);

        AuthenticationContextHolder.setContext(Authentication.builder().userId("id").build());
        ComplianceReadingDto result = complianceReadingConverter.convert(complianceReading,userName);
        assertNotNull(result);

    }

    @Test
    void updateConvert() {
        ComplianceReading existingReading = new ComplianceReading();
        existingReading.setId("id");
        existingReading.setComplianceSubCategoryId("oldSubcategory");
        existingReading.setBusinessId("oldBusinessId");
        existingReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        ComplianceReadingDto complianceReadingDto = new ComplianceReadingDto();
        complianceReadingDto.setId("newId");

        Set<CheckListReadingDto> checkListReadingsDto = new HashSet<>();
        complianceReadingDto.setCheckListReadings(checkListReadingsDto);

        Set<SubCategoryQuestionsReadingsDto> subCategoryQuestionsReadingsDto = new HashSet<>();
        complianceReadingDto.setSubCategoryQuestionsReadings(subCategoryQuestionsReadingsDto);

        Set<TemperatureReadingDto> temperatureReadingsDto = new HashSet<>();
        complianceReadingDto.setTemperatureReadings(temperatureReadingsDto);

        AuthenticationContextHolder.setContext(Authentication.builder().userId("id").build());
        complianceReadingConverter.updateConvert(existingReading, complianceReadingDto);
        assertEquals(complianceReadingDto.getId(), existingReading.getId());
    }
    @Test
    void converToDto() {
        String userName = "test";
        ComplianceReading complianceReading = new ComplianceReading();
        complianceReading.setId("id");
        complianceReading.setComplianceSubCategoryId("subcategory");
        complianceReading.setBusinessId("businessId");
        complianceReading.setComments("Test comments");
        complianceReading.setReviewerComments("Test reviewer comments");
        complianceReading.setComplianceStatus(ComplianceStatus.PENDING_REVIEW);

        Set<CheckListReading> checkListReadings = new HashSet<>();
        complianceReading.setCheckListReadings(checkListReadings);

        Set<SubCategoryQuestionsReadings> subCategoryQuestionsReadings = new HashSet<>();
        complianceReading.setSubCategoryQuestionsReadings(subCategoryQuestionsReadings);

        Set<TemperatureReading> temperatureReadings = new HashSet<>();
        complianceReading.setTemperatureReadings(temperatureReadings);

        AuthenticationContextHolder.setContext(Authentication.builder().userId("id").build());
        ComplianceReadingGetDto result = complianceReadingConverter.convertToDto(complianceReading,userName);
        assertNotNull(result);

    }
}