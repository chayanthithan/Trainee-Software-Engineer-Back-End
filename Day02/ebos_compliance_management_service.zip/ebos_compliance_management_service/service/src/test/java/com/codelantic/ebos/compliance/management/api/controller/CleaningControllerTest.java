package com.codelantic.ebos.compliance.management.api.controller;

import com.codelantic.ebos.compliance.management.agent.CleaningAgent;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverViewDisplayDto;
import com.codelantic.ebos.compliance.management.api.dto.CleaningOverviewSearchDto;
import com.codelantic.ebos.compliance.management.api.dto.PaginatedResponseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CleaningControllerTest {
    @Mock
    private CleaningAgent cleaningAgent;

    @InjectMocks
    private CleaningController cleaningControllerTest;

    @Test
    void overViewForCleaning() {
        String businessId = "51d08357-9c4f-4d6c-a391-89db99edfff8";
        LocalDate fromDate = LocalDate.now().minusDays(30);
        LocalDate toDate = LocalDate.now();
        String employeeName = "John Doe";
        String complianceStatus = "Approved";
        Integer page = 1;
        Integer size = 10;
        String subCategoryId = "sub-12345";

        PaginatedResponseDto<CleaningOverViewDisplayDto> paginatedResponseDto = new PaginatedResponseDto<>();


        Mockito.when(cleaningAgent.getAllOverViewForCleaning(Mockito.any(CleaningOverviewSearchDto.class)))
                .thenReturn(paginatedResponseDto);
        PaginatedResponseDto<CleaningOverViewDisplayDto> response = cleaningControllerTest.overViewForCleaning(
                businessId, fromDate, toDate, employeeName, complianceStatus, page, size, subCategoryId
        );
        assertNotNull(response);
        Mockito.verify(cleaningAgent).getAllOverViewForCleaning(Mockito.any(CleaningOverviewSearchDto.class));
    }

    @Test
    void getOverviewCleaningById(){
        String complianceReadingId = "";
        Mockito.when(cleaningAgent.getOverviewCleaningById(complianceReadingId)).thenReturn(new CleaningOverViewDisplayDto());
        assertNotNull(cleaningControllerTest.getOverviewCleaningById(complianceReadingId));
    }
}