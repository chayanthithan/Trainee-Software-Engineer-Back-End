package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.api.dto.DocumentsDto;
import com.codelantic.ebos.compliance.management.api.dto.DocumentsLicenseDto;
import com.codelantic.ebos.compliance.management.api.dto.LicenseAndPermitReadingDto;
import com.codelantic.ebos.compliance.management.api.dto.ReminderToDto;
import com.codelantic.ebos.compliance.management.entity.Documents;
import com.codelantic.ebos.compliance.management.entity.LicenseAndPermitReading;
import com.codelantic.ebos.compliance.management.entity.ReminderTo;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import com.codelantic.ebos.compliance.management.security.Authentication;
import com.codelantic.ebos.compliance.management.security.AuthenticationContextHolder;
import com.codelantic.ebos.user.management.UserManagementClient;
import com.codelantic.ebos.user.management.domain.UserName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LicenseAndPermitReadingConverterTest {
    @InjectMocks
    LicenseAndPermitReadingConverter licenseAndPermitReadingConverter;

    @Mock
    ReminderToConverter reminderToConverter;

    @Mock
    DocumentsConverter documentsConverter;
    @Mock
    UserManagementClient userManagementClient;


    @Test
    void convert() {
        Authentication authentication = Authentication.builder().build();
        authentication.setUserId("Nijanthan");
        AuthenticationContextHolder.setContext(authentication);

        LicenseAndPermitReadingDto dto = new LicenseAndPermitReadingDto();
        dto.setId("1L");
        dto.setLicenseOrPermitName("Sample License");
        dto.setLicenseOrPermitNumber("LIC123");
        dto.setTypeOfLicenseOrPermit("Type A");
        dto.setIssuingAuthority("Authority X");
        dto.setIssueDate(LocalDate.now());
        dto.setExpiryDate(LocalDate.now().plusYears(1));
        dto.setRenewalDate(LocalDate.now().plusYears(1).minusMonths(1));
        dto.setBusinessName("Sample Business");
        dto.setBusinessAddress("123 Business St");
        dto.setHoldersName("John Doe");
        dto.setContactPhoneNumber("123-456-7890");
        dto.setContactEmail("john@example.com");
        dto.setConditionsOrRestrictions("None");
        dto.setRenewalApplicationDedLine(LocalDate.now().plusYears(1).minusMonths(2));
        dto.setReminderDate(LocalDate.now().plusYears(1).minusMonths(3));
        dto.setReminderTime(LocalTime.of(9, 0));
        dto.setComments("Sample comment");
        dto.setSubCategoryFormConfigurationsId("2L");
        dto.setReminderTos(Set.of(new ReminderToDto()));
        dto.setDocuments(new HashSet<>());

        assertNotNull(licenseAndPermitReadingConverter.convert(dto));

    }

    @Test
    void convertToDto() {
        Set<Documents> documents = new HashSet<>();
        documents.add(Documents.builder().id("1").build());

        LicenseAndPermitReading licenseAndPermitReading = LicenseAndPermitReading.builder()
                .id("123")
                .reminderTime(LocalTime.of(14, 30)) // Assuming reminderTime is the correct field
                .licenseOrPermitName("Business License")
                .licenseOrPermitNumber("BL123456")
                .typeOfLicenseOrPermit("Commercial")
                .createdBy("mithuja")
                .documents(documents)
                .issueDate(LocalDate.of(2023, 5, 1))
                .expiryDate(LocalDate.of(2025, 5, 1))
                .renewalDate(LocalDate.of(2024, 4, 15))
                .comments("Renew annually")
                .complianceStatus(ComplianceStatus.APPROVED) // Assuming it's an enum or object, adjust accordingly
                .build();
        when(userManagementClient.getUserNameById(Mockito.anyString())).thenReturn(new UserName());
        assertNotNull(licenseAndPermitReadingConverter.convertToDto(licenseAndPermitReading));


    }

    @Test
    void testConvert() {
        Set<Documents> documents = new HashSet<>();
        documents.add(Documents.builder().id("1").build());

        LicenseAndPermitReading licenseAndPermitReading = LicenseAndPermitReading.builder()
                .id("123")
                .reminderTime(LocalTime.of(14, 30)) // Assuming reminderTime is the correct field
                .licenseOrPermitName("Business License")
                .licenseOrPermitNumber("BL123456")
                .typeOfLicenseOrPermit("Commercial")
                .createdBy("mithuja")
                .documents(documents)
                .issueDate(LocalDate.of(2023, 5, 1))
                .expiryDate(LocalDate.of(2025, 5, 1))
                .renewalDate(LocalDate.of(2024, 4, 15))
                .comments("Renew annually")
                .complianceStatus(ComplianceStatus.APPROVED) // Assuming it's an enum or object, adjust accordingly
                .build();
        assertNotNull(licenseAndPermitReadingConverter.convert(licenseAndPermitReading));


    }

    @Test
    void updateConvert() {
        LicenseAndPermitReading licenseAndPermitReading = new LicenseAndPermitReading();
        Set<DocumentsDto> documentsDtos = new HashSet<>();
        documentsDtos.add(DocumentsDto.builder().id("1").build());
        Set<ReminderToDto> reminderToDto = new HashSet<>();
        reminderToDto.add(ReminderToDto.builder().id("1").build());

        LicenseAndPermitReadingDto licenseAndPermitReadingDto = LicenseAndPermitReadingDto.builder()
                .id("123")
                .reminderTime(LocalTime.of(14, 30))
                .licenseOrPermitName("Business License")
                .licenseOrPermitNumber("BL123456")
                .typeOfLicenseOrPermit("Commercial")
                .createdBy("mithuja")
                .documents(documentsDtos)
                .issueDate(LocalDate.of(2023, 5, 1))
                .expiryDate(LocalDate.of(2025, 5, 1))
                .renewalDate(LocalDate.of(2024, 4, 15))
                .comments("Renew annually")
                .reminderTos(reminderToDto)
                .build();
        licenseAndPermitReadingConverter.updateConvert(licenseAndPermitReading, licenseAndPermitReadingDto);
        assertEquals(licenseAndPermitReadingDto.getId(), licenseAndPermitReading.getId());
    }

    @Test
    void convertToDtos() {
        ReminderTo reminderTo = new ReminderTo();
        Set<ReminderTo> reminders = new HashSet<>();
        reminders.add(reminderTo);
        Documents document = new Documents();
        Set<Documents> documents= new HashSet<>();
        documents.add(document);
        LicenseAndPermitReading license = LicenseAndPermitReading.builder()
                .id("123e4567-e89b-12d3-a456-426614174000") // Optional; can be auto-generated
                .licenseOrPermitName("Business License")
                .licenseOrPermitNumber("BL123456")
                .typeOfLicenseOrPermit("Business")
                .issuingAuthority("City Government")
                .issueDate(LocalDate.of(2020, 1, 1))
                .expiryDate(LocalDate.of(2025, 1, 1))
                .renewalDate(LocalDate.of(2024, 12, 31))
                .businessName("Example Corp")
                .businessAddress("123 Example St, Example City")
                .holdersName("John Doe")
                .contactPhoneNumber("123-456-7890")
                .contactEmail("johndoe@example.com")
                .conditionsOrRestrictions("None")
                .renewalApplicationDedLine(LocalDate.of(2024, 11, 30))
                .reminderDate(LocalDate.of(2024, 11, 1))
                .reminderTime(LocalTime.of(9, 0)) // 9:00 AM
                .comments("This is a comment.")
                .reminderTos(reminders)
                .documents(documents)
                .complianceSubCategoryId("subcategoryId123")
                .createdBy("admin")
                .reviewerComments("Reviewed and approved.")
                .complianceStatus(ComplianceStatus.APPROVED) // Use the appropriate enum value
                .build();
        when(userManagementClient.getUserNameById(anyString())).thenReturn(new UserName());
        when(documentsConverter.convertForLicense(any(Documents.class))).thenReturn(new DocumentsLicenseDto());
        assertNotNull(licenseAndPermitReadingConverter.convertToDtos(license,"1"));
    }
}
