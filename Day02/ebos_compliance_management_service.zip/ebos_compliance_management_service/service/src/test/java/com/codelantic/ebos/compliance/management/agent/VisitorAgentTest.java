package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.CompliantOverViewConverter;
import com.codelantic.ebos.compliance.management.agent.converter.VisitorConvertor;
import com.codelantic.ebos.compliance.management.api.dto.*;
import com.codelantic.ebos.compliance.management.entity.VisitType;
import com.codelantic.ebos.compliance.management.entity.VisitorReading;
import com.codelantic.ebos.compliance.management.service.VisitorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VisitorAgentTest {

    @Mock
    private VisitorConvertor visitorConvertor;
    @Mock
    private VisitorService visitorService;

    @InjectMocks
    private VisitorAgent visitorAgent;
    @Mock
    CompliantOverViewConverter compliantOverViewConverter;

    @Test
    void addNewVisitorType() {
        VisitType visitType=new VisitType();
        VisitTypeDto visitTypeDto=new VisitTypeDto("id","type");
        when(visitorConvertor.convertToEntity(visitTypeDto)).thenReturn(visitType);
        when(visitorService.addNewVisitType(visitType)).thenReturn(ResponseDto.builder().build());
        assertNotNull(visitorAgent.addNewVisitorType(visitTypeDto));


    }

    @Test
    void getAllVisitTypeByBusinessId() {
        String businessId="businessId";
        VisitTypeDto visitTypeDto=new VisitTypeDto("id","type");
        when(visitorService.getAllVisitType(businessId)).thenReturn(List.of(visitTypeDto));
        assertNotNull(visitorAgent.getAllVisitTypeByBusinessId(businessId));

    }
    @Test
    void testGetVistorOverview() {
        // Arrange
        VisitorSearchDto searchDto =  VisitorSearchDto.builder().build();
        searchDto.setPage(0);
        searchDto.setSize(10);

        VisitorReading visitorReading1 = new VisitorReading();
        VisitorReading visitorReading2 = new VisitorReading();
        List<VisitorReading> content = Arrays.asList(visitorReading1, visitorReading2);

        Page<VisitorReading> page = new PageImpl<>(content, PageRequest.of(0, 10), 20);

        when(visitorService.getVistorOverview(searchDto)).thenReturn(page);

        VisitorOverviewDto dto1 = new VisitorOverviewDto();
        VisitorOverviewDto dto2 = new VisitorOverviewDto();
        when(compliantOverViewConverter.convertToVisitorDto(visitorReading1)).thenReturn(dto1);
        when(compliantOverViewConverter.convertToVisitorDto(visitorReading2)).thenReturn(dto2);

        // Act
        PaginatedResponseDto<VisitorOverviewDto> result = visitorAgent.getVistorOverview(searchDto);

        // Assert
        assertNotNull(result);

        // Test empty result
        when(visitorService.getVistorOverview(searchDto)).thenReturn(Page.empty());
        result = visitorAgent.getVistorOverview(searchDto);

        assertNotNull(result);
        assertTrue(result.getData().isEmpty());
        assertEquals(0, result.getTotalItems());

        // Test null page (edge case)
        when(visitorService.getVistorOverview(searchDto)).thenReturn(null);
        assertThrows(NullPointerException.class, () -> visitorAgent.getVistorOverview(searchDto));
    }


    @Test
    void getRowVisitor() {
        VisitorReading visitorReading = new VisitorReading();
        visitorReading.setId("1");
        when(visitorService.getRowVisitor("1")).thenReturn(visitorReading);
        when(compliantOverViewConverter.convertToVisitorDto(visitorReading)).thenReturn(new VisitorOverviewDto());
        assertNotNull(visitorAgent.getRowVisitor("1"));

    }
}