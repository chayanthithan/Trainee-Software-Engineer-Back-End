package com.codelantic.ebos.compliance.management.agent.converter;

import com.codelantic.ebos.compliance.management.entity.*;
import com.codelantic.ebos.compliance.management.repository.SubCategoryCheckListRepository;
import com.codelantic.ebos.compliance.management.repository.SubCategoryQuestionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class CheckListAndQuestionDisplayConverterTest {

    @Mock
    SubCategoryCheckListRepository subCategoryCheckListRepository;

    @Mock
    SubCategoryQuestionRepository subCategoryQuestionRepository;

    @InjectMocks
    CheckListAndQuestionDisplayConverter checkListAndQuestionDisplayConverter;

    @Test
    void convert() {
        CheckListReading checkListReading = new CheckListReading();
        checkListReading.setId("1");
        checkListReading.setComplianceReadingId("1");
        checkListReading.setSubCategoryCheckListId("c1");
        checkListReading.setReadingImages(Set.of(new ReadingImages()));

        SubCategoryQuestionsReadings subCategoryQuestionsReadings = SubCategoryQuestionsReadings.builder()
                .id("1")
                .yesOrNo("Yes")
                .subCategoryQuestionsId("q1")
                .readingImages(Set.of(new ReadingImages()))
                .build();
        ComplianceReading complianceReading = ComplianceReading.builder()
                .id("1")
                .checkListReadings(Set.of(checkListReading))
                .subCategoryQuestionsReadings(Set.of(subCategoryQuestionsReadings))
                .build();

        SubCategoryCheckList subCategoryCheckList = SubCategoryCheckList.builder()
                .id("1")
                .complianceSubCategoryId("c1")
                .heading("test")
                .checkListReadings(Set.of(checkListReading))
                .build();

        SubCategoryQuestions subCategoryQuestions = SubCategoryQuestions.builder()
                .id("1")
                .complianceSubCategoryId("c1")
                .subCategoryQuestionsReadings(Set.of(subCategoryQuestionsReadings))
                .build();

        when(subCategoryCheckListRepository.findById(checkListReading.getSubCategoryCheckListId())).thenReturn(Optional.ofNullable(subCategoryCheckList));
        when(subCategoryQuestionRepository.findById(subCategoryQuestionsReadings.getSubCategoryQuestionsId())).thenReturn(Optional.ofNullable(subCategoryQuestions));

        assertNotNull(checkListAndQuestionDisplayConverter.convert(complianceReading));
    }

}