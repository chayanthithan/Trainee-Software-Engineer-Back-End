package com.codelantic.ebos.compliance.management.agent;

import com.codelantic.ebos.compliance.management.agent.converter.PestControlConverter;
import com.codelantic.ebos.compliance.management.api.dto.PestControlOverviewDto;
import com.codelantic.ebos.compliance.management.api.dto.WasteManagementOverviewSearchDto;
import com.codelantic.ebos.compliance.management.entity.ComplianceReading;
import com.codelantic.ebos.compliance.management.service.PestControlService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PestControlAgentTest {

    @Mock
    PestControlService pestControlService;
    @Mock
    PestControlConverter pestControlConverter;
    @InjectMocks
    PestControlAgent pestControlAgent;

    @Test
    void getAll() {
        WasteManagementOverviewSearchDto searchDto = WasteManagementOverviewSearchDto.builder()
                .page(1)
                .size(10)
                .build();

        when(pestControlService.getAll(searchDto)).thenReturn(Page.empty());
        assertNotNull(pestControlAgent.getAll(searchDto));
    }

    @Test
    void getOverViewById() {
        when(pestControlService.getOverViewById(anyString())).thenReturn(new ComplianceReading());
        when(pestControlConverter.convertFromEntity(any(ComplianceReading.class), eq(1))).thenReturn(new PestControlOverviewDto());
        assertNotNull(pestControlAgent.getOverViewById("1"));
    }
}