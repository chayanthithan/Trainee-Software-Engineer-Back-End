package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.service.UserDetailService;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/users-identity")
@RequiredArgsConstructor
@Validated
public class UserController {


    private final UserDetailService userDetailService;

    @PostMapping("/updatePasswordOtp")
    public AgentResponseDto updatePasswordOtpSend(@Valid @RequestBody TwoFactorRequestDto twoFactorRequestDto) {
        return userDetailService.updatePasswordOtpSend(twoFactorRequestDto);
    }

    @PutMapping("/update_user_password")
    public Boolean updateUser(@RequestBody @Valid AuthenticationDto authenticationDto) {
        return userDetailService.updateUserPassword(authenticationDto);
    }


    @PutMapping("/updatePassword")
    public ResponseDto updatePassword(@RequestBody @Valid ResetPasswordDto resetPasswordDto) {
        return userDetailService.updatePassword(resetPasswordDto);
    }

    @PutMapping("/resetPassword")
    public ResponseDto resetPassword(@RequestBody @Valid ResetPasswordDto resetPasswordDto) {
        return userDetailService.resetPassword(resetPasswordDto);
    }


    @DeleteMapping("/deleteUser/{id}")
    public ResponseDto deleteUser(@PathVariable(value = "id") String id) {
        return userDetailService.deleteUser(id);
    }
}
