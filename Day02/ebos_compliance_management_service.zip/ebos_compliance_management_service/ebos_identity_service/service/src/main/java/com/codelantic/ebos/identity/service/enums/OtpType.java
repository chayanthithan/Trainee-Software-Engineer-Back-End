package com.codelantic.ebos.identity.service.enums;

public enum OtpType {

    SIGN_IN,
    RESET_PASSWORD,
    UPDATE_PASSWORD,
    SIGN_UP
}
