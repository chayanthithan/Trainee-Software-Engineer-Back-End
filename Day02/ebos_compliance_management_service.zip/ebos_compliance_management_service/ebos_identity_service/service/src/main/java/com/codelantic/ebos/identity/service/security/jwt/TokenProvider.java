package com.codelantic.ebos.identity.service.security.jwt;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.config.AppProperties;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import io.jsonwebtoken.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class TokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(TokenProvider.class);

    private AppProperties appProperties;
    @Autowired
    private UserAuthenticationRepository userAuthenticationRepository;

    public TokenProvider(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public String createToken(Authentication authentication) {
        User user = (User) authentication.getPrincipal();

        Date now = new Date();

        Date expiryDate = new Date(now.getTime() + appProperties.getAuth().getTokenExpirationMsec());


        UserAuthentication userAuthentication = userAuthenticationRepository.findByEmail(user.getUsername()).orElseThrow(() -> new ServiceException("User not found","Bad request", HttpStatus.BAD_REQUEST));

        Map<String, Object> claims = new HashMap<>();
        claims.put("user_id",userAuthentication.getUserId());
        claims.put("user_type",userAuthentication.getUserType());


        return Jwts.builder().setSubject(user.getUsername()).setIssuedAt(new Date()).setExpiration(expiryDate)
                .addClaims(claims).signWith(SignatureAlgorithm.HS512, appProperties.getAuth().getTokenSecret()).compact();
    }

    public String getUserIdFromToken(String token) {
        Claims claims = Jwts.parser().setSigningKey(appProperties.getAuth().getTokenSecret()).parseClaimsJws(token).getBody();

        return (claims.getSubject());
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey(appProperties.getAuth().getTokenSecret()).parseClaimsJws(authToken);
            return true;
        } catch (SignatureException ex) {
            logger.error("Invalid JWT signature");
        } catch (MalformedJwtException ex) {
            logger.error("Invalid JWT token");
        } catch (ExpiredJwtException ex) {
            logger.error("Expired JWT token");
        } catch (UnsupportedJwtException ex) {
            logger.error("Unsupported JWT token");
        } catch (IllegalArgumentException ex) {
            logger.error("JWT claims string is empty.");
        }
        return false;
    }

    public Boolean validateRefreshToken(String refreshToken) {
        DecodedJWT decodedJWT = JWT.decode(refreshToken);

        validateToken(refreshToken);

        Date expirationTime = decodedJWT.getClaim("exp").asDate();
        Date currentTime = new Date(System.currentTimeMillis());

        Boolean isRefresh = decodedJWT.getClaim("refresh").asBoolean();

        if(isRefresh==null) {
            throw new ServiceException("Invalid refresh token", "Unauthorized", HttpStatus.UNAUTHORIZED);
        }

        if (currentTime.after(expirationTime)) {
            throw new ServiceException("Refresh token expired", "Forbidden", HttpStatus.FORBIDDEN);
        }

        return Boolean.TRUE;
    }


    public String createTokenFromRefreshToken(UserAuthentication userAuthentication) {
        Date now = new Date();

        Date expiryDate = new Date(now.getTime() + appProperties.getAuth().getTokenExpirationMsec());

        Map<String, Object> claims = new HashMap<>();
        claims.put("user_id", userAuthentication.getUserId());
        claims.put("user_type", userAuthentication.getUserType());


        return Jwts.builder().setSubject(userAuthentication.getEmail()).setIssuedAt(new Date()).setExpiration(expiryDate)
                .addClaims(claims).signWith(SignatureAlgorithm.HS512, appProperties.getAuth().getTokenSecret()).compact();
    }

    public String doGenerateToken(String subject, UserAuthentication userAuthentication) {
        Date now = new Date();

        Map<String, Object> claims = new HashMap<>();
        claims.put("refresh", true);
        claims.put("user_id", userAuthentication.getId());
        claims.put("user_name", userAuthentication.getUserName());

        Date expiryDate = new Date(now.getTime() + appProperties.getAuth().getRefreshTokenExpirationMsec());

        String jti = UUID.randomUUID().toString();

        return Jwts.builder().setClaims(claims).setSubject(subject).setId(jti).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(expiryDate).signWith(SignatureAlgorithm.HS512, appProperties.getAuth().getTokenSecret()).compact();
    }

}
