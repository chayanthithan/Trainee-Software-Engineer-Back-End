package com.codelantic.ebos.identity.service.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TwoFactorCodeDto {
    private String email;
}
