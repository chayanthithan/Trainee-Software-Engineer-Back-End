package com.codelantic.ebos.identity.service.security;


import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@Component
@RequiredArgsConstructor
@Slf4j
public class AuthenticationFilter extends OncePerRequestFilter {
    private final UserAuthenticationRepository userAuthenticationRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {



        String header = request.getHeader("Authorization");
        String url = String.valueOf(request.getRequestURL());

        String businessUrl = request.getHeader("Origin");

        if (businessUrl != null && businessUrl.startsWith("http://")) {
            businessUrl = businessUrl.substring(7);
        }
        if (businessUrl != null && businessUrl.startsWith("https://")) {
            businessUrl = businessUrl.substring(8);
        }

        if(url.contains("/auth") || url.contains("users-identity") || url.contains("two-factor-codes") ) {
            if(businessUrl!=null && businessUrl.contains("localhost:4200")) {
                businessUrl = request.getHeader("businessUrl");
            }
            Authentication authentication = new Authentication(null,null,null,businessUrl);
            AuthenticationContextHolder.setContext(authentication);
        }

        if (url.contains("api/v1/auth/validate2FA") || url.contains("api/v1/users-identity/updatePasswordOtp")) {

            if (header == null || !header.startsWith("Bearer ")) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.setContentType("application/json");
                String jsonResponse = "{\n" +
                        "    \"status\": 403,\n" +
                        "    \"message\": \"Forbidden\",\n" +
                        "    \"errors\": [\n" +
                        "        \"Forbidden\"\n" +
                        "    ]\n" +
                        "}";
                response.getWriter().write(jsonResponse);
                return;
            }

            String authToken = header.substring(7);
            DecodedJWT decodedJWT = JWT.decode(authToken);

            Date expirationTime = decodedJWT.getClaim("exp").asDate();
            Date currentTime = new Date(System.currentTimeMillis());


            if (currentTime.after(expirationTime)) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.setContentType("application/json");

                String jsonResponse = "{\n" +
                        "    \"status\": 401,\n" +
                        "    \"message\": \"Unauthorized\",\n" +
                        "    \"errors\": [\n" +
                        "        \"Token expired\"\n" +
                        "    ]\n" +
                        "}";
                response.getWriter().write(jsonResponse);
                return;
            }

            String email = decodedJWT.getClaim("sub").asString();
            UserAuthentication userAuthentication = userAuthenticationRepository.findByEmail(email).orElse(null);
            AuthenticationContextHolder.setContext(Authentication.builder()
                    .userId(userAuthentication.getUserId())
                    .userName(userAuthentication.getEmail())
                    .userType(userAuthentication.getUserType())
                            .businessUrl(businessUrl)
                    .build());
        }
        try {
            chain.doFilter(request, response);
        } catch (Exception e) {
            if (e instanceof ServletException) {
                throw (ServletException) e;
            }
        } finally {
            AuthenticationContextHolder.clearContext();
        }
    }
}