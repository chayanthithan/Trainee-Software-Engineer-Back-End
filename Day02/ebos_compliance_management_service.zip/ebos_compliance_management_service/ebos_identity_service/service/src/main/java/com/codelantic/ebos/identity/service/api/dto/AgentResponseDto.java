package com.codelantic.ebos.identity.service.api.dto;

import lombok.Data;

@Data
public class AgentResponseDto {
    private String message;

}
