package com.codelantic.ebos.identity.service.enums;

public enum ChannelType {
    EMAIL,
    MOBILE
}
