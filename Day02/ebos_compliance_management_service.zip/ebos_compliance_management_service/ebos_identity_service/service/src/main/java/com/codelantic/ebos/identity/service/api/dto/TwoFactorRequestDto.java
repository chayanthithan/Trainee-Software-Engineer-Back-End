package com.codelantic.ebos.identity.service.api.dto;

import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class TwoFactorRequestDto {
    //    @NotNull(message = "Channel Type must not be null")
    private ChannelType channelType;
    private String userId;
    //    @NotNull(message = "OTP Type is required")
    private OtpType otpType;
    @Email(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Invalid email format")
    private String email;
    private String username;
    private String password;
    private String twoFactorCode;
    private String grantType;
}
