package com.codelantic.ebos.identity.service.api.dto;

import com.codelantic.ebos.identity.service.enums.UserType;
import lombok.Data;

import javax.validation.constraints.Email;
import java.time.LocalDateTime;

@Data
public class UserAuthenticationDto {
    private String id;
    private LocalDateTime createdDateTime;
    @Email(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Invalid email format")
    private String email;
    private String userName;
    private String password;
    private String userId;
    private UserType userType;
    private String url;
}
