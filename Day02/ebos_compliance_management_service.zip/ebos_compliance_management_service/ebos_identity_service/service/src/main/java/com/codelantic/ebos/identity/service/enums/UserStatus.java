package com.codelantic.ebos.identity.service.enums;

public enum UserStatus {

    CREATED,
    ACTIVE,
    DE_ACTIVE,
    LOCKED;

    private UserStatus() {
    }
}
