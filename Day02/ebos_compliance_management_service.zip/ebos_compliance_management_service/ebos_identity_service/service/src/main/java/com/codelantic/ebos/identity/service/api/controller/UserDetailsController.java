package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.service.UserDetailService;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api/v1/users-details")
@RequiredArgsConstructor
@Validated
public class UserDetailsController {

    private final UserDetailService userDetailService;

    @GetMapping("/url")
    public String getUrlByOwnerId(@RequestParam(value = "ownerId") String ownerId) {
        return userDetailService.getUrlByOwnerId(ownerId);
    }


}
