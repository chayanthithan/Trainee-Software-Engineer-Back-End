package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.UserLoginDetailsDto;
import com.codelantic.ebos.identity.service.converter.UserAuthenticationConverter;
import com.codelantic.ebos.identity.service.converter.UserLoginDetailsConverter;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.entity.UserLoginDetails;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.repository.UserLoginDetailsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserLoginDetailsService {
    private final UserLoginDetailsRepository userLoginDetailsRepository;
    private final UserLoginDetailsConverter userLoginDetailsConverter;
    private final UserAuthenticationRepository userAuthenticationRepository;
    private final UserAuthenticationConverter userAuthenticationConverter;

    @Value("${lockedUser.invalidCount}")
    private String invalidLoginBlockCount;

    public UserLoginDetailsDto updateLastRecord(String userName, boolean isSuccess) {
        log.info("UserLoginDetailsService.updateLastRecord(userName) invoked.");
        UserLoginDetails userLoginDetails = userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(userName);
        if (userLoginDetails == null) {
            userLoginDetails = new UserLoginDetails();
            userLoginDetails.setUserName(userName);
        }
        userLoginDetails.setIsSuccess(isSuccess);
        userLoginDetails.setInvalidLoginCount(isSuccess ? 0 : userLoginDetails.getInvalidLoginCount());
        userLoginDetails.setLoginTime(LocalTime.now());
        userLoginDetails.setLoginDate(LocalDate.now());
        UserLoginDetails updatedUserLoginDetails = userLoginDetailsRepository.save(userLoginDetails);
        return userLoginDetailsConverter.convertToDTo(updatedUserLoginDetails);
    }

    public UserLoginDetailsDto save(String userName, String userIp, boolean isSuccess) {
        log.info("UserLoginDetailsService.save(userName, userIp) invoked.");

        UserLoginDetails lastUserLoginDetails = userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(userName);
        UserLoginDetailsDto userLoginDetailsDtoResult = lastUserLoginDetails != null
                ? userLoginDetailsConverter.convertToDTo(lastUserLoginDetails)
                : null;

        if (userLoginDetailsDtoResult != null) {
            updateExistingLoginDetails(userLoginDetailsDtoResult, userIp, isSuccess);
        } else {
            userLoginDetailsDtoResult = createNewLoginDetails(userName, userIp, isSuccess);
        }

        checkAndLockUser(userName,userLoginDetailsDtoResult);

        return userLoginDetailsDtoResult;
    }

    private void updateExistingLoginDetails(UserLoginDetailsDto userLoginDetailsDto, String userIp, boolean isSuccess) {
        if (!isSuccess) {
            int invalidLoginCount = userLoginDetailsDto.getInvalidLoginCount() != null
                    ? userLoginDetailsDto.getInvalidLoginCount() + 1
                    : 1;
            userLoginDetailsDto.setInvalidLoginCount(invalidLoginCount);
        } else {
            userLoginDetailsDto.setInvalidLoginCount(0);
        }

        userLoginDetailsDto.setUserIp(userIp);
        userLoginDetailsDto.setLoginDate(LocalDate.now());
        userLoginDetailsDto.setLoginTime(LocalTime.now());
        userLoginDetailsDto.setSuccess(isSuccess);

        UserLoginDetails userLoginDetails = userLoginDetailsConverter.convertToDomain(userLoginDetailsDto);
        userLoginDetailsRepository.save(userLoginDetails);
    }

    private UserLoginDetailsDto createNewLoginDetails(String userName, String userIp, boolean isSuccess) {
        UserLoginDetailsDto userLoginDetailsDto = new UserLoginDetailsDto();
        userLoginDetailsDto.setUserName(userName);
        userLoginDetailsDto.setUserIp(userIp);
        userLoginDetailsDto.setSuccess(isSuccess);
        userLoginDetailsDto.setInvalidLoginCount(isSuccess ? 0 : 1);
        userLoginDetailsDto.setLoginTime(LocalTime.now());
        userLoginDetailsDto.setLoginDate(LocalDate.now());

        UserLoginDetails userLoginDetails = userLoginDetailsConverter.convertToDomain(userLoginDetailsDto);
        userLoginDetailsRepository.save(userLoginDetails);

        return userLoginDetailsDto;
    }

    private void checkAndLockUser(String userName, UserLoginDetailsDto userLoginDetailsDto) {
        if (!userLoginDetailsDto.isSuccess()
                && userLoginDetailsDto.getInvalidLoginCount() >= Integer.parseInt(invalidLoginBlockCount)) {
            Optional<UserAuthentication> optionalUserAuthentication = userAuthenticationRepository.findByEmail(userName);
            if (optionalUserAuthentication.isPresent()) {
                UserAuthentication userAuthentication = optionalUserAuthentication.get();
                if (!Boolean.TRUE.equals(userAuthentication.getIsLocked())) {
                    userAuthentication.setIsLocked(Boolean.TRUE);
                    userAuthentication.setLockedDateTime(LocalDateTime.now());
                    userAuthenticationRepository.save(userAuthentication);
                }
            }
        }
    }
}
