package com.codelantic.ebos.identity.service;

import com.codelantic.bankoyo.notification.client.NotificationClientConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import({NotificationClientConfiguration.class})
public class Application {
    public static void main(String[] args) {

        SpringApplication.run(Application.class, args);

    }
}