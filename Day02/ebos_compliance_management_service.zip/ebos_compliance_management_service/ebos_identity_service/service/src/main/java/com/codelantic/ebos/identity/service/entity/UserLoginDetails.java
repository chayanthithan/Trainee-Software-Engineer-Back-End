package com.codelantic.ebos.identity.service.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Data
public class UserLoginDetails {

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private String userName;
    private String userIp;
    private LocalDate loginDate;
    private LocalTime loginTime;
    private Boolean isSuccess;
    private Integer invalidLoginCount;
}
