package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.constants.ApplicationConstants;
import com.codelantic.ebos.identity.service.converter.UserAuthenticationConverter;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.enums.UserType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.security.jwt.TokenProvider;
import com.codelantic.ebos.identity.service.service.util.HttpReqRespUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final TokenProvider tokenProvider;
    private final UserAuthenticationRepository userAuthenticationRepository;
    private final TwoFactorCodeService twoFactorCodeService;
    private final UserAuthenticationConverter userAuthenticationConverter;
    private final UserLoginDetailsService userLoginDetailsService;
    @Value("${reset.password.redirection.url}")
    private String resetPasswordRedirectionUrl;

    @Value("${url.domain}")
    private String urlDomain;


    public ResponseEntity<Object> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) throws AuthenticationException {

        validateBusinessUrl(loginRequest);

        UserAuthentication user = userAuthenticationRepository.findByEmailAndUrl(loginRequest.getUsername(),loginRequest.getUrl())
                .orElseThrow(() -> new ServiceException("Invalid credentials, please ensure to enter the correct credentials.", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        if (!user.getUserType().equals(UserType.OWNER) && !user.getUserType().equals(UserType.STAFF)) {
            throw new ServiceException("Your user type is not authorized to login to this portal", ApplicationConstants.UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
        }
        if (user.getIsLocked() != null && user.getIsLocked().equals(Boolean.TRUE)) {
            throw new ServiceException("The Credentials you entered are invalid. Your account will be blocked due to three invalid login attempts, and you will not have access to the account again.", ApplicationConstants.UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
        }
        return generateToken(loginRequest,user);
    }

    public Boolean authenticate2FA(@Valid @RequestBody LoginRequest loginRequest) {

        validateBusinessUrl(loginRequest);

        UserAuthentication userAuthentication = userAuthenticationRepository.findByEmail(loginRequest.getUsername()).orElseThrow(() -> new ServiceException(ApplicationConstants.USER_NOT_FOUND, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);
        twoFactorRequestDto.setUsername(loginRequest.getUsername());
        twoFactorRequestDto.setTwoFactorCode(loginRequest.getTwoFactorCode());
        twoFactorRequestDto.setUserId(userAuthentication.getUserId());
        twoFactorCodeService.validate(twoFactorRequestDto);
        userAuthenticationRepository.save(userAuthentication);
        return true;
    }

    private void validateBusinessUrl(LoginRequest loginRequest) {
        if(AuthenticationContextHolder.getContext().getBusinessUrl()!=null) {
            String url = trimUrl(AuthenticationContextHolder.getContext().getBusinessUrl());
            loginRequest.setUrl(url);
        }else {
            throw new ServiceException("Business url is required","Bad request", HttpStatus.BAD_REQUEST);
        }
        if(!userAuthenticationRepository.existsByUrl(loginRequest.getUrl())){
            throw new ServiceException("Not found","Not found", HttpStatus.NOT_FOUND);
        }
    }

    private ResponseEntity<Object> generateToken(LoginRequest loginRequest,UserAuthentication userAuthentication) throws AuthenticationException {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = tokenProvider.createToken(authentication);
            String refreshToken = tokenProvider.doGenerateToken(loginRequest.getUsername(),userAuthentication);

            userLoginDetailsService.updateLastRecord(loginRequest.getUsername(), Boolean.TRUE);
            return ResponseEntity.ok(new JwtAuthenticationResponse(jwt, refreshToken));
        } catch (DisabledException e) {
            throw new DisabledException("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            userLoginDetailsService.save(loginRequest.getUsername(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), false);
            throw new ServiceException("Invalid credentials, please ensure to enter the correct credentials.", ApplicationConstants.UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
        }
    }

    public UserAuthentication save(UserAuthenticationDto userAuthenticationDto) {
        return userAuthenticationRepository.save(userAuthenticationConverter.convert(userAuthenticationDto));
    }

    public UserAuthentication getById(String id) {
        return userAuthenticationRepository.findByUserId(id).orElseThrow(() -> new ServiceException(ApplicationConstants.USER_NOT_FOUND, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
    }

    public ResponseEntity<Object> refreshToken(RefreshTokenRequest refreshTokenRequest) {
        String refreshToken = refreshTokenRequest.getRefreshToken();

        if (!tokenProvider.validateRefreshToken(refreshToken).equals(Boolean.TRUE)) {
            throw new ServiceException("Invalid refresh token", "Unauthorized", HttpStatus.UNAUTHORIZED);
        }

        String username = tokenProvider.getUserIdFromToken(refreshToken);
        UserAuthentication userAuthentication = userAuthenticationRepository.findByEmail(username).orElseThrow(() -> new ServiceException("User not found", "Bad request", HttpStatus.BAD_REQUEST));

        if (userAuthentication == null) {
            throw new ServiceException("User not found", "Unauthorized", HttpStatus.UNAUTHORIZED);
        }

        String jwt = tokenProvider.createTokenFromRefreshToken(userAuthentication);
        refreshToken = tokenProvider.doGenerateToken(userAuthentication.getEmail(),  userAuthentication);

        // Return response with new tokens
        return ResponseEntity.ok(new JwtAuthenticationResponse(jwt, refreshToken));
    }

    public Boolean isBusinessUrlValid(String url) {
        String trimmedUrl = trimUrl(url);

        if(trimmedUrl != null && trimmedUrl.equals(urlDomain)) {
            return Boolean.FALSE;
        }

        if (userAuthenticationRepository.existsByUrl(trimmedUrl)) {
            return Boolean.TRUE;
        }
        throw new ServiceException("Page not found","Page not found",HttpStatus.FORBIDDEN);
    }

    private String trimUrl(String url) {
        if (url != null && url.startsWith("http://")) {
            url = url.substring(7);
        }
        if (url != null && url.startsWith("https://")) {
            url = url.substring(8);
        }
        return url;
    }

    public UrlDto validateBusinessNameUrl(String businessName) {
        int count = 0;
        String url = nameUrl(businessName,count);
        return new UrlDto(url);


    }
    private String nameUrl(String businessName, int count){
        businessName = businessName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

        if(businessName.isBlank()) {
           return businessName;
        }

        String businessUrl = businessName+ (count==0?"":count)+"."+urlDomain;
        if(isBusinessUrlExist(businessUrl).equals(Boolean.FALSE)){
            return businessUrl.toLowerCase();
        }

        return nameUrl(businessName,count+1);
    }

    private Boolean isBusinessUrlExist(String url) {
        String trimmedUrl = trimUrl(url);

        if (userAuthenticationRepository.existsByUrl(trimmedUrl)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean isUrlExist(String url) {
        if (url != null && url.startsWith("http://")) {
            url = url.substring(7);
        }
        if (url != null && url.startsWith("https://")) {
            url = url.substring(8);
        }
        if (userAuthenticationRepository.existsByUrl(url)) {
            throw new ServiceException("Business url already exist", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        return Boolean.FALSE;
    }
}