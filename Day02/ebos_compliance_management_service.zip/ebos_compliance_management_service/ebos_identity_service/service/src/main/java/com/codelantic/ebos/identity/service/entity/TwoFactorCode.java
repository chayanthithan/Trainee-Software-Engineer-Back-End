package com.codelantic.ebos.identity.service.entity;

import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.enums.TokenStatus;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
public class TwoFactorCode {

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private String email;
    @Enumerated(EnumType.STRING)
    private TokenStatus tokenStatus;
    private String userId;
    @Enumerated(EnumType.STRING)
    private ChannelType channelType;
    @Enumerated(EnumType.STRING)
    private OtpType otpType;
    private String twoFactorCode;
    private LocalDateTime createdDateTime;
    private LocalDateTime expiryDateTime;
    private String verificationToken;
    @Enumerated(EnumType.STRING)
    private TokenStatus verificationTokenStatus;


}
