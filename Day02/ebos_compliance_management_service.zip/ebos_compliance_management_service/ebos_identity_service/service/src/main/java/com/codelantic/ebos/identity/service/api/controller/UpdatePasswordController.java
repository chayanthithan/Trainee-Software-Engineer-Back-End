package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.AgentResponseDto;
import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.service.UserDetailService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/updatePassword")
@RequiredArgsConstructor
public class UpdatePasswordController {

    private final UserDetailService userDetailService;

    @PostMapping("/updatePasswordOtp")
    public AgentResponseDto updatePasswordOtpSend(@RequestBody TwoFactorRequestDto twoFactorRequestDto) {
        return userDetailService.updatePasswordOtpSend(twoFactorRequestDto);
    }
}
