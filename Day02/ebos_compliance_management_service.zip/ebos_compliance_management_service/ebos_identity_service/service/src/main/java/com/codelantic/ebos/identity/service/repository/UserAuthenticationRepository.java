package com.codelantic.ebos.identity.service.repository;

import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Modifying;

import java.util.Optional;
import org.springframework.data.repository.query.Param;
@Repository
public interface UserAuthenticationRepository extends JpaRepository<UserAuthentication, String> {

    Optional<UserAuthentication> findByUserId(String userId);

    Optional<UserAuthentication> findByEmail(String email);
    Optional<UserAuthentication> findByEmailAndUrl(String email,String url);
    @Transactional
    @Modifying
    @Query("DELETE FROM UserAuthentication ua WHERE ua.userId = :id")
    void deleteUserById(@Param("id") String id);

    boolean existsByUrl(String url);

    @Query("SELECT u.url FROM UserAuthentication u WHERE u.userId=:ownerId")
    String getUrlByOwnerId(@Param("ownerId") String ownerId);
}
