package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.UserAuthenticationDto;
import com.codelantic.ebos.identity.service.config.SecurityConfig;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserAuthenticationConverter {

    private final SecurityConfig securityConfig;

    public UserAuthentication convert(UserAuthenticationDto userAuthenticationDto) {
        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setId(userAuthenticationDto.getId());
        userAuthentication.setUserId(userAuthenticationDto.getUserId());
        userAuthentication.setUserName(userAuthenticationDto.getUserName());
        userAuthentication.setUserType(userAuthenticationDto.getUserType());
        userAuthentication.setPassword(securityConfig.passwordEncoder().encode(userAuthenticationDto.getPassword()));
        userAuthentication.setCreatedDateTime(userAuthenticationDto.getCreatedDateTime());
        userAuthentication.setEmail(userAuthenticationDto.getEmail());
        userAuthentication.setUrl(userAuthenticationDto.getUrl());
        return userAuthentication;
    }
}

