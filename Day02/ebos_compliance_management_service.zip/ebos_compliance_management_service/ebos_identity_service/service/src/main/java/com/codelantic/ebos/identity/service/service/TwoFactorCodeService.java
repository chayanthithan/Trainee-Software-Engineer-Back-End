package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.AgentResponseDto;
import com.codelantic.ebos.identity.service.api.dto.ResponseDto;
import com.codelantic.ebos.identity.service.api.dto.TwoFactorCodeDto;
import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.constants.ApplicationConstants;
import com.codelantic.ebos.identity.service.converter.TwoFactorCodeConverter;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.enums.TokenStatus;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.TwoFactorCodeRepository;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.service.support.EmailTemplateGenerator;
import com.codelantic.ebos.identity.service.service.support.TwoFactorCodeGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import static com.codelantic.ebos.identity.service.service.UserDetailService.NOT_FOUND;

@Slf4j
@Service
@RequiredArgsConstructor
public class TwoFactorCodeService {

    public static final String BAD_REQUEST = "Bad request";
    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String YOUR_USER_TYPE_IS_NOT_AUTHORIZED_TO_THIS_PORTAL = "Your user type is not authorized to this portal";
    public static final String USER_NOT_FOUND = "User Not Found";
    private final UserAuthenticationRepository userAuthenticationRepository;
    private final TwoFactorCodeRepository twoFactorCodeRepository;
    private final TwoFactorCodeConverter twoFactorCodeConverter;
    private final TwoFactorCodeGenerator twoFactorCodeGenerator;
    private final EmailTemplateGenerator emailTemplateGenerator;

    @Value("${two.factor.code.timeout.minutes}")
    private int twoFactorCodeTimeoutMinutes;

    public AgentResponseDto createAndSend(TwoFactorRequestDto twoFactorRequestDto) {
        validateBusinessUrl();

        UserAuthentication userAuthentication = null;
        AgentResponseDto agentResponseDto = new AgentResponseDto();


        if (twoFactorRequestDto.getOtpType().equals(OtpType.SIGN_IN)) {
            validateEmail(twoFactorRequestDto.getUsername());
            userAuthentication = userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getUsername(), AuthenticationContextHolder.getContext().getBusinessUrl()).
                    orElseThrow(() -> new ServiceException(USER_NOT_FOUND, BAD_REQUEST, HttpStatus.BAD_REQUEST));
            if (!twoFactorRequestDto.getGrantType().equals(String.valueOf(userAuthentication.getUserType()))) {
                throw new ServiceException(YOUR_USER_TYPE_IS_NOT_AUTHORIZED_TO_THIS_PORTAL, UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
            }

            if (!userAuthentication.getUserName().equals(twoFactorRequestDto.getUsername())) {
                throw new ServiceException("Username mismatch: The provided username does not match the authenticated user", BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
            twoFactorRequestDto.setUserId(userAuthentication.getUserId());
            twoFactorRequestDto.setEmail(userAuthentication.getEmail());

            String password = twoFactorRequestDto.getPassword(); // Password entered during login
            boolean passwordMatch = BCrypt.checkpw(password, userAuthentication.getPassword());

            if (!passwordMatch)
                throw new ServiceException("Invalid Credentials", BAD_REQUEST, HttpStatus.UNAUTHORIZED);
        } else if (twoFactorRequestDto.getOtpType().equals(OtpType.RESET_PASSWORD)) {
            validateEmail(twoFactorRequestDto.getUsername());
            userAuthentication = userAuthenticationRepository.findByEmail(twoFactorRequestDto.getUsername()).
                    orElseThrow(() -> new ServiceException(USER_NOT_FOUND, BAD_REQUEST, HttpStatus.BAD_REQUEST));
            if (!twoFactorRequestDto.getGrantType().equals(String.valueOf(userAuthentication.getUserType()))) {
                throw new ServiceException(YOUR_USER_TYPE_IS_NOT_AUTHORIZED_TO_THIS_PORTAL, UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
            }
            twoFactorRequestDto.setUserId(userAuthentication.getUserId());
            twoFactorRequestDto.setEmail(userAuthentication.getEmail());

        } else if (twoFactorRequestDto.getOtpType().equals(OtpType.UPDATE_PASSWORD)) {
            userAuthentication = createAndSendUpdatePassword(twoFactorRequestDto);
        }
        updateUnusedTwoFactorCodesByUserId(twoFactorRequestDto);
        //save twoFactorCode
        TwoFactorCode twoFactorCode = twoFactorCodeConverter.convert(twoFactorRequestDto);
        twoFactorCode.setTwoFactorCode(twoFactorCodeGenerator.generateTwoFactorCode());
        twoFactorCode.setCreatedDateTime(LocalDateTime.now());
        twoFactorCode.setExpiryDateTime(LocalDateTime.now().plusSeconds(twoFactorCodeTimeoutMinutes * 60L));
        twoFactorCode.setTokenStatus(TokenStatus.CREATED);
        twoFactorCodeRepository.save(twoFactorCode);

        if (twoFactorRequestDto.getChannelType().equals(ChannelType.EMAIL)) {
            emailTemplateGenerator.forgotPasswordOtpEmailSend(twoFactorCode, userAuthentication);
        } else {
            throw new ServiceException("other channel types not implemented", BAD_REQUEST, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        agentResponseDto.setMessage(ApplicationConstants.TWOFACTOR_CODE_SEND_SUCCESSFULLY);
        return agentResponseDto;
    }

    private UserAuthentication createAndSendUpdatePassword(TwoFactorRequestDto twoFactorRequestDto) {
        validateBusinessUrl();
        UserAuthentication userAuthentication;
        validateEmail(twoFactorRequestDto.getUsername());
        userAuthentication = userAuthenticationRepository.findByEmail(twoFactorRequestDto.getUsername()).
                orElseThrow(() -> new ServiceException(USER_NOT_FOUND, BAD_REQUEST, HttpStatus.BAD_REQUEST));

        if (!twoFactorRequestDto.getGrantType().equals(String.valueOf(userAuthentication.getUserType()))) {
            throw new ServiceException(YOUR_USER_TYPE_IS_NOT_AUTHORIZED_TO_THIS_PORTAL, UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
        }
        twoFactorRequestDto.setUserId(userAuthentication.getUserId());
        twoFactorRequestDto.setEmail(userAuthentication.getEmail());

        boolean passwordMatch = BCrypt.checkpw(twoFactorRequestDto.getPassword(), userAuthentication.getPassword());
        if (!passwordMatch)
            throw new ServiceException("Invalid Credentials", BAD_REQUEST, HttpStatus.UNAUTHORIZED);
        return userAuthentication;
    }

    public ResponseDto validate(TwoFactorRequestDto twoFactorRequestDto) {
        validateBusinessUrl();


        ResponseDto responseDto = new ResponseDto();
        TwoFactorCode twoFactorCodeForValidate = null;

        UserAuthentication userAuthentication = null;

        if (twoFactorRequestDto.getEmail() != null) {
            userAuthentication = userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getEmail(), AuthenticationContextHolder.getContext().getBusinessUrl())
                    .orElseThrow(() -> new ServiceException(USER_NOT_FOUND, BAD_REQUEST, HttpStatus.BAD_REQUEST));
        }

        if (userAuthentication != null) {
            if (!twoFactorRequestDto.getOtpType().equals(OtpType.SIGN_IN) && !twoFactorRequestDto.getOtpType().equals(OtpType.SIGN_UP) && !twoFactorRequestDto.getOtpType().equals(OtpType.RESET_PASSWORD)) {
                validateUserId(twoFactorRequestDto.getUserId());
            }
            /** validate using email and otp type */
            twoFactorCodeForValidate = twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode()).orElseThrow(() -> new ServiceException("Please enter a valid OTP", BAD_REQUEST, HttpStatus.BAD_REQUEST));
            if (twoFactorCodeForValidate != null && LocalDateTime.now().isBefore(twoFactorCodeForValidate.getExpiryDateTime())) {
                log.info("two factor code validated");
                twoFactorCodeForValidate.setTokenStatus(TokenStatus.USED);
                twoFactorCodeForValidate.setVerificationToken(UUID.randomUUID().toString());
                twoFactorCodeForValidate.setVerificationTokenStatus(TokenStatus.CREATED);
                twoFactorCodeRepository.save(twoFactorCodeForValidate);
                responseDto.setMessage("Authentication successful");
                responseDto.setAuthenticationToken(twoFactorCodeForValidate.getVerificationToken());
            } else {
                throw new ServiceException("two factor code expired", BAD_REQUEST, HttpStatus.BAD_REQUEST);
            }
        }
        return responseDto;
    }

    public void updateUnusedTwoFactorCodesByUserId(TwoFactorRequestDto twoFactorRequestDto) {
        List<TwoFactorCode> twoFactorCodeList = twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getUserId()).orElseThrow(() -> new NoSuchElementException("No such two factor code " + twoFactorRequestDto.getTwoFactorCode()));
        if (twoFactorCodeList != null) {
            for (TwoFactorCode twoFactorCode : twoFactorCodeList) {
                twoFactorCode.setTokenStatus(TokenStatus.UNUSED);
                twoFactorCodeRepository.save(twoFactorCode);
            }
        }
    }


    private void validateEmail(String email) {
        if (email == null || email.isEmpty()) {
            throw new ServiceException("Email required", BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    private void validateUserId(String userId) {
        if (userId == null || userId.isEmpty()) {
            throw new ServiceException("User Id required", BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
    }

    public void updateUnusedTwoFactorCodesByEmail(TwoFactorRequestDto twoFactorRequestDto) {
        List<TwoFactorCode> twoFactorCodeList = twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmail(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getEmail()).orElseThrow(() -> new NoSuchElementException("No such two factor code " + twoFactorRequestDto.getTwoFactorCode()));
        if (twoFactorCodeList != null) {
            for (TwoFactorCode twoFactorCode : twoFactorCodeList) {
                twoFactorCode.setTokenStatus(TokenStatus.UNUSED);
                twoFactorCodeRepository.save(twoFactorCode);
            }
        }
    }

    public ResponseDto signUpOtpSend(String email) {
        /* Check if the email is already registered in the system */
        Optional<UserAuthentication> userAuthentication = userAuthenticationRepository.findByEmail(email);
        if (userAuthentication.isPresent()) {
            /* If the email is already in use, throw a ServiceException with an appropriate message */
            throw new ServiceException(ApplicationConstants.EMAIL_ALREADY_USED, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_UP);
        twoFactorRequestDto.setEmail(email);

        /* Update any unused two-factor codes  */
        updateUnusedTwoFactorCodesByEmail(twoFactorRequestDto);

        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode(twoFactorCodeGenerator.generateTwoFactorCode());
        twoFactorCode.setCreatedDateTime(LocalDateTime.now());
        twoFactorCode.setExpiryDateTime(LocalDateTime.now().plusSeconds(twoFactorCodeTimeoutMinutes * 60L));
        twoFactorCode.setTokenStatus(TokenStatus.CREATED);
        twoFactorCode.setChannelType(ChannelType.EMAIL);
        twoFactorCode.setOtpType(OtpType.SIGN_UP);
        twoFactorCode.setEmail(email);

        twoFactorCodeRepository.save(twoFactorCode);

        /* Send the OTP to the user's email using the email template generator */
        emailTemplateGenerator.signUpOtpEmailSend(twoFactorCode);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage(ApplicationConstants.TWOFACTOR_CODE_SEND_SUCCESSFULLY);

        return responseDto;

    }

    public ResponseDto forgotOrChangePasswordOtpEmail(String email) {
        validateBusinessUrl();
        ResponseDto responseDto = new ResponseDto();
        UserAuthentication userAuthentication = userAuthenticationRepository.findByEmail(email).
                orElseThrow(() -> new ServiceException("Invalid email address, please enter the valid business email address", NOT_FOUND, HttpStatus.BAD_REQUEST));

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setUserId(userAuthentication.getUserId());
        twoFactorRequestDto.setUsername(userAuthentication.getEmail());
        twoFactorRequestDto.setPassword(userAuthentication.getPassword());
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setGrantType(userAuthentication.getUserType().toString());
        createAndSend(twoFactorRequestDto);
        responseDto.setMessage("Two factor code sent successfully!");

        return responseDto;
    }

    public List<TwoFactorCodeDto> getTwofacterForSignUp(String email, String twoFactorCode) {
        LocalDateTime createdDateTime = LocalDateTime.now().minusMinutes(10);
        LocalDateTime endDateTime = LocalDateTime.now();
        TokenStatus tokenStatus = TokenStatus.USED;
        ChannelType channelType = ChannelType.EMAIL;
        OtpType otpType = OtpType.SIGN_UP;
        return twoFactorCodeRepository.getTwofacterForSignUp(email, twoFactorCode, createdDateTime, endDateTime, tokenStatus, channelType, otpType);

    }


    private void validateBusinessUrl() {
        String businessUrl = null;
        if (AuthenticationContextHolder.getContext().getBusinessUrl() != null) {
            businessUrl = AuthenticationContextHolder.getContext().getBusinessUrl();
        } else {
            throw new ServiceException("Business url is required", BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (businessUrl != null && businessUrl.startsWith("http://")) {
            businessUrl = businessUrl.substring(7);
        }
        if (businessUrl != null && businessUrl.startsWith("https://")) {
            businessUrl = businessUrl.substring(8);
        }
        if (!userAuthenticationRepository.existsByUrl(businessUrl)) {
            throw new ServiceException("Not found", "Not found", HttpStatus.NOT_FOUND);
        }
    }


    public ResponseDto isOtpVerified(TwoFactorRequestDto twoFactorRequestDto, String verificationToken) {
        TwoFactorCode twoFactorCode = twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndVerificationTokenAndVerificationTokenStatus(twoFactorRequestDto.getOtpType(), TokenStatus.USED,
                        twoFactorRequestDto.getEmail(), verificationToken, TokenStatus.CREATED)
                .orElseThrow(() -> new ServiceException(ApplicationConstants.UNAUTHORIZED, ApplicationConstants.UNAUTHORIZED, HttpStatus.UNAUTHORIZED));
        twoFactorCode.setVerificationTokenStatus(TokenStatus.USED);
        twoFactorCodeRepository.save(twoFactorCode);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("otp verification success");
        return responseDto;
    }

    public ResponseDto validateSignUpOtp(TwoFactorRequestDto twoFactorRequestDto) {
        ResponseDto responseDto = new ResponseDto();
        TwoFactorCode twoFactorCode = null;


        /** validate using email and otp type */
        twoFactorCode = twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode()).orElseThrow(() -> new ServiceException("Incorrect code, please enter the valid code that was sent to "+twoFactorRequestDto.getEmail(), BAD_REQUEST, HttpStatus.BAD_REQUEST));
        if (twoFactorCode != null && LocalDateTime.now().isBefore(twoFactorCode.getExpiryDateTime())) {
            log.info("two factor code validated");
            twoFactorCode.setTokenStatus(TokenStatus.USED);
            twoFactorCode.setVerificationToken(UUID.randomUUID().toString());
            twoFactorCode.setVerificationTokenStatus(TokenStatus.CREATED);
            twoFactorCodeRepository.save(twoFactorCode);
            responseDto.setMessage("Authentication successful");
            responseDto.setAuthenticationToken(twoFactorCode.getVerificationToken());
        } else {
            throw new ServiceException("two factor code expired", BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }

        return responseDto;
    }

}
