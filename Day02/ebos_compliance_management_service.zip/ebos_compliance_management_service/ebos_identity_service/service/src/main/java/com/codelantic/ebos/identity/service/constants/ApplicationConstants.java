package com.codelantic.ebos.identity.service.constants;

public interface ApplicationConstants {


    static final String BAD_REQUEST = "Bad Request";

    static final String USER_NOT_FOUND = "User Not Found";
    static final String UNAUTHORIZED = "Unauthorized";
    static final String EMAIL_ALREADY_USED="Please enter a different email address, as the one provided is already in use.";

    static final String TWOFACTOR_CODE_SEND_SUCCESSFULLY="Two factor code sent successfully!";
    static final String INVALID_CREDENTIALS = "Invalid Credentials";
    public static final String EMAIL_SEND_FAILED_MESSAGE = "Email send failed";


}
