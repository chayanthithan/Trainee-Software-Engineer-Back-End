package com.codelantic.ebos.identity.service.service.support;

import com.codelantic.ebos.identity.service.enums.OtpType;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class OTPTemplateContentGenerator {

    public static final String TEMPLATE_NAME_KEY = "templateName";
    public static final String CONFIRMATION_CODE_TEMPLATE_NAME = "2fa_confirmation_code";
    public Map<String, String> generateOtpTemplateContent(OtpType otpType) {
        Map<String, String> otpTypeTemplateContent = new HashMap<>();
        if (otpType.equals(OtpType.SIGN_IN)) {
            otpTypeTemplateContent.put("subject", "Login Confirmation Code");
            otpTypeTemplateContent.put(TEMPLATE_NAME_KEY, CONFIRMATION_CODE_TEMPLATE_NAME);
        } else if (otpType.equals(OtpType.UPDATE_PASSWORD)) {
            otpTypeTemplateContent.put("subject", "Update Password Activation Code");
            otpTypeTemplateContent.put(TEMPLATE_NAME_KEY, CONFIRMATION_CODE_TEMPLATE_NAME);
        }else if (otpType.equals(OtpType.RESET_PASSWORD)) {
            otpTypeTemplateContent.put("subject","🔃Reset Password - OTP Verification for Your EBOS Account! 🔑");
            otpTypeTemplateContent.put(TEMPLATE_NAME_KEY, CONFIRMATION_CODE_TEMPLATE_NAME);
        }
        return otpTypeTemplateContent;
    }
}
