package com.codelantic.ebos.identity.service.service.support;

import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class TwoFactorCodeGenerator {

    public String generateTwoFactorCode() {
        SecureRandom random = new SecureRandom();
        int otp = random.nextInt(10000);
        return String.format("%04d", otp);
    }
}
