package com.codelantic.ebos.identity.service.service;

import com.codelantic.bankoyo.notification.client.NotificationClient;
import com.codelantic.bankoyo.notification.client.dto.EmailDataDto;
import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.config.SecurityConfig;
import com.codelantic.ebos.identity.service.constants.ApplicationConstants;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@Slf4j
@RequiredArgsConstructor
public class UserDetailService implements UserDetailsService {


    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String NOT_FOUND = "Not Found";
    public static final String USER_NOT_FOUND = "User not found";
    private final UserAuthenticationRepository userAuthenticationRepository;
    private final TwoFactorCodeService twoFactorCodeService;
    private final SecurityConfig securityConfig;
    private final NotificationClient notificationClient;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        UserAuthentication user = userAuthenticationRepository.findByEmail(userName).orElseThrow(() -> new ServiceException("User " + userName + " was not found", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));
        return new User(user.getEmail(), user.getPassword(), Arrays.asList());
    }

    public AgentResponseDto updatePasswordOtpSend(TwoFactorRequestDto twoFactorRequestDto) {
        validateBusinessUrl();
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setOtpType(OtpType.UPDATE_PASSWORD);
        return twoFactorCodeService.createAndSend(twoFactorRequestDto);
    }

    public Boolean updateUserPassword(AuthenticationDto authenticationDto) {
        validateBusinessUrl();
        Boolean isUserDetailsUpdated = false;
        UserAuthentication authentication = userAuthenticationRepository.findByUserId(authenticationDto.getUserId()).orElseThrow(() ->
                new ServiceException("User Not Found", UNAUTHORIZED, HttpStatus.UNAUTHORIZED));

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setTwoFactorCode(authenticationDto.getTwoFactorCode());
        twoFactorRequestDto.setOtpType(OtpType.UPDATE_PASSWORD);
        twoFactorRequestDto.setUserId(authenticationDto.getUserId());
        twoFactorCodeService.validate(twoFactorRequestDto);

        if (BCrypt.checkpw(authenticationDto.getOldPassword(), authentication.getPassword())) {
            throw new ServiceException("Your previous password is wrong", UNAUTHORIZED, HttpStatus.UNAUTHORIZED);
        }

        authentication.setPassword(securityConfig.passwordEncoder().encode(authenticationDto.getPassword()));
        userAuthenticationRepository.save(authentication);
        isUserDetailsUpdated = true;


        return isUserDetailsUpdated;
    }

    public ResponseDto updatePassword(ResetPasswordDto resetPasswordDto) {
        validateBusinessUrl();
        ResponseDto isValid = null;
        ResponseDto agentResponseDto = new ResponseDto();

        if (resetPasswordDto.getUserAuthentication() == null || resetPasswordDto.getUserAuthentication().getEmail() == null || resetPasswordDto.getUserAuthentication().getEmail().isEmpty() || resetPasswordDto.getUserAuthentication().getEmail().isBlank()) {
            throw new ServiceException("Email Id is Required",ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        else {
            UserAuthentication userAuthenticationByEmail = userAuthenticationRepository.findByEmail(resetPasswordDto.getUserAuthentication().getEmail())
                    .orElseThrow(() -> new ServiceException(USER_NOT_FOUND, ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST));

            TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();

                if (resetPasswordDto.getIsUpdatePassword() != null && resetPasswordDto.getIsUpdatePassword()) {
                    twoFactorRequestDto.setOtpType(OtpType.UPDATE_PASSWORD);
                    String userId = userAuthenticationByEmail.getUserId();
                    twoFactorRequestDto.setUserId(userId);
                    twoFactorRequestDto.setEmail(userAuthenticationByEmail.getEmail());
                    twoFactorRequestDto.setTwoFactorCode(resetPasswordDto.getTwoFactorCode());
                    isValid = twoFactorCodeService.validate(twoFactorRequestDto);
                } else {
                    if (resetPasswordDto.getVerificationToken() == null || resetPasswordDto.getVerificationToken().isEmpty() || resetPasswordDto.getVerificationToken().isBlank()) {
                        throw new ServiceException("Verification token is required", ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
                    }
                    twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
                    twoFactorRequestDto.setEmail(userAuthenticationByEmail.getEmail());
                    isValid = twoFactorCodeService.isOtpVerified(twoFactorRequestDto, resetPasswordDto.getVerificationToken());
                }

                if (isValid != null && !isValid.getMessage().isBlank()) {
                    userAuthenticationByEmail.setPassword(securityConfig.passwordEncoder().encode(resetPasswordDto.getPassword()));
                    userAuthenticationByEmail.setIsLocked(Boolean.FALSE);
                    log.info("User Authentication Object : {}" + userAuthenticationByEmail);
                    userAuthenticationRepository.save(userAuthenticationByEmail);
                    agentResponseDto.setMessage("Password Changed");
                }
            }

        return agentResponseDto;
    }

    public ResponseDto deleteUser(String id) {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("Your account has been deleted successfully.");
        userAuthenticationRepository.deleteUserById(id);
        return responseDto;
    }


    public ResponseDto resetPassword(ResetPasswordDto resetPasswordDto) {

        log.info("resetPassword-------{}", resetPasswordDto.getUserAuthentication());
        ResponseDto responseDto = updatePassword(resetPasswordDto);

        EmailDataDto emailDataDto = new EmailDataDto();
        emailDataDto.setRecipients(List.of(resetPasswordDto.getUserAuthentication().getEmail()));
        emailDataDto.setServiceProvider("ebos");
        emailDataDto.setSubject("\uD83D\uDD12 Your Password Has Been Changed");
        emailDataDto.setMailTemplateName("password_change_confirmation");
        Map<String, Object> emailDataData = new HashMap<>();

        Optional<UserAuthentication> userAuthentication=userAuthenticationRepository.findByEmail(resetPasswordDto.getUserAuthentication().getEmail());

        emailDataData.put("userName", userAuthentication.get().getUserName());
        emailDataDto.setData(emailDataData);
        try {
            notificationClient.send(emailDataDto);
        } catch (Exception e) {
            log.info(ApplicationConstants.EMAIL_SEND_FAILED_MESSAGE);
            throw new ServiceException(ApplicationConstants.EMAIL_SEND_FAILED_MESSAGE, ApplicationConstants.EMAIL_SEND_FAILED_MESSAGE, HttpStatus.SERVICE_UNAVAILABLE);
        }
        return responseDto;
    }

    private void validateBusinessUrl() {
        String businessUrl = null;
        if(AuthenticationContextHolder.getContext().getBusinessUrl()!=null) {
            businessUrl = AuthenticationContextHolder.getContext().getBusinessUrl();
        }else {
            throw new ServiceException("Business url is required",ApplicationConstants.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        if (businessUrl != null && businessUrl.startsWith("http://")) {
            businessUrl = businessUrl.substring(7);
        }
        if (businessUrl != null && businessUrl.startsWith("https://")) {
            businessUrl = businessUrl.substring(8);
        }
        if(!userAuthenticationRepository.existsByUrl(businessUrl)){
            throw new ServiceException("Not found","Not found", HttpStatus.NOT_FOUND);
        }
    }

    public String getUrlByOwnerId(String ownerId){
        return userAuthenticationRepository.getUrlByOwnerId(ownerId);
    }
}
