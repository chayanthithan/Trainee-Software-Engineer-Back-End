package com.codelantic.ebos.identity.service.service.util;

import com.codelantic.ebos.identity.service.api.dto.LocalUser;
import com.codelantic.ebos.identity.service.api.dto.UserInfo;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;

import java.util.List;
import java.util.stream.Collectors;

public class GeneralUtils {

    public static UserInfo buildUserInfo(LocalUser localUser) {
        List<String> roles = localUser.getAuthorities().stream().map(item -> item.getAuthority()).collect(Collectors.toList());
        UserAuthentication user = localUser.getUser();
        return new UserInfo(user.getId().toString(), user.getUserId(), user.getEmail(), roles);
    }
}
