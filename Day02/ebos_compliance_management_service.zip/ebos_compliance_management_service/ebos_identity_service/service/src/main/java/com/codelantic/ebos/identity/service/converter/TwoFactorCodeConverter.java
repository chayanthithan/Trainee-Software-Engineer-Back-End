package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import org.springframework.stereotype.Component;

@Component
public class TwoFactorCodeConverter {
    public TwoFactorCode convert(TwoFactorRequestDto twoFactorRequestDto) {
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(twoFactorRequestDto.getChannelType());
        twoFactorCode.setOtpType(twoFactorRequestDto.getOtpType());
        twoFactorCode.setUserId(twoFactorRequestDto.getUserId());
        twoFactorCode.setEmail(twoFactorRequestDto.getEmail());
        return twoFactorCode;
    }
}
