package com.codelantic.ebos.identity.service.security;

import com.codelantic.ebos.identity.service.enums.UserType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Authentication {
    private String userId;
    private String userName;
    private UserType userType;
    private String businessUrl;
}
