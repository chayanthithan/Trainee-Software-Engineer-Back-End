package com.codelantic.ebos.identity.service.repository;

import com.codelantic.ebos.identity.service.api.dto.TwoFactorCodeDto;
import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.enums.TokenStatus;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TwoFactorCodeRepository extends JpaRepository<TwoFactorCode, String> {
    Optional<TwoFactorCode> findByOtpTypeAndTokenStatusAndUserIdAndTwoFactorCode(OtpType otpType, TokenStatus created, String userId, String twoFactorCode);

    Optional<TwoFactorCode> findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(OtpType otpType, TokenStatus created, String email, String twoFactorCode);

    Optional<List<TwoFactorCode>> findByOtpTypeAndTokenStatusAndUserId(OtpType otpType, TokenStatus created, String userId);

    Optional<List<TwoFactorCode>> findByOtpTypeAndTokenStatusAndEmail(OtpType otpType, TokenStatus created, String email);

    @Query("SELECT NEW com.codelantic.ebos.identity.service.api.dto.TwoFactorCodeDto(t.email) from TwoFactorCode t where t.email=:email and t.twoFactorCode=:twoFactorCode and t.createdDateTime BETWEEN :startDateTime AND :endDateTime and t.tokenStatus=:token and t.channelType=:channelType and t.otpType=:otpType")
    List<TwoFactorCodeDto> getTwofacterForSignUp(@Param("email") String email,
                                                 @Param("twoFactorCode") String twoFactorCode,
                                                 @Param("startDateTime") LocalDateTime startDateTime,
                                                 @Param("endDateTime") LocalDateTime endDateTime,
                                                 @Param("token") TokenStatus tokenStatus,
                                                 @Param("channelType") ChannelType channelType,
                                                 @Param("otpType") OtpType otpType);


    Optional<TwoFactorCode> findByOtpTypeAndTokenStatusAndEmailAndVerificationTokenAndVerificationTokenStatus(OtpType otpType, TokenStatus created, String email,String verificationToken,TokenStatus verificationTokenStatus);
}
