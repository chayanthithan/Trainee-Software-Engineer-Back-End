package com.codelantic.ebos.identity.service.repository;

import com.codelantic.ebos.identity.service.entity.UserLoginDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLoginDetailsRepository extends JpaRepository<UserLoginDetails, String> {
    UserLoginDetails findTopByUserNameOrderByIdDesc(String userName);
}
