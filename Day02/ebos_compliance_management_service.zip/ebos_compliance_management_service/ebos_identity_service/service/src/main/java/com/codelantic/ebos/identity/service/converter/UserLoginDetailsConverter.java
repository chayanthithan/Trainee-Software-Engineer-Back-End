package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.UserLoginDetailsDto;
import com.codelantic.ebos.identity.service.entity.UserLoginDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserLoginDetailsConverter {
    public UserLoginDetails convertToDomain(UserLoginDetailsDto userLoginDetailsDto) {
        UserLoginDetails userLoginDetails = new UserLoginDetails();
        userLoginDetails.setId(userLoginDetailsDto.getId());
        userLoginDetails.setUserIp(userLoginDetailsDto.getUserIp());
        userLoginDetails.setUserName(userLoginDetailsDto.getUserName());
        userLoginDetails.setLoginDate(userLoginDetailsDto.getLoginDate());
        userLoginDetails.setLoginTime(userLoginDetailsDto.getLoginTime());
        userLoginDetails.setInvalidLoginCount(userLoginDetailsDto.getInvalidLoginCount());
        userLoginDetails.setIsSuccess(userLoginDetailsDto.isSuccess());
        return userLoginDetails;
    }

    public UserLoginDetailsDto convertToDTo(UserLoginDetails userLoginDetails) {
        UserLoginDetailsDto userLoginDetailsDto = new UserLoginDetailsDto();
        userLoginDetailsDto.setId(userLoginDetails.getId());
        userLoginDetailsDto.setUserIp(userLoginDetails.getUserIp());
        userLoginDetailsDto.setUserName(userLoginDetails.getUserName());
        userLoginDetailsDto.setLoginDate(userLoginDetails.getLoginDate());
        userLoginDetailsDto.setLoginTime(userLoginDetails.getLoginTime());
        userLoginDetailsDto.setInvalidLoginCount(userLoginDetails.getInvalidLoginCount());
        userLoginDetailsDto.setSuccess(userLoginDetails.getIsSuccess());
        return userLoginDetailsDto;
    }
}
