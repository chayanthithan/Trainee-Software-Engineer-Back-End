package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.service.TwoFactorCodeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.util.List;

@RestController
@RequestMapping("/api/v1/two-factor-codes")
@RequiredArgsConstructor
public class TwoFactorCodeController {

    private final TwoFactorCodeService twoFactorCodeService;


    @PostMapping
    public AgentResponseDto create(@RequestBody @Valid TwoFactorRequestDto twoFactorRequestDto) {
        return twoFactorCodeService.createAndSend(twoFactorRequestDto);
    }

    /* ebos */
    @PutMapping("/validate")
    public ResponseDto validate(@RequestBody @Valid TwoFactorRequestDto twoFactorRequestDto) {
        return twoFactorCodeService.validate(twoFactorRequestDto);
    }

    @PutMapping("/validateSignUpOtp")
    public ResponseDto validateSignUpOtp(@RequestBody @Valid TwoFactorRequestDto twoFactorRequestDto) {
        return twoFactorCodeService.validateSignUpOtp(twoFactorRequestDto);
    }


    @PostMapping("/signUpOtpSend")
    public ResponseDto signUpOtpSend(@RequestBody @Valid SignUpOtpSendDto signUpOtpSendDto) {
        return twoFactorCodeService.signUpOtpSend(signUpOtpSendDto.getEmail());
    }

    @GetMapping("/changePasswordOtpEmail/{email}")
    public ResponseDto forgotOrChangePasswordOtpEmail(@PathVariable @Valid @NotBlank(message = "Email is required!") @Email(message = "Email address is invalid!")
                                                      @Email(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Invalid email format")
                                                      String email) {
        return twoFactorCodeService.forgotOrChangePasswordOtpEmail(email);
    }

    @GetMapping("/getTwofacterForSignUp")
    List<TwoFactorCodeDto> getTwofacterForSignUp(@RequestParam(value = "email", required = true) String email, @RequestParam(value = "otp", required = true) String otp) {
        return twoFactorCodeService.getTwofacterForSignUp(email, otp);

    }

    @GetMapping("/otpVerification")
    public ResponseDto otpVerification(@RequestParam("otpType") OtpType otpType,
                                       @RequestParam("email") String email,
                                       @RequestParam("verificationToken") String verificationToken) {

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setEmail(email);
        twoFactorRequestDto.setOtpType(otpType);
        return twoFactorCodeService.isOtpVerified(twoFactorRequestDto, verificationToken);
    }
}
