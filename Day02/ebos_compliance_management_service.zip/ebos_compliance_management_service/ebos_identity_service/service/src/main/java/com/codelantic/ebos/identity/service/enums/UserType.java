package com.codelantic.ebos.identity.service.enums;

public enum UserType {

    ADMIN,
    OWNER,
    STAFF;
    private UserType() {
    }


}
