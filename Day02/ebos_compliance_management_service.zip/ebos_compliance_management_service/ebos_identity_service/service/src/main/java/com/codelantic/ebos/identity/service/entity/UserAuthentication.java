package com.codelantic.ebos.identity.service.entity;

import com.codelantic.ebos.identity.service.enums.UserType;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
public class UserAuthentication {

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    private String id;
    private LocalDateTime createdDateTime;
    private String email;
    private String userName;
    private String password;
    @Column(unique = true, nullable = false)
    private String userId;
    @Enumerated(EnumType.STRING)
    private UserType userType;
    private Boolean isLocked;
    private LocalDateTime lockedDateTime;
    private String url;
}
