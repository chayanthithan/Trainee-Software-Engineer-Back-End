package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.LoginRequest;
import com.codelantic.ebos.identity.service.api.dto.RefreshTokenRequest;
import com.codelantic.ebos.identity.service.api.dto.UrlDto;
import com.codelantic.ebos.identity.service.api.dto.UserAuthenticationDto;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Validated
public class AuthController {

    private final AuthService authservice;

    @PostMapping("/login")
    public ResponseEntity<Object> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) throws AuthenticationException {
        return authservice.authenticateUser(loginRequest);
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<Object> refreshToken(@Valid @RequestBody RefreshTokenRequest refreshTokenRequest) {
        return authservice.refreshToken(refreshTokenRequest);
    }

    @PostMapping("/validate2FA")
    public Boolean authenticate2FA(@Valid @RequestBody LoginRequest loginRequest) {
        loginRequest.setUsername(AuthenticationContextHolder.getContext().getUserName());
        return authservice.authenticate2FA(loginRequest);
    }

    @PostMapping("/save")
    public UserAuthentication save(@RequestBody UserAuthenticationDto userAuthenticationDto) {
        return authservice.save(userAuthenticationDto);
    }

    @GetMapping("/getById")
    public UserAuthentication getById(@RequestParam(value = "id") String id) {
        return authservice.getById(id);
    }

    @GetMapping("/validateBusinessUrl")
    public Boolean validateBusinessUrl() {
        String url = AuthenticationContextHolder.getContext().getBusinessUrl();
        return authservice.isBusinessUrlValid(url);
    }
    @GetMapping("/validateBusinessNameUrl")
    public UrlDto validateBusinessNameUrl(@RequestParam(value = "businessName") String businessName){
        return authservice.validateBusinessNameUrl(businessName);
    }

    @GetMapping("/isUrlExist")
    public Boolean isUrlExist(@RequestParam("url") String url) {
        return authservice.isUrlExist(url);
    }
}
