package com.codelantic.ebos.identity.service.service.support;


import com.codelantic.bankoyo.notification.client.NotificationClient;
import com.codelantic.bankoyo.notification.client.dto.EmailDataDto;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Slf4j
@Component
public class EmailTemplateGenerator {
    public static final String EMAIL_SEND_FAILED_MESSAGE = "Email send failed";
    private final NotificationClient notificationClient;
    private final String serviceProvider = "satellite";
    private final OTPTemplateContentGenerator otpTemplateContentGenerator;
    @Value("${two.factor.code.timeout.minutes}")
    private int twoFactorCodeTimeoutMinutes;

    public Boolean otpEmailSend(TwoFactorCode twoFactorCode, UserAuthentication userAuthentication, String beneficiaryName) {
        Boolean isEmailSent = Boolean.TRUE;
        Map<String, String> otpTypeTemplateContent = otpTemplateContentGenerator.generateOtpTemplateContent(twoFactorCode.getOtpType());
        EmailDataDto emailDataDto1 = new EmailDataDto();
        emailDataDto1.setRecipients(List.of(userAuthentication.getEmail()));
        emailDataDto1.setServiceProvider("remax");
        emailDataDto1.setSubject(otpTypeTemplateContent.get("subject"));
        emailDataDto1.setMailTemplateName(otpTypeTemplateContent.get("templateName"));
        Map<String, Object> emailData = new HashMap<>();
        emailData.put("userName", userAuthentication.getUserName());
        emailData.put("twoFactorCode", twoFactorCode.getTwoFactorCode());
        emailData.put("validForInMinutes", String.valueOf(twoFactorCodeTimeoutMinutes));
        emailDataDto1.setData(emailData);
        try {
            notificationClient.send(emailDataDto1);
        } catch (Exception e) {
            log.info(EMAIL_SEND_FAILED_MESSAGE);
            throw new ServiceException(EMAIL_SEND_FAILED_MESSAGE, EMAIL_SEND_FAILED_MESSAGE, HttpStatus.SERVICE_UNAVAILABLE);
        }
        return isEmailSent;

    }

    public Boolean otpEmailSendSignUp(TwoFactorCode twoFactorCode) {
        Boolean isEmailSent = Boolean.TRUE;
        Map<String, String> otpTypeTemplateContent = otpTemplateContentGenerator.generateOtpTemplateContent(twoFactorCode.getOtpType());
        EmailDataDto mailDataDto = new EmailDataDto();
        mailDataDto.setRecipients(List.of(twoFactorCode.getEmail()));
        mailDataDto.setServiceProvider("satellite");
        mailDataDto.setSubject(otpTypeTemplateContent.get("subject"));
        mailDataDto.setMailTemplateName(otpTypeTemplateContent.get("templateName"));
        Map<String, Object> emailData = new HashMap<>();
        emailData.put("twoFactorCode", twoFactorCode.getTwoFactorCode());
        emailData.put("validForInMinutes", String.valueOf(twoFactorCodeTimeoutMinutes));
        mailDataDto.setData(emailData);
        try {
            notificationClient.send(mailDataDto);
        } catch (Exception e) {
            log.info(EMAIL_SEND_FAILED_MESSAGE, e);
            throw new ServiceException(EMAIL_SEND_FAILED_MESSAGE, EMAIL_SEND_FAILED_MESSAGE, HttpStatus.SERVICE_UNAVAILABLE);
        }
        return isEmailSent;
    }


    public void signUpOtpEmailSend(TwoFactorCode twoFactorCode) {
        EmailDataDto emailDataDto = new EmailDataDto();
        emailDataDto.setRecipients(List.of(twoFactorCode.getEmail()));
        emailDataDto.setServiceProvider("ebos");
        emailDataDto.setSubject("\uD83D\uDD03OTP Verification for Your Ebos Account! \uD83D\uDD11");
        emailDataDto.setMailTemplateName("signup_otp_send");
        Map<String, Object> emailData = new HashMap<>();

        emailData.put("twoFactorCode", twoFactorCode.getTwoFactorCode());
        emailData.put("validForInMinutes", String.valueOf(twoFactorCodeTimeoutMinutes));

        emailDataDto.setData(emailData);
        try {
            notificationClient.send(emailDataDto);
        } catch (Exception e) {
            log.info(EMAIL_SEND_FAILED_MESSAGE);
            throw new ServiceException(EMAIL_SEND_FAILED_MESSAGE, EMAIL_SEND_FAILED_MESSAGE, HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
    public Boolean forgotPasswordOtpEmailSend(TwoFactorCode twoFactorCode, UserAuthentication userAuthentication) {
        Boolean isEmailSent = Boolean.TRUE;
        Map<String, String> otpTypeTemplateContent = otpTemplateContentGenerator.generateOtpTemplateContent(twoFactorCode.getOtpType());
        EmailDataDto emailDataDto = new EmailDataDto();
        emailDataDto.setRecipients(List.of(userAuthentication.getEmail()));
        emailDataDto.setServiceProvider("ebos");
        emailDataDto.setSubject(otpTypeTemplateContent.get("subject"));
        emailDataDto.setMailTemplateName(otpTypeTemplateContent.get("templateName"));
        Map<String, Object> emailData = new HashMap<>();

        emailData.put("userName", userAuthentication.getUserName());
        emailData.put("twoFactorCode", twoFactorCode.getTwoFactorCode());
        emailData.put("validForInMinutes", String.valueOf(twoFactorCodeTimeoutMinutes));
        emailDataDto.setData(emailData);
        try {
            notificationClient.send(emailDataDto);
        } catch (Exception e) {
            log.info(EMAIL_SEND_FAILED_MESSAGE);
            throw new ServiceException(EMAIL_SEND_FAILED_MESSAGE, EMAIL_SEND_FAILED_MESSAGE, HttpStatus.SERVICE_UNAVAILABLE);
        }
        return isEmailSent;

    }

}

