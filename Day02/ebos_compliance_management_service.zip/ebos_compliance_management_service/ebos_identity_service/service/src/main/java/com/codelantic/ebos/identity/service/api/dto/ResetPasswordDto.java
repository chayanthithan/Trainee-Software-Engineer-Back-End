package com.codelantic.ebos.identity.service.api.dto;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
public class ResetPasswordDto {
    @Valid
    UserAuthenticationDto userAuthentication;
    @NotBlank(message = "Password is required")
    @Size(min = 4, max = 12, message = "Incorrect Password Kindly adhere to the specified criteria when setting the new password")
    @Pattern(regexp = "^[^\\s]+$", message = "Password should not contain any spaces")
    String password;
    private String twoFactorCode;
    private Boolean isUpdatePassword;
    private Boolean isOtpValidated;
    private String verificationToken;
}
