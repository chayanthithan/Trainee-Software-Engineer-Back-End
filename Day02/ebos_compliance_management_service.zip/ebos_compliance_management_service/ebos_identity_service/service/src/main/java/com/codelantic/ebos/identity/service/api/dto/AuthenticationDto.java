package com.codelantic.ebos.identity.service.api.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class AuthenticationDto {
    @NotBlank(message = "User Id is required")
    private String userId;
    @NotBlank(message = "Email is required")
    private String email;
    @NotBlank(message = "Password is required")
    private String password;
    @NotBlank(message = "Old Password is required")
    private String oldPassword;
    @NotBlank(message = "TwoFactorCode is required")
    private String twoFactorCode;
}
