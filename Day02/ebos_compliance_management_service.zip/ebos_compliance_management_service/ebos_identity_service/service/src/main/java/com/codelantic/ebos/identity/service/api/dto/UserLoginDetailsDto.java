package com.codelantic.ebos.identity.service.api.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class UserLoginDetailsDto {
    private String id;
    private String userName;
    private String userIp;
    private LocalDate loginDate;
    private LocalTime loginTime;
    private boolean isSuccess;
    private Integer invalidLoginCount;
}
