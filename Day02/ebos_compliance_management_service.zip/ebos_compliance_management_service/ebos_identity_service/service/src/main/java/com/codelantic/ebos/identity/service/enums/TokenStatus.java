package com.codelantic.ebos.identity.service.enums;

public enum TokenStatus {

    CREATED,

    USED,

    UNUSED

}
