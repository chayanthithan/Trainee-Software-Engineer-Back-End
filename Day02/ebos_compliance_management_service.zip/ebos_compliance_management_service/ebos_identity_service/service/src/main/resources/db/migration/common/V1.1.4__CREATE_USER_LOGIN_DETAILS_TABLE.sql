CREATE TABLE `user_login_details` (
  `id` varchar(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `login_date` date DEFAULT NULL,
  `login_time` time DEFAULT NULL,
  `is_success` tinyint(2) DEFAULT NULL,
  `invalid_login_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
);