CREATE TABLE `user_authentication` (
  `id` varchar(255) NOT NULL,
  `created_date_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `is_locked` tinyint(2) DEFAULT NULL,
  `locked_date_time` datetime DEFAULT NULL,
  `customized_user_id` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);