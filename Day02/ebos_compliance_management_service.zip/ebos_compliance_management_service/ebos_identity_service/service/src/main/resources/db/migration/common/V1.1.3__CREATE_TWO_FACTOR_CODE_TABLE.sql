CREATE TABLE `two_factor_code` (
  `id` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `token_status` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `channel_type` varchar(255) DEFAULT NULL,
  `otp_type` varchar(255) DEFAULT NULL,
  `two_factor_code` varchar(255) DEFAULT NULL,
  `created_date_time` datetime DEFAULT NULL,
  `expiry_date_time` datetime DEFAULT NULL,
  `verification_token` varchar(255) DEFAULT NULL,
  `verification_token_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);