package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.service.TwoFactorCodeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class TwoFactorCodeControllerTest {
    @InjectMocks
    TwoFactorCodeController twoFactorCodeController;
    @Mock
    TwoFactorCodeService twoFactorCodeService;


    @Test
    void create() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        Mockito.when(twoFactorCodeService.createAndSend(twoFactorRequestDto)).thenReturn(new AgentResponseDto());
        assertNotNull(twoFactorCodeController.create(twoFactorRequestDto));
    }

    @Test
    void validate() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        Mockito.when(twoFactorCodeService.validate(twoFactorRequestDto)).thenReturn(new ResponseDto());
        twoFactorCodeController.validate(twoFactorRequestDto);
    }

    @Test
    void signUpOtpSend() {
        SignUpOtpSendDto signUpOtpSendDto = new SignUpOtpSendDto();
        signUpOtpSendDto.setEmail("mithuja@codelantic.com");
        Mockito.when(twoFactorCodeService.signUpOtpSend(signUpOtpSendDto.getEmail())).thenReturn(new ResponseDto());
        assertNotNull(twoFactorCodeController.signUpOtpSend(signUpOtpSendDto));
    }

    @Test
    void forgetPasswordOtpSend() {
        String email = "email";
        Mockito.when(twoFactorCodeService.forgotOrChangePasswordOtpEmail(email)).thenReturn(new ResponseDto());
        assertNotNull(twoFactorCodeController.forgotOrChangePasswordOtpEmail(email));
    }

    @Test
    void getTwofacterForSignUp(){
        String email="elilvannan@gmail.com";
        String otp="10000";
        List<TwoFactorCodeDto> twoFactorCodeDtos= new ArrayList<>();
        Mockito.when(twoFactorCodeService.getTwofacterForSignUp(email, otp)).thenReturn(twoFactorCodeDtos);
        assertNotNull(twoFactorCodeController.getTwofacterForSignUp(email, otp));

    }
    @Test
    void validateSignUpOtp() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        Mockito.when(twoFactorCodeService.validateSignUpOtp(twoFactorRequestDto)).thenReturn(new ResponseDto());
        twoFactorCodeController.validateSignUpOtp(twoFactorRequestDto);
    }

    @Test
    void otpVerification() {

        OtpType otpType = OtpType.SIGN_UP;
        String email = "abc";
        String verificationToken = "kjdngjsdgrg";
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(otpType);
        twoFactorRequestDto.setEmail(email);

        Mockito.when(twoFactorCodeService.isOtpVerified(twoFactorRequestDto,verificationToken)).thenReturn(new ResponseDto());
        assertNotNull(twoFactorCodeController.otpVerification(otpType,email,verificationToken));
    }
}

