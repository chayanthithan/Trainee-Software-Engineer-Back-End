package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.service.UserDetailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(MockitoExtension.class)
class UserDetailsControllerTest {

    @InjectMocks
    UserDetailsController userDetailsController;

    @Mock
    UserDetailService userDetailService;


    @Test
    void getUrlByOwnerId() {
        String ownerId="ownerId";
        Mockito.when(userDetailService.getUrlByOwnerId(ownerId)).thenReturn("url");
        assertNotNull(userDetailsController.getUrlByOwnerId(ownerId));

    }
}