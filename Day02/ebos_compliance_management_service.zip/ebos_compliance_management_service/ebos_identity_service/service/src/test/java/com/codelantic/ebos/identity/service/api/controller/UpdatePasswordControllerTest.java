package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.AgentResponseDto;
import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.service.UserDetailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class UpdatePasswordControllerTest {
    @InjectMocks
    UpdatePasswordController updatePasswordController;
    @Mock
    UserDetailService userDetailService;
    @Test
    void updatePasswordOtpSend() {
        TwoFactorRequestDto twoFactorRequestDto =new TwoFactorRequestDto();
        Mockito.when(userDetailService.updatePasswordOtpSend(twoFactorRequestDto)).thenReturn(new AgentResponseDto());
        assertNotNull(updatePasswordController.updatePasswordOtpSend(twoFactorRequestDto));
    }
}