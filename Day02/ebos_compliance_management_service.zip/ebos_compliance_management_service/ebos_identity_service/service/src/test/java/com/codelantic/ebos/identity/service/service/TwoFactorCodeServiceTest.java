package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.ResponseDto;
import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.converter.TwoFactorCodeConverter;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.enums.TokenStatus;
import com.codelantic.ebos.identity.service.enums.UserType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.TwoFactorCodeRepository;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.Authentication;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.service.support.EmailTemplateGenerator;
import com.codelantic.ebos.identity.service.service.support.TwoFactorCodeGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TwoFactorCodeServiceTest {
    @InjectMocks
    TwoFactorCodeService twoFactorCodeService;
    @Mock
    UserAuthenticationRepository userAuthenticationRepository;
    @Mock
    TwoFactorCodeRepository twoFactorCodeRepository;
    @Mock
    TwoFactorCodeConverter twoFactorCodeConverter;
    @Mock
    TwoFactorCodeGenerator twoFactorCodeGenerator;
    @Mock
    EmailTemplateGenerator emailTemplateGenerator;



    @Test
    void createAndSend() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);

        assertThrows(
                ServiceException.class,
                () -> twoFactorCodeService.createAndSend(twoFactorRequestDto));

    }

    @Test
    void createAndSend13() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);
        twoFactorRequestDto.setGrantType("Staff");
        twoFactorRequestDto.setUsername("hello@gmail.com");
        UserAuthentication userAuthentication = new UserAuthentication();
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        Mockito.when(userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getUsername(), "url")).thenReturn(Optional.of(userAuthentication));
        userAuthentication.setUserType(UserType.ADMIN);

        assertThrows(
                ServiceException.class,
                () -> twoFactorCodeService.createAndSend(twoFactorRequestDto));

    }

    @Test
    void createAndSend14() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);
        twoFactorRequestDto.setGrantType("ADMIN");
        twoFactorRequestDto.setUsername("hello@gmail.com");
        UserAuthentication userAuthentication = new UserAuthentication();
        Mockito.when(userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getUsername(), "url")).thenReturn(Optional.of(userAuthentication));
        userAuthentication.setUserType(UserType.ADMIN);

        userAuthentication.setUserName("hi@gmail.com");
        assertThrows(
                ServiceException.class,
                () -> twoFactorCodeService.createAndSend(twoFactorRequestDto));

    }

    @Test
    void createAndSend1() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);
        twoFactorRequestDto.setUsername("sivanathan@codelantic.com");
        twoFactorRequestDto.setPassword("Test_2user");
        twoFactorRequestDto.setUserId("001");
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setGrantType("STAFF");


        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setUserId("001");
        userAuthentication.setEmail("sivanathan@codelantic.com");
        userAuthentication.setPassword("$2a$10$a/88ieYcfn4ZXuxFsEhAy.Z7XqrWiZq5kQ9VAJ50aRHTDvjqAROgG");
        userAuthentication.setUserType(UserType.STAFF);
        userAuthentication.setUserName("sivanathan@codelantic.com");
        when(userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getUsername(), "url")).thenReturn(Optional.of(userAuthentication));

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode("1234");
        twoFactorCodeList.add(twoFactorCode);
        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getUserId())).thenReturn(Optional.of(twoFactorCodeList));

        TwoFactorCode twoFactorCode2 = new TwoFactorCode();
        twoFactorCode2.setTwoFactorCode("5678");
        when(twoFactorCodeConverter.convert(twoFactorRequestDto)).thenReturn(twoFactorCode2);
        when(twoFactorCodeGenerator.generateTwoFactorCode()).thenReturn("5678");
        assertNotNull(twoFactorCodeService.createAndSend(twoFactorRequestDto));
    }

    @Test
    void createAndSend_SignIn_Success() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.UPDATE_PASSWORD);
        twoFactorRequestDto.setUsername("sivanathan@codelantic.com");
        twoFactorRequestDto.setPassword("Test_2user");
        twoFactorRequestDto.setTwoFactorCode("1234");
        twoFactorRequestDto.setUserId("4028818f8e4042d1018e407800000000");
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setGrantType("STAFF");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("sivanathan@codelantic.com");
        userAuthentication.setUserId("4028818f8e4042d1018e407800000000");
        userAuthentication.setUserType(UserType.STAFF);
        userAuthentication.setPassword("$2a$10$a/88ieYcfn4ZXuxFsEhAy.Z7XqrWiZq5kQ9VAJ50aRHTDvjqAROgG");
        userAuthentication.setUserName("sivanathan@codelantic.com");
        when(userAuthenticationRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.of(userAuthentication));

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode("1234");
        twoFactorCodeList.add(twoFactorCode);
        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getUserId())).thenReturn(Optional.of(twoFactorCodeList));
        TwoFactorCode twoFactorCode2 = new TwoFactorCode();
        twoFactorCode2.setTwoFactorCode("5678");
        when(twoFactorCodeConverter.convert(twoFactorRequestDto)).thenReturn(twoFactorCode2);

        when(twoFactorCodeGenerator.generateTwoFactorCode()).thenReturn("123456");

        assertNotNull(twoFactorCodeService.createAndSend(twoFactorRequestDto));

    }


    @Test
    void createAndSend2() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setUsername("sivanathan@codelantic.com");
        twoFactorRequestDto.setEmail("sivanathan@codelantic.com");
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setPassword("$2a$10$a/88ieYcfn4ZXuxFsEhAy.Z7XqrWiZq5kQ9VAJ50aRHTDvjqAROgG");
        twoFactorRequestDto.setUserId("123");
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setGrantType("STAFF");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setUserType(UserType.STAFF);
        userAuthentication.setId("id");

        when(userAuthenticationRepository.findByEmail(twoFactorRequestDto.getUsername())).thenReturn(Optional.of(userAuthentication));

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setId("id");
        twoFactorCodeList.add(twoFactorCode);

        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(any(), any(), any())).thenReturn(Optional.of(twoFactorCodeList));


        TwoFactorCode twoFactorCode1 = new TwoFactorCode();
        when(twoFactorCodeConverter.convert(twoFactorRequestDto)).thenReturn(twoFactorCode1);
        when(twoFactorCodeGenerator.generateTwoFactorCode()).thenReturn(new String());


        assertNotNull(twoFactorCodeService.createAndSend(twoFactorRequestDto));


    }


    @Test
    void validateEmail() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String email = "null@gmail.com";
        Method method = TwoFactorCodeService.class.getDeclaredMethod("validateEmail", String.class);
        method.setAccessible(true);
        method.invoke(twoFactorCodeService, email);
        int k = 90;
        assertEquals(90, k);
    }

    @Test
    void updateUnusedTwoFactorCodesByUserId() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setEmail("abc@gmail.com");

        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode("bhjck");

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        twoFactorCodeList.add(twoFactorCode);
        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getUserId())).thenReturn(Optional.of(twoFactorCodeList));

        twoFactorCodeService.updateUnusedTwoFactorCodesByUserId(twoFactorRequestDto);
        int k = 90;
        assertEquals(90, k);
    }


    @Test
    void validateTest() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setEmail("nethmi@codelantic.com");
        twoFactorRequestDto.setUserId("bjhi");
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(ChannelType.EMAIL);

        when(userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getEmail(), "url")).thenReturn(Optional.of(new UserAuthentication()));

        twoFactorCode.setExpiryDateTime(LocalDateTime.MAX);
        Mockito.when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(twoFactorRequestDto.getOtpType(),
                TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode())).thenReturn(Optional.of(twoFactorCode));

        twoFactorCodeService.validate(twoFactorRequestDto);
    }

    @Test
    void validateException() {
        Authentication authentication = Authentication.builder()
                .businessUrl("http://shahithiyan.ebos.com").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("shahithiyan.ebos.com")).thenReturn(Boolean.TRUE);
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setEmail("nethmi@codelantic.com");
        twoFactorRequestDto.setUserId("bjhi");
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(ChannelType.EMAIL);


        assertThrows(ServiceException.class, () -> twoFactorCodeService.validate(twoFactorRequestDto));
    }

    @Test
    void validateTest_ExpiredOtp() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setEmail("nethmi@codelantic.com");
        twoFactorRequestDto.setUserId("bjhi");
        twoFactorRequestDto.setTwoFactorCode("someCode");

        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(ChannelType.EMAIL);
        twoFactorCode.setExpiryDateTime(LocalDateTime.now().minusMinutes(1));

        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);
        when(userAuthenticationRepository.findByEmailAndUrl(twoFactorRequestDto.getEmail(), "url"))
                .thenReturn(Optional.of(new UserAuthentication()));

        Mockito.when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(
                        twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode()))
                .thenReturn(Optional.of(twoFactorCode));

        ServiceException exception = assertThrows(ServiceException.class, () -> {
            twoFactorCodeService.validate(twoFactorRequestDto);
        });

        assertEquals("two factor code expired", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }


    @Test
    void validateEmail2() throws NoSuchMethodException, SecurityException {
        Method method = TwoFactorCodeService.class.getDeclaredMethod("validateEmail", String.class);
        method.setAccessible(true);

        String email = null;

        TwoFactorCodeService cb = new TwoFactorCodeService(userAuthenticationRepository, twoFactorCodeRepository, twoFactorCodeConverter, twoFactorCodeGenerator, emailTemplateGenerator);
        assertThrows(
                InvocationTargetException.class,
                () -> method.invoke(cb, email)
        );
    }

    @Test
    void validateUserId() throws NoSuchMethodException, SecurityException {
        Method method = TwoFactorCodeService.class.getDeclaredMethod("validateUserId", String.class);
        method.setAccessible(true);

        String userId = null;

        TwoFactorCodeService cb = new TwoFactorCodeService(userAuthenticationRepository, twoFactorCodeRepository, twoFactorCodeConverter, twoFactorCodeGenerator, emailTemplateGenerator);
        assertThrows(
                InvocationTargetException.class,
                () -> method.invoke(cb, userId)
        );
    }


    @Test
    void validateTest_null() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);

        assertThrows(
                ServiceException.class,
                () -> twoFactorCodeService.validate(twoFactorRequestDto));
    }

    @Test
    void testSignUpOtpSend_EmailAlreadyExists() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);

        String email = "test@example.com";
        UserAuthentication userAuthentication = new UserAuthentication();
        when(userAuthenticationRepository.findByEmail(email)).thenReturn(Optional.of(userAuthentication));

        ServiceException exception = assertThrows(ServiceException.class, () -> {
            twoFactorCodeService.signUpOtpSend(email);
        });
        assertEquals("Please enter a different email address, as the one provided is already in use.", exception.getMessage());
    }

    @Test
    void signUpOtpSend() {
        String email = "abc@gmail.com";

        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setEmail("abc@gmail.com");
        twoFactorRequestDto.setOtpType(OtpType.SIGN_UP);

        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode("bhjck");

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        twoFactorCodeList.add(twoFactorCode);
        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmail(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getEmail())).thenReturn(Optional.of(twoFactorCodeList));
        assertNotNull(twoFactorCodeService.signUpOtpSend(email));
    }

    @Test
    void forgetPasswordOtpSend() {
        Authentication authentication = Authentication.builder()
                .businessUrl("https://shahithiyan.ebos.com").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("shahithiyan.ebos.com")).thenReturn(Boolean.TRUE);

        ResponseDto responseDto = new ResponseDto();
        String email = "abc@gmail.com";
        UserAuthentication userAuthentication = new UserAuthentication();
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setEmail(email);
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setUsername(email);
        twoFactorRequestDto.setEmail(email);
        twoFactorRequestDto.setGrantType("STAFF");
        twoFactorRequestDto.setUserId("2");
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setTwoFactorCode("bhjck");
        twoFactorCode.setEmail(email);
        twoFactorCode.setChannelType(ChannelType.EMAIL);
        twoFactorCode.setId("2");

        List<TwoFactorCode> twoFactorCodeList = new ArrayList<>();
        twoFactorCodeList.add(twoFactorCode);

        //case 1 user not found exception
        Mockito.when(userAuthenticationRepository.findByEmail(email)).thenReturn(Optional.empty());
        assertThrows(ServiceException.class, () -> {
            twoFactorCodeService.forgotOrChangePasswordOtpEmail(email);
        });
        //case 2 user unauthorized  exception
        userAuthentication.setUserType(UserType.STAFF);
        userAuthentication.setEmail(email);
        userAuthentication.setUserId("2");
        Mockito.when(userAuthenticationRepository.findByEmail(email)).thenReturn(Optional.of(userAuthentication));

        //case 3 userAuthentication null scenario
        responseDto.setMessage("Two factor code sent successfully!");
        Mockito.when(twoFactorCodeConverter.convert(twoFactorRequestDto)).thenReturn(twoFactorCode);
        Mockito.when(twoFactorCodeGenerator.generateTwoFactorCode()).thenReturn("fjefhek");
        Mockito.when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndUserId(twoFactorRequestDto.getOtpType(), TokenStatus.CREATED, twoFactorRequestDto.getUserId())).thenReturn(Optional.of(twoFactorCodeList));
        ResponseDto actual = twoFactorCodeService.forgotOrChangePasswordOtpEmail(email);
        assertEquals(responseDto.getMessage(), actual.getMessage());
    }

    @Test
    void getTwofacterForSignUp() {
        String email = "elilvannan@gmail.com";
        String twoFactorCode = "10000";
        assertNotNull(twoFactorCodeService.getTwofacterForSignUp(email, twoFactorCode));
    }

    @Test
    void isOtpVerified() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        String verificationToken = "token";

        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setVerificationToken(verificationToken);
        when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndVerificationTokenAndVerificationTokenStatus(twoFactorRequestDto.getOtpType(), TokenStatus.USED,
                twoFactorRequestDto.getEmail(), verificationToken, TokenStatus.CREATED))
                .thenReturn(Optional.of(twoFactorCode));
        when(twoFactorCodeRepository.save(twoFactorCode)).thenReturn(twoFactorCode);

        assertNotNull(twoFactorCodeService.isOtpVerified(twoFactorRequestDto, verificationToken));
    }

    @Test
    void validateSignUpOtp() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setEmail("nethmi@codelantic.com");
        twoFactorRequestDto.setUserId("bjhi");
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(ChannelType.EMAIL);

        twoFactorCode.setExpiryDateTime(LocalDateTime.MAX);
        Mockito.when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(twoFactorRequestDto.getOtpType(),
                TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode())).thenReturn(Optional.of(twoFactorCode));

        twoFactorCodeService.validateSignUpOtp(twoFactorRequestDto);
    }

    @Test
    void validateSignUpOtpException() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setEmail("nethmi@codelantic.com");
        twoFactorRequestDto.setUserId("bjhi");
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setChannelType(ChannelType.EMAIL);

        twoFactorCode.setExpiryDateTime(LocalDateTime.MIN);
        Mockito.when(twoFactorCodeRepository.findByOtpTypeAndTokenStatusAndEmailAndTwoFactorCode(twoFactorRequestDto.getOtpType(),
                TokenStatus.CREATED, twoFactorRequestDto.getEmail(), twoFactorRequestDto.getTwoFactorCode())).thenReturn(Optional.of(twoFactorCode));

        assertThrows(ServiceException.class, () -> {
            twoFactorCodeService.validateSignUpOtp(twoFactorRequestDto);
        });
    }

}