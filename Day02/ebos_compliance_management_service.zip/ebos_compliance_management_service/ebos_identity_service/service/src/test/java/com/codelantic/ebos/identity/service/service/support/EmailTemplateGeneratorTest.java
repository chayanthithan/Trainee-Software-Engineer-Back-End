package com.codelantic.ebos.identity.service.service.support;

import com.codelantic.bankoyo.notification.client.NotificationClient;
import com.codelantic.bankoyo.notification.client.dto.EmailDataDto;
import com.codelantic.ebos.identity.service.entity.TwoFactorCode;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmailTemplateGeneratorTest {
    @InjectMocks
    EmailTemplateGenerator emailTemplateGenerator;
    @Mock
    NotificationClient notificationClient;
    @Mock
    OTPTemplateContentGenerator otpTemplateContentGenerator;

    @Test
    void otpEmailSend() {
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setOtpType(OtpType.SIGN_IN);

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("fgui@gmail.com");
        String beneficiaryName = "yathusangar";

        Mockito.when(otpTemplateContentGenerator.generateOtpTemplateContent(twoFactorCode.getOtpType())).thenReturn(new HashMap<>());

        assertNotNull(emailTemplateGenerator.otpEmailSend(twoFactorCode, userAuthentication, beneficiaryName));
    }

    @Test
    void otpEmailSendSignUp() {
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setOtpType(OtpType.SIGN_IN);
        twoFactorCode.setEmail("fgui@gmail.com");
        twoFactorCode.setTwoFactorCode("gyhhjlbjhlbjhlb");

        Mockito.when(otpTemplateContentGenerator.generateOtpTemplateContent(twoFactorCode.getOtpType())).thenReturn(new HashMap<>());

        assertNotNull(emailTemplateGenerator.otpEmailSendSignUp(twoFactorCode));
    }

    @Test
    void testSignUpOtpEmailSend_Success() {
        TwoFactorCode twoFactorCode = new TwoFactorCode();

        twoFactorCode.setEmail("test@example.com");
        twoFactorCode.setTwoFactorCode("4664");
        twoFactorCode.setCreatedDateTime(LocalDateTime.now());
        twoFactorCode.setExpiryDateTime(LocalDateTime.now().plusMinutes(10));

        emailTemplateGenerator.signUpOtpEmailSend(twoFactorCode);

        EmailDataDto expectedEmailDataDto = new EmailDataDto();
        expectedEmailDataDto.setRecipients(List.of("test@example.com"));
        expectedEmailDataDto.setServiceProvider("ebos");
        expectedEmailDataDto.setSubject("\uD83D\uDD03OTP Verification for Your Ebos Account! \uD83D\uDD11");
        expectedEmailDataDto.setMailTemplateName("signup_otp_send");
        Map<String, Object> emailData = new HashMap<>();
        emailData.put("twoFactorCode", "4664");
        emailData.put("validForInMinutes", "0");
        expectedEmailDataDto.setData(emailData);

        verify(notificationClient, times(1)).send(refEq(expectedEmailDataDto));
    }

    @Test
    void testSignUpOtpEmailSend_Failure() {

        TwoFactorCode twoFactorCode = new TwoFactorCode();

        twoFactorCode.setEmail("test@example.com");
        twoFactorCode.setTwoFactorCode("123456");
        twoFactorCode.setCreatedDateTime(LocalDateTime.now());
        twoFactorCode.setExpiryDateTime(LocalDateTime.now().plusMinutes(10));

        doThrow(new RuntimeException()).when(notificationClient).send(any(EmailDataDto.class));

        ServiceException exception = assertThrows(ServiceException.class, () -> {
            emailTemplateGenerator.signUpOtpEmailSend(twoFactorCode);
        });

        assertEquals("Email send failed", exception.getMessage());
        verify(notificationClient, times(1)).send(any(EmailDataDto.class));
    }

    @Test
    void testForgotPasswordOtpEmailSend_Success() {
        // Arrange
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorCode.setTwoFactorCode("123456");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("user@example.com");
        userAuthentication.setUserName("Test User");

        Map<String, String> otpTemplateContent = new HashMap<>();
        otpTemplateContent.put("subject", "Password Reset OTP");
        otpTemplateContent.put("templateName", "forgot_password_template");

        when(otpTemplateContentGenerator.generateOtpTemplateContent(OtpType.RESET_PASSWORD)).thenReturn(otpTemplateContent);

        // Act
        Boolean result = emailTemplateGenerator.forgotPasswordOtpEmailSend(twoFactorCode, userAuthentication);

        // Assert
        assertTrue(result);
    }

    @Test
    void testForgotPasswordOtpEmailSend_Failure() {
        // Arrange
        TwoFactorCode twoFactorCode = new TwoFactorCode();
        twoFactorCode.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorCode.setTwoFactorCode("123456");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("user@example.com");
        userAuthentication.setUserName("Test User");

        Map<String, String> otpTemplateContent = new HashMap<>();
        otpTemplateContent.put("subject", "Password Reset OTP");
        otpTemplateContent.put("templateName", "forgot_password_template");

        when(otpTemplateContentGenerator.generateOtpTemplateContent(OtpType.RESET_PASSWORD)).thenReturn(otpTemplateContent);
        doThrow(new RuntimeException("Email service failure")).when(notificationClient).send(any(EmailDataDto.class));

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () -> {
            emailTemplateGenerator.forgotPasswordOtpEmailSend(twoFactorCode, userAuthentication);
        });

        assertEquals("Email send failed", exception.getMessage());
    }
}