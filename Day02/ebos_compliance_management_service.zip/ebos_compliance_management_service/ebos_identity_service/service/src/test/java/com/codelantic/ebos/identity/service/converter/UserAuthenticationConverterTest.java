package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.UserAuthenticationDto;
import com.codelantic.ebos.identity.service.config.SecurityConfig;
import com.codelantic.ebos.identity.service.enums.UserType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserAuthenticationConverterTest {
    @InjectMocks
    UserAuthenticationConverter userAuthenticationConverter;
    @Mock
    SecurityConfig securityConfig;

    @Test
    void convert() {
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        UserAuthenticationDto userAuthenticationDto=new UserAuthenticationDto();
        userAuthenticationDto.setUserId("bsdji123");
        userAuthenticationDto.setUserName("yumesh");
        userAuthenticationDto.setUserType(UserType.STAFF);
        userAuthenticationDto.setPassword("password");
        userAuthenticationDto.setCreatedDateTime(LocalDateTime.MAX);
        userAuthenticationDto.setEmail("yumesh@Qgmail.com");
        when(securityConfig.passwordEncoder()).thenReturn(passwordEncoder);

        assertNotNull(userAuthenticationConverter.convert(userAuthenticationDto));
    }
}