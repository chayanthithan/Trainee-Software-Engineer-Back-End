package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.service.UserDetailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @InjectMocks
    UserController userController;

    @Mock
    UserDetailService userDetailService;


    @Test
    void update_user_password() {
        AuthenticationDto authenticationDto = new AuthenticationDto();
        Mockito.when(userDetailService.updateUserPassword(authenticationDto)).thenReturn(false);

        assertNotNull(userController.updateUser(authenticationDto));
    }


    @Test
    void updatePassword() {
        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        resetPasswordDto.setPassword("passwold");
        Mockito.when(userDetailService.updatePassword(resetPasswordDto)).thenReturn(new ResponseDto());

        assertNotNull(userController.updatePassword(resetPasswordDto));

    }

    @Test
    void updatePasswordOtpSend() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        Mockito.when(userDetailService.updatePasswordOtpSend(twoFactorRequestDto)).thenReturn(new AgentResponseDto());
        assertNotNull(userController.updatePasswordOtpSend(twoFactorRequestDto));
    }

    @Test
    void resetPassword() {
        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        Mockito.when(userDetailService.resetPassword(resetPasswordDto)).thenReturn(new ResponseDto());
        assertNotNull(userController.resetPassword(resetPasswordDto));
    }
    @Test
    void deleteUser()
    {
        String id="cusid12";
        Mockito.when(userDetailService.deleteUser(id)).thenReturn(new ResponseDto());
        assertNotNull(userController.deleteUser(id));
    }
}
