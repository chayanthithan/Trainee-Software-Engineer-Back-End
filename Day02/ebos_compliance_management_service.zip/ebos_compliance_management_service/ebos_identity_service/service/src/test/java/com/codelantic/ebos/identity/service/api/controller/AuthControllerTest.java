package com.codelantic.ebos.identity.service.api.controller;

import com.codelantic.ebos.identity.service.api.dto.LoginRequest;
import com.codelantic.ebos.identity.service.api.dto.RefreshTokenRequest;
import com.codelantic.ebos.identity.service.api.dto.UrlDto;
import com.codelantic.ebos.identity.service.api.dto.UserAuthenticationDto;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.security.Authentication;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.service.AuthService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {
    @InjectMocks
    AuthController authController;
    @Mock
    AuthService authservice;
    @Mock
    private AuthenticationContextHolder authenticationContextHolder;

    @Test
    void authenticateUser()  {
        LoginRequest loginRequest = new LoginRequest();

        when(authservice.authenticateUser(loginRequest)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        authController.authenticateUser(loginRequest);
        assertNotNull(authController.authenticateUser(loginRequest));
    }

    @Test
    void authenticate2FA() {
        String username = "testUser";
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(username);
        Authentication authentication = Authentication.builder().userId("1234").userName(username).build();
        AuthenticationContextHolder.setContext(authentication);
        when(authservice.authenticate2FA(loginRequest)).thenReturn(true);
        authController.authenticate2FA(loginRequest);
        assertNotNull(authController.authenticate2FA(loginRequest));
    }

    @Test
    void save() {
        UserAuthenticationDto userAuthenticationDto = new UserAuthenticationDto();
        Mockito.when(authservice.save(userAuthenticationDto)).thenReturn(new UserAuthentication());
        assertNotNull(authController.save(userAuthenticationDto));
    }

    @Test
    void getById() {
        String id = "vbg1231";
        UserAuthentication userAuthentication = new UserAuthentication();
        when(authservice.getById(id)).thenReturn(userAuthentication);
        assertNotNull(authController.getById(id));
    }
    @Test
    void refreshToken() {
        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
        Mockito.when(authservice.refreshToken(refreshTokenRequest)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        assertNotNull(authController.refreshToken(refreshTokenRequest));
    }

    @Test
    void validateBusinessUrl() {
        Authentication authentication = Authentication.builder().businessUrl("ebos.com").build();
        AuthenticationContextHolder.setContext(authentication);
        Mockito.when(authservice.isBusinessUrlValid("ebos.com")).thenReturn(Boolean.TRUE);
        assertNotNull(authController.validateBusinessUrl());
    }

    @Test
    void validateBusinessNameUrl() {
        when(authservice.validateBusinessNameUrl("ajith")).thenReturn(new UrlDto("ajith"));
        assertNotNull(authController.validateBusinessNameUrl("ajith"));
    }

    @Test
    void isUrlExist() {
        Mockito.when(authservice.isUrlExist("ebos.com")).thenReturn(Boolean.TRUE);
        assertNotNull(authController.isUrlExist("ebos.com"));
    }
}