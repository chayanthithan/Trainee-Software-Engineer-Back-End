package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.UserLoginDetailsDto;
import com.codelantic.ebos.identity.service.entity.UserLoginDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;

@ExtendWith(MockitoExtension.class)
class UserLoginDetailsConverterTest {

    private final UserLoginDetailsConverter converter = new UserLoginDetailsConverter();

    @Test
    void testConvertToDomain() {
        UserLoginDetailsDto dto = new UserLoginDetailsDto();
        dto.setId("1l");
        dto.setUserIp("192.168.0.1");
        dto.setUserName("john.doe");
        dto.setLoginDate(LocalDate.now());
        dto.setLoginTime(LocalTime.now());
        dto.setInvalidLoginCount(0);
        dto.setSuccess(true);

        UserLoginDetails domain = converter.convertToDomain(dto);

        Assertions.assertEquals(dto.getId(), domain.getId());
        Assertions.assertEquals(dto.getUserIp(), domain.getUserIp());
        Assertions.assertEquals(dto.getUserName(), domain.getUserName());
        Assertions.assertEquals(dto.getLoginDate(), domain.getLoginDate());
        Assertions.assertEquals(dto.getLoginTime(), domain.getLoginTime());
        Assertions.assertEquals(dto.getInvalidLoginCount(), domain.getInvalidLoginCount());
        Assertions.assertEquals(dto.isSuccess(), domain.getIsSuccess());
    }

    @Test
    void testConvertToDTO() {
        UserLoginDetails domain = new UserLoginDetails();
        domain.setId("1l");
        domain.setUserIp("192.168.0.1");
        domain.setUserName("john.doe");
        domain.setLoginDate(LocalDate.now());
        domain.setLoginTime(LocalTime.now());
        domain.setInvalidLoginCount(0);
        domain.setIsSuccess(true);

        UserLoginDetailsDto dto = converter.convertToDTo(domain);

        Assertions.assertEquals(domain.getId(), dto.getId());
        Assertions.assertEquals(domain.getUserIp(), dto.getUserIp());
        Assertions.assertEquals(domain.getUserName(), dto.getUserName());
        Assertions.assertEquals(domain.getLoginDate(), dto.getLoginDate());
        Assertions.assertEquals(domain.getLoginTime(), dto.getLoginTime());
        Assertions.assertEquals(domain.getInvalidLoginCount(), dto.getInvalidLoginCount());
        Assertions.assertEquals(domain.getIsSuccess(), dto.isSuccess());
    }
}