package com.codelantic.ebos.identity.service.converter;

import com.codelantic.ebos.identity.service.api.dto.TwoFactorRequestDto;
import com.codelantic.ebos.identity.service.enums.ChannelType;
import com.codelantic.ebos.identity.service.enums.OtpType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class TwoFactorCodeConverterTest {
    @InjectMocks
    TwoFactorCodeConverter twoFactorCodeConverter;

    @Test
    void convert() {
        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setChannelType(ChannelType.EMAIL);
        twoFactorRequestDto.setOtpType(OtpType.SIGN_IN);
        twoFactorRequestDto.setUserId("ibjhl");

        twoFactorCodeConverter.convert(twoFactorRequestDto);
        assertNotNull(twoFactorCodeConverter.convert(twoFactorRequestDto));

    }
}