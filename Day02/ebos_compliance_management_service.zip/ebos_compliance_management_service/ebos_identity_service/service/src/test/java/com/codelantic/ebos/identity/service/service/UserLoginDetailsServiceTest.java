package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.UserLoginDetailsDto;
import com.codelantic.ebos.identity.service.converter.UserAuthenticationConverter;
import com.codelantic.ebos.identity.service.converter.UserLoginDetailsConverter;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.entity.UserLoginDetails;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.repository.UserLoginDetailsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserLoginDetailsServiceTest {


    @Mock
    private UserLoginDetailsRepository userLoginDetailsRepository;

    @Mock
    private UserLoginDetailsConverter userLoginDetailsConverter;

    @Mock
    private UserAuthenticationRepository userAuthenticationRepository;

    @Mock
    private UserAuthenticationConverter userAuthenticationConverter;

    @InjectMocks
    @Spy
    private UserLoginDetailsService userLoginDetailsService;


    private UserLoginDetails userLoginDetails;
    private UserLoginDetailsDto userLoginDetailsDto;
    private UserAuthentication userAuthentication;

    @BeforeEach
    void setUp() {
        userLoginDetails = new UserLoginDetails();
        userLoginDetails.setId("1L");
        userLoginDetails.setUserName("user@example.com");
        userLoginDetails.setUserIp("192.168.1.1");
        userLoginDetails.setLoginDate(LocalDate.now());
        userLoginDetails.setLoginTime(LocalTime.now());
        userLoginDetails.setInvalidLoginCount(0);
        userLoginDetails.setIsSuccess(true);

        userLoginDetailsDto = new UserLoginDetailsDto();
        userLoginDetailsDto.setId("1L");
        userLoginDetailsDto.setUserName("user@example.com");
        userLoginDetailsDto.setUserIp("192.168.1.1");
        userLoginDetailsDto.setLoginDate(LocalDate.now());
        userLoginDetailsDto.setLoginTime(LocalTime.now());
        userLoginDetailsDto.setInvalidLoginCount(0);
        userLoginDetailsDto.setSuccess(true);

        userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("user@example.com");
        userAuthentication.setIsLocked(false);


    }

    @Test
    void testUpdateLastRecord_NewRecord() {
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(anyString())).thenReturn(null);
        when(userLoginDetailsConverter.convertToDTo(any(UserLoginDetails.class))).thenReturn(userLoginDetailsDto);
        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenReturn(userLoginDetails);

        UserLoginDetailsDto result = userLoginDetailsService.updateLastRecord("user@example.com", true);

        assertEquals(userLoginDetailsDto, result);
        verify(userLoginDetailsRepository, times(1)).save(any(UserLoginDetails.class));
    }

    @Test
    void testUpdateLastRecord_ExistingRecord() {
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(anyString())).thenReturn(userLoginDetails);
        when(userLoginDetailsConverter.convertToDTo(any(UserLoginDetails.class))).thenReturn(userLoginDetailsDto);
        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenReturn(userLoginDetails);

        UserLoginDetailsDto result = userLoginDetailsService.updateLastRecord("user@example.com", false);

        assertEquals(userLoginDetailsDto, result);
        verify(userLoginDetailsRepository, times(1)).save(any(UserLoginDetails.class));
    }

    @Test
    void testSave_NewRecord() {
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(anyString())).thenReturn(userLoginDetails);
        when(userLoginDetailsConverter.convertToDomain(any(UserLoginDetailsDto.class))).thenReturn(userLoginDetails);
        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenReturn(userLoginDetails);
        when(userLoginDetailsConverter.convertToDTo(any(UserLoginDetails.class))).thenReturn(userLoginDetailsDto);

        UserLoginDetailsDto result = userLoginDetailsService.save("user@example.com", "192.168.1.1", true);
        assertEquals(userLoginDetailsDto, result);
        verify(userLoginDetailsRepository, times(1)).save(any(UserLoginDetails.class));
    }

    @Test
    void testSave_ExistingRecord_Success() {
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(anyString())).thenReturn(userLoginDetails);
        when(userLoginDetailsConverter.convertToDTo(any(UserLoginDetails.class))).thenReturn(userLoginDetailsDto);
        when(userLoginDetailsConverter.convertToDomain(any(UserLoginDetailsDto.class))).thenReturn(userLoginDetails);
        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenReturn(userLoginDetails);

        UserLoginDetailsDto result = userLoginDetailsService.save("user@example.com", "192.168.1.1", true);

        assertEquals(userLoginDetailsDto, result);
        verify(userLoginDetailsRepository, times(1)).save(any(UserLoginDetails.class));
    }

    @Test
    void testSave_ExistingRecord_Failure_NotLocked() throws IllegalAccessException, NoSuchFieldException {
        userLoginDetailsDto.setInvalidLoginCount(2);
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(anyString())).thenReturn(userLoginDetails);
        when(userLoginDetailsConverter.convertToDTo(any(UserLoginDetails.class))).thenReturn(userLoginDetailsDto);
        when(userLoginDetailsConverter.convertToDomain(any(UserLoginDetailsDto.class))).thenReturn(userLoginDetails);
        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenReturn(userLoginDetails);
        when(userAuthenticationRepository.findByEmail(anyString())).thenReturn(Optional.of(userAuthentication));
        Field invalidLoginBlockCount = UserLoginDetailsService.class.getDeclaredField("invalidLoginBlockCount");
        invalidLoginBlockCount.setAccessible(true);
        invalidLoginBlockCount.set(userLoginDetailsService, "2");
        UserLoginDetailsDto result = userLoginDetailsService.save("user@example.com", "192.168.1.1", false);

        assertEquals(userLoginDetailsDto, result);
        verify(userLoginDetailsRepository, times(1)).save(any(UserLoginDetails.class));
        verify(userAuthenticationRepository, times(1)).findByEmail(anyString());
    }

    @Test
    void testSave_CreatesNewRecord() {
        // Arrange
        String userName = "newuser@example.com";
        String userIp = "192.168.1.2";
        boolean isSuccess = true;

        // Simulate no existing record found
        when(userLoginDetailsRepository.findTopByUserNameOrderByIdDesc(userName)).thenReturn(null);
        when(userLoginDetailsConverter.convertToDomain(any(UserLoginDetailsDto.class))).thenAnswer(invocation -> {
            UserLoginDetailsDto dto = invocation.getArgument(0);
            UserLoginDetails entity = new UserLoginDetails();
            entity.setUserName(dto.getUserName());
            entity.setUserIp(dto.getUserIp());
            entity.setIsSuccess(dto.isSuccess());
            entity.setInvalidLoginCount(dto.getInvalidLoginCount());
            entity.setLoginDate(dto.getLoginDate());
            entity.setLoginTime(dto.getLoginTime());
            return entity;
        });

        when(userLoginDetailsRepository.save(any(UserLoginDetails.class))).thenAnswer(invocation -> {
            UserLoginDetails entity = invocation.getArgument(0);
            entity.setId("2L");
            return entity;
        });

        // Act
        UserLoginDetailsDto result = userLoginDetailsService.save(userName, userIp, isSuccess);

        // Assert
        assertNotNull(result);
        assertEquals(userName, result.getUserName());
        assertEquals(userIp, result.getUserIp());
        assertEquals(isSuccess, result.isSuccess());
        assertEquals(0, result.getInvalidLoginCount());
    }


}