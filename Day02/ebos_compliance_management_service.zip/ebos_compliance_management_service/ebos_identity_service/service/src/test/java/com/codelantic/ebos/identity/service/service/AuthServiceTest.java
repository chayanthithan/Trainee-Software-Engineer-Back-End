package com.codelantic.ebos.identity.service.service;

import com.codelantic.ebos.identity.service.api.dto.JwtAuthenticationResponse;
import com.codelantic.ebos.identity.service.api.dto.LoginRequest;
import com.codelantic.ebos.identity.service.api.dto.RefreshTokenRequest;
import com.codelantic.ebos.identity.service.api.dto.UserAuthenticationDto;
import com.codelantic.ebos.identity.service.converter.UserAuthenticationConverter;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.UserType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import com.codelantic.ebos.identity.service.security.jwt.TokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @InjectMocks
    AuthService authService;
    @Mock
    AuthenticationManager authenticationManager;
    @Mock
    TokenProvider tokenProvider;
    @Mock
    UserDetailService userDetailService;
    @Mock
    UserAuthenticationRepository userAuthenticationRepository;
    @Mock
    TwoFactorCodeService twoFactorCodeService;
    @Mock
    UserAuthenticationConverter userAuthenticationConverter;
    @Mock
    UserLoginDetailsService userLoginDetailsService;

    @Value("${url.domain}")
    private String urlDomain;


    @Test
    void authenticateUser_SuccessfulAuthentication() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        // Arrange
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setPassword("password");
        loginRequest.setUrl("keeka.cebos.com");
        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUserType(UserType.STAFF);
        userAuthentication.setPassword("$2a$12$c6/.2dMRVvHY7Ab8SrBnE.voRk3gKITN9SYun2d/Q6lHFlseaOrJq");
        userAuthentication.setUserType(UserType.OWNER);

        org.junit.jupiter.api.Assertions.assertThrows(
                ServiceException.class,
                () -> authService.authenticateUser(loginRequest)
        );
    }

    @Test
    void authenticateUser_UserNotFound() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        // Arrange
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("nonexistent@example.com");
        loginRequest.setUrl("keeka..com");

        // Act and Assert
        org.junit.jupiter.api.Assertions.assertThrows(
                ServiceException.class,
                () -> authService.authenticateUser(loginRequest)
        );

    }

    @Test
    void authenticate2FA() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("user");
        loginRequest.setTwoFactorCode("code");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setUserId("1");

        Mockito.when(userAuthenticationRepository.findByEmail(loginRequest.getUsername())).thenReturn(Optional.of(userAuthentication));

        assertNotNull(authService.authenticate2FA(loginRequest));
    }

    @Test
    void generateToken_Success() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setPassword("password");

        Authentication authentication = mock(Authentication.class);
        Mockito.when(authenticationManager.authenticate(Mockito.any())).thenReturn(authentication);

        String jwtToken = "exampleJwtToken";
        Mockito.when(tokenProvider.createToken(authentication)).thenReturn(jwtToken);

        Method method = AuthService.class.getDeclaredMethod("generateToken", LoginRequest.class, UserAuthentication.class);
        method.setAccessible(true);
        assertNotNull(method.invoke(authService, loginRequest, new UserAuthentication()));

    }

    @Test
    void save() {
        UserAuthenticationDto userAuthenticationDto = new UserAuthenticationDto();
        Mockito.when(userAuthenticationRepository.save(userAuthenticationConverter.convert(userAuthenticationDto))).thenReturn(new UserAuthentication());
        assertNotNull(authService.save(userAuthenticationDto));
    }

    @Test
    void getById_UserExists() {
        // Arrange
        String userId = "user123";
        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setUserId(userId);

        when(userAuthenticationRepository.findByUserId(userId)).thenReturn(Optional.of(userAuthentication));
        UserAuthentication result = authService.getById(userId);
        assertEquals(userId, result.getUserId());
        verify(userAuthenticationRepository, times(1)).findByUserId(userId);
    }

    @Test
    void getById_UserDoesNotExist() {
        String userId = "nonExistingUser";
        when(userAuthenticationRepository.findByUserId(userId)).thenReturn(Optional.empty());

        ServiceException exception = assertThrows(
                ServiceException.class,
                () -> authService.getById(userId)
        );
        assertEquals("User Not Found", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
        verify(userAuthenticationRepository, times(1)).findByUserId(userId);
    }

    @Test
    void testAuthenticateUser_UrlNotFound() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setUrl("http://example.com");

        ServiceException thrown = assertThrows(ServiceException.class, () -> {
            authService.authenticateUser(loginRequest);
        });


        assertEquals(HttpStatus.BAD_REQUEST, thrown.getHttpStatus());
    }

    @Test
    void testAuthenticateUser_Success() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("http://example.com").build();
        AuthenticationContextHolder.setContext(authentication);

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setUrl("example.com");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUrl("example.com");
        userAuthentication.setUserType(UserType.OWNER);
        userAuthentication.setIsLocked(false);
        when(userAuthenticationRepository.existsByUrl("example.com")).thenReturn(true);
        when(userAuthenticationRepository.findByEmailAndUrl(loginRequest.getUsername(), loginRequest.getUrl()))
                .thenReturn(Optional.of(userAuthentication));

        ResponseEntity<Object> response = authService.authenticateUser(loginRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testAuthenticateUser_UserAccountLocked() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("http://example.com").build();
        AuthenticationContextHolder.setContext(authentication);

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setUrl("example.com");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUrl("example.com");
        userAuthentication.setUserType(UserType.OWNER);
        userAuthentication.setIsLocked(true);

        when(userAuthenticationRepository.existsByUrl("example.com")).thenReturn(true);
        when(userAuthenticationRepository.findByEmailAndUrl(loginRequest.getUsername(), loginRequest.getUrl()))
                .thenReturn(Optional.of(userAuthentication));

        ServiceException thrown = assertThrows(ServiceException.class, () -> {
            authService.authenticateUser(loginRequest);
        });

        assertEquals("The Credentials you entered are invalid. Your account will be blocked due to three invalid login attempts, and you will not have access to the account again.", thrown.getMessage());
        assertEquals(HttpStatus.UNAUTHORIZED, thrown.getHttpStatus());
    }

    @Test
    void testAuthenticateUser_UserTypeNotAuthorized() {
        com.codelantic.ebos.identity.service.security.Authentication authentication = com.codelantic.ebos.identity.service.security.Authentication.builder()
                .businessUrl("http://example.com").build();
        AuthenticationContextHolder.setContext(authentication);

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("test@example.com");
        loginRequest.setUrl("example.com");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUrl("http://example.com");
        userAuthentication.setIsLocked(true);

        userAuthentication.setUserType(UserType.ADMIN);

        when(userAuthenticationRepository.existsByUrl("example.com")).thenReturn(true);
        when(userAuthenticationRepository.findByEmailAndUrl(loginRequest.getUsername(), loginRequest.getUrl()))
                .thenReturn(Optional.of(userAuthentication));

        assertThrows(ServiceException.class, () -> {
            authService.authenticateUser(loginRequest);
        });


    }

    @Test
    void refreshToken_Success() {
        // Arrange
        String validRefreshToken = "validRefreshToken";
        String expectedJwtToken = "newJwtToken";
        String expectedNewRefreshToken = "newRefreshToken";

        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
        refreshTokenRequest.setRefreshToken(validRefreshToken);

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");

        // Mocking the tokenProvider behavior
        when(tokenProvider.validateRefreshToken(validRefreshToken)).thenReturn(Boolean.TRUE);
        when(tokenProvider.getUserIdFromToken(validRefreshToken)).thenReturn("test@example.com");
        when(userAuthenticationRepository.findByEmail("test@example.com")).thenReturn(Optional.of(userAuthentication));
        when(tokenProvider.createTokenFromRefreshToken(userAuthentication)).thenReturn(expectedJwtToken);
        when(tokenProvider.doGenerateToken(userAuthentication.getEmail(), userAuthentication)).thenReturn(expectedNewRefreshToken);

        // Act
        ResponseEntity<Object> response = authService.refreshToken(refreshTokenRequest);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        JwtAuthenticationResponse jwtResponse = (JwtAuthenticationResponse) response.getBody();
        assertNotNull(jwtResponse);
        assertEquals(expectedJwtToken, jwtResponse.getAccessToken());
        assertEquals(expectedNewRefreshToken, jwtResponse.getRefreshToken());
    }

    @Test
    void refreshToken_InvalidToken() {
        // Arrange
        String invalidRefreshToken = "invalidRefreshToken";

        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
        refreshTokenRequest.setRefreshToken(invalidRefreshToken);

        when(tokenProvider.validateRefreshToken(invalidRefreshToken)).thenReturn(Boolean.FALSE);

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () -> authService.refreshToken(refreshTokenRequest));
        assertEquals("Invalid refresh token", exception.getMessage());
        assertEquals(HttpStatus.UNAUTHORIZED, exception.getHttpStatus());
    }

    @Test
    void refreshToken_UserNotFound() {
        // Arrange
        String validRefreshToken = "validRefreshToken";

        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
        refreshTokenRequest.setRefreshToken(validRefreshToken);

        when(tokenProvider.validateRefreshToken(validRefreshToken)).thenReturn(Boolean.TRUE);
        when(tokenProvider.getUserIdFromToken(validRefreshToken)).thenReturn("test@example.com");
        when(userAuthenticationRepository.findByEmail("test@example.com")).thenReturn(Optional.empty());

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () -> authService.refreshToken(refreshTokenRequest));
        assertEquals("User not found", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }

    @Test
    void refreshToken_UserAuthenticationIsNull() {
        // Arrange
        String validRefreshToken = "validRefreshToken";

        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
        refreshTokenRequest.setRefreshToken(validRefreshToken);

        when(tokenProvider.validateRefreshToken(validRefreshToken)).thenReturn(Boolean.TRUE);
        when(tokenProvider.getUserIdFromToken(validRefreshToken)).thenReturn("test@example.com");
        when(userAuthenticationRepository.findByEmail("test@example.com")).thenReturn(Optional.ofNullable(null));

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class, () -> authService.refreshToken(refreshTokenRequest));
        assertEquals("User not found", exception.getMessage());
        assertEquals(HttpStatus.BAD_REQUEST, exception.getHttpStatus());
    }


    @Test
    void isBusinessUrlValid() {
        Mockito.when(userAuthenticationRepository.existsByUrl("ebos.com")).thenReturn(Boolean.TRUE);

        assertNotNull(authService.isBusinessUrlValid("http://ebos.com"));
    }
    @Test
    void isBusinessUrlValid_with_https() {
        Mockito.when(userAuthenticationRepository.existsByUrl("ebos.com")).thenReturn(Boolean.TRUE);

        assertNotNull(authService.isBusinessUrlValid("https://ebos.com"));
    }

@Test
void isBusinessUrlValid_existByUrl() {
    String url = "http://testing.com";
    String trimmedUrl = "testing.com";

    when(userAuthenticationRepository.existsByUrl(trimmedUrl)).thenReturn(true);
    Boolean result = authService.isBusinessUrlValid(url);

    assertNotNull(result);
}

@Test
void isBusinessUrlValid_Exception(){
    String url = "http://testing.com";
    String trimmedUrl = "testing.com";

    when(userAuthenticationRepository.existsByUrl(trimmedUrl)).thenReturn(false);
    assertThrows(ServiceException.class, () -> authService.isBusinessUrlValid(url));
}

    @Test
    void isUrlExist_null() {
        assertNotNull(authService.isUrlExist(null));
    }

    @Test
    void isUrlExisthttp(){
        assertNotNull(authService.isUrlExist("http://ebos.com"));
        assertNotNull(authService.isUrlExist("https://ebos.com"));
    }

    @Test
    void isUrlExist_ServiceException(){
        String url = "htt://";
        when(userAuthenticationRepository.existsByUrl(url)).thenReturn(true);
        assertThrows(ServiceException.class,()->authService.isUrlExist(url));
    }

    @Test
    void testGenerateToken_DisabledException() throws Exception {

        LoginRequest loginRequest = mock(LoginRequest.class);
        UserAuthentication userAuthentication = mock(UserAuthentication.class);
        DisabledException disabledException = new DisabledException("USER_DISABLED");


        when(loginRequest.getUsername()).thenReturn("testUsername");
        when(loginRequest.getPassword()).thenReturn("testPassword");

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(disabledException);

        Method method = AuthService.class.getDeclaredMethod("generateToken", LoginRequest.class, UserAuthentication.class);
        method.setAccessible(true);

        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, () -> {
            method.invoke(authService, loginRequest, userAuthentication);
        });

        assertEquals(DisabledException.class, thrown.getCause().getClass());
        assertEquals("USER_DISABLED", thrown.getCause().getMessage());
    }

    @Test
    void testGenerateToken_BadCredential() throws Exception {

        LoginRequest loginRequest = mock(LoginRequest.class);
        UserAuthentication userAuthentication = mock(UserAuthentication.class);
        BadCredentialsException badCredentialsException = new BadCredentialsException("Invalid credentials");

        when(loginRequest.getUsername()).thenReturn("testUsername");
        when(loginRequest.getPassword()).thenReturn("testPassword");

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(badCredentialsException);

        when(userLoginDetailsService.save(eq("testUser"), anyString(), eq(false))).thenReturn(null);

        Method method = AuthService.class.getDeclaredMethod("generateToken", LoginRequest.class, UserAuthentication.class);
        method.setAccessible(true);

         assertThrows(InvocationTargetException.class, () -> {
            method.invoke(authService, loginRequest, userAuthentication);
        });

    }

    @Test
    void validateBusinessUrl_ServiceException1() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        com.codelantic.ebos.identity.service.security.Authentication authentication = mock(com.codelantic.ebos.identity.service.security.Authentication.class);
        when(authentication.getBusinessUrl()).thenReturn(null); // Mocking null businessUrl

        AuthenticationContextHolder.setContext(authentication);

        LoginRequest loginRequest = mock(LoginRequest.class);

        Method method = AuthService.class.getDeclaredMethod("validateBusinessUrl", LoginRequest.class);
        method.setAccessible(true);

        try {
            method.invoke(authService, loginRequest);
            fail("Expected ServiceException to be thrown"); // If no exception is thrown, the test should fail
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof ServiceException);
        }
    }

    @Test
    void validateBusinessUrl_ServiceException2() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        com.codelantic.ebos.identity.service.security.Authentication authentication = mock(com.codelantic.ebos.identity.service.security.Authentication.class);
        when(authentication.getBusinessUrl()).thenReturn("testUrl");

        AuthenticationContextHolder.setContext(authentication);

        LoginRequest loginRequest = mock(LoginRequest.class);

        when(userAuthenticationRepository.existsByUrl(loginRequest.getUrl())).thenReturn(false);
        Method method = AuthService.class.getDeclaredMethod("validateBusinessUrl", LoginRequest.class);
        method.setAccessible(true);

        try {
            method.invoke(authService, loginRequest);
            fail("Expected ServiceException to be thrown"); // If no exception is thrown, the test should fail
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof ServiceException);
        }
    }
    @Test
    void testRecursiveCaseFindsValidUrl() {
        when(userAuthenticationRepository.existsByUrl(anyString())).thenReturn(true);
        assertThrows(StackOverflowError.class,()->  authService.validateBusinessNameUrl("ajith"));


    }
    @Test
    void validateBusinessNameUrl(){
        String businessName ="ajith";
        when(userAuthenticationRepository.existsByUrl(anyString())).thenReturn(false);
        assertNotNull(authService.validateBusinessNameUrl(businessName));
    }
}