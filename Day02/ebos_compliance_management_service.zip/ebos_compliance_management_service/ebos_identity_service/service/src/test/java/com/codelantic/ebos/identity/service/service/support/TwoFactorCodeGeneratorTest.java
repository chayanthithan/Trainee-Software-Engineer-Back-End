package com.codelantic.ebos.identity.service.service.support;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TwoFactorCodeGeneratorTest {
    @InjectMocks
    TwoFactorCodeGenerator twoFactorCodeGenerator;

    @Test
    void generateTwoFactorCode() {
        Assertions.assertNotNull(twoFactorCodeGenerator.generateTwoFactorCode());
    }
}