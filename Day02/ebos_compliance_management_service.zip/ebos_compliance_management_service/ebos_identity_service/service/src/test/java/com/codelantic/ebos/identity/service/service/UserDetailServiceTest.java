package com.codelantic.ebos.identity.service.service;

import com.codelantic.bankoyo.notification.client.NotificationClient;
import com.codelantic.bankoyo.notification.client.dto.EmailDataDto;
import com.codelantic.ebos.identity.service.api.dto.*;
import com.codelantic.ebos.identity.service.config.SecurityConfig;
import com.codelantic.ebos.identity.service.entity.UserAuthentication;
import com.codelantic.ebos.identity.service.enums.OtpType;
import com.codelantic.ebos.identity.service.exception.ServiceException;
import com.codelantic.ebos.identity.service.repository.UserAuthenticationRepository;
import com.codelantic.ebos.identity.service.security.Authentication;
import com.codelantic.ebos.identity.service.security.AuthenticationContextHolder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserDetailServiceTest {

    @InjectMocks
    UserDetailService userDetailService;

    @Mock
    UserAuthenticationRepository userAuthenticationRepository;

    @Mock
    TwoFactorCodeService twoFactorCodeService;

    @Mock
    SecurityConfig securityConfig;
    @Mock
    NotificationClient notificationClient;


    @Test
    void loadUserByUsername() {
        String userName = "aj";

        UserAuthentication user = new UserAuthentication();
        user.setEmail("email");
        user.setPassword("pass0");


        Mockito.when(userAuthenticationRepository.findByEmail(userName)).thenReturn(Optional.of(user));
        assertNotNull(userDetailService.loadUserByUsername(userName));
    }

    @Test
    void updateUserPassword() {
        Authentication authentication = Authentication.builder()
                .businessUrl("https://shahithiyan.ebos.com").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("shahithiyan.ebos.com")).thenReturn(Boolean.TRUE);

        AuthenticationDto authenticationDto = new AuthenticationDto();
        authenticationDto.setOldPassword("pass");
        authenticationDto.setEmail("email");
        authenticationDto.setPassword("newPass");
        String hashedPassword = BCrypt.hashpw("pass", BCrypt.gensalt());

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setPassword(hashedPassword);
        userAuthentication.setEmail("email");

        Mockito.when(userAuthenticationRepository.findByUserId(authenticationDto.getUserId())).thenReturn(Optional.of(userAuthentication));


        assertThrows(
                ServiceException.class,
                () -> userDetailService.updateUserPassword(authenticationDto));

    }

    @Test
    void updatePasswordOtpSend() {
        Authentication authentication = Authentication.builder().build();
        authentication.setUserName("mithuja@codelantic.com");
        authentication.setBusinessUrl("http://shahithiyan.ebos.com");
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("shahithiyan.ebos.com")).thenReturn(Boolean.TRUE);

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setUsername("mithuja@codelantic.com");

        AuthenticationContextHolder.setContext(authentication);
        Mockito.when(twoFactorCodeService.createAndSend(twoFactorRequestDto)).thenReturn(new AgentResponseDto());
        assertNotNull(userDetailService.updatePasswordOtpSend(twoFactorRequestDto));

    }

    @Test
    void updatePassword_Success() {
        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        resetPasswordDto.setTwoFactorCode("123456");
        resetPasswordDto.setPassword("newPassword");

        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUserId("user123");

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        twoFactorRequestDto.setUserId("user123");
        twoFactorRequestDto.setTwoFactorCode("123456");

        assertThrows(
                ServiceException.class,
                () -> userDetailService.updatePassword(resetPasswordDto)
        );
    }

    @Test
    void updatePassword_InvalidEmail() {
        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();

        assertThrows(
                ServiceException.class,
                () -> userDetailService.updatePassword(resetPasswordDto)
        );
    }

    @Test
    void updatePassword_UserNotFound() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        UserAuthenticationDto userAuthentication = new UserAuthenticationDto();
        userAuthentication.setPassword("Shgvghvj54@$g");
        userAuthentication.setEmail("gfddfg@gmail.com");
        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        resetPasswordDto.setUserAuthentication(userAuthentication);
        resetPasswordDto.setIsUpdatePassword(Boolean.TRUE);

        assertThrows(
                ServiceException.class,
                () -> userDetailService.updatePassword(resetPasswordDto)
        );
    }


    @Test
    void updatePassword_PasswordChanged() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        resetPasswordDto.setTwoFactorCode("123456");
        resetPasswordDto.setPassword("newPassword");
        resetPasswordDto.setVerificationToken("token");

        UserAuthenticationDto userAuthentication = new UserAuthenticationDto();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUserId("user123");
        userAuthentication.setPassword("Shgvghvj54@$g");

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setOtpType(OtpType.UPDATE_PASSWORD);
        twoFactorRequestDto.setTwoFactorCode("123456");
        resetPasswordDto.setUserAuthentication(userAuthentication);
        resetPasswordDto.setIsUpdatePassword(Boolean.TRUE);

        UserAuthentication userAuthenticationByEmail = new UserAuthentication();
        Mockito.when(userAuthenticationRepository.findByEmail(resetPasswordDto.getUserAuthentication().getEmail())).thenReturn(Optional.of(userAuthenticationByEmail));
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("success");
        Mockito.when(twoFactorCodeService.validate(twoFactorRequestDto)).thenReturn(responseDto);
        Mockito.when(securityConfig.passwordEncoder()).thenReturn(new BCryptPasswordEncoder());

        userDetailService.updatePassword(resetPasswordDto);
    }

    @Test
    void deleteUser()
    {
        String id="vdgy519";
        assertNotNull(userDetailService.deleteUser(id));
    }

    @Test
    void resetPassword() {
        Authentication authentication = Authentication.builder()
                .businessUrl("url").build();
        AuthenticationContextHolder.setContext(authentication);
        when(userAuthenticationRepository.existsByUrl("url")).thenReturn(Boolean.TRUE);

        ResetPasswordDto resetPasswordDto = new ResetPasswordDto();
        resetPasswordDto.setPassword("newPassword");
        resetPasswordDto.setIsOtpValidated(Boolean.TRUE);
        resetPasswordDto.setVerificationToken("token");

        UserAuthenticationDto userAuthenticationDto = new UserAuthenticationDto();
        userAuthenticationDto.setEmail("test@example.com");
        userAuthenticationDto.setUserId("user123");
        userAuthenticationDto.setUserName("tester");
        UserAuthentication userAuthentication = new UserAuthentication();
        userAuthentication.setEmail("test@example.com");
        userAuthentication.setUserId("user123");
        userAuthentication.setUserName("tester");
        resetPasswordDto.setUserAuthentication(userAuthenticationDto);
        when(userAuthenticationRepository.findByEmail(resetPasswordDto.getUserAuthentication().getEmail()))
                .thenReturn(Optional.of(userAuthentication));

        TwoFactorRequestDto twoFactorRequestDto = new TwoFactorRequestDto();
        twoFactorRequestDto.setEmail(userAuthentication.getEmail());
        twoFactorRequestDto.setTwoFactorCode(resetPasswordDto.getTwoFactorCode());
        twoFactorRequestDto.setOtpType(OtpType.RESET_PASSWORD);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setMessage("success");
        Mockito.when(twoFactorCodeService.isOtpVerified(twoFactorRequestDto, resetPasswordDto.getVerificationToken())).thenReturn(responseDto);


        Mockito.when(securityConfig.passwordEncoder()).thenReturn(new BCryptPasswordEncoder());
        when(userAuthenticationRepository.save(userAuthentication)).thenReturn(new UserAuthentication());
        EmailDataDto emailDataDto = new EmailDataDto();
        emailDataDto.setRecipients(List.of(resetPasswordDto.getUserAuthentication().getEmail()));

        emailDataDto.setServiceProvider("ebos");
        emailDataDto.setSubject("\uD83D\uDD12 Your Password Has Been Changed");
        emailDataDto.setMailTemplateName("password_change_confirmation");
        Map<String, Object> emailDataData = new HashMap<>();

        emailDataData.put("userName", resetPasswordDto.getUserAuthentication().getUserName());
        emailDataDto.setData(emailDataData);
        notificationClient.send(emailDataDto);

        assertNotNull(userDetailService.resetPassword(resetPasswordDto));
    }

    @Test
    void getUrlByOwnerId(){
        String ownerId="ownerId";
        Mockito.when(userAuthenticationRepository.getUrlByOwnerId(ownerId)).thenReturn("url");
        assertNotNull(userDetailService.getUrlByOwnerId(ownerId));
    }
}