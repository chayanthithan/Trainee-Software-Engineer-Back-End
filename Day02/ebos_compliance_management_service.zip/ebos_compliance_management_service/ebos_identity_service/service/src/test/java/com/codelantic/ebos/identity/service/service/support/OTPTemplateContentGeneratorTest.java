package com.codelantic.ebos.identity.service.service.support;

import com.codelantic.ebos.identity.service.enums.OtpType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class OTPTemplateContentGeneratorTest {
    @InjectMocks
    OTPTemplateContentGenerator otpTemplateContentGenerator;

    @Test
    void generateOtpTemplateContent() {
        Assertions.assertNotNull(otpTemplateContentGenerator.generateOtpTemplateContent(OtpType.SIGN_IN));
    }

    @Test
    void generateOtpTemplateContent1() {
        Assertions.assertNotNull(otpTemplateContentGenerator.generateOtpTemplateContent(OtpType.UPDATE_PASSWORD));
    }

    @Test
    void generateOtpTemplateContent2() {
        Assertions.assertNotNull(otpTemplateContentGenerator.generateOtpTemplateContent(OtpType.RESET_PASSWORD));
    }
}