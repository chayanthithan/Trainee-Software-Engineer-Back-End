package com.codelantic.ebos.identity.client.dto;

import com.codelantic.ebos.identity.client.enums.UserType;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserAuthentication {
    private String id;
    private LocalDateTime createdDateTime;
    private String email;
    private String userName;
    private String password;
    private String userId;
    private UserType userType;
    private String url;
}
