package com.codelantic.ebos.identity.client.enums;

public enum UserType {

    ADMIN,
    OWNER,
    STAFF;

    private UserType() {
    }


}
