package com.codelantic.ebos.identity.client.dto;

import lombok.Data;

@Data
public class AgentResponse {
    private String message;

}
