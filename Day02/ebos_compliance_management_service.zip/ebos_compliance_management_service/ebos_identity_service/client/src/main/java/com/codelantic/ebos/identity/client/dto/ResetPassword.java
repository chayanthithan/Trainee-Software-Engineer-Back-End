package com.codelantic.ebos.identity.client.dto;

import lombok.Data;


@Data
public class ResetPassword {
    UserAuthentication userAuthentication;
    String password;
    private String twoFactorCode;
    private Boolean isUpdatePassword;
}
