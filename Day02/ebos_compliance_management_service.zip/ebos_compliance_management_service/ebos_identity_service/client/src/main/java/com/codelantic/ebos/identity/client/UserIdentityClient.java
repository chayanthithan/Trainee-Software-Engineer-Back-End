package com.codelantic.ebos.identity.client;

import com.codelantic.ebos.identity.client.dto.*;
import com.codelantic.ebos.identity.client.enums.OtpType;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "user-identity-client", url = "${user.identity.service.url}")
public interface UserIdentityClient {

    @PutMapping("/api/v1/users/update_user_password")
    public Boolean updateUser(Authentication authenticationDto);

    @PostMapping("/api/v1/auth/save")
    public UserAuthentication save(@RequestBody UserAuthentication userAuthenticationDto);

    @PutMapping("/api/v1/users-identity/updatePassword")
    public Response updatePassword(@RequestBody ResetPassword resetPasswordDto);

    @GetMapping("/api/v1/auth/getById")
    public UserAuthentication getById(@RequestParam(value = "id") String id);

    @DeleteMapping("/api/v1/users-identity/deleteUser/{id}")
    public Response deleteUser(@PathVariable(value = "id") String id);

    @GetMapping("/api/v1/two-factor-codes/getTwofacterForSignUp")
    List<TwoFactorCodeDto> getTwofacterForSignUp(@RequestParam(value = "email",required = true) String email, @RequestParam(value = "otp" ,required = true)String otp);

    @GetMapping("/api/v1/two-factor-codes/otpVerification")
    public Response otpVerification(@RequestParam("otpType") OtpType otpType,
                                    @RequestParam("email") String email,
                                    @RequestParam("verificationToken") String verificationToken);

    @GetMapping("/api/v1/users-details/url")
    public String getUrlByOwnerId(@RequestParam(value = "ownerId") String ownerId);

    @GetMapping("/api/v1/auth/isUrlExist")
    public Boolean validateBusinessUrl(@RequestParam("url") String url);
}
