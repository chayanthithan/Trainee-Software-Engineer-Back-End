package com.codelantic.ebos.identity.client.dto;

import lombok.Data;

@Data
public class Authentication {
    private String id;
    private String email;
    private String password;
    private String oldPassword;
}
