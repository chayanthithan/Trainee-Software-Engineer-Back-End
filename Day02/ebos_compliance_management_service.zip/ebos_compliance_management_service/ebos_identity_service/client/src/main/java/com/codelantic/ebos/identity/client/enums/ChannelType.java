package com.codelantic.ebos.identity.client.enums;

public enum ChannelType {
    EMAIL,
    MOBILE
}
