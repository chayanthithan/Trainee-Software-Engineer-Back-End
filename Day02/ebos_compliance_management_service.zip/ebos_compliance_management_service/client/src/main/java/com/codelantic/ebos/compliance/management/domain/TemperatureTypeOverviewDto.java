package com.codelantic.ebos.compliance.management.domain;

import com.codelantic.ebos.compliance.management.enums.TemperatureType;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TemperatureTypeOverviewDto {
    private String id;
    private String itemName;
    private String temperatureType;
    private String startTemperature;
    private String endTemperature;
    private String temperature;
    private int quantity;
    private String images;
    private List<ImageOrAudioNameWithLink> temperatureOverviewDownloadDto;
    private List<String> notifyTo;
    private String temperatureTypeRangeConfigurationsId;

    public TemperatureTypeOverviewDto(String itemName, TemperatureType temperatureType, String startTemperature, String endTemperature, String temperature, int quantity) {
        this.itemName = itemName;
        this.temperatureType = temperatureType.getMappedValue();
        this.startTemperature = startTemperature;
        this.endTemperature = endTemperature;
        this.temperature = temperature;
        this.quantity = quantity;
    }
    public TemperatureTypeOverviewDto(String id,String itemName, TemperatureType temperatureType, String startTemperature, String endTemperature, String temperature, int quantity,String temperatureTypeRangeConfigurationsId) {
        this.id=id;
        this.itemName = itemName;
        this.temperatureType = temperatureType.getMappedValue();
        this.startTemperature = startTemperature;
        this.endTemperature = endTemperature;
        this.temperature = temperature;
        this.quantity = quantity;
        this.temperatureTypeRangeConfigurationsId=temperatureTypeRangeConfigurationsId;
    }

    public TemperatureTypeOverviewDto(){

    }

    public TemperatureTypeOverviewDto(String itemName, String startTemperature, String endTemperature, TemperatureType temperatureType,String temperatureTypeRangeConfigurationsId) {
        this.itemName = itemName;
        this.startTemperature = startTemperature;
        this.endTemperature = endTemperature;
        this.temperatureType = temperatureType.getMappedValue();
        this.temperatureTypeRangeConfigurationsId=temperatureTypeRangeConfigurationsId;
    }
}
