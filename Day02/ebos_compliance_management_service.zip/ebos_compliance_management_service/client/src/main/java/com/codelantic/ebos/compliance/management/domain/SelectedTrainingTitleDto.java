package com.codelantic.ebos.compliance.management.domain;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class SelectedTrainingTitleDto {
    private String id;
    private String trainingTitleId;
    private String trainingReadingId;
}
