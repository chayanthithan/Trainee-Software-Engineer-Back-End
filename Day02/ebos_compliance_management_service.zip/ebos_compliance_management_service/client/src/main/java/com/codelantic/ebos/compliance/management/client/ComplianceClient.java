package com.codelantic.ebos.compliance.management.client;

import com.codelantic.ebos.compliance.management.domain.*;
import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@FeignClient(name = "compliance-management-client", url = "${compliance.management.service.url}")
public interface ComplianceClient {
    @GetMapping("api/v1/incident/incident-overview")
    public PaginatedResponseDto<IncidentOverviewDto> getAllIncidentOverview(@SpringQueryMap IncidentOverviewSearchDto incidentOverviewSearchDto);

    @GetMapping("api/v1/health-and-safety/get-all-health-and-safety")
    public PaginatedResponseDto<HealthAndSafetyOverViewDisplayDto> overViewForHealthAndSafety(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                              @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                              @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                              @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                              @RequestParam(value = "complianceStatus", required = false) ComplianceStatus complianceStatus,
                                                                                              @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                              @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                              @RequestParam(value = "subCategoryId") String subCategoryId);
    @GetMapping("api/v1/health-and-safety/get-overview-health-and-safety-by-id")
    public HealthAndSafetyOverViewDisplayDto getOverviewHealthAndSafetyById( @RequestParam(value = "id") String id);


    @GetMapping("api/v1/cleaning/get-all-cleaning")
    public PaginatedResponseDto<CleaningOverViewDisplayDto> overViewForCleaning(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                @RequestParam(value = "subCategoryId") String subCategoryId);

    @GetMapping("api/v1/cleaning/get-overview-cleaning-by-id")
    public CleaningOverViewDisplayDto getOverviewCleaningById(@RequestParam(value = "id") String complianceReadingId);

    @GetMapping("api/v1/incident/get-overview-by-id")
    public IncidentOverviewDto getOverViewById(@RequestParam(value = "id") String id);

    @GetMapping("api/v1/temperature/temperature-overview-row-download")
    public TemperatureOverviewDto getAllTemperatureOverviewRow(@RequestParam(value = "id") String id);



    @GetMapping("api/v1/pest-control/get-all")
    public PaginatedResponseDto<PestControlOverviewDto> getAll(@Valid @SpringQueryMap WasteManagementOverviewSearchDto searchDto) ;

    @GetMapping("api/v1/pest-control/get-overview-by-id")
    public PestControlOverviewDto getOneOverViewById(@RequestParam(value = "id") String id) ;

    @GetMapping("api/v1/complaint/get-all-compliant-overview")
    public PaginatedResponseDto<CompliantOverViewDto> getAllComplaints(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business id is required") String businessId,
                                                                       @RequestParam(value = "complianceSubCategoryId", required = false) @NotBlank(message = "Compliance Sub Category Id is required") String complianceSubCategoryId,
                                                                       @RequestParam(value = "fromDate", required = false) @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                       @RequestParam(value = "toDate", required = false) @NotNull(message = "To Date is required") LocalDate toDate,
                                                                       @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                       @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                       @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                       @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size);
    @GetMapping("/api/v1/waste-management/get-all-waste-overview")
    PaginatedResponseDto<WasteManagementOverviewDto> getAllWasteOverview(@RequestParam(value = "businessId",required = false) @NotBlank String businessId,
                                                                         @RequestParam(value = "complianceSubCategoryId", required = false) @NotBlank(message = "Compliance Sub Category Id is required") String complianceSubCategoryId,
                                                                         @RequestParam(value = "fromDate", required = false) @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                         @RequestParam(value = "toDate", required = false) @NotNull(message = "To Date is required") LocalDate toDate,
                                                                         @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                         @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                         @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                         @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size);
    @GetMapping("api/v1/complaint/get-overview-compliant-by-id")
    public CompliantOverViewDto getOverviewCompliantById( @RequestParam(value = "id") String id);

    @GetMapping("/api/v1/waste-management/get-overview-waste-by-id")
    public WasteManagementOverviewDto getOverviewWasteById( @RequestParam(value = "id") String id);


    @GetMapping("api/v1/license-and-permit/get-all-license-and-permit-reading")
    public PaginatedResponseDto<LicenseAndPermitReadingOverViewDto> overViewForLicenseAndPermitReading(@RequestParam(value = "businessId") @NotBlank(message = "Business Id is required") String businessId,
                                                                                                       @RequestParam(value = "fromDate") @NotNull(message = "From Date is required") LocalDate fromDate,
                                                                                                       @RequestParam(value = "toDate") @NotNull(message = "To Date is required") LocalDate toDate,
                                                                                                       @RequestParam(value = "employeeName", required = false) String employeeName,
                                                                                                       @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                                       @RequestParam(value = "page", required = false) @NotNull(message = "Page is required") @Positive(message = "Page should be positive numerical value") Integer page,
                                                                                                       @RequestParam(value = "size", required = false) @NotNull(message = "Size is required") @Positive(message = "size should be positive numerical value") Integer size,
                                                                                                       @RequestParam(value = "subCategoryId",required = true) String subCategoryId);

    @GetMapping("api/v1/license-and-permit/get-overview-by-id")
    public LicenseAndPermitReadingOverViewDto getLicenseOverviewById(@RequestParam(value = "id")String id,@RequestParam(value = "rowNo")String rowNo);

    @GetMapping("/api/v1/training/get-overview-training-by-id")
    public TrainingReadingDto getOverviewTrainingById(@RequestParam(value = "id") String id,@RequestParam(value = "rowNo") String rowNo);

    @GetMapping("/api/v1/training/training-overview")
    public PaginatedResponseDto<TrainingReadingDto> getAllTrainingReadings (@SpringQueryMap  @Valid TrainingOverViewSearchDto trainingOverViewSearchDto);

    @GetMapping("api/v1/visitor/get-visitor-overview")
    public PaginatedResponseDto<VisitorOverviewDto> getVistorOverview(
            @RequestParam(value = "businessId") String businessId,
            @RequestParam(value = "subCategoryId") String subCategoryId,
            @RequestParam(value = "fromDate") LocalDate fromDate,
            @RequestParam(value = "toDate") LocalDate toDate,
            @RequestParam(value = "employeeId", required = false) String employeeId,
            @RequestParam(value = "complianceStatus", required = false) String complianceStatus,
            @RequestParam(value = "page", required = false) @Positive(message = "Page number must be positive") Integer page,
            @RequestParam(value = "size", required = false) @Positive(message = "Size must be positive") Integer size
    );

    @GetMapping("api/v1/visitor/get-row-visitor")
    public VisitorOverviewDto getRowVisitor(@RequestParam(value = "id",required = false) @NotBlank(message = "Id is required") String id);

    @GetMapping("api/v1/temperature/temperature-overview")
    public PaginatedResponseDto<TemperatureOverviewDto> getAllTemperatureOverview(@RequestParam(value = "businessId",required = false) @NotBlank(message = "Business Id is required") String businessId, @RequestParam(value = "subCategoryId",required = false) @NotBlank(message = "Sub Category Id is required") String subCategoryId,
                                                                                  @RequestParam(value = "fromDate",required = false) @NotNull(message = "From date is required") LocalDate fromDate,
                                                                                  @RequestParam(value = "toDate",required = false) @NotNull(message = "To date is required") LocalDate toDate,
                                                                                  @RequestParam(value = "page") @Positive(message = "Page should be positive") int page, @RequestParam(value = "size") @Positive(message = "Size should be positive")int size,
                                                                                  @RequestParam(value = "complianceStatus",required = false) String complianceStatus,
                                                                                  @RequestParam(value = "employeeIds",required = false) List<String> employeeIds, @RequestParam(value = "notifyTos",required = false) List<String> notifyTos);

    @GetMapping("api/v1/temperature/temperature-overview-row-download-by-id")
    public TemperatureOverviewDto getAllTemperatureOverviewRowById(@RequestParam(value = "id") String id);


    }
