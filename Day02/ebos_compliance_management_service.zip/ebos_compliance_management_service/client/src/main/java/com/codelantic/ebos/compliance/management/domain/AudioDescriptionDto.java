package com.codelantic.ebos.compliance.management.domain;

import lombok.Data;

@Data
public class AudioDescriptionDto {
    private String id;
    private String fileName;
    private String fullViewPath;
    private String downloadPath;
}
