package com.codelantic.ebos.compliance.management.domain;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
public class IncidentOverviewDto {
    private int rowNo;
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String typeOfIncident;
    private String severity;
    private String department;
    private String supportingEvidence;
    private List<String> documentsList;
    private String affectedParties;
    private String potentialImpact;
    private String immediateResponse;
    private List<String> notifyTo;
    private String comments;
    private String complianceStatus;
    private String location;
    private String description;

    private List<ImageOrAudioNameWithLink> affectedPartiesAudio;
    private List<ImageOrAudioNameWithLink> potentialImpactsAudio;
    private List<ImageOrAudioNameWithLink> immediateResponsesAudio;
    private List<ImageOrAudioNameWithLink> descriptions;
    private List<ImageOrAudioNameWithLink> documents;
}
