package com.codelantic.ebos.compliance.management.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CleaningOverViewDisplayDto {
    private String rowNo;
    private String id;
    private String subCategoryName;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String pendingTotal;
    private String complianceStatus;
    private Set<ImageDescriptionDto> images;
}
