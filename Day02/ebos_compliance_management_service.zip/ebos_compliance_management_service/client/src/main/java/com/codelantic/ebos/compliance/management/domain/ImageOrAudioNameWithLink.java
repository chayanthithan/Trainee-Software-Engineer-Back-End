package com.codelantic.ebos.compliance.management.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ImageOrAudioNameWithLink {
    String name;
    String downloadLink;
    String link;

    public ImageOrAudioNameWithLink(String name, String link, String downloadLink) {
        this.name = name;
        this.link = link;
        this.downloadLink = downloadLink;
    }

    public ImageOrAudioNameWithLink(){

    }
}
