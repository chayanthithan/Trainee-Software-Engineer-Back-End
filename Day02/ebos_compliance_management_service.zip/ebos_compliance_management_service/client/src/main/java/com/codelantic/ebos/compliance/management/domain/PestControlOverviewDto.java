package com.codelantic.ebos.compliance.management.domain;

import com.codelantic.ebos.compliance.management.enums.ComplianceStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class PestControlOverviewDto {
    private Object rowNo;
    private String id;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String pendingOverTotal;
    private String complianceStatus;
    private Set<ImageDescriptionDto> images;

    public PestControlOverviewDto(Object rowNo, String id, LocalDate date, LocalTime time, String employeeName, Long countOfCheckListReading, Long countOfCheckList,
                                  Long countOfQuestionReading, Long countOfQuestions, ComplianceStatus complianceStatus) {
        this.rowNo = rowNo;
        this.id = id;
        this.date = date;
        this.time = time;
        this.employeeName = employeeName;
        if (complianceStatus != null) {
            this.complianceStatus = complianceStatus.getMappedValue();
        }
        this.pendingOverTotal = ( countOfCheckListReading + countOfQuestionReading) + " out of " + (countOfCheckList + countOfQuestions);
    }
}
