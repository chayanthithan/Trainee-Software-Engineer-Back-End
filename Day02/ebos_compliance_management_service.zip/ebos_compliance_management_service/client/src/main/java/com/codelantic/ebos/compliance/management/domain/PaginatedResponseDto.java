package com.codelantic.ebos.compliance.management.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedResponseDto<T> {
    private long totalItems;
    private List<T> data;
    private int totalPages;
    private int currentPage;

}