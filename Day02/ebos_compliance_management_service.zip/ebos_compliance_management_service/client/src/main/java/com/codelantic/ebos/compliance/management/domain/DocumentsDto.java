package com.codelantic.ebos.compliance.management.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentsDto {
    private String id;
    private String imageName;
    private String viewImagePath;
    private String downloadImagePath;
    private String trainingReadingId;
    private String licenseAndPermitReadingId;
    private String wasteManagementReadingId;
    private String incidentReadingId;
    private String visitorReadingId;
    private String complaintReadingId;
}
