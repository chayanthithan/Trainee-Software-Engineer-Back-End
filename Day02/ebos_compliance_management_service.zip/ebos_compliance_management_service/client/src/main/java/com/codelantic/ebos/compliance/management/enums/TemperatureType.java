package com.codelantic.ebos.compliance.management.enums;

import com.codelantic.ebos.compliance.management.exception.ServiceException;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public enum TemperatureType {
    COOL("Cool"),
    FROZEN("Frozen"),
    AMBIENT("Ambient"),
    WARM("Warm"),
    HOT("Hot");

    private final String mappedValue;

    TemperatureType(String mappedValue) {
        this.mappedValue = mappedValue;
    }

    public static TemperatureType fromMappedValue(String mappedValue) {
        if (mappedValue == null || mappedValue.isBlank()) {
            return null;
        }
        for (TemperatureType temperatureType : TemperatureType.values()) {
            if (temperatureType.mappedValue.equalsIgnoreCase(mappedValue)) {
                return temperatureType;
            }
        }
        throw new ServiceException("Unsupported type: " + mappedValue, "Bad request", HttpStatus.BAD_REQUEST);
    }

    public String getMappedValue() {
        return mappedValue;
    }

    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        for (TemperatureType temperatureType : TemperatureType.values()) {
            list.add(temperatureType.mappedValue);
        }
        return list;
    }

}
