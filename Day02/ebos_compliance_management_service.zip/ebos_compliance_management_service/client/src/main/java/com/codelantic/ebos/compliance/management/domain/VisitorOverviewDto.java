package com.codelantic.ebos.compliance.management.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

@Data
@Builder
@RequiredArgsConstructor
@AllArgsConstructor
public class VisitorOverviewDto {
    private String rowNo;
    private String id;
    private String subCategoryName;
    private LocalDate date;
    private LocalTime time;
    private String employeeName;
    private String fullName;
    private String visitorType;
    private String description;
    private String comments;
    private String complianceStatus;
    List<String> notifyTo;
    private Set<ImageDescriptionDto> images;
    private Set<AudioDescriptionDto> audios;
}
